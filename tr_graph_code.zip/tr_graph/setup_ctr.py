#!/usr/bin/env python3
"""
CTR Setup Script

Run this once after cloning the repository:
    python setup_ctr.py

It installs dependencies and pre-downloads the sentence embedding model
so that the first task runs without any network delay.
"""

import subprocess
import sys
import os
import warnings


def main():
    print("=" * 60)
    print("CTR SYSTEM SETUP")
    print("=" * 60)
    print(f"  Python: {sys.executable}")
    print(f"  Version: {sys.version.split()[0]}")
    print("  (Ensure this is the same Python used by 'ctr web')")

    # Step 1: Install the package + all dependencies from pyproject.toml
    # (pyproject.toml is the single source of truth for dependencies).
    print("\n[1/3] Installing TR-Graph package and dependencies...")
    print("-" * 40)
    subprocess.check_call([
        sys.executable, "-m", "pip", "install", "-e", "."
    ])
    print("-" * 40)
    print("[1/3] Dependencies installed.\n")

    # Step 2: Pre-download the sentence embedding model
    print("[2/3] Downloading sentence embedding model...")
    print("      Model: all-MiniLM-L6-v2 (22MB)")
    print("      Source: huggingface.co/sentence-transformers")
    print("-" * 40)
    try:
        # Suppress harmless HuggingFace warnings
        os.environ['TOKENIZERS_PARALLELISM'] = 'false'
        os.environ['HF_HUB_DISABLE_SYMLINKS_WARNING'] = '1'
        os.environ['TRANSFORMERS_VERBOSITY'] = 'error'
        os.environ['SAFETENSORS_FAST_GPU'] = '0'
        warnings.filterwarnings('ignore')

        import logging
        logging.getLogger('sentence_transformers').setLevel(logging.ERROR)
        logging.getLogger('transformers').setLevel(logging.ERROR)
        logging.getLogger('transformers.modeling_utils').setLevel(logging.ERROR)
        logging.getLogger('huggingface_hub').setLevel(logging.ERROR)
        logging.getLogger('safetensors').setLevel(logging.ERROR)

        # Redirect stderr temporarily to suppress native C-level warnings
        import io
        import contextlib
        from sentence_transformers import SentenceTransformer
        with contextlib.redirect_stderr(io.StringIO()):
            model = SentenceTransformer('all-MiniLM-L6-v2')
        dim = model.get_sentence_embedding_dimension()
        print(f"      Model downloaded and cached.")
        print(f"      Embedding dimension: {dim}")

        # Quick sanity check
        emb = model.encode(["test sentence"])
        print(f"      Encoding verified: shape={emb.shape}")
    except Exception as e:
        print(f"      Warning: Model download failed: {e}")
        print(f"      The system will fall back to word overlap for goal similarity.")
        print(f"      This is non-critical — the system works without it.")
    print("-" * 40)
    print("[2/3] Embedding model ready.\n")

    # Step 3: Verify key imports
    print("[3/3] Verifying system components...")
    print("-" * 40)
    modules = {
        'ctr.pipeline': 'CTR Pipeline',
        'ctr.affinity': 'Affinity Scoring',
        'ctr.safety_evaluation': 'Safety Evaluation',
        'ctr.guided_generator': 'Repair Generator',
        'ctr.plan_linter': 'Plan Linter',
        'ctr.bandit': 'Operator Bandit',
        'ctr.cost': 'Cost Computation',
        'ctr.interface.app': 'Web Interface',
    }
    all_ok = True
    for module, name in modules.items():
        try:
            __import__(module)
            print(f"      {name:<25} OK")
        except Exception as e:
            print(f"      {name:<25} FAILED: {e}")
            all_ok = False

    print("-" * 40)
    if all_ok:
        print("[3/3] All components verified.\n")
    else:
        print("[3/3] Some components failed. Check errors above.\n")

    print("=" * 60)
    print("Setup complete!")
    print()
    print("  Start the system:    ctr web")
    print("  Run benchmarks:      python -m ctr.benchmarks.run_safeagentbench --num-tasks 100 --model gpt-4o")
    print("=" * 60)


if __name__ == "__main__":
    main()
