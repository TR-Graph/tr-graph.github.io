# TR-Graph: Task Command Repair for Safe LLM-Controlled Robot Systems

TR-Graph is a graph-structured framework for repairing defective robot task commands. When a user issues a command that could cause physical harm ("Hand the knife to the toddler"), TR-Graph detects the hazard, diagnoses the causal structure, generates safe alternatives, and selects the repair that best preserves the user's original intent.

The system operates over a structured task specification τ = ⟨a, O, L, r, P, C, M, H⟩ and uses a task repair graph to condition every downstream decision, ranging from cost weighting to affinity scoring to operator allocation.

## Quick Start

```bash
# 1. Clone and install
cd tr_graph
pip install -e .

# 2. Pre-download the embedding model (one-time, ~22MB)
python setup_ctr.py

# 3. Set your API key
cp .env.example .env
# Edit .env and add your API key (OpenAI, Google, or Anthropic)

# 4. Start the web interface
tr-graph web
```

The interface opens at `http://localhost:5000`. Type a command, select a scene context, and the system evaluates it for safety, diagnoses any hazards, generates repair candidates, and presents the best alternative with an explanation.

## API Keys

TR-Graph requires an LLM API key. You only need one provider. Copy `.env.example` to `.env` and fill in the key for your preferred provider:

```bash
cp .env.example .env
```

Then edit `.env`:

```
# OpenAI (GPT-4o, GPT-4 Turbo)
OPENAI_API_KEY=your-key-here

# Google (Gemini 2.5 Pro, Gemini 2.5 Flash)
GOOGLE_API_KEY=your-key-here

# Anthropic (Claude)
ANTHROPIC_API_KEY=your-key-here
```

Alternatively, export the key directly:

```bash
export OPENAI_API_KEY=your-key-here
```

## Installation

Requires Python 3.9+.

```bash
# Core installation (includes all required dependencies)
pip install -e .

# Optional dependency groups
pip install -e ".[dev]"        # Development tools (pytest, black, mypy)
pip install -e ".[ai2thor]"    # AI2-THOR simulation for benchmark execution
pip install -e ".[perception]" # Real-time perception (torch, ultralytics)
pip install -e ".[all]"        # Everything
```

After installation, run the setup script to pre-download the sentence embedding model used for goal similarity scoring and grounding validation:

```bash
python setup_ctr.py
```

This downloads `all-MiniLM-L6-v2` (~22MB) so the first task runs without network delay.


## Running the System

### Web Interface

```bash
# Default: opens browser at localhost:5000
tr-graph web

# Custom port, no auto-browser
tr-graph web --port 8080 --no-browser

# Debug mode (auto-reload on code changes)
tr-graph web --debug
```

The interface provides:
- Method toggle between TR-Graph, LLM-CoT, SafePlan, and SELP-lite baselines
- Model selection across providers
- AI2-THOR execution and visualization
- AI2-THOR Scene configuration with floor plan selection and object lists
- Stage-by-stage pipeline visualization (decomposition → diagnosis → repair → validation)
- Repair comparison showing original vs. repaired task with scoring breakdown
- Multi-option display showing alternative repair candidates with affinity, cost, and final scores


### Python API

```python
from ctr.llm_client import create_client
from ctr.pipeline import CTRPipeline, CTRConfig

# Create LLM client
client = create_client(provider="openai", model="gpt-4o")

# Create pipeline
config = CTRConfig()
pipeline = CTRPipeline(client, config)

# Process a command
result = pipeline.process("Hand the knife to the toddler")

# Check result
if result.repair_performed:
    print(f"Original: {result.original_command}")
    print(f"Repaired: {result.repaired_command}")
    print(f"Explanation: {result.explanation}")
    print(f"Score: {result.final_score:.3f}")
else:
    print("Command is safe — no repair needed")
```

## Running Benchmarks

### SafeAgentBench

SafeAgentBench evaluates safety detection and repair across 750 AI2-THOR tasks in four splits: safe_detailed (300), unsafe_detailed (300), abstract (100), and long_horizon (50).

```bash

# Full run on all splits
python -m ctr.benchmarks.run_safeagentbench --model gpt-4o

# Specific split
python -m ctr.benchmarks.run_safeagentbench --split unsafe_detailed --num-tasks 50

# Use Gemini
python -m ctr.benchmarks.run_safeagentbench --model gemini-2.5-flash

# Parallel workers (faster, uses more API quota)
python -m ctr.benchmarks.run_safeagentbench --model gpt-4o --workers 5
```

Results are saved to `results/safeagentbench/` with per-task outcomes, aggregate metrics (Part A: detection rates, Part B: repair quality), and timing data.

### EAR-Bench

EAR-Bench evaluates physical risk awareness across diverse environments (home, workplace, outdoor).

```bash
# Quick test
python -m ctr.benchmarks.run_earbench --model gpt-4o

# Full run
python -m ctr.benchmarks.run_earbench --model gpt-4o --workers 3

# Specific environment
python -m ctr.benchmarks.run_earbench --environment home 

# With independent cross-model validation
python -m ctr.benchmarks.run_earbench --model gpt-4o --independent-model gemini-2.5-flash
```

### Ablation Study

The ablation runner evaluates five variants, each disabling one component to measure its contribution:

| Variant | What's disabled |
|---------|----------------|
| `full` | Nothing (control) |
| `no-graph` | Causal graph derivation |
| `no-bandit` | Learned operator prioritization |
| `no-consistency` | Graph consistency gating |
| `no-operator-val` | Operator precondition validation |

```bash
# Run all variants (3 seeds each)
python -m ctr.benchmarks.run_safeagentbench --ablation all

# Custom seeds
python -m ctr.benchmarks.run_safeagentbench --ablation all --seeds 42 123 456 789
```

### Baselines

Three baselines are included for comparison:

```bash
# Run baselines on SafeAgentBench
python -m ctr.benchmarks.run_safeagentbench --baselines --model gpt-4o

# Run baselines on EAR-Bench
python -m ctr.benchmarks.run_earbench --baselines--model gpt-4o
```

The baselines are: (1) LLM-CoT — single-pass chain-of-thought safety reasoning, (2) SELP-Lite — safety evaluation with LLM planning, (3) SafePlan+Repair — three-layer safety evaluation with direct LLM repair (no graph, no operators, no structured scoring).

## System Architecture

The pipeline has four stages, with all scoring and validation deterministic after Stage 2:

```
Stage 1: Task Understanding
  Command → parse → τ = ⟨a, O, L, r, P, C, M, H⟩
  Scene → build scene graph G_S = (V_S, E_S)
  References → ground: Γ: τ → V_S ∪ {⊥}

Stage 2: Safety Evaluation + Diagnosis
  τ + G_S → three-layer alignment matrix (societal, organizational, individual)
  If FORBIDDEN → extract causal variables, build repair graph G_τ
  Compute λ from safety severity

Stage 3: Repair Generation + Validation
  G_τ → operator allocation via LinUCB bandit
  Generate n candidates (diagnosis-guided)
  Validate each: safety re-eval → consistency gate → operator check → score
  Score: F(τ,τ'|G_τ) = A - λC - γΠ_cons
  Select: τ* = argmax F

Stage 4: Output
  Selected repair → action sequence + explanation
  Full structured trace → artifact package
```

Deterministic components (same inputs → same outputs, zero variance): cost weights from graph, affinity scoring (6 dimensions), operator classification, operator validation, consistency gating, final score formula. LLM-dependent components (inherently variable): task parsing, safety evaluation, candidate generation.

## Project Structure

```
tr_graph/
├── ctr/
│   ├── pipeline.py                  # Core 4-stage pipeline
│   ├── data_structures.py           # Task spec, scene graph, repair types
│   ├── safety_evaluation.py         # Three-layer alignment matrix
│   ├── affinity.py                  # 6-dimension deterministic affinity scoring
│   ├── cost.py                      # Graph-conditioned cost computation
│   ├── operators.py                 # 6 repair operators (classify + validate)
│   ├── bandit.py                    # LinUCB operator allocation
│   ├── ablation.py                  # AblationConfig dataclass
│   ├── guided_generator.py          # Diagnosis-guided candidate generation
│   ├── plan_linter.py               # Action sequence validation
│   ├── scene_graph_builder.py       # Scene graph construction + enrichment
│   ├── scene_domain_adapter.py      # SceneDomainAdapter protocol
│   ├── scene_adapters.py            # AI2-THOR, VLM, generic, tabletop adapters
│   ├── trace_recorder.py            # Structured trace recording
│   ├── llm_client.py                # Multi-provider LLM client
│   ├── vlm_prompts.py               # VLM interface + prompt formatting
│   ├── baseline.py                  # Baseline LLM repair (for comparison)
│   │   ├── cli.py                       # Command-line interface
│   │
│   ├── prompts/                     # Structured prompt templates
│   │   ├── combined_safety_prompt.md        # Three-layer safety evaluation
│   │   ├── task_parsing_v3.md               # Ontological task parsing
│   │   ├── generation_prompt_v2.md          # Diagnosis-guided generation
│   │   ├── fidelity_evaluation_rubric.md    # 5-level fidelity rubric
│   │   ├── defect_feasibility_evaluation.md # Defect + feasibility judgment
│   │   ├── repair_safety_verification.md    # Repair safety re-check
│   │   ├── task_router.md                   # Atomic vs compound routing
│   │   ├── grounding_disambiguation.md      # Reference resolution fallback
│   │   ├── enriched_prompts.md              # Scene, frame, grounding prompts
│   │   ├── enriched_prompts.py              # Prompt loader + utilities
│   │   └── generation_prompts.py            # Generation format utilities
│   │
│   ├── benchmarks/                  # Benchmark evaluation
│   │   ├── run_safeagentbench.py            # SafeAgentBench CLI
│   │   ├── run_earbench.py                  # EAR-Bench CLI
│   │   ├── safeagentbench_adapter.py        # SafeAgentBench pipeline adapter
│   │   ├── safeagentbench_loader.py         # Dataset loader (750 tasks)
│   │   ├── earbench_adapter.py              # EAR-Bench pipeline adapter
│   │   ├── earbench_loader.py               # Dataset loader
│   │   ├── ablation_runner.py               # 5-variant ablation experiments
│   │   ├── baseline_runners.py              # 3 baseline implementations
│   │   ├── independent_safety.py            # Cross-model safety validation
│   │   ├── metrics.py                       # Part A + Part B metrics
│   │   ├── execution_harness.py             # AI2-THOR execution
│   │   └── scene_cache.py                   # Scene object caching
│   │
│   ├── simulation/                  # AI2-THOR simulation
│   │   ├── ai2thor_actions.py               # Action executor (navigation, manipulation)
│   │   ├── execution_adapter.py             # CanonicalAction IR + dialect parsers
│   │   ├── task_executor.py                 # Task orchestration
│   │   ├── code_generator.py                # Action sequence generation
│   │   └── video_recorder.py                # Execution video capture
│   │
│   ├── interface/                   # Web interface
│   │   ├── app.py                           # Flask application
│   │   ├── export.py                        # Trace artifact export
│   │   └── templates/index.html             # Single-page UI
│   │
│   └── utils/
│       └── trace_serialization.py           # Trace JSON serialization
│
├── data/
│   └── benchmarks/
│       ├── safeagentbench/                  # 4 splits (750 tasks)
│       └── earbench/                        # Physical risk dataset
│
├── .env.example                     # API key template
├── pyproject.toml                   # Package configuration
├── setup_ctr.py                     # One-time setup (embedding model)
└── README.md
```

## Configuration

The pipeline is configured via `CTRConfig`. Key parameters:

```python
from ctr.pipeline import CTRConfig

config = CTRConfig()

# Scoring
config.lambda_min = 0.1       # Min cost penalty (high severity → low lambda)
config.lambda_max = 0.9       # Max cost penalty (low severity → high lambda)
config.consistency_penalty = 0.1  # γ: soft inconsistency penalty

# Generation
config.n_candidates = 5       # Candidates to generate per task
config.max_generation_retries = 2

# Bandit
config.bandit_top_k = 3       # Top-k operators to allocate
config.bandit_alpha_ucb = 1.0  # UCB exploration rate

# Validation gates
config.enable_graph = True
config.enable_bandit = True
config.enable_consistency_gating = True
config.enable_operator_validation_gating = True
```

## Supported LLM Providers

| Provider | Models | API Key Variable |
|----------|--------|-----------------|
| OpenAI | gpt-4o, gpt-4-turbo, gpt-4o-mini | `OPENAI_API_KEY` |
| Google | gemini-2.5-pro, gemini-2.5-flash | `GOOGLE_API_KEY` |
| Anthropic | claude-sonnet-4-20250514 | `ANTHROPIC_API_KEY` |

## License

MIT
