"""Tests for graph data structure and algorithms."""

import pytest
from ctr.data_structures import CausalEdge, CausalGraph


def make_sample_graph():
    """Build a sample causal graph for testing."""
    g = CausalGraph()
    # Nodes: object.temperature, object.type, recipient.age, safety.burn_risk,
    #        safety.child_protection, goal
    g.add_edge("object.temperature", "safety.burn_risk", "hot causes burn risk")
    g.add_edge("recipient.age", "safety.child_protection", "child age triggers protection")
    g.add_edge("safety.burn_risk", "goal", "burn risk blocks goal")
    g.add_edge("safety.child_protection", "goal", "child protection blocks goal")
    g.add_edge("object.type", "object.temperature", "object type determines temperature")
    return g


class TestCausalGraphBasics:
    def test_add_nodes_and_edges(self):
        g = CausalGraph()
        g.add_node("a")
        g.add_node("b")
        g.add_edge("a", "b", "causes")
        assert "a" in g.nodes
        assert "b" in g.nodes
        assert len(g.edges) == 1

    def test_shortest_path(self):
        g = make_sample_graph()
        assert g.shortest_path("object.temperature", "goal") == 2
        assert g.shortest_path("safety.burn_risk", "goal") == 1
        assert g.shortest_path("object.type", "goal") == 3
        assert g.shortest_path("goal", "object.temperature") == float('inf')

    def test_shortest_path_same_node(self):
        g = make_sample_graph()
        assert g.shortest_path("goal", "goal") == 0

    def test_shortest_path_no_path(self):
        g = CausalGraph()
        g.add_node("a")
        g.add_node("b")
        assert g.shortest_path("a", "b") == float('inf')


class TestImportanceWeights:
    def test_importance_sums_to_one(self):
        g = make_sample_graph()
        importance = g.compute_importance("goal")
        assert abs(sum(importance.values()) - 1.0) < 1e-6

    def test_goal_has_highest_importance(self):
        g = make_sample_graph()
        importance = g.compute_importance("goal")
        # Goal node is distance 0 from itself, so importance = 1/(1+0) = 1.0
        assert importance["goal"] >= importance["safety.burn_risk"]
        assert importance["safety.burn_risk"] >= importance["object.temperature"]

    def test_unreachable_gets_default(self):
        g = CausalGraph()
        g.add_node("a")
        g.add_node("b")
        g.add_node("goal")
        g.add_edge("a", "goal")
        importance = g.compute_importance("goal")
        # "b" has no path to goal, gets default weight 0.1
        assert importance["b"] < importance["a"]


class TestPathDisruption:
    def test_no_disruption(self):
        g = make_sample_graph()
        disruption = g.compute_path_disruption("goal", set())
        assert disruption == 0.0

    def test_full_disruption(self):
        g = make_sample_graph()
        # Changing goal disrupts all paths (they all end at goal)
        disruption = g.compute_path_disruption("goal", {"goal"})
        # All paths to goal contain goal, but it's the target, not an intermediate
        # Actually paths TO goal won't contain goal in intermediate nodes
        # Let's test with an intermediate node
        disruption = g.compute_path_disruption("goal", {"safety.burn_risk", "safety.child_protection"})
        assert disruption > 0.0


class TestDensity:
    def test_density(self):
        g = make_sample_graph()
        d = g.density()
        n = len(g.nodes)
        assert d == len(g.edges) / (n * (n - 1))

    def test_empty_graph_density(self):
        g = CausalGraph()
        assert g.density() == 0.0


class TestConsistency:
    def test_consistent_change(self):
        g = CausalGraph()
        g.add_edge("object", "sharpness", "object determines sharpness")
        original = {"object": "butter knife", "sharpness": "dull"}
        repaired = {"object": "spoon", "sharpness": "dull"}
        # Both changed or new parent compatible with old child
        inconsistencies = g.check_consistency(original, repaired)
        assert len(inconsistencies) == 0

    def test_inconsistent_change(self):
        g = CausalGraph()
        g.add_edge("object", "object.sharpness", "object determines sharpness")
        original = {"object": "knife", "object.sharpness": "sharp"}
        repaired = {"object": "sippy cup", "object.sharpness": "sharp"}
        inconsistencies = g.check_consistency(original, repaired)
        assert len(inconsistencies) > 0


class TestCostWeightsPrefixMatching:
    """Test that CostWeights.from_graph uses prefix matching for dynamic node names."""

    def test_prefix_matching_produces_differentiated_weights(self):
        from ctr.cost import CostWeights

        g = CausalGraph()
        g.add_node('hazard.mechanical', node_type='violation_sink')
        g.add_node('action.place', node_type='task_variable')
        g.add_node('violation.physical_safety', node_type='violation_sink')
        g.add_node('resource.cup_red', node_type='task_variable')
        g.add_node('hazard.tipping', node_type='violation_sink')
        g.add_edge('resource.cup_red', 'hazard.tipping', 'causes instability')
        g.add_edge('action.place', 'hazard.tipping', 'triggers tipping')

        weights = CostWeights.from_graph(g)

        assert weights.cost_available is True
        # Causal variables should get high weight
        assert weights.action > 0.15, f"action should be high, got {weights.action}"
        assert weights.object > 0.15, f"object should be high, got {weights.object}"
        # Non-causal variables should get floor weight
        assert weights.goal < 0.10, f"goal should be floor, got {weights.goal}"
        assert weights.manner < 0.10, f"manner should be floor, got {weights.manner}"
        assert weights.preference < 0.10, f"preference should be floor, got {weights.preference}"

    def test_resource_maps_to_object(self):
        from ctr.cost import CostWeights

        g = CausalGraph()
        g.add_node('resource.knife', node_type='task_variable')
        g.add_node('hazard.cut', node_type='violation_sink')
        g.add_edge('resource.knife', 'hazard.cut', 'sharp object causes cut')

        weights = CostWeights.from_graph(g)
        assert weights.object > weights.goal, "resource prefix should map to object type"

    def test_empty_graph_cost_unavailable(self):
        from ctr.cost import CostWeights

        weights = CostWeights.from_graph(None)
        assert weights.cost_available is False

    def test_no_sinks_no_goal_cost_unavailable(self):
        from ctr.cost import CostWeights

        g = CausalGraph()
        g.add_node('action.place', node_type='task_variable')
        g.add_node('object.cup', node_type='task_variable')

        weights = CostWeights.from_graph(g)
        assert weights.cost_available is False


class TestSerialization:
    def test_to_dict_and_back(self):
        g = make_sample_graph()
        d = g.to_dict()
        g2 = CausalGraph.from_dict(d)
        assert g.nodes == g2.nodes
        assert len(g.edges) == len(g2.edges)
