"""Tests for OperatorBandit (LinUCB contextual bandit)."""

import os
import tempfile
import numpy as np
import pytest
from ctr.bandit import OperatorBandit, CONTEXT_DIM, OPERATOR_NAMES

# CONTEXT_DIM is 22: 9 base + 5 defect type + 8 frame type


class TestBanditBasics:
    def test_initialization(self):
        bandit = OperatorBandit()
        assert bandit.n_operators == 6
        assert bandit.context_dim == CONTEXT_DIM
        assert len(bandit.A) == 6
        assert len(bandit.b) == 6

    def test_select_returns_valid_probabilities(self):
        bandit = OperatorBandit()
        context = np.ones(CONTEXT_DIM)
        probs = bandit.select(context)
        assert len(probs) == 6
        assert abs(probs.sum() - 1.0) < 1e-6
        assert all(p >= 0 for p in probs)

    def test_allocate_sums_to_n(self):
        bandit = OperatorBandit()
        probs = np.array([0.4, 0.2, 0.15, 0.1, 0.1, 0.05])
        for n in [3, 5, 7, 10]:
            alloc = bandit.allocate(probs, n)
            assert sum(alloc) == n
            assert all(a >= 0 for a in alloc)

    def test_uniform_initial_distribution(self):
        bandit = OperatorBandit()
        context = np.ones(CONTEXT_DIM)
        probs = bandit.select(context)
        # With no training data, exploration dominates -> roughly uniform
        assert max(probs) - min(probs) < 0.5  # Not too skewed


class TestBanditLearning:
    def test_update_shifts_theta(self):
        bandit = OperatorBandit()
        context = np.random.randn(CONTEXT_DIM)
        theta_before = bandit.theta[0].copy()
        bandit.update(context, [0], reward=1.0)
        assert not np.allclose(bandit.theta[0], theta_before)

    def test_positive_reward_increases_preference(self):
        bandit = OperatorBandit()
        context = np.random.randn(CONTEXT_DIM)
        context = context / np.linalg.norm(context)  # Normalize

        # Get initial UCB for operator 0
        probs_before = bandit.select(context)

        # Give high reward to operator 0 several times
        for _ in range(10):
            bandit.update(context, [0], reward=1.0)

        probs_after = bandit.select(context)
        # Operator 0 should have higher priority after positive rewards
        assert probs_after[0] > probs_before[0] or probs_after[0] > 0.2


class TestBanditReward:
    def test_compute_reward(self):
        bandit = OperatorBandit()
        reward = bandit.compute_reward(
            n_total=5, n_safe=4, n_valid=3, best_rubric_level=4
        )
        assert 0.0 <= reward <= 1.0

    def test_perfect_reward(self):
        bandit = OperatorBandit()
        reward = bandit.compute_reward(
            n_total=5, n_safe=5, n_valid=5, best_rubric_level=5
        )
        assert reward == 1.0

    def test_zero_reward(self):
        bandit = OperatorBandit()
        reward = bandit.compute_reward(
            n_total=5, n_safe=0, n_valid=0, best_rubric_level=1
        )
        assert reward == 0.0


class TestBanditPersistence:
    def test_save_load_roundtrip(self):
        bandit = OperatorBandit()
        context = np.random.randn(CONTEXT_DIM)
        bandit.update(context, [0, 2], reward=0.8)

        with tempfile.NamedTemporaryFile(suffix='.json', delete=False, mode='w') as f:
            path = f.name

        try:
            bandit.save(path)

            bandit2 = OperatorBandit()
            bandit2.load(path)

            assert np.allclose(bandit.A[0], bandit2.A[0])
            assert np.allclose(bandit.b[0], bandit2.b[0])
            assert np.allclose(bandit.theta[0], bandit2.theta[0])
        finally:
            os.unlink(path)


class TestBanditContext:
    def test_compute_context_with_graph(self):
        from ctr.data_structures import CausalGraph, CausalEdge, Diagnosis, Violation
        g = CausalGraph()
        g.add_edge("object", "safety.burn_risk")
        g.add_edge("recipient", "safety.child_protection")

        diagnosis = Diagnosis(
            violations=[Violation(layer="societal", rule="test", severity=0.9, explanation="test")],
            causal_variables=["object", "recipient"],
            causal_edges=[CausalEdge("object", "safety.burn_risk")],
            max_hazard=0.9
        )

        bandit = OperatorBandit()
        context = bandit.compute_context(g, diagnosis)
        assert len(context) == CONTEXT_DIM
        # 11D: Context features are now normalized (counts / max)
        assert abs(context[0] - 0.2) < 0.01  # 2 causal vars / 10 = 0.2
        assert abs(context[1] - 1/15) < 0.01  # 1 causal edge / 15 ≈ 0.067
        assert abs(context[2] - 0.9) < 0.01  # max hazard (already 0-1)

    def test_compute_context_without_graph(self):
        from ctr.data_structures import Diagnosis
        diagnosis = Diagnosis(causal_variables=["object"], max_hazard=0.5)
        bandit = OperatorBandit()
        context = bandit.compute_context(None, diagnosis)
        assert len(context) == CONTEXT_DIM
