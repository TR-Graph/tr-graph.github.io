"""
Integration tests for diagnosis-guided generation.

These tests use a mock LLM to test the full flow without API calls.
"""

import pytest
import sys
import json
sys.path.insert(0, '.')

from ctr.data_structures import (
    SceneGraph, SceneNode, NodeType,
    ObjectProperties, PersonProperties, RegionProperties,
    HazardLevel, AgeGroup, Sharpness,
    TaskVariables, ObjectReference
)
from ctr.safety_evaluation import SafePlanEvaluator, extract_diagnosis
from ctr.guided_generator import GuidedGenerator, GenerationConfig
from ctr.operators import classify_operators, validate_operator


class MockLLMClient:
    """Mock LLM client for testing."""

    def __init__(self, responses=None):
        self.responses = responses or {}
        self.call_count = 0
        self.last_prompt = None

    def generate(self, system_prompt: str, user_prompt: str) -> str:
        self.call_count += 1
        self.last_prompt = user_prompt

        # Safety evaluation
        if "SOCIETAL LAYER" in user_prompt or "Evaluate" in system_prompt:
            return json.dumps({
                "societal": {
                    "decision": "FORBIDDEN",
                    "triggered_conditions": ["sharp_object_to_child"],
                    "values_considered": ["child_safety"],
                    "explanation": "Sharp objects dangerous for children under 8",
                    "causal_variables": ["object"],
                    "causal_values": {"object": "knife"}
                },
                "organizational": {
                    "decision": "PERMISSIBLE",
                    "triggered_conditions": [],
                    "values_considered": [],
                    "explanation": "",
                    "causal_variables": [],
                    "causal_values": {}
                },
                "individual": {
                    "decision": "FORBIDDEN",
                    "triggered_conditions": ["age_inappropriate"],
                    "values_considered": ["safety"],
                    "explanation": "Tommy (age 5) cannot safely handle sharp objects",
                    "causal_variables": ["recipient"],
                    "causal_values": {"recipient": "Tommy"}
                },
                "reasoning_summary": "Unsafe task"
            })

        # Repair generation - STRUCTURED FORMAT
        if "Generate safe repair candidates" in user_prompt:
            return json.dumps({
                "candidates": [
                    {
                        "goal": "Place the butter knife on the low table for Tommy to pick up",
                        "action": "place",
                        "objects": [
                            {"reference": "butter knife", "role": "instrument"},
                            {"reference": "low table", "role": "target"}
                        ],
                        "recipient": {"reference": "Tommy"},
                        "manner": "for safe retrieval",
                        "changes_made": ["Substituted sharp knife with butter knife", "Changed handoff to placement"],
                        "safety_addressed": ["Sharp object hazard", "Direct contact risk"],
                        "reasoning": "Butter knife is child-safe and placement reduces risk",
                        "confidence": 0.9
                    },
                    {
                        "goal": "Hand Tommy a plastic knife suitable for children",
                        "action": "hand",
                        "objects": [
                            {"reference": "plastic knife", "role": "instrument"}
                        ],
                        "recipient": {"reference": "Tommy"},
                        "manner": None,
                        "changes_made": ["Substituted with plastic knife"],
                        "safety_addressed": ["Sharp object hazard"],
                        "reasoning": "Plastic knife has no sharp edges",
                        "confidence": 0.85
                    }
                ]
            })

        # Default
        return json.dumps({"status": "ok"})


def create_test_scene():
    """Create standard test scene."""
    scene = SceneGraph()

    scene.nodes['person_01'] = SceneNode(
        id='person_01',
        type=NodeType.PERSON,
        label='Tommy',
        properties=PersonProperties(name='Tommy', age=5, age_group=AgeGroup.CHILD)
    )

    scene.nodes['knife_01'] = SceneNode(
        id='knife_01',
        type=NodeType.OBJECT,
        label='kitchen knife',
        properties=ObjectProperties(sharpness=Sharpness.SHARP, hazard_level=HazardLevel.HIGH, child_safe=False)
    )

    scene.nodes['knife_02'] = SceneNode(
        id='knife_02',
        type=NodeType.OBJECT,
        label='butter knife',
        properties=ObjectProperties(sharpness=Sharpness.DULL, hazard_level=HazardLevel.LOW, child_safe=True)
    )

    scene.nodes['table_01'] = SceneNode(
        id='table_01',
        type=NodeType.OBJECT,
        label='low table',
        properties=ObjectProperties(hazard_level=HazardLevel.NONE, child_safe=True)
    )

    return scene


def create_test_task():
    """Create standard test task."""
    return TaskVariables(
        goal="hand the kitchen knife to Tommy",
        action="hand",
        original_utterance="Hand the sharp knife to Tommy",
        objects=[ObjectReference(reference_text="kitchen knife", grounded_id="knife_01", role="instrument")],
        recipient=ObjectReference(reference_text="Tommy", grounded_id="person_01")
    )


class TestSafetyEvaluationIntegration:
    """Integration tests for safety evaluation."""

    def test_unsafe_task_detection(self):
        llm = MockLLMClient()
        evaluator = SafePlanEvaluator(llm)
        task = create_test_task()
        scene = create_test_scene()

        result = evaluator.evaluate(task, scene)

        assert not result.is_safe
        assert result.societal.decision.value == "FORBIDDEN"
        assert result.individual.decision.value == "FORBIDDEN"

    def test_diagnosis_extraction(self):
        llm = MockLLMClient()
        evaluator = SafePlanEvaluator(llm)
        task = create_test_task()
        scene = create_test_scene()

        result = evaluator.evaluate(task, scene)
        diagnosis = extract_diagnosis(result)

        assert len(diagnosis.violations) >= 2
        assert diagnosis.max_hazard > 0
        assert len(diagnosis.explanations) > 0


class TestGuidedGenerationIntegration:
    """Integration tests for guided generation."""

    def test_candidate_generation(self):
        llm = MockLLMClient()
        evaluator = SafePlanEvaluator(llm)
        task = create_test_task()
        scene = create_test_scene()

        # Get diagnosis
        result = evaluator.evaluate(task, scene)
        diagnosis = extract_diagnosis(result)

        # Generate repairs
        config = GenerationConfig(n_candidates=2)
        generator = GuidedGenerator(llm, config)
        candidates = generator.generate(
            original_task=task.original_utterance,
            diagnosis=diagnosis,
            scene_graph=scene
        )

        assert len(candidates) == 2
        assert all(c.repaired_task.goal for c in candidates)
        assert all(c.confidence > 0 for c in candidates)

    def test_operator_classification(self):
        llm = MockLLMClient()
        evaluator = SafePlanEvaluator(llm)
        task = create_test_task()
        scene = create_test_scene()

        # Get diagnosis and generate
        result = evaluator.evaluate(task, scene)
        diagnosis = extract_diagnosis(result)

        generator = GuidedGenerator(llm)
        candidates = generator.generate(
            original_task=task.original_utterance,
            diagnosis=diagnosis,
            scene_graph=scene
        )

        # Classify operators
        for candidate in candidates:
            classifications = classify_operators(
                original=task,
                repaired=candidate.repaired_task,
                scene_graph=scene
            )

            # Each candidate should have at least some operator classified
            # (may be empty if detection doesn't find specific patterns)
            for cls in classifications:
                # Validate
                validation = validate_operator(cls, task, candidate.repaired_task, scene)
                assert validation.operator_type == cls.operator_type


class TestEndToEndFlow:
    """End-to-end integration tests."""

    def test_full_flow_knife_to_child(self):
        """Test the complete flow for knife-to-child scenario."""
        llm = MockLLMClient()
        task = create_test_task()
        scene = create_test_scene()

        # Step 1: Safety evaluation
        evaluator = SafePlanEvaluator(llm)
        safety_result = evaluator.evaluate(task, scene)
        assert not safety_result.is_safe

        # Step 2: Extract diagnosis
        diagnosis = extract_diagnosis(safety_result)
        assert diagnosis.max_hazard > 0
        assert len(diagnosis.violations) > 0

        # Step 3: Generate repairs
        generator = GuidedGenerator(llm)
        candidates = generator.generate(
            original_task=task.original_utterance,
            diagnosis=diagnosis,
            scene_graph=scene
        )
        assert len(candidates) > 0

        # Step 4: Classify and validate operators
        best_candidate = candidates[0]
        classifications = classify_operators(task, best_candidate.repaired_task, scene)

        # Step 5: All operators should be valid (or no operators detected)
        for cls in classifications:
            validation = validate_operator(cls, task, best_candidate.repaired_task, scene)
            # Note: validation may fail for some operators in mock scenario

        # Final check: repaired task should be different from original
        assert best_candidate.repaired_task.goal != task.goal

    def test_multiple_repair_strategies(self):
        """Test that different repair strategies are generated."""
        llm = MockLLMClient()
        task = create_test_task()
        scene = create_test_scene()

        evaluator = SafePlanEvaluator(llm)
        safety_result = evaluator.evaluate(task, scene)
        diagnosis = extract_diagnosis(safety_result)

        config = GenerationConfig(n_candidates=3)
        generator = GuidedGenerator(llm, config)
        candidates = generator.generate(
            original_task=task.original_utterance,
            diagnosis=diagnosis,
            scene_graph=scene
        )

        # Check that candidates are distinct
        goals = [c.repaired_task.goal for c in candidates]
        assert len(set(goals)) == len(goals), "Candidates should be distinct"


class TestEdgeCases:
    """Tests for edge cases."""

    def test_empty_scene(self):
        """Test handling of empty scene."""
        llm = MockLLMClient()
        scene = SceneGraph()  # Empty scene

        task = TaskVariables(
            goal="hand the knife to someone",
            action="hand",
            original_utterance="hand the knife"
        )

        evaluator = SafePlanEvaluator(llm)
        result = evaluator.evaluate(task, scene)

        # Should still produce a result
        assert result is not None

    def test_safe_task(self):
        """Test that safe tasks don't need repair."""
        # Override mock to return safe
        class SafeMockLLM:
            def generate(self, system_prompt, user_prompt):
                return json.dumps({
                    "societal": {"decision": "PERMISSIBLE", "triggered_conditions": [], "values_considered": [], "explanation": "", "causal_variables": [], "causal_values": {}},
                    "organizational": {"decision": "PERMISSIBLE", "triggered_conditions": [], "values_considered": [], "explanation": "", "causal_variables": [], "causal_values": {}},
                    "individual": {"decision": "PERMISSIBLE", "triggered_conditions": [], "values_considered": [], "explanation": "", "causal_variables": [], "causal_values": {}},
                    "reasoning_summary": "Task is safe"
                })

        llm = SafeMockLLM()
        task = TaskVariables(
            goal="place the cup on the table",
            action="place",
            original_utterance="place cup on table"
        )
        scene = create_test_scene()

        evaluator = SafePlanEvaluator(llm)
        result = evaluator.evaluate(task, scene)

        assert result.is_safe
        # Diagnosis for safe task should have no violations
        diagnosis = extract_diagnosis(result)
        assert len(diagnosis.violations) == 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
