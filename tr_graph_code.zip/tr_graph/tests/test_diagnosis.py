"""
Unit tests for diagnosis extraction and related functionality.
"""

import pytest
import sys
sys.path.insert(0, '.')

from ctr.data_structures import (
    Diagnosis, Violation, OperatorClassification, OperatorValidation,
    ValidatedRepair, GroundingOutcome, GroundingResult,
    CausalEdge, CausalGraph,
    OperatorType, AgeGroup,
    TaskFrame, DefectType, HazardType
)
from ctr.safety_evaluation import (
    extract_diagnosis, LayerDecision, LayerEvaluation, AlignmentResult,
    SafePlanInput, FinalDecision, DiagnosisExtractor
)


class TestViolation:
    """Tests for Violation data structure."""

    def test_violation_creation(self):
        v = Violation(
            layer="societal",
            rule="sharp_object_to_child",
            severity=0.9,
            explanation="Sharp objects dangerous for children"
        )
        assert v.layer == "societal"
        assert v.severity == 0.9
        assert "Sharp" in v.explanation


class TestDiagnosis:
    """Tests for Diagnosis data structure."""

    def test_diagnosis_creation(self):
        v = Violation(layer="societal", rule="test", severity=0.8, explanation="Test")
        d = Diagnosis(
            violations=[v],
            causal_variables=["object", "recipient"],
            explanations=["Test explanation"],
            max_hazard=0.8
        )
        assert len(d.violations) == 1
        assert "object" in d.causal_variables
        assert d.max_hazard == 0.8

    def test_get_violation_summary(self):
        v1 = Violation(layer="societal", rule="r1", severity=0.9, explanation="Societal issue")
        v2 = Violation(layer="individual", rule="r2", severity=0.5, explanation="Individual issue")
        d = Diagnosis(violations=[v1, v2], causal_variables=[], explanations=[], max_hazard=0.9)

        summary = d.get_violation_summary()
        assert "SOCIETAL" in summary
        assert "INDIVIDUAL" in summary

    def test_empty_diagnosis(self):
        d = Diagnosis()
        assert d.get_violation_summary() == "No violations detected."
        assert d.get_causal_summary() == "No causal variables identified."


class TestOperatorClassification:
    """Tests for OperatorClassification data structure."""

    def test_classification_creation(self):
        oc = OperatorClassification(
            operator_type=OperatorType.SUBSTITUTE,
            confidence=0.9,
            evidence="Replaced knife with butter knife",
            variables_affected=["object"]
        )
        assert oc.operator_type == OperatorType.SUBSTITUTE
        assert oc.confidence == 0.9
        assert "knife" in oc.evidence


class TestOperatorValidation:
    """Tests for OperatorValidation data structure."""

    def test_validation_creation(self):
        ov = OperatorValidation(
            operator_type=OperatorType.SUBSTITUTE,
            valid=True,
            checks=[("replacement_exists", True), ("hazard_reduced", True)],
            explanation="All checks passed"
        )
        assert ov.valid
        assert len(ov.checks) == 2
        assert ov.get_failed_checks() == []

    def test_failed_checks(self):
        ov = OperatorValidation(
            operator_type=OperatorType.SUBSTITUTE,
            valid=False,
            checks=[("replacement_exists", True), ("hazard_reduced", False)],
            explanation="Hazard not reduced"
        )
        assert not ov.valid
        failed = ov.get_failed_checks()
        assert "hazard_reduced" in failed


class TestValidatedRepair:
    """Tests for ValidatedRepair data structure."""

    def test_validated_repair_creation(self):
        oc = OperatorClassification(
            operator_type=OperatorType.SUBSTITUTE,
            confidence=0.9,
            evidence="test"
        )
        ov = OperatorValidation(
            operator_type=OperatorType.SUBSTITUTE,
            valid=True,
            checks=[("test", True)]
        )
        vr = ValidatedRepair(
            task_text="Place butter knife on table",
            is_safe=True,
            operators_applied=[oc],
            operator_validations=[ov],
            affinity_score=0.85,
            cost_score=0.3,
            final_score=0.55
        )
        assert vr.is_safe
        assert vr.all_operators_valid()
        assert "substitute" in vr.get_operator_summary()

    def test_invalid_operators(self):
        ov = OperatorValidation(
            operator_type=OperatorType.SUBSTITUTE,
            valid=False,
            checks=[("test", False)]
        )
        vr = ValidatedRepair(
            task_text="test",
            is_safe=True,
            operator_validations=[ov]
        )
        assert not vr.all_operators_valid()


class TestGroundingResult:
    """Tests for the three-outcome GroundingResult data structure."""

    def test_resolved_grounding(self):
        gr = GroundingResult(
            reference="Tommy",
            outcome=GroundingOutcome.RESOLVED,
            entity_id="person_01",
            confidence=0.95
        )
        assert gr.outcome == GroundingOutcome.RESOLVED
        assert gr.entity_id == "person_01"
        assert gr.confidence == 0.95

    def test_infeasible_grounding(self):
        gr = GroundingResult(
            reference="the knife",
            outcome=GroundingOutcome.INFEASIBLE,
            available_alternatives=["butter knife", "spoon", "spatula"]
        )
        assert gr.outcome == GroundingOutcome.INFEASIBLE
        assert gr.entity_id is None
        assert "butter knife" in gr.available_alternatives

    def test_clarify_grounding(self):
        gr = GroundingResult(
            reference="Tommy",
            outcome=GroundingOutcome.CLARIFY,
            missing_attributes=["age"],
            clarification_question="Could you tell me about Tommy's age?"
        )
        assert gr.outcome == GroundingOutcome.CLARIFY
        assert "age" in gr.missing_attributes
        assert "age" in gr.clarification_question


class TestDiagnosisWithCausalGraph:
    """Tests for Diagnosis with causal graph and available alternatives."""

    def test_diagnosis_with_graph(self):
        g = CausalGraph()
        g.add_edge("object.temperature", "safety.burn_risk", "hot causes burn")
        g.add_edge("safety.burn_risk", "goal")

        d = Diagnosis(
            violations=[Violation(layer="societal", rule="test", severity=0.9, explanation="test")],
            causal_variables=["object"],
            causal_edges=[CausalEdge("object.temperature", "safety.burn_risk", "hot causes burn")],
            causal_graph=g,
            max_hazard=0.9
        )
        assert d.causal_graph is not None
        assert len(d.causal_edges) == 1
        assert d.causal_graph.shortest_path("object.temperature", "goal") == 2

    def test_infeasibility_diagnosis(self):
        d = Diagnosis(
            violations=[Violation(
                layer="grounding", rule="object_not_in_scene",
                severity=1.0, explanation="Knife not found in scene"
            )],
            causal_variables=["object"],
            max_hazard=0.0,
            available_alternatives=["butter knife", "spoon"]
        )
        assert d.violations[0].layer == "grounding"
        assert d.max_hazard == 0.0
        assert "butter knife" in d.available_alternatives


class TestDiagnosisExtraction:
    """Tests for diagnosis extraction from safety results."""

    def test_extract_diagnosis_basic(self):
        """Basic test that extract_diagnosis function exists and can be called.
        Full integration tests are in test_guided_generation_integration.py"""
        # This test verifies the function signature is correct
        # Full testing is done via integration tests with mock LLM
        from ctr.safety_evaluation import extract_diagnosis
        assert callable(extract_diagnosis)


class TestDiagnosisExtractor:
    """Tests for DiagnosisExtractor class."""

    def test_get_repair_hints(self):
        diagnosis = Diagnosis(
            violations=[Violation(layer="societal", rule="test", severity=0.8, explanation="test")],
            causal_variables=["object", "recipient"],
            explanations=["Test"],
            max_hazard=0.8
        )

        extractor = DiagnosisExtractor()
        hints = extractor.get_repair_hints(diagnosis)

        assert len(hints) > 0
        # Should suggest SUBSTITUTE for object
        assert any("SUBSTITUTE" in h for h in hints)
        # Should suggest CONSTRAIN or RETARGET for recipient
        assert any("CONSTRAIN" in h or "RETARGET" in h for h in hints)

    def test_compute_lambda(self):
        extractor = DiagnosisExtractor()

        # High hazard -> low lambda
        high_hazard = Diagnosis(violations=[], causal_variables=[], explanations=[], max_hazard=0.9)
        lambda_high = extractor.compute_lambda(high_hazard)

        # Low hazard -> high lambda
        low_hazard = Diagnosis(violations=[], causal_variables=[], explanations=[], max_hazard=0.1)
        lambda_low = extractor.compute_lambda(low_hazard)

        assert lambda_high < lambda_low


class TestDefectAndHazardTypes:
    """Tests for defect type, hazard type, and frame classification."""

    def test_violation_with_defect_type(self):
        v = Violation(
            layer="societal", rule="thermal_hazard", severity=0.9,
            explanation="Hot coffee burn risk",
            defect_type=DefectType.PHYSICAL_SAFETY,
            hazard_type=HazardType.THERMAL,
            hazard_severity="serious",
            hazard_probability="certain"
        )
        assert v.defect_type == DefectType.PHYSICAL_SAFETY
        assert v.hazard_type == HazardType.THERMAL
        assert v.hazard_severity == "serious"

    def test_diagnosis_with_defect_classification(self):
        d = Diagnosis(
            violations=[Violation(
                layer="individual", rule="privacy", severity=0.6,
                explanation="Recording without consent",
                defect_type=DefectType.NORMATIVE,
                hazard_type=HazardType.NORMATIVE
            )],
            causal_variables=["action.type"],
            defect_type=DefectType.NORMATIVE,
            hazard_type=HazardType.NORMATIVE,
            max_hazard=0.6
        )
        assert d.defect_type == DefectType.NORMATIVE
        assert d.hazard_type == HazardType.NORMATIVE

    def test_all_defect_types(self):
        for dt in DefectType:
            assert dt.value  # Each has a string value

    def test_all_hazard_types(self):
        for ht in HazardType:
            assert ht.value

    def test_all_frame_types(self):
        for ft in TaskFrame:
            assert ft.value


class TestAlignmentMatrix:
    """Tests for the alignment matrix (FORBIDDEN/PERMISSIBLE only)."""

    def test_all_permissible(self):
        from ctr.safety_evaluation import apply_alignment_matrix, LayerDecision, FinalDecision
        r = apply_alignment_matrix(
            LayerDecision.PERMISSIBLE, LayerDecision.PERMISSIBLE, LayerDecision.PERMISSIBLE
        )
        assert r == FinalDecision.ACCEPT

    def test_any_forbidden_rejects(self):
        from ctr.safety_evaluation import apply_alignment_matrix, LayerDecision, FinalDecision
        r = apply_alignment_matrix(
            LayerDecision.FORBIDDEN, LayerDecision.PERMISSIBLE, LayerDecision.PERMISSIBLE
        )
        assert r == FinalDecision.REJECT

    def test_all_forbidden(self):
        from ctr.safety_evaluation import apply_alignment_matrix, LayerDecision, FinalDecision
        r = apply_alignment_matrix(
            LayerDecision.FORBIDDEN, LayerDecision.FORBIDDEN, LayerDecision.FORBIDDEN
        )
        assert r == FinalDecision.REJECT


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
