"""Tests for deterministic affinity scoring."""

import pytest
from ctr.data_structures import TaskVariables, ObjectReference, Diagnosis, CausalGraph
from ctr.affinity import (
    score_action_preservation,
    score_object_preservation,
    score_location_preservation,
    score_recipient_preservation,
    score_causal_minimality,
    score_goal_similarity,
    compute_affinity_dimension_weights,
    compute_deterministic_affinity,
    CLOSE_VERB_PAIRS,
)


# ACTION PRESERVATION TESTS

class TestActionPreservation:
    def test_exact_match(self):
        assert score_action_preservation("put", "put") == 1.0

    def test_close_verb(self):
        assert score_action_preservation("put", "place") == 0.8

    def test_different_verb(self):
        assert score_action_preservation("put", "slice") == 0.3

    def test_missing_original(self):
        assert score_action_preservation(None, "put") == 0.5

    def test_missing_repair(self):
        assert score_action_preservation("put", None) == 0.5

    def test_case_insensitive(self):
        assert score_action_preservation("Put", "PUT") == 1.0

    def test_close_verb_symmetric(self):
        assert score_action_preservation("hand", "give") == 0.8
        assert score_action_preservation("give", "hand") == 0.8


# OBJECT PRESERVATION TESTS

class TestObjectPreservation:
    def _refs(self, *names):
        return [ObjectReference(reference_text=n) for n in names]

    def test_full_overlap(self):
        assert score_object_preservation(
            self._refs("apple", "bowl"), self._refs("apple", "bowl")
        ) == 1.0

    def test_partial_overlap(self):
        score = score_object_preservation(
            self._refs("apple", "soap bottle"), self._refs("apple", "bowl")
        )
        assert abs(score - 1/3) < 0.01  # Jaccard: 1 intersection / 3 union

    def test_no_overlap(self):
        assert score_object_preservation(
            self._refs("apple"), self._refs("knife")
        ) == 0.0

    def test_both_empty(self):
        assert score_object_preservation([], []) == 1.0

    def test_one_empty(self):
        assert score_object_preservation(self._refs("apple"), []) == 0.0


# LOCATION PRESERVATION TESTS

class TestLocationPreservation:
    def _refs(self, *names):
        return [ObjectReference(reference_text=n) for n in names]

    def test_same_location(self):
        assert score_location_preservation(
            self._refs("counter"), self._refs("counter")
        ) == 1.0

    def test_both_empty(self):
        assert score_location_preservation([], []) == 1.0

    def test_location_added(self):
        assert score_location_preservation([], self._refs("shelf")) == 0.3

    def test_location_removed(self):
        assert score_location_preservation(self._refs("counter"), []) == 0.3


# RECIPIENT PRESERVATION TESTS

class TestRecipientPreservation:
    def test_same(self):
        r1 = ObjectReference(reference_text="child")
        r2 = ObjectReference(reference_text="child")
        assert score_recipient_preservation(r1, r2) == 1.0

    def test_different(self):
        r1 = ObjectReference(reference_text="child")
        r2 = ObjectReference(reference_text="grandma")
        assert score_recipient_preservation(r1, r2) == 0.0

    def test_both_none(self):
        assert score_recipient_preservation(None, None) == 1.0

    def test_added(self):
        r2 = ObjectReference(reference_text="child")
        assert score_recipient_preservation(None, r2) == 0.3

    def test_removed(self):
        r1 = ObjectReference(reference_text="child")
        assert score_recipient_preservation(r1, None) == 0.3


# CAUSAL MINIMALITY TESTS

class TestCausalMinimality:
    def test_all_on_path(self):
        score = score_causal_minimality(
            changes_made=["changed soap_bottle to bowl"],
            causal_graph=None,
            causal_variables=["resource.soap_bottle"]
        )
        assert score == 1.0

    def test_none_on_path(self):
        score = score_causal_minimality(
            changes_made=["added verification step"],
            causal_graph=None,
            causal_variables=["resource.knife"]
        )
        assert score == 0.0

    def test_mixed(self):
        score = score_causal_minimality(
            changes_made=["changed knife to scissors", "added extra step"],
            causal_graph=None,
            causal_variables=["resource.knife"]
        )
        assert score == 0.5

    def test_no_changes(self):
        assert score_causal_minimality([], None, ["resource.knife"]) == 0.5

    def test_no_causal_vars(self):
        assert score_causal_minimality(["some change"], None, []) == 0.5


# GOAL SIMILARITY TESTS

class TestGoalSimilarity:
    def test_identical(self):
        assert score_goal_similarity("put apple in bowl", "put apple in bowl") == 1.0

    def test_missing(self):
        assert score_goal_similarity(None, "put apple") == 0.5

    def test_word_overlap_fallback(self):
        # Even without sentence-transformers, word overlap should work
        score = score_goal_similarity("put apple in bowl", "put apple in cabinet")
        assert 0.0 < score < 1.0  # partial overlap

    def test_no_overlap(self):
        score = score_goal_similarity("put apple in bowl", "slice the bread")
        assert score < 0.7  # should be low similarity


# DIMENSION WEIGHT TESTS

class TestDimensionWeights:
    def test_default_weights_sum_to_one(self):
        weights = compute_affinity_dimension_weights(None, None)
        assert abs(sum(weights.values()) - 1.0) < 1e-6

    def test_object_heavy_graph(self):
        weights = compute_affinity_dimension_weights(
            None,  # graph not needed for counting
            ["resource.knife", "object.apple", "resource.microwave"]
        )
        assert weights['object'] > weights['recipient']
        assert weights['object'] > weights['location']

    def test_recipient_heavy_graph(self):
        weights = compute_affinity_dimension_weights(
            None,
            ["recipient.child", "recipient.age_3"]
        )
        # Recipient gets the distributable boost, object doesn't
        # recipient base=0.10 + boost, object base=0.15 + 0 boost
        # Recipient should be boosted above its base weight
        default_weights = compute_affinity_dimension_weights(None, None)
        assert weights['recipient'] > default_weights['recipient']

    def test_weights_always_sum_to_one(self):
        test_vars = [
            ["action.put"],
            ["resource.knife", "object.apple"],
            ["recipient.child", "location.kitchen"],
            ["action.hand", "resource.knife", "recipient.toddler"],
        ]
        for vars in test_vars:
            weights = compute_affinity_dimension_weights(None, vars)
            assert abs(sum(weights.values()) - 1.0) < 1e-6


# INTEGRATION / DETERMINISM TESTS

class TestDeterministicAffinity:
    def _make_tasks(self):
        original = TaskVariables(
            goal="put the apple in the soap bottle",
            action="put",
            objects=[ObjectReference(reference_text="apple"),
                     ObjectReference(reference_text="soap bottle")],
            original_utterance="put the apple in the soap bottle"
        )
        repaired = TaskVariables(
            goal="put the apple in the bowl",
            action="put",
            objects=[ObjectReference(reference_text="apple"),
                     ObjectReference(reference_text="bowl")],
            original_utterance="put the apple in the bowl"
        )
        diagnosis = Diagnosis(
            causal_variables=["resource.soap_bottle", "action.put"],
            causal_edges=[]
        )
        return original, repaired, diagnosis

    def test_same_inputs_same_output(self):
        original, repaired, diagnosis = self._make_tasks()
        results = []
        for _ in range(10):
            score, _, _ = compute_deterministic_affinity(
                original, repaired, diagnosis, ["changed soap bottle to bowl"]
            )
            results.append(score)
        # ALL 10 must be EXACTLY equal
        assert all(r == results[0] for r in results)

    def test_score_range(self):
        original, repaired, diagnosis = self._make_tasks()
        score, _, _ = compute_deterministic_affinity(
            original, repaired, diagnosis, ["changed soap bottle to bowl"]
        )
        assert -0.5 <= score <= 1.0

    def test_identical_tasks_high_score(self):
        task = TaskVariables(
            goal="put the apple in the bowl",
            action="put",
            objects=[ObjectReference(reference_text="apple"),
                     ObjectReference(reference_text="bowl")],
            original_utterance="put the apple in the bowl"
        )
        score, _, _ = compute_deterministic_affinity(task, task, None, [])
        assert score > 0.5  # high affinity for identical tasks

    def test_returns_breakdown(self):
        original, repaired, diagnosis = self._make_tasks()
        score, dim_scores, dim_weights = compute_deterministic_affinity(
            original, repaired, diagnosis, ["changed soap bottle to bowl"]
        )
        assert isinstance(dim_scores, dict)
        assert isinstance(dim_weights, dict)
        assert set(dim_scores.keys()) == {'action', 'object', 'location', 'recipient', 'minimality', 'goal'}
        assert set(dim_weights.keys()) == {'action', 'object', 'location', 'recipient', 'minimality', 'goal'}
        assert abs(sum(dim_weights.values()) - 1.0) < 1e-6
