"""Tests for the plan linter (deterministic action sequence validation)."""

import pytest
from ctr.plan_linter import (
    lint_action_sequence,
    extract_action_name,
    extract_object_args,
    VALID_ACTIONS,
)


class TestExtractActionName:
    def test_simple_action(self):
        assert extract_action_name("GoToObject(robot1, 'Apple')") == "GoToObject"

    def test_no_args(self):
        assert extract_action_name("DropHandObject(robot1)") == "DropHandObject"

    def test_malformed(self):
        assert extract_action_name("not an action") is None

    def test_whitespace(self):
        assert extract_action_name("  GoToObject (robot1, 'Apple')") == "GoToObject"


class TestExtractObjectArgs:
    def test_single_object(self):
        assert extract_object_args("GoToObject(robot1, 'Apple')") == ["Apple"]

    def test_two_objects(self):
        assert extract_object_args("PutObject(robot1, 'Apple', 'CounterTop')") == ["Apple", "CounterTop"]

    def test_no_objects(self):
        assert extract_object_args("DropHandObject(robot1)") == []


class TestLintActionSequence:
    SCENE = {"Apple", "CounterTop", "Knife", "Bowl", "Fridge", "Sink"}

    def test_valid_sequence(self):
        seq = [
            "GoToObject(robot1, 'Apple')",
            "PickupObject(robot1, 'Apple')",
            "GoToObject(robot1, 'CounterTop')",
            "PutObject(robot1, 'Apple', 'CounterTop')",
        ]
        is_valid, errors = lint_action_sequence(seq, self.SCENE)
        assert is_valid
        assert errors == []

    def test_invented_action_rejected(self):
        seq = [
            "GoToObject(robot1, 'Apple')",
            "Observe(robot1, 'Apple')",
        ]
        is_valid, errors = lint_action_sequence(seq, self.SCENE)
        assert not is_valid
        assert any("Unsupported action 'Observe'" in e for e in errors)

    def test_nonexistent_object_rejected(self):
        seq = [
            "GoToObject(robot1, 'KitchenEntrance')",
        ]
        is_valid, errors = lint_action_sequence(seq, self.SCENE)
        assert not is_valid
        assert any("KitchenEntrance" in e for e in errors)

    def test_holding_violation(self):
        seq = [
            "GoToObject(robot1, 'Apple')",
            "PickupObject(robot1, 'Apple')",
            "GoToObject(robot1, 'Knife')",
            "PickupObject(robot1, 'Knife')",  # Holding Apple already
        ]
        is_valid, errors = lint_action_sequence(seq, self.SCENE)
        assert not is_valid
        assert any("already holding" in e for e in errors)

    def test_empty_sequence_rejected(self):
        is_valid, errors = lint_action_sequence([], self.SCENE)
        assert not is_valid
        assert any("Empty" in e for e in errors)

    def test_drop_clears_held(self):
        seq = [
            "GoToObject(robot1, 'Apple')",
            "PickupObject(robot1, 'Apple')",
            "DropHandObject(robot1)",
            "GoToObject(robot1, 'Knife')",
            "PickupObject(robot1, 'Knife')",  # OK — dropped Apple first
        ]
        is_valid, errors = lint_action_sequence(seq, self.SCENE)
        assert is_valid

    def test_put_clears_held(self):
        seq = [
            "GoToObject(robot1, 'Apple')",
            "PickupObject(robot1, 'Apple')",
            "GoToObject(robot1, 'CounterTop')",
            "PutObject(robot1, 'Apple', 'CounterTop')",
            "GoToObject(robot1, 'Knife')",
            "PickupObject(robot1, 'Knife')",  # OK — put Apple down
        ]
        is_valid, errors = lint_action_sequence(seq, self.SCENE)
        assert is_valid

    def test_case_sensitive_objects(self):
        seq = [
            "GoToObject(robot1, 'apple')",  # lowercase — not in scene
        ]
        is_valid, errors = lint_action_sequence(seq, self.SCENE)
        assert not is_valid
        assert any("apple" in e for e in errors)

    def test_valid_actions_set(self):
        expected = {
            'GoToObject', 'PickupObject', 'PutObject', 'OpenObject',
            'CloseObject', 'ToggleObjectOn', 'ToggleObjectOff',
            'SliceObject', 'BreakObject', 'ThrowObject', 'PushObject',
            'PullObject', 'DropHandObject',
        }
        assert VALID_ACTIONS == expected
