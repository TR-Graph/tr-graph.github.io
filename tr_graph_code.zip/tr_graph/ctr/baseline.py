# ctr/baseline.py
"""
Baseline LLM Repair Module.

Provides a simple LLM-based approach to repairing unsafe tasks,
without using TR-Graph's structured operators, search, or cost functions.

Used for comparison against TR-Graph's structured repair approach.
"""

from typing import Dict, List, Optional, Any
from dataclasses import dataclass
import logging
import time

logger = logging.getLogger(__name__)


# DATA STRUCTURES

@dataclass
class BaselineRepairResult:
    """Result from baseline LLM repair."""
    original_task: str
    repaired_task: str
    analysis: str
    what_changed: str
    model: str
    latency_ms: float
    raw_response: str
    success: bool = True
    error: Optional[str] = None


# BASELINE REPAIR CLASS

class BaselineLLMRepair:
    """
    Baseline LLM-based task repair.

    Simply prompts an LLM to identify hazards and suggest safe alternatives,
    without any structured operators or search.
    """

    def __init__(self, llm_client: Any, model: Optional[str] = None):
        """
        Initialize baseline repair.

        Args:
            llm_client: LLM client (from ctr.llm_client)
            model: Optional model override
        """
        self.llm_client = llm_client
        self.model = model

    def repair(
        self,
        task: str,
        scene: str,
        scene_objects: Optional[List[str]] = None
    ) -> BaselineRepairResult:
        """
        Attempt to repair an unsafe task using LLM.

        Args:
            task: The original task description
            scene: Scene description or context
            scene_objects: Optional list of available objects

        Returns:
            BaselineRepairResult with repaired task and metadata
        """
        start_time = time.time()

        # Build scene description
        scene_desc = scene
        if scene_objects:
            scene_desc += f"\nAvailable objects: {', '.join(scene_objects)}"

        # Use the same prompt as the benchmark CoT baseline for fair comparison
        from ctr.benchmarks.baseline_runners import _COT_SYSTEM, _COT_USER, _parse_json
        objects_str = ', '.join(scene_objects[:50]) if scene_objects else 'Not specified'

        prompt = _COT_USER.format(
            task=task,
            scene_type=scene_desc,
            scene_objects=objects_str,
        )

        try:
            # Generate response
            response = self.llm_client.generate(
                system_prompt=_COT_SYSTEM,
                user_prompt=prompt
            )

            latency_ms = (time.time() - start_time) * 1000

            # Handle response object or string
            if hasattr(response, 'text'):
                response_text = response.text
                model_used = getattr(response, 'model', self.model or 'unknown')
            else:
                response_text = str(response)
                model_used = self.model or 'unknown'

            # Parse JSON response (same format as benchmark)
            parsed = _parse_json(response_text)
            is_safe = parsed.get('is_safe', True)
            reasoning = parsed.get('reasoning', '')
            safe_alternative = parsed.get('safe_alternative', '')

            if is_safe:
                repaired = task  # No change needed
                analysis = reasoning
                what_changed = ''
            else:
                repaired = safe_alternative if safe_alternative else task
                analysis = reasoning
                what_changed = 'Suggested safe alternative via chain-of-thought reasoning'

            return BaselineRepairResult(
                original_task=task,
                repaired_task=repaired,
                analysis=analysis,
                what_changed=what_changed,
                model=model_used,
                latency_ms=latency_ms,
                raw_response=response_text,
                success=True
            )

        except Exception as e:
            latency_ms = (time.time() - start_time) * 1000
            logger.error(f"Baseline repair failed: {e}")

            return BaselineRepairResult(
                original_task=task,
                repaired_task=task,  # Return original if failed
                analysis="",
                what_changed="",
                model=self.model or 'unknown',
                latency_ms=latency_ms,
                raw_response="",
                success=False,
                error=str(e)
            )

    def _parse_response(self, response) -> Dict[str, str]:
        """Parse the LLM response to extract structured fields."""
        # Handle LLMResponse objects
        if hasattr(response, 'text'):
            text = response.text
        elif isinstance(response, str):
            text = response
        else:
            text = str(response)

        result = {
            'analysis': '',
            'repaired_task': '',
            'what_changed': ''
        }

        lines = text.strip().split('\n')
        current_field = None
        current_content = []

        for line in lines:
            line_stripped = line.strip()

            if line_stripped.startswith('ANALYSIS:'):
                if current_field:
                    result[current_field] = ' '.join(current_content).strip()
                current_field = 'analysis'
                current_content = [line_stripped[9:].strip()]

            elif line_stripped.startswith('REPAIRED_TASK:'):
                if current_field:
                    result[current_field] = ' '.join(current_content).strip()
                current_field = 'repaired_task'
                current_content = [line_stripped[14:].strip()]

            elif line_stripped.startswith('WHAT_CHANGED:'):
                if current_field:
                    result[current_field] = ' '.join(current_content).strip()
                current_field = 'what_changed'
                current_content = [line_stripped[13:].strip()]

            elif current_field and line_stripped:
                current_content.append(line_stripped)

        # Don't forget the last field
        if current_field:
            result[current_field] = ' '.join(current_content).strip()

        # Fallback: if parsing failed, try to extract any reasonable response
        if not result['repaired_task']:
            # Look for any line that looks like a task
            for line in lines:
                if line.strip() and not line.startswith(('ANALYSIS', 'WHAT_CHANGED', '#', '-')):
                    result['repaired_task'] = line.strip()
                    break

        return result

    def repair_batch(
        self,
        tasks: List[Dict[str, str]],
        progress_callback: Optional[callable] = None
    ) -> List[BaselineRepairResult]:
        """
        Repair multiple tasks.

        Args:
            tasks: List of dicts with 'task' and 'scene' keys
            progress_callback: Optional callback(current, total) for progress

        Returns:
            List of BaselineRepairResult objects
        """
        results = []
        total = len(tasks)

        for i, task_info in enumerate(tasks):
            task = task_info.get('task', '')
            scene = task_info.get('scene', '')
            scene_objects = task_info.get('scene_objects', None)

            result = self.repair(task, scene, scene_objects)
            results.append(result)

            if progress_callback:
                progress_callback(i + 1, total)

        return results
