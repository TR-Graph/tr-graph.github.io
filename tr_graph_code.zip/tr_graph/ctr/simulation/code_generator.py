# ctr/simulation/code_generator.py
"""
Generate executable robot code for AI2-THOR.

Takes TR-Graph's repaired TaskVariables and generates action sequences
that can be executed by the AI2THORActionExecutor.
"""

from typing import Dict, List, Optional, Any, TYPE_CHECKING
import ast
import re
import logging

if TYPE_CHECKING:
    from ctr.llm_client import MultiLLMClient

logger = logging.getLogger(__name__)


class CodeGenerator:
    """
    Generate robot action code from task descriptions.

    This generator:
    1. Takes a task description (original or repaired)
    2. Uses LLM to generate AI2-THOR action sequences
    3. Adds safety assertions based on repair constraints
    4. Validates and cleans the generated code
    """

    def __init__(self, llm_client: 'MultiLLMClient'):
        """
        Initialize code generator.

        Args:
            llm_client: LLM client for code generation
        """
        self.llm = llm_client

    def generate(
        self,
        task: str,
        scene_objects: List[str],
        repair_constraints: Dict = None,
        invariants: Dict = None,
        relations: List[Dict] = None
    ) -> str:
        """
        Generate executable action sequence for a task.

        Args:
            task: Task description (may be repaired task from CTR)
            scene_objects: List of objects available in the scene
            repair_constraints: TR-Graph repair constraints to enforce
            invariants: Safety invariants (PDDL/LTL/STL)
            relations: Object relations from scene

        Returns:
            Generated action sequence code
        """
        invariants = invariants or {}
        repair_constraints = repair_constraints or {}

        # Build relations text
        relations_text = ""
        if relations:
            relations_text = f"""
        Relations Summary (use these EXACT object names):
        {relations}

        CRITICAL: Use the exact object names and capitalization as they appear in the Relations Summary above.
        For example, if Relations Summary shows "AlarmClock", use 'AlarmClock' not 'alarmclock'.
        If Relations Summary shows "CoffeeTable", use 'CoffeeTable' not 'coffee table'.
        """

        # Build TR-Graph repair constraints text
        repair_text = ""
        if repair_constraints:
            repair_text = self._format_repair_constraints(repair_constraints)

        prompt = f"""
        Generate a sequence of robot actions to accomplish the following task.

        Task: {task}

        Available objects in scene: {scene_objects}
        {relations_text}
        IMPORTANT: You have access to ONE robot only. Use 'robot1' as the identifier (not robot2, robot3, etc.).

        {repair_text}

        Safety constraints that MUST be maintained:
        Preconditions: {invariants.get('pddl_preconditions', [])}
        Postconditions: {invariants.get('pddl_postconditions', [])}
        Invariants: {invariants.get('ltl_invariants', [])}
        Physical constraints: {invariants.get('stl_constraints', [])}
        Context: {invariants.get('llm_contextual', [])}

        Use ONLY these robot actions:
        - GoToObject(robot1, 'ObjectName') - Navigate robot to object
        - PickupObject(robot1, 'ObjectName') - Pick up an object
        - PutObject(robot1, 'ObjectName', 'Location') - Place object at location
        - OpenObject(robot1, 'ObjectName') - Open an object (door, drawer, etc.)
        - CloseObject(robot1, 'ObjectName') - Close an object
        - ToggleObjectOn(robot1, 'ObjectName') - Turn on an appliance
        - ToggleObjectOff(robot1, 'ObjectName') - Turn off an appliance
        - BreakObject(robot1, 'ObjectName') - Break an object
        - SliceObject(robot1, 'ObjectName') - Slice an object
        - ThrowObject(robot1, 'ObjectName') - Throw an object
        - PushObject(robot1, 'ObjectName') - Push an object
        - PullObject(robot1, 'ObjectName') - Pull an object
        - DropHandObject(robot1) - Drop held object

        Output ONLY the action sequence, one action per line. No function definitions, no comments.

        Example output format:
        GoToObject(robot1, 'Apple')
        PickupObject(robot1, 'Apple')
        GoToObject(robot1, 'CounterTop')
        PutObject(robot1, 'Apple', 'CounterTop')

        Ensure all safety constraints are respected in the action sequence.
        """

        try:
            response = self.llm.generate(
                system_prompt="You are a robot code generator. Output only valid action sequences.",
                user_prompt=prompt
            )

            # Extract text from LLMResponse object
            code = response.text if hasattr(response, 'text') else str(response)

            # Clean and validate
            code = self._clean_code(code)
            code = self._normalize_robot_identifiers(code)
            code = self._add_safety_checks(code, invariants, repair_constraints)

            return code

        except Exception as e:
            logger.error(f"Error generating code: {e}")
            return f"# Error generating code: {e}"

    def generate_from_task_variables(
        self,
        task_variables: Any,
        scene_objects: List[str],
        relations: List[Dict] = None
    ) -> str:
        """
        Generate code from TR-Graph TaskVariables.

        Args:
            task_variables: TR-Graph TaskVariables object
            scene_objects: List of scene objects
            relations: Object relations

        Returns:
            Generated action sequence
        """
        # Extract task description
        task = task_variables.goal or task_variables.action
        if task_variables.target:
            task += f" with {task_variables.target.reference_text}"
        if task_variables.recipient:
            task += f" for {task_variables.recipient.reference_text}"

        # Extract repair constraints from task variables
        repair_constraints = {}
        if hasattr(task_variables, 'constraints') and task_variables.constraints:
            for constraint in task_variables.constraints:
                if hasattr(constraint, 'constraint_type') and hasattr(constraint, 'value'):
                    repair_constraints[constraint.constraint_type] = constraint.value

        return self.generate(
            task=task,
            scene_objects=scene_objects,
            repair_constraints=repair_constraints,
            relations=relations
        )

    def _format_repair_constraints(self, constraints: Dict) -> str:
        """Format repair constraints for the prompt."""
        lines = ["TR-GRAPH REPAIR CONSTRAINTS (MUST BE FOLLOWED):"]

        if 'temperature_max' in constraints:
            lines.append(f"- Maximum temperature allowed: {constraints['temperature_max']}°C")
            lines.append("  (Do not use hot objects, let them cool first)")

        if 'forbidden_objects' in constraints:
            forbidden = ', '.join(constraints['forbidden_objects'])
            lines.append(f"- FORBIDDEN objects (do not use): {forbidden}")

        if 'required_container' in constraints:
            lines.append(f"- MUST use container: {constraints['required_container']}")

        if 'recipient_age' in constraints:
            age = constraints['recipient_age']
            lines.append(f"- Recipient is {age} years old (use age-appropriate items)")

        if 'substitutions' in constraints:
            for orig, replacement in constraints['substitutions'].items():
                lines.append(f"- Use '{replacement}' instead of '{orig}'")

        return '\n        '.join(lines)

    def _clean_code(self, code: str) -> str:
        """Clean generated code by removing markdown formatting."""
        if "```python" in code:
            code = code.split("```python")[1].split("```")[0]
        elif "```" in code:
            code = code.split("```")[1].split("```")[0]

        return code.strip()

    def _normalize_robot_identifiers(self, code: str) -> str:
        """
        Normalize robot identifiers to enforce single-robot constraint.

        Replaces robot2, robot3, etc. with robot1.
        """
        pattern = r'\brobot([2-9]|\d{2,})\b'
        normalized_code = re.sub(pattern, 'robot1', code)
        return normalized_code

    def _add_safety_checks(
        self,
        code: str,
        invariants: Dict,
        repair_constraints: Dict
    ) -> str:
        """Add runtime safety assertions to code."""
        safety_checks = []

        # Add invariant-based checks
        for precond in invariants.get('pddl_preconditions', []):
            if 'exists' in precond:
                obj = precond.split('(')[1].split(')')[0]
                safety_checks.append(f"assert scene_has('{obj}')")

        # Add TR-Graph repair constraint checks
        if repair_constraints.get('forbidden_objects'):
            for obj in repair_constraints['forbidden_objects']:
                safety_checks.append(f"# TR-Graph: {obj} is forbidden")

        if repair_constraints.get('required_container'):
            container = repair_constraints['required_container']
            safety_checks.append(f"# TR-Graph: Must use {container}")

        if repair_constraints.get('temperature_max'):
            max_temp = repair_constraints['temperature_max']
            safety_checks.append(f"# TR-Graph: Max temperature {max_temp}°C")

        if safety_checks:
            code = '\n'.join(safety_checks) + '\n\n' + code

        return code

    def validate_code(self, code: str) -> tuple[bool, List[str]]:
        """
        Validate generated code.

        Args:
            code: Generated action sequence

        Returns:
            Tuple of (is_valid, list of errors)
        """
        errors = []
        lines = code.strip().split('\n')

        from ctr.plan_linter import VALID_ACTIONS
        valid_actions = VALID_ACTIONS | {'SwitchOn', 'SwitchOff'}  # Canonical + legacy aliases

        for i, line in enumerate(lines, 1):
            line = line.strip()

            # Skip comments and assertions
            if not line or line.startswith('#') or line.startswith('assert'):
                continue

            # Check if line matches action pattern
            match = re.match(r'(\w+)\(', line)
            if not match:
                errors.append(f"Line {i}: Invalid syntax: {line}")
                continue

            action_name = match.group(1)
            if action_name not in valid_actions:
                errors.append(f"Line {i}: Unknown action: {action_name}")

        return len(errors) == 0, errors

    def translate_for_robot(self, code: str, robot_mode: str = 'ai2thor') -> tuple[str, bool, List[str]]:
        """Translate AI2-THOR action sequence to target robot's action format.

        For AI2-THOR and SafeAgentBench modes, returns code unchanged.
        For Franka/Spot, maps supported actions and rejects unsupported ones.

        Args:
            code: AI2-THOR action sequence (one action per line)
            robot_mode: Target robot mode

        Returns:
            Tuple of (translated_code, is_valid, list of errors)
        """
        if robot_mode in ('ai2thor', 'safeagentbench'):
            return code, True, []

        # Action translation maps per robot mode
        _TRANSLATION_MAPS = {
            'franka': {
                'GoToObject': 'move_to',
                'PickupObject': 'pick',
                'PutObject': 'place',
                'PushObject': 'push',
                'DropHandObject': 'open_gripper',
            },
            'spot': {
                'GoToObject': 'navigate',
                'PickupObject': 'pick',
                'PutObject': 'place',
                'OpenObject': 'open_door',
                'DropHandObject': 'open_gripper',
            },
        }

        trans_map = _TRANSLATION_MAPS.get(robot_mode, {})
        if not trans_map:
            return code, True, []

        lines = code.strip().split('\n')
        translated_lines = []
        errors = []

        for i, line in enumerate(lines, 1):
            line = line.strip()
            if not line or line.startswith('#') or line.startswith('assert'):
                translated_lines.append(line)
                continue

            match = re.match(r'(\w+)\((.*)$', line)
            if not match:
                translated_lines.append(line)
                continue

            action_name = match.group(1)
            rest = match.group(2)

            if action_name in trans_map:
                new_action = trans_map[action_name]
                translated_lines.append(f"{new_action}({rest}")
            else:
                errors.append(
                    f"Line {i}: Action '{action_name}' is not supported by "
                    f"{robot_mode} robot. Cannot translate."
                )

        translated_code = '\n'.join(translated_lines)
        is_valid = len(errors) == 0

        if errors:
            logger.warning(
                f"[CodeGenerator] {len(errors)} actions could not be translated "
                f"to {robot_mode}: {errors}"
            )

        return translated_code, is_valid, errors
