# ctr/simulation/task_executor.py
"""
Task execution orchestrator for TR-Graph.

Connects TR-Graph's repaired tasks with AI2-THOR simulation execution.
Coordinates code generation, safety monitoring, and action execution.
"""

import traceback
import logging
import uuid
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class ExecutionResult:
    """Result of task execution."""
    success: bool
    error: Optional[str] = None
    executed_actions: List[Dict] = field(default_factory=list)
    failed_action: Optional[Dict] = None
    safety_violations: List[Dict] = field(default_factory=list)
    constraint_violations: List[Dict] = field(default_factory=list)
    final_state: Optional[Dict] = None
    video_info: Optional[Dict] = None
    execution_trace: List[str] = field(default_factory=list)


class TaskExecutor:
    """
    Execute TR-Graph-repaired tasks in AI2-THOR simulation.

    This executor:
    1. Takes a repaired task from CTR
    2. Generates executable code
    3. Executes in AI2-THOR with safety monitoring
    4. Records video of execution
    5. Returns detailed execution results
    """

    def __init__(
        self,
        use_ai2thor: bool = True,
        scene: str = "FloorPlan1",
        headless: bool = True,
        enable_video: bool = True,
        llm_client: Any = None
    ):
        """
        Initialize task executor.

        Args:
            use_ai2thor: Whether to use real AI2-THOR (False = offline mode)
            scene: AI2-THOR scene name
            headless: Run AI2-THOR without display
            enable_video: Enable video recording
            llm_client: LLM client for code generation
        """
        self.use_ai2thor = use_ai2thor
        self.scene = scene
        self.headless = headless
        self.enable_video = enable_video
        self.llm_client = llm_client

        self.controller = None
        self.action_executor = None
        self.code_generator = None

        if use_ai2thor:
            self._init_ai2thor()

        if llm_client:
            self._init_code_generator()

    def _init_ai2thor(self):
        """Initialize AI2-THOR controller and components."""
        try:
            from ai2thor.controller import Controller

            self.controller = Controller(
                scene=self.scene,
                width=1280,
                height=720,
                headless=self.headless,
                renderDepthImage=False,
                renderInstanceSegmentation=False,
            )
            logger.info(f"AI2-THOR initialized with scene: {self.scene}")

            # Initialize action executor
            from ctr.simulation.ai2thor_actions import AI2THORActionExecutor
            session_id = str(uuid.uuid4())[:8]
            self.action_executor = AI2THORActionExecutor(
                self.controller,
                enable_video=self.enable_video,
                session_id=session_id
            )

            # Setup video recording camera (required for capturing frames)
            if self.action_executor.video_recorder:
                self.action_executor.video_recorder.notify_scene_reset()
                self.action_executor.video_recorder.setup_camera_after_scene_load(
                    self.controller.last_event
                )
                logger.info("Video recording camera initialized")



        except ImportError as e:
            logger.warning(f"AI2-THOR not available: {e}. Running in offline mode.")
            self.use_ai2thor = False
            self.controller = None

    def _init_code_generator(self):
        """Initialize code generator."""
        from ctr.simulation.code_generator import CodeGenerator
        self.code_generator = CodeGenerator(self.llm_client)

    def reset_scene(self, scene: str = None):
        """Reset to a new scene and re-initialize dependent components."""
        if self.controller:
            scene = scene or self.scene
            self.controller.reset(scene=scene)
            self.scene = scene
            logger.info(f"Scene reset to: {scene}")

            # Re-initialize action executor scene data (reachable positions)
            if self.action_executor:
                self.action_executor._initialize_scene()

                # Re-initialize video camera (old camera destroyed by reset)
                if self.action_executor.video_recorder:
                    self.action_executor.video_recorder.notify_scene_reset()
                    self.action_executor.video_recorder.setup_camera_after_scene_load(
                        self.controller.last_event
                    )

    def execute_task(
        self,
        task_variables: Any,
        repair_constraints: Dict = None,
        dry_run: bool = False
    ) -> ExecutionResult:
        """
        Execute a TR-Graph task (original or repaired).

        Args:
            task_variables: TR-Graph TaskVariables object
            repair_constraints: Constraints from TR-Graph repair
            dry_run: If True, only generate code without executing

        Returns:
            ExecutionResult with execution details
        """
        result = ExecutionResult(success=False)
        repair_constraints = repair_constraints or {}

        try:
            # Use pre-generated action sequence if available
            action_seq = getattr(task_variables, 'action_sequence', None)
            if action_seq and isinstance(action_seq, list) and action_seq:
                code = '\n'.join(action_seq)
                result.execution_trace.append(
                    f"Using pre-generated action sequence: {len(action_seq)} steps"
                )
            elif self.code_generator:
                # Fallback for original safe tasks without action sequences
                scene_objects = self._get_scene_objects()
                code = self.code_generator.generate_from_task_variables(
                    task_variables,
                    scene_objects=scene_objects
                )
                result.execution_trace.append(f"Generated code:\n{code}")
            else:
                logger.warning(
                    "[CTR] No action_sequence on task — falling back to simple code generation. "
                    "This may produce drift from schema-based generation."
                )
                code = self._generate_simple_code(task_variables)
                result.execution_trace.append(f"Generated simple code:\n{code}")

            if dry_run:
                result.success = True
                result.execution_trace.append("Dry run - no execution")
                return result

            # Step 1.5: Set up human stand-ins if task references people/animals
            task_text = getattr(task_variables, 'goal', '') or ''
            if not task_text and hasattr(task_variables, 'action'):
                task_text = str(task_variables.action)
            task_id = getattr(task_variables, 'task_id', None)

            # Step 2: Execute code
            if not self.use_ai2thor or not self.action_executor:
                # Mock execution
                result.success = True
                result.execution_trace.append("Mock execution completed")
                result.final_state = {'mode': 'mock'}
                return result

            # Set repair constraints on safety monitor

            # Set repair constraints on action executor
            if repair_constraints:
                self.action_executor.set_repair_constraints(repair_constraints)

            # Parse code into action list
            actions = self._parse_code_to_actions(code)
            result.execution_trace.append(f"Parsed {len(actions)} actions")

            # Execute actions
            execution_result = self.action_executor.execute_action_sequence(actions)

            # Collect results
            result.success = execution_result.get('success', False)
            result.executed_actions = execution_result.get('executed_actions', [])
            result.failed_action = execution_result.get('failed_action')
            result.error = execution_result.get('error')
            result.constraint_violations = execution_result.get('constraint_violations', [])

            # Get video info
            if 'video' in execution_result:
                result.video_info = execution_result['video']

            # Get final state
            result.final_state = self._get_current_state()

        except Exception as e:
            result.error = str(e)
            result.execution_trace.append(f"Error: {traceback.format_exc()}")
            logger.error(f"Task execution failed: {e}")

        return result

    def execute_code(
        self,
        code: str,
        repair_constraints: Dict = None,
        dry_run: bool = False
    ) -> ExecutionResult:
        """
        Execute raw action code.

        Args:
            code: Action sequence code
            repair_constraints: Constraints to enforce
            dry_run: If True, only validate code

        Returns:
            ExecutionResult
        """
        result = ExecutionResult(success=False)
        repair_constraints = repair_constraints or {}

        try:
            if dry_run:
                # Just validate the code
                if self.code_generator:
                    valid, errors = self.code_generator.validate_code(code)
                    result.success = valid
                    if not valid:
                        result.error = "; ".join(errors)
                else:
                    result.success = True
                result.execution_trace.append("Dry run completed")
                return result

            if not self.use_ai2thor or not self.action_executor:
                result.success = True
                result.execution_trace.append("Mock execution completed")
                return result

            # Set constraints
            if repair_constraints:
                self.action_executor.set_repair_constraints(repair_constraints)

            # Parse and execute
            actions = self._parse_code_to_actions(code)
            execution_result = self.action_executor.execute_action_sequence(actions)

            result.success = execution_result.get('success', False)
            result.executed_actions = execution_result.get('executed_actions', [])
            result.failed_action = execution_result.get('failed_action')
            result.error = execution_result.get('error')

            if 'video' in execution_result:
                result.video_info = execution_result['video']

            result.final_state = self._get_current_state()

        except Exception as e:
            result.error = str(e)
            logger.error(f"Code execution failed: {e}")

        return result

    def _get_scene_objects(self) -> List[str]:
        """Get list of objects in current scene."""
        if self.action_executor:
            return self.action_executor.get_scene_objects()
        elif self.controller:
            try:
                objects = self.controller.last_event.metadata.get("objects", [])
                return [obj["objectType"] for obj in objects]
            except Exception:
                pass
        return []

    def _get_current_state(self) -> Dict:
        """Get current simulation state."""
        if self.action_executor:
            return self.action_executor.get_robot_state()
        elif self.controller:
            try:
                metadata = self.controller.last_event.metadata
                return {
                    'agent_position': metadata.get("agent", {}).get("position"),
                    'holding': metadata.get("inventoryObjects", []),
                    'objects': [obj["objectType"] for obj in metadata.get("objects", [])]
                }
            except Exception:
                pass
        return {'mode': 'mock'}

    def _parse_code_to_actions(self, code: str) -> List[str]:
        """Parse code string into list of action strings."""
        actions = []
        for line in code.strip().split('\n'):
            line = line.strip()
            if line and not line.startswith('#') and not line.startswith('assert'):
                actions.append(line)
        return actions

    def _generate_simple_code(self, task_variables: Any) -> str:
        """Generate simple code from task variables without LLM."""
        lines = []

        # Extract target object
        target = None
        if hasattr(task_variables, 'target') and task_variables.target:
            target = task_variables.target.reference_text

        # Extract destination/recipient
        destination = None
        if hasattr(task_variables, 'recipient') and task_variables.recipient:
            destination = task_variables.recipient.reference_text

        # Simple action pattern based on action type
        action = getattr(task_variables, 'action', '').lower()

        if target:
            lines.append(f"GoToObject(robot1, '{target}')")
            lines.append(f"PickupObject(robot1, '{target}')")

        if destination:
            lines.append(f"GoToObject(robot1, '{destination}')")
            lines.append(f"PutObject(robot1, '{target}', '{destination}')")

        return '\n'.join(lines) if lines else "# No actions generated"

    def cleanup(self):
        """Clean up resources."""
        if self.controller:
            try:
                self.controller.stop()
            except Exception:
                pass
        logger.info("Task executor cleaned up")

    def __del__(self):
        """Destructor."""
        self.cleanup()
