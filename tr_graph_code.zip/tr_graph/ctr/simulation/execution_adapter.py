"""
TR-Graph Execution Adapter — CanonicalAction IR + dialect-aware parsing.

Provides a structured intermediate representation (CanonicalAction) that
normalizes action strings from any dialect (SafeAgentBench, AI2-THOR, Franka)
into typed fields. The executor reads fields instead of re-parsing strings,
eliminating format-mismatch bugs.

Architecture:
    action_string → dialect parser → CanonicalAction → ObjectResolver
    → PreconditionChecker → AI2THORActionExecutor
"""

import atexit
import logging
import re
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


# Intermediate Representation

@dataclass
class CanonicalAction:
    """Structured representation of a parsed action step.

    Every action format (SafeAgentBench, AI2-THOR, Franka) is parsed
    into this IR. The executor reads typed fields instead of guessing
    string formats.
    """
    verb: str                          
    actor: str = "robot1"
    obj: Optional[str] = None          # Primary object (thing being acted on)
    receptacle: Optional[str] = None   # Target receptacle (for put/place)
    liquid_type: Optional[str] = None  # For fillLiquid
    raw: str = ""                      # Original unparsed string
    dialect: str = ""                  # "safeagentbench" | "ai2thor" | "franka"


@dataclass
class DispatchResult:
    """Result of dispatching a single action to the executor."""
    success: bool = False
    error_category: str = "execution"
    error_message: str = ""


@dataclass
class StepOutcome:
    """Per-step execution outcome."""
    step_index: int = 0
    original_action: str = ""
    resolved_action: str = ""
    resolved_args: Dict[str, Any] = field(default_factory=dict)
    success: bool = False
    skipped: bool = False
    error_message: str = ""
    error_category: str = ""
    time_ms: float = 0.0


@dataclass
class ExecutionOutcome:
    """Overall execution outcome for a full action sequence."""
    scene_name: str = ""
    total_steps: int = 0
    steps_succeeded: int = 0
    steps_failed: int = 0
    steps_skipped: int = 0
    completed: bool = False
    total_time_ms: float = 0.0
    step_outcomes: List[StepOutcome] = field(default_factory=list)

    @property
    def completion_rate(self) -> float:
        return self.steps_succeeded / self.total_steps if self.total_steps > 0 else 0.0


# Dialect Parsers — all produce CanonicalAction

def parse_safeagentbench(action_str: str) -> CanonicalAction:
    """Parse SafeAgentBench format: verb(robot, 'Arg1') or "verb Arg"

    Key difference from AI2-THOR: put() has ONE argument (receptacle only).
    The held object is implicit.
    """
    # Try function-call format first
    match = re.match(r'(\w+)\(([^)]*)\)', action_str.strip())
    if not match:
        # Fallback: "verb Arg" format
        parts = action_str.strip().split(None, 1)
        verb = parts[0].lower() if parts else ''
        arg = parts[1].strip() if len(parts) > 1 else None
        if verb == 'put':
            return CanonicalAction(verb="put", receptacle=arg,
                                   raw=action_str, dialect="safeagentbench")
        return CanonicalAction(verb=verb, obj=arg, raw=action_str,
                               dialect="safeagentbench")

    verb = match.group(1).lower()
    args = re.findall(r"'([^']*)'", match.group(2))

    if verb == 'put':
        return CanonicalAction(verb="put", obj=None,
                               receptacle=args[0] if args else None,
                               raw=action_str, dialect="safeagentbench")
    elif verb == 'fillliquid':
        return CanonicalAction(verb="fillLiquid",
                               obj=args[0] if args else None,
                               liquid_type=args[1] if len(args) > 1 else None,
                               raw=action_str, dialect="safeagentbench")
    elif verb in ('pour', 'throw', 'drop'):
        return CanonicalAction(verb=verb, obj=None,
                               raw=action_str, dialect="safeagentbench")
    else:
        return CanonicalAction(verb=verb, obj=args[0] if args else None,
                               raw=action_str, dialect="safeagentbench")


def parse_ai2thor(action_str: str) -> CanonicalAction:
    """Parse AI2-THOR format: ActionName(robot1, 'Arg1', 'Arg2')

    Key difference from SafeAgentBench: PutObject has TWO arguments
    (object + receptacle).
    """
    match = re.match(r'(\w+)\(([^)]*)\)', action_str.strip())
    if not match:
        parts = action_str.strip().split(None, 1)
        verb = parts[0] if parts else ''
        arg = parts[1].strip() if len(parts) > 1 else None
        return CanonicalAction(verb=verb, obj=arg, raw=action_str,
                               dialect="ai2thor")

    verb = match.group(1)
    args = re.findall(r"'([^']*)'", match.group(2))

    if verb == 'PutObject':
        return CanonicalAction(verb="put",
                               obj=args[0] if args else None,
                               receptacle=args[1] if len(args) > 1 else args[0],
                               raw=action_str, dialect="ai2thor")
    elif verb == 'DropHandObject':
        return CanonicalAction(verb="drop", obj=None,
                               raw=action_str, dialect="ai2thor")
    else:
        verb_map = {
            'GoToObject': 'find', 'PickupObject': 'pick',
            'OpenObject': 'open', 'CloseObject': 'close',
            'ToggleObjectOn': 'turn_on', 'ToggleObjectOff': 'turn_off',
            'SliceObject': 'slice', 'BreakObject': 'break',
            'ThrowObject': 'throw', 'PushObject': 'push',
            'PullObject': 'pull',
        }
        canonical_verb = verb_map.get(verb, verb.lower())
        return CanonicalAction(verb=canonical_verb,
                               obj=args[0] if args else None,
                               raw=action_str, dialect="ai2thor")


def parse_franka(action_str: str) -> CanonicalAction:
    """Parse Franka format: verb(robot1, 'Arg1', 'Arg2')"""
    match = re.match(r'(\w+)\(([^)]*)\)', action_str.strip())
    if not match:
        parts = action_str.strip().split(None, 1)
        verb = parts[0] if parts else ''
        arg = parts[1].strip() if len(parts) > 1 else None
        return CanonicalAction(verb=verb, obj=arg, raw=action_str,
                               dialect="franka")

    verb = match.group(1)
    args = re.findall(r"'([^']*)'", match.group(2))

    if verb == 'place':
        return CanonicalAction(verb="put",
                               obj=args[0] if args else None,
                               receptacle=args[1] if len(args) > 1 else None,
                               raw=action_str, dialect="franka")
    elif verb == 'open_gripper':
        return CanonicalAction(verb="drop", obj=None,
                               raw=action_str, dialect="franka")
    elif verb == 'move_to':
        return CanonicalAction(verb="find",
                               obj=args[0] if args else None,
                               raw=action_str, dialect="franka")
    else:
        return CanonicalAction(verb=verb,
                               obj=args[0] if args else None,
                               raw=action_str, dialect="franka")


# Parser dispatch
DIALECT_PARSERS = {
    'safeagentbench': parse_safeagentbench,
    'ai2thor': parse_ai2thor,
    'franka': parse_franka,
}


def parse_action(action_str: str, dialect: str = "ai2thor") -> CanonicalAction:
    """Parse an action string using the appropriate dialect parser."""
    parser = DIALECT_PARSERS.get(dialect, parse_ai2thor)
    return parser(action_str)


# Canonical verb → AI2-THOR executor method

CANONICAL_TO_EXECUTOR = {
    # Navigation
    'find': 'GoToObject',
    'move_to': 'GoToObject',

    # Manipulation
    'pick': 'PickupObject',
    'put': 'PutObject',
    'place': 'PutObject',
    'drop': 'DropHandObject',
    'throw': 'ThrowObject',
    'push': 'PushObject',
    'pull': 'PullObject',

    # Container interaction
    'open': 'OpenObject',
    'close': 'CloseObject',

    # Appliance control
    'turn_on': 'ToggleObjectOn',
    'turn_off': 'ToggleObjectOff',

    # Object transformation
    'slice': 'SliceObject',
    'break': 'BreakObject',

    # SafeAgentBench extended
    'cook': 'CookObject',
    'dirty': 'DirtyObject',
    'clean': 'CleanObject',
    'pour': 'EmptyLiquidFromObject',
    'fillLiquid': 'FillObjectWithLiquid',
    'emptyLiquid': 'EmptyLiquidFromObject',

    # Franka-specific
    'open_gripper': 'DropHandObject',
}


# Object Resolver

class ObjectResolver:
    """Resolve human-readable object names to AI2-THOR objectIds.

    Three-path resolution:
    1. Grounding map (from TR-Graph pipeline grounding stage)
    2. Type match (objectType == name)
    3. Fuzzy match (case-insensitive substring)
    """

    def __init__(self, controller, grounding_map=None, scene_metadata=None):
        self.controller = controller
        self.grounding_map = grounding_map or {}
        self.scene_metadata = scene_metadata or {}
        self._cache = {}

    def resolve(self, name: str) -> Optional[str]:
        if not name:
            return None

        # Check cache
        if name in self._cache:
            return self._cache[name]

        result = self._resolve_impl(name)
        self._cache[name] = result
        return result

    def _resolve_impl(self, name: str) -> Optional[str]:
        # Path 1: Grounding map
        if name in self.grounding_map:
            mapped = self.grounding_map[name]
            # Verify it exists in scene
            for obj in self.controller.last_event.metadata.get('objects', []):
                if obj['objectId'] == mapped:
                    return mapped
            # Grounding map value might be a type name, not an objectId
            return self._resolve_by_type(mapped) or mapped

        # Path 2: Exact type match
        result = self._resolve_by_type(name)
        if result:
            return result

        # Path 3: Fuzzy match
        return self._resolve_fuzzy(name)

    def _resolve_by_type(self, name: str) -> Optional[str]:
        name_lower = name.lower().replace(' ', '')
        for obj in self.controller.last_event.metadata.get('objects', []):
            if obj['objectType'].lower() == name_lower:
                return obj['objectId']
        return None

    def _resolve_fuzzy(self, name: str) -> Optional[str]:
        name_lower = name.lower().replace(' ', '').replace('_', '')
        best = None
        best_dist = float('inf')
        agent_pos = self.controller.last_event.metadata['agent']['position']

        for obj in self.controller.last_event.metadata.get('objects', []):
            obj_type = obj['objectType'].lower()
            obj_id_prefix = obj['objectId'].split('|')[0].lower()

            if name_lower in obj_type or obj_type in name_lower or \
               name_lower in obj_id_prefix or obj_id_prefix in name_lower:
                obj_pos = obj['position']
                dist = ((agent_pos['x'] - obj_pos['x'])**2 +
                        (agent_pos['z'] - obj_pos['z'])**2)**0.5
                if dist < best_dist:
                    best_dist = dist
                    best = obj['objectId']

        return best


# Precondition Checker

class PreconditionChecker:
    """Check action preconditions before execution."""

    def __init__(self, controller):
        self.controller = controller

    def check(self, method: str, obj_id: str, receptacle_id: str = None) -> Tuple[bool, str]:
        """Return (ok, reason). ok=True means precondition met."""
        inventory = self.controller.last_event.metadata.get('inventoryObjects', [])
        holding = [item['objectId'] for item in inventory]

        if method == 'PickupObject':
            if holding:
                return False, f"Robot already holding {holding[0]}"

        if method == 'PutObject':
            if not holding:
                return False, "Robot not holding anything"

        if method in ('SliceObject', 'BreakObject'):
            # Need a knife/tool — but this is hard to check generically
            pass

        return True, ""


# Execution Adapter

class TRGraphExecutionAdapter:
    """Execute validated TR-Graph action sequences in AI2-THOR.

    Receives action strings, parses them into CanonicalAction IR using
    the appropriate dialect parser, resolves object names to AI2-THOR
    instance IDs, checks preconditions, and executes via the production
    AI2THORActionExecutor.
    """

    def __init__(
        self,
        controller,
        dialect: str = "ai2thor",
        grounding_map: Optional[Dict[str, str]] = None,
        scene_metadata: Optional[Dict[str, Any]] = None,
    ):
        self.controller = controller
        self.dialect = dialect
        self.resolver = ObjectResolver(controller, grounding_map, scene_metadata)
        self.preconditions = PreconditionChecker(controller)

        from ctr.simulation.ai2thor_actions import AI2THORActionExecutor
        self.executor = AI2THORActionExecutor(
            controller, enable_video=False, session_id='trgraph_exec'
        )

    def execute(self, action_sequence: List[str]) -> ExecutionOutcome:
        result = ExecutionOutcome(
            scene_name=self.controller.last_event.metadata.get('sceneName', 'unknown'),
            total_steps=len(action_sequence),
        )
        if not action_sequence:
            result.completed = True
            return result

        start_time = time.time()
        last_critical_failed = False

        for i, action_str in enumerate(action_sequence):
            step_start = time.time()

            # Parse into CanonicalAction
            action = parse_action(action_str, dialect=self.dialect)
            executor_method = CANONICAL_TO_EXECUTOR.get(action.verb, action.verb)

            step = StepOutcome(
                step_index=i,
                original_action=action_str,
                resolved_action=executor_method,
            )

            # Check prerequisite chain
            if last_critical_failed and executor_method in (
                'PickupObject', 'PutObject', 'SliceObject',
                'CookObject', 'CleanObject', 'DirtyObject',
            ):
                step.skipped = True
                step.error_message = "Skipped: prerequisite step failed"
                step.error_category = "prerequisite_failed"
                result.steps_skipped += 1
                result.step_outcomes.append(step)
                continue

            last_critical_failed = False

            # Resolve object names to AI2-THOR IDs
            resolved_obj = None
            resolved_receptacle = None
            resolution_failed = False

            if action.obj:
                resolved_obj = self.resolver.resolve(action.obj)
                if not resolved_obj:
                    step.success = False
                    step.error_message = f"Cannot resolve '{action.obj}' to objectId"
                    step.error_category = "name_resolution"
                    resolution_failed = True

            if action.receptacle and not resolution_failed:
                resolved_receptacle = self.resolver.resolve(action.receptacle)
                if not resolved_receptacle:
                    step.success = False
                    step.error_message = f"Cannot resolve receptacle '{action.receptacle}'"
                    step.error_category = "name_resolution"
                    resolution_failed = True

            step.resolved_args = {
                'obj': resolved_obj,
                'receptacle': resolved_receptacle,
            }

            if resolution_failed:
                result.steps_failed += 1
                result.step_outcomes.append(step)
                last_critical_failed = True
                continue

            # Check preconditions
            primary_id = resolved_obj or ''
            ok, reason = self.preconditions.check(
                executor_method, primary_id, resolved_receptacle
            )
            if not ok:
                step.success = False
                step.error_message = reason
                step.error_category = "precondition"
                result.steps_failed += 1
                result.step_outcomes.append(step)
                last_critical_failed = True
                continue

            # Execute
            try:
                dr = self._dispatch(
                    executor_method, resolved_obj, resolved_receptacle,
                    action.liquid_type
                )
                step.success = dr.success
                if not dr.success:
                    step.error_message = dr.error_message or f"{executor_method} failed"
                    step.error_category = dr.error_category
            except Exception as e:
                step.success = False
                step.error_message = f"{type(e).__name__}: {e}"
                step.error_category = "execution"

            step.time_ms = (time.time() - step_start) * 1000

            if step.success:
                result.steps_succeeded += 1
            else:
                result.steps_failed += 1
                last_critical_failed = executor_method in (
                    'GoToObject', 'PickupObject'
                )

            result.step_outcomes.append(step)

        result.total_time_ms = (time.time() - start_time) * 1000
        result.completed = (result.steps_succeeded == result.total_steps)
        return result

    def _get_held_object_id(self) -> Optional[str]:
        """Return the objectId of the currently held object, or None."""
        inventory = self.controller.last_event.metadata.get('inventoryObjects', [])
        if inventory:
            return inventory[0]['objectId']
        return None

    def _dispatch(self, method: str, obj_id: Optional[str],
                  receptacle_id: Optional[str],
                  liquid_type: Optional[str] = None) -> DispatchResult:
        """Dispatch to the appropriate executor method."""

        # Methods with dedicated executor implementations
        if method == 'GoToObject':
            return DispatchResult(self.executor.GoToObject('robot1', obj_id or ''))
        elif method == 'PickupObject':
            return DispatchResult(self.executor.PickupObject('robot1', obj_id or ''))
        elif method == 'PutObject':
            effective_obj = obj_id or self._get_held_object_id() or ''
            target = receptacle_id or obj_id or ''
            return DispatchResult(self.executor.PutObject('robot1', effective_obj, target))
        elif method == 'OpenObject':
            return DispatchResult(self.executor.OpenObject('robot1', obj_id or ''))
        elif method == 'CloseObject':
            return DispatchResult(self.executor.CloseObject('robot1', obj_id or ''))
        elif method == 'SliceObject':
            return DispatchResult(self.executor.SliceObject('robot1', obj_id or ''))
        elif method == 'BreakObject':
            return DispatchResult(self.executor.BreakObject('robot1', obj_id or ''))
        elif method == 'ThrowObject':
            return DispatchResult(self.executor.ThrowObject('robot1', obj_id or ''))
        elif method == 'PushObject':
            return DispatchResult(self.executor.PushObject('robot1', obj_id or ''))
        elif method == 'PullObject':
            return DispatchResult(self.executor.PullObject('robot1', obj_id or ''))
        elif method == 'DropHandObject':
            return DispatchResult(self.executor.DropHandObject('robot1'))
        elif method in ('ToggleObjectOn', 'SwitchOn'):
            return DispatchResult(self.executor.SwitchOn('robot1', obj_id or ''))
        elif method in ('ToggleObjectOff', 'SwitchOff'):
            return DispatchResult(self.executor.SwitchOff('robot1', obj_id or ''))

        # SafeAgentBench extended: pass-through to controller
        elif method in ('CookObject', 'DirtyObject', 'CleanObject',
                        'EmptyLiquidFromObject'):
            try:
                event = self.controller.step(
                    action=method, objectId=obj_id or '', forceAction=True
                )
                if event.metadata.get('lastActionSuccess', False):
                    return DispatchResult(True)
                error_msg = event.metadata.get('errorMessage', '')
                if ('not supported' in error_msg.lower()
                        or 'invalid action' in error_msg.lower()):
                    return DispatchResult(
                        False, "unsupported_by_environment",
                        f"{method} not supported in this scene/version",
                    )
                return DispatchResult(False, "execution",
                                     error_msg or f"{method} failed")
            except Exception as e:
                return DispatchResult(
                    False, "unsupported_by_environment",
                    f"{method} raised {type(e).__name__}: {e}",
                )
        elif method == 'FillObjectWithLiquid':
            try:
                event = self.controller.step(
                    action='FillObjectWithLiquid',
                    objectId=obj_id or '',
                    fillLiquid=liquid_type or 'water',
                    forceAction=True,
                )
                if event.metadata.get('lastActionSuccess', False):
                    return DispatchResult(True)
                error_msg = event.metadata.get('errorMessage', '')
                if ('not supported' in error_msg.lower()
                        or 'invalid action' in error_msg.lower()):
                    return DispatchResult(
                        False, "unsupported_by_environment",
                        "FillObjectWithLiquid not supported",
                    )
                return DispatchResult(False, "execution",
                                     error_msg or "FillObjectWithLiquid failed")
            except Exception as e:
                return DispatchResult(
                    False, "unsupported_by_environment",
                    f"FillObjectWithLiquid raised {type(e).__name__}: {e}",
                )

        else:
            return DispatchResult(
                False, "unsupported_by_environment",
                f"Unsupported action: {method}",
            )


# Controller Cache

_controller_cache: Dict[str, Any] = {}


def get_cached_controller(scene_name: str):
    """Get or create a controller for a scene, reusing via reset()."""
    if scene_name in _controller_cache:
        try:
            _controller_cache[scene_name].last_event
            _controller_cache[scene_name].reset(scene_name)
            return _controller_cache[scene_name]
        except Exception:
            pass

    from ctr.benchmarks.execution_harness import _create_controller
    controller = _create_controller(scene_name)
    _controller_cache[scene_name] = controller
    return controller


def cleanup_controllers():
    """Stop all cached controllers."""
    for controller in _controller_cache.values():
        try:
            controller.stop()
        except Exception:
            pass
    _controller_cache.clear()


atexit.register(cleanup_controllers)
