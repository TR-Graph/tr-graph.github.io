# ctr/simulation/ai2thor_actions.py
"""
AI2-THOR action executor for TR-Graph.

Provides robot action execution in AI2-THOR simulation environment.

"""

import math
import re
import time
from typing import List, Dict, Tuple, Optional, Callable, Any
from collections import deque
import logging

logger = logging.getLogger(__name__)

# Optional imports for AI2-THOR (may not be installed)
try:
    import numpy as np
    from scipy.spatial import distance
    HAS_SCIPY = True
except ImportError:
    HAS_SCIPY = False
    logger.warning("scipy not available - some navigation features may be limited")


# Navigation constants 
NAV_GOAL_THRESH = 0.3            # Meters; distance threshold for "close enough"
NAV_STALL_MOVEMENT_THRESH = 0.2  # Min movement per step to count as progress
NAV_STALL_COUNT_LIMIT = 15       # Stalls before switching stalls before switching to fallback
NAV_MAX_ITERATIONS = 150         # Safety limit (typical nav is 20-40 iterations)
NAV_FRAME_CAPTURE_INTERVAL = 5   # Video frame every N steps
NAV_STEP_DELAY = 0.5             # Seconds between navigation steps 


class AI2THORActionExecutor:
    """
    Execute robot actions in AI2-THOR environment.

    This executor wraps an AI2-THOR controller and provides:
    - High-level action methods (GoToObject, PickupObject, etc.)
    - Fallback navigation when expert navigation fails
    - Video recording of execution
    - Safety monitor callback hooks
    - TR-Graph repair constraint checking
    """

    def __init__(
        self,
        controller,
        enable_video: bool = True,
        session_id: str = None,
        repair_constraints: Dict = None
    ):
        """
        Initialize executor with AI2-THOR controller.

        Args:
            controller: AI2-THOR controller instance
            enable_video: Whether to enable video recording
            session_id: Session ID for video recording
            repair_constraints: TR-Graph repair constraints to enforce during execution
        """
        self.controller = controller
        self.action_queue = deque()
        self.task_over = False
        self.reachable_positions = []
        self.robots = []
        self.monitor_callback = None

        # TR-Graph-specific: repair constraints
        self.repair_constraints = repair_constraints or {}

        # Human stand-in positions: {label: {x, y, z}}
        self.human_positions: Dict[str, Dict[str, float]] = {}

        self.enable_video = enable_video
        self.video_recorder = None
        if enable_video and session_id:
            try:
                from ctr.simulation.video_recorder import VideoRecorder
                self.video_recorder = VideoRecorder(controller, session_id)
                logger.info(f"Video recording enabled for session {session_id}")
            except Exception as e:
                logger.warning(f"Could not initialize video recorder: {e}")
                self.video_recorder = None

        # Get reachable positions from scene
        self._initialize_scene()

    def step_render(self, **kwargs):
        """Central wrapper that always enforces renderImage=True for third-party camera frames."""
        kwargs["renderImage"] = True
        return self.controller.step(**kwargs)

    def _initialize_scene(self):
        """Initialize scene data from AI2-THOR."""
        try:
            event = self.step_render(action="GetReachablePositions")
            if event.metadata.get("actionReturn"):
                self.reachable_positions = [
                    (p["x"], p["y"], p["z"])
                    for p in event.metadata["actionReturn"]
                ]
            else:
                logger.warning("Could not get reachable positions from scene")
                self.reachable_positions = []

        except Exception as e:
            logger.error(f"Error initializing scene: {e}")
            self.reachable_positions = []

    def set_human_positions(self, positions: Dict[str, Dict[str, float]]):
        """Set human stand-in positions for person-related tasks.

        Args:
            positions: {label: {x, y, z}} mapping for human proxies
        """
        self.human_positions = positions
        if positions:
            logger.info(f"Human stand-in positions set: {list(positions.keys())}")

    def _lookup_human_position(self, label: str) -> Optional[Dict[str, float]]:
        """Look up a human stand-in position by label (case-insensitive)."""
        for key, pos in self.human_positions.items():
            if key.lower() == label.lower():
                return pos
        return None

    def set_monitor_callback(self, callback: Callable):
        """Set callback for safety monitoring during execution."""
        self.monitor_callback = callback

    def set_repair_constraints(self, constraints: Dict):
        """
        Set TR-Graph repair constraints for this execution.

        Args:
            constraints: Dictionary of constraints from TR-Graph repair, e.g.:
                {
                    'temperature_max': 40,  # max temperature in Celsius
                    'forbidden_objects': ['Knife'],
                    'required_container': 'SippyCup',
                    'recipient_age': 3
                }
        """
        self.repair_constraints = constraints
        logger.info(f"Repair constraints set: {constraints}")

    def _check_repair_constraints(self, action: Dict) -> Tuple[bool, str]:
        """
        Check if action violates TR-Graph repair constraints.

        Returns:
            Tuple of (is_allowed, reason_if_blocked)
        """
        if not self.repair_constraints:
            return True, ""

        action_name = action.get('action', '')
        args = action.get('args', [])

        def normalize_name(name: str) -> str:
            """Normalize object name for comparison (remove spaces, underscores, lowercase)."""
            return name.lower().replace(' ', '').replace('_', '').replace('-', '')

        # Check forbidden objects
        forbidden = self.repair_constraints.get('forbidden_objects', [])
        for arg in args:
            arg_normalized = normalize_name(str(arg))
            for forbidden_obj in forbidden:
                forbidden_normalized = normalize_name(forbidden_obj)
                if forbidden_normalized in arg_normalized or arg_normalized in forbidden_normalized:
                    return False, f"Object '{arg}' is forbidden by repair constraints"

        # Check required container (for pouring/putting actions)
        required_container = self.repair_constraints.get('required_container')
        if required_container and action_name == 'PutObject':
            if len(args) > 1:
                container_normalized = normalize_name(str(args[1]))
                required_normalized = normalize_name(required_container)
                if required_normalized not in container_normalized and container_normalized not in required_normalized:
                    return False, f"Must use '{required_container}' as container per repair constraints"

        return True, ""

    def _capture_frame(self, action_name: str, success: bool = True):
        """Helper method to capture video frame if recording is enabled."""
        if self.video_recorder:
            try:
                # Update camera to follow agent before capturing
                self.video_recorder._update_overhead_follow()
                # Capture the frame
                self.video_recorder.capture_frame(action_name, success)
            except Exception as e:
                logger.debug(f"Frame capture failed (non-critical): {e}")

    def _get_agent_position(self) -> Dict:
        """Get current agent position as {x, y, z} dict."""
        return self.controller.last_event.metadata["agent"]["position"]

    def _get_sorted_reachable_near_object(self, obj_pos: Dict) -> List[Dict]:
        """Get reachable positions sorted by 2D distance to object (nearest first)."""
        event = self.step_render(action="GetReachablePositions")
        reachable = event.metadata.get("actionReturn", [])
        if not reachable:
            return []

        def dist_2d(pos):
            return ((pos["x"] - obj_pos["x"]) ** 2 +
                    (pos["z"] - obj_pos["z"]) ** 2) ** 0.5

        return sorted(reachable, key=dist_2d)

    def _orient_towards_object(self, obj_id: str, obj_pos: Dict, obj_name: str):
        """Orient agent to face the target object after arrival.

        Strategy 1: LookAtObject (handles yaw + pitch).
        Strategy 2: Compute yaw via atan2 and apply via Teleport.
        """
        try:
            look_event = self.step_render(
                action="LookAtObject",
                objectId=obj_id,
                forceAction=True
            )
            if look_event.metadata.get("lastActionSuccess"):
                logger.info(f"Oriented towards {obj_name} via LookAtObject")
                return
        except Exception:
            pass

        # Fallback: compute yaw manually and teleport with new rotation
        try:
            agent_pos = self._get_agent_position()
            dx = obj_pos["x"] - agent_pos["x"]
            dz = obj_pos["z"] - agent_pos["z"]
            yaw = math.degrees(math.atan2(dx, dz))

            agent_meta = self.controller.last_event.metadata["agent"]
            self.step_render(
                action="Teleport",
                position=agent_pos,
                rotation=dict(x=0, y=yaw, z=0),
                horizon=agent_meta.get("cameraHorizon", 0),
                forceAction=True
            )
            logger.info(f"Oriented towards {obj_name} via manual yaw ({yaw:.1f} deg)")
        except Exception as e:
            logger.debug(f"Could not orient towards {obj_name}: {e}")

    def _iterative_navigate_to_object(self, obj_id: str, obj_pos: Dict, obj_name: str) -> bool:
        """Step-by-step expert navigation to object .

        Calls ObjectNavExpertAction in a loop, executing one movement step per
        iteration, with stall detection and progressive fallback to next-nearest
        reachable positions.
        """
        sorted_positions = self._get_sorted_reachable_near_object(obj_pos)
        if not sorted_positions:
            logger.warning("No reachable positions found for iterative navigation")
            return False

        target_idx = 0
        target_pos = sorted_positions[target_idx]
        stall_count = 0

        logger.info(f"Starting iterative navigation to {obj_name}")
        self._capture_frame(f"GoToObject({obj_name}) - Nav Start", True)

        for iteration in range(NAV_MAX_ITERATIONS):
            # . Check if within goal threshold
            agent_pos = self._get_agent_position()
            dist_to_target = ((agent_pos["x"] - target_pos["x"]) ** 2 +
                              (agent_pos["z"] - target_pos["z"]) ** 2) ** 0.5

            if dist_to_target < NAV_GOAL_THRESH:
                logger.info(f"Reached target after {iteration} steps (dist={dist_to_target:.2f}m)")
                self._orient_towards_object(obj_id, obj_pos, obj_name)
                self._capture_frame(f"GoToObject({obj_name}) - Arrived", True)
                return True

            # . Get next movement command from expert
            try:
                nav_event = self.step_render(
                    action="ObjectNavExpertAction",
                    position=dict(x=target_pos["x"], y=target_pos["y"], z=target_pos["z"])
                )
            except Exception as e:
                logger.warning(f"ObjectNavExpertAction unavailable: {e}")
                return False

            next_action = nav_event.metadata.get("actionReturn")

            # . If no action, check proximity or switch target
            if not next_action:
                dist_to_obj = ((agent_pos["x"] - obj_pos["x"]) ** 2 +
                               (agent_pos["z"] - obj_pos["z"]) ** 2) ** 0.5
                if dist_to_obj < 1.5:
                    logger.info(f"Nav expert returned None but agent is {dist_to_obj:.2f}m from {obj_name}")
                    self._orient_towards_object(obj_id, obj_pos, obj_name)
                    return True

                target_idx += 1
                if target_idx >= len(sorted_positions):
                    logger.warning("Exhausted all reachable positions")
                    return False
                target_pos = sorted_positions[target_idx]
                stall_count = 0
                continue

            # . Execute the step
            prev_pos = agent_pos
            try:
                self.step_render(action=next_action, forceAction=True)
            except Exception as e:
                logger.debug(f"Action {next_action} failed: {e}")

            # . Detect stalls
            new_pos = self._get_agent_position()
            movement = ((new_pos["x"] - prev_pos["x"]) ** 2 +
                        (new_pos["z"] - prev_pos["z"]) ** 2) ** 0.5

            if movement < NAV_STALL_MOVEMENT_THRESH:
                stall_count += 1
            else:
                stall_count = 0

            # . Switch target on stall
            if stall_count >= NAV_STALL_COUNT_LIMIT:
                target_idx += 1
                if target_idx >= len(sorted_positions):
                    dist_to_obj = ((new_pos["x"] - obj_pos["x"]) ** 2 +
                                   (new_pos["z"] - obj_pos["z"]) ** 2) ** 0.5
                    if dist_to_obj < 1.5:
                        logger.info(f"Stall limit but {dist_to_obj:.2f}m from {obj_name} — accepting")
                        self._orient_towards_object(obj_id, obj_pos, obj_name)
                        return True
                    return False
                target_pos = sorted_positions[target_idx]
                stall_count = 0
                logger.info(f"Stall detected, switching to target {target_idx}")
                self._capture_frame(f"GoToObject({obj_name}) - Stall Switch", True)

            # . Periodic video capture
            if iteration > 0 and iteration % NAV_FRAME_CAPTURE_INTERVAL == 0:
                self._capture_frame(f"GoToObject({obj_name}) - Step {iteration}", True)

            # . Delay between steps for simulator stability 
            time.sleep(NAV_STEP_DELAY)

        # Max iterations — check if close enough
        agent_pos = self._get_agent_position()
        dist_to_obj = ((agent_pos["x"] - obj_pos["x"]) ** 2 +
                       (agent_pos["z"] - obj_pos["z"]) ** 2) ** 0.5
        if dist_to_obj < 1.5:
            logger.info(f"Max iterations but {dist_to_obj:.2f}m from {obj_name} — accepting")
            self._orient_towards_object(obj_id, obj_pos, obj_name)
            return True

        logger.warning(f"Iterative navigation failed after {NAV_MAX_ITERATIONS} iterations")
        return False

    def _fallback_navigation(self, obj_id: str, obj_data: Dict, obj_name: str) -> bool:
        """
        Fallback navigation when iterative expert navigation fails.

        Attempts to get close to the object using position-based teleportation
        to the nearest reachable position.

        Args:
            obj_id: AI2-THOR object ID
            obj_data: Full object metadata dictionary
            obj_name: Human-readable object name for logging

        Returns:
            True if successfully navigated near object, False otherwise
        """
        try:
            obj_pos = obj_data['position']

            reachable_event = self.step_render(action="GetReachablePositions")
            reachable = reachable_event.metadata.get('actionReturn', [])

            if not reachable:
                logger.error("No reachable positions available for fallback navigation")
                return False

            min_dist = float('inf')
            closest_pos = None

            for pos in reachable:
                dist = ((pos['x'] - obj_pos['x'])**2 +
                       (pos['z'] - obj_pos['z'])**2)**0.5
                if dist < min_dist:
                    min_dist = dist
                    closest_pos = pos

            # Use 1.5m threshold for better interaction range
            if closest_pos and min_dist < 1.5:
                event = self.step_render(
                    action="Teleport",
                    position=closest_pos,
                    forceAction=True
                )

                if event.metadata.get("lastActionSuccess"):
                    logger.info(f"Fallback navigation successful (teleported {min_dist:.2f}m from {obj_name})")

                    try:
                        look_event = self.step_render(
                            action="LookAtObject",
                            objectId=obj_id,
                            forceAction=True
                        )
                        if look_event.metadata.get("lastActionSuccess"):
                            logger.info(f"Oriented towards {obj_name}")
                    except Exception as e:
                        logger.debug(f"Could not orient towards object: {e}")

                    self._capture_frame(f"GoToObject({obj_name}) - Fallback", True)
                    return True
                else:
                    logger.error(f"Teleport failed: {event.metadata.get('errorMessage')}")
                    return False

            logger.error(f"Fallback navigation failed - closest reachable position is {min_dist:.2f}m away (threshold: 1.5m)")
            self._capture_frame(f"GoToObject({obj_name}) - Failed", False)
            return False

        except Exception as e:
            logger.error(f"Fallback navigation error: {e}")
            return False

    def _evaluate_condition(self, condition: str) -> bool:
        """C3: Evaluate a runtime condition against AI2-THOR object state.

        Parses simple conditions like "microwave is on", "drawer is open",
        "stove burner is hot" by checking the object's metadata.
        """
        condition_lower = condition.lower()
        try:
            objects = self.controller.last_event.metadata.get("objects", [])

            for obj in objects:
                obj_type = obj.get("objectType", "").lower()
                obj_id = obj.get("objectId", "").lower()

                # Check if this object is mentioned in the condition
                if obj_type not in condition_lower and obj_type.replace("_", " ") not in condition_lower:
                    continue

                # Check toggleable state (is on / is off)
                if "is on" in condition_lower or "turned on" in condition_lower:
                    return obj.get("isToggled", False)
                if "is off" in condition_lower or "turned off" in condition_lower:
                    return not obj.get("isToggled", False)

                # Check open/closed state
                if "is open" in condition_lower or "opened" in condition_lower:
                    return obj.get("isOpen", False)
                if "is closed" in condition_lower or "shut" in condition_lower:
                    return not obj.get("isOpen", False)

                # Check temperature
                if "hot" in condition_lower or "warm" in condition_lower:
                    return obj.get("temperature", "RoomTemp") == "Hot"
                if "cold" in condition_lower or "cool" in condition_lower:
                    return obj.get("temperature", "RoomTemp") == "Cold"

                # Check broken state
                if "broken" in condition_lower:
                    return obj.get("isBroken", False)

        except Exception as e:
            logger.warning(f"Condition evaluation failed: {e}")

        # Default: condition not determinable, assume met (proceed with action)
        logger.info(f"Could not evaluate condition '{condition}' — assuming True")
        return True

    def _look_at_target(self, obj_id: str):
        """Pitch the agent camera toward a target object before manipulation.

        Calls LookAtObject so the first-person view captures objects below
        eye level (drawers, floor items, etc.) during the action frame.
        """
        try:
            self.step_render(
                action="LookAtObject",
                objectId=obj_id,
                forceAction=True,
            )
        except Exception:
            pass  # Non-critical — action still executes with forceAction

    def _navigate_to_position(self, target_pos: Dict) -> bool:
        """Simple position-based navigation fallback."""
        try:
            reachable = self.step_render(action="GetReachablePositions").metadata.get('actionReturn', [])

            if not reachable:
                return False

            min_dist = float('inf')
            closest_pos = None

            for pos in reachable:
                dist = ((pos['x'] - target_pos['x'])**2 +
                       (pos['z'] - target_pos['z'])**2)**0.5
                if dist < min_dist:
                    min_dist = dist
                    closest_pos = pos

            if closest_pos and min_dist < 1.5:  # Within 1.5 meters
                event = self.step_render(
                    action="Teleport",
                    position=closest_pos,
                    forceAction=True
                )
                return event.metadata.get("lastActionSuccess", False)

            return False

        except Exception as e:
            logger.error(f"Position navigation failed: {e}")
            return False

    def execute_action_sequence(self, actions: List[str], robots: List[Dict] = None) -> Dict:
        """
        Execute a sequence of robot actions.

        Args:
            actions: List of action strings like "GoToObject(robot1, 'Apple')"
            robots: List of robot configurations

        Returns:
            Execution result dictionary
        """
        if robots is None:
            robots = [{'name': 'robot1', 'skills': ['all']}]

        self.robots = robots
        results = {
            'success': True,
            'executed_actions': [],
            'failed_action': None,
            'error': None,
            'screenshots': [],
            'constraint_violations': []
        }

        try:
            # Capture initial state for recording
            if self.video_recorder:
                self._capture_frame("Initial State", True)

            # Track gate state for conditional sub-tasks
            _gate_active = False
            _gate_condition_met = True

            for action_str in actions:
                action_str_stripped = action_str.strip()
                if not action_str_stripped or action_str_stripped.startswith('assert'):
                    continue

                # Parse CHECK/GATE markers for conditional execution
                if action_str_stripped.startswith('# CHECK:'):
                    condition = action_str_stripped[8:].strip()
                    _gate_condition_met = self._evaluate_condition(condition)
                    logger.info(f"Condition check '{condition}': {_gate_condition_met}")
                    continue
                elif action_str_stripped.startswith('# GATE:'):
                    _gate_active = True
                    if not _gate_condition_met:
                        # Condition not met — skip remaining gated actions
                        # Drop held object if robot is holding something
                        inventory = self.controller.last_event.metadata.get("inventoryObjects", [])
                        if inventory:
                            logger.info("Gate skipped — dropping held object")
                            self.DropHandObject("robot1")
                        logger.info("Gate not met — skipping remaining sub-task actions")
                        break
                    continue
                elif action_str_stripped.startswith('#'):
                    continue  # Regular comment

                parsed = self._parse_action(action_str)
                if parsed:
                    self.action_queue.append(parsed)
                else:
                    results['success'] = False
                    results['error'] = f"Could not parse action: {action_str}"
                    return results

            # Execute actions sequentially
            while self.action_queue:
                action = self.action_queue.popleft()

                # TR-Graph: Check repair constraints before execution
                constraint_ok, constraint_reason = self._check_repair_constraints(action)
                if not constraint_ok:
                    logger.warning(f"Repair constraint violated: {constraint_reason}")
                    results['constraint_violations'].append({
                        'action': action,
                        'reason': constraint_reason
                    })
                    # CRITICAL: Block execution on constraint violation
                    results['success'] = False
                    results['failed_action'] = action
                    results['error'] = f"Repair constraint violated: {constraint_reason}"
                    break

                # Safety monitoring callback
                if self.monitor_callback:
                    if not self.monitor_callback(action, self.controller):
                        results['success'] = False
                        results['error'] = f"Safety monitor stopped execution at: {action}"
                        break

                # Execute the action
                success = self._execute_single_action(action)

                if success:
                    results['executed_actions'].append(action)
                    # Capture screenshot after action
                    if self.controller.last_event.frame is not None:
                        results['screenshots'].append(self.controller.last_event.frame)
                else:
                    results['success'] = False
                    results['failed_action'] = action
                    results['error'] = f"Action failed: {action}"
                    break

                # Small delay between actions for stability
                time.sleep(0.1)

        except Exception as e:
            results['success'] = False
            results['error'] = str(e)
            logger.error(f"Error executing action sequence: {e}")

        # Finalize video recording
        if self.video_recorder:
            try:
                video_results = self.video_recorder.finalize()
                results['video'] = video_results
                logger.info(f"Video recording complete: {video_results}")
            except Exception as e:
                logger.warning(f"Could not finalize video: {e}")

        return results

    def _parse_action(self, action_str: str) -> Optional[Dict]:
        """
        Parse action string into structured format.

        Example: "GoToObject(robot1, 'Apple')" ->
                 {'action': 'GoToObject', 'robot': 'robot1', 'args': ['Apple']}
        """
        pattern = r'(\w+)\((robot\d+)(?:,\s*[\'"]([^\'"]*)[\'"]\s*(?:,\s*[\'"]([^\'"]*)[\'"])?)?\)'
        match = re.match(pattern, action_str.strip())

        if not match:
            pattern2 = r'(\w+)\((robot\d+)\)'
            match = re.match(pattern2, action_str.strip())
            if match:
                return {
                    'action': match.group(1),
                    'robot': match.group(2),
                    'args': []
                }
            logger.warning(f"Could not parse action: {action_str}")
            return None

        action_name = match.group(1)
        robot_name = match.group(2)
        args = [arg for arg in match.groups()[2:] if arg is not None]

        return {
            'action': action_name,
            'robot': robot_name,
            'args': args
        }

    def _execute_single_action(self, action: Dict) -> bool:
        """
        Execute a single parsed action.

        Args:
            action: Parsed action dictionary

        Returns:
            True if successful, False otherwise
        """
        action_name = action['action']
        robot_name = action['robot']
        args = action['args']

        agent_id = int(robot_name[-1]) - 1

        try:
            if action_name == 'GoToObject':
                return self.GoToObject(robot_name, args[0] if args else None)
            elif action_name == 'PickupObject':
                return self.PickupObject(robot_name, args[0] if args else None)
            elif action_name == 'PutObject':
                return self.PutObject(robot_name, args[0] if args else None,
                                     args[1] if len(args) > 1 else None)
            elif action_name == 'OpenObject':
                return self.OpenObject(robot_name, args[0] if args else None)
            elif action_name == 'CloseObject':
                return self.CloseObject(robot_name, args[0] if args else None)
            elif action_name in ('SwitchOn', 'ToggleObjectOn'):
                return self.SwitchOn(robot_name, args[0] if args else None)
            elif action_name in ('SwitchOff', 'ToggleObjectOff'):
                return self.SwitchOff(robot_name, args[0] if args else None)
            elif action_name == 'BreakObject':
                return self.BreakObject(robot_name, args[0] if args else None)
            elif action_name == 'SliceObject':
                return self.SliceObject(robot_name, args[0] if args else None)
            elif action_name == 'ThrowObject':
                return self.ThrowObject(robot_name, args[0] if args else None)
            elif action_name == 'PushObject':
                return self.PushObject(robot_name, args[0] if args else None)
            elif action_name == 'PullObject':
                return self.PullObject(robot_name, args[0] if args else None)
            elif action_name == 'DropHandObject':
                return self.DropHandObject(robot_name)
            else:
                logger.warning(f"Unknown action: {action_name}")
                return False

        except Exception as e:
            logger.error(f"Error executing {action_name}: {e}")
            return False

    def GoToObject(self, robot: str, dest_obj: str) -> bool:
        """Navigate robot to object using iterative expert navigation.

        Multi-phase approach :
          Phase 1: Step-by-step ObjectNavExpertAction loop with stall detection
          Phase 2: Teleport to nearest reachable position (fallback)
          Phase 3: Orient agent to face the target object
        """
        if not dest_obj:
            logger.error("GoToObject: No destination object specified")
            return False

        logger.info(f"Going to {dest_obj}")

        try:
            objects = self.controller.last_event.metadata.get("objects", [])

            dest_obj_id = None
            dest_obj_data = None

            for obj in objects:
                if re.match(dest_obj, obj["objectId"], re.IGNORECASE):
                    dest_obj_id = obj["objectId"]
                    dest_obj_data = obj
                    break

            if not dest_obj_id:
                # Check human stand-in positions before giving up
                human_pos = self._lookup_human_position(dest_obj)
                if human_pos:
                    logger.info(f"Object '{dest_obj}' is a human stand-in, navigating to position")
                    success = self._navigate_to_position(human_pos)
                    if success:
                        self._capture_frame(f"GoToObject({dest_obj}) - Human Stand-in", True)
                    else:
                        self._capture_frame(f"GoToObject({dest_obj}) - Human Stand-in Failed", False)
                    return success

                logger.warning(f"Object '{dest_obj}' not found in scene")
                self._capture_frame(f"GoToObject({dest_obj}) - Not Found", False)
                return False

            obj_pos = dest_obj_data["position"]

            # Phase 1: Iterative step-by-step expert navigation
            success = self._iterative_navigate_to_object(dest_obj_id, obj_pos, dest_obj)

            # Phase 2: Fallback teleport if iterative nav fails
            if not success:
                logger.info(f"Iterative navigation failed for {dest_obj}, trying fallback teleport")
                success = self._fallback_navigation(dest_obj_id, dest_obj_data, dest_obj)

            # Phase 3: Orient towards object after successful arrival
            if success:
                self._orient_towards_object(dest_obj_id, obj_pos, dest_obj)
                self._capture_frame(f"GoToObject({dest_obj}) - Complete", True)

            return success

        except Exception as e:
            logger.error(f"Error in GoToObject: {e}")
            return False

    def PickupObject(self, robot: str, pick_obj: str) -> bool:
        """Pick up an object."""
        if not pick_obj:
            logger.error("PickupObject: No object specified")
            return False

        try:
            objects = self.controller.last_event.metadata.get("objects", [])

            pick_obj_id = None
            for obj in objects:
                if re.match(pick_obj, obj["objectId"], re.IGNORECASE):
                    pick_obj_id = obj["objectId"]
                    break

            if not pick_obj_id:
                logger.warning(f"Object '{pick_obj}' not found")
                return False

            self._look_at_target(pick_obj_id)

            event = self.step_render(
                action="PickupObject",
                objectId=pick_obj_id,
                forceAction=True
            )

            success = event.metadata.get("lastActionSuccess", False)
            if success:
                logger.info(f"Picked up {pick_obj}")
                self._capture_frame(f"PickupObject({pick_obj})", True)
            else:
                logger.warning(f"Failed to pickup {pick_obj}: {event.metadata.get('errorMessage')}")
                self._capture_frame(f"PickupObject({pick_obj})", False)

            return success

        except Exception as e:
            logger.error(f"Error in PickupObject: {e}")
            return False

    def PutObject(self, robot: str, put_obj: str, receptacle: str) -> bool:
        """
        Put object on/in receptacle.

        Picks the nearest matching receptacle by distance from the agent,
        preventing placement on the wrong instance when multiple exist
        (e.g., two CounterTops).
        """
        if not receptacle:
            logger.error("PutObject: No receptacle specified")
            return False

        try:
            metadata = self.controller.last_event.metadata
            objects = metadata.get("objects", [])

            # Step 1: Verify robot is holding an object
            inventory = metadata.get("inventoryObjects", [])
            if not inventory:
                logger.warning("PutObject: Robot is not holding any object")
                self._capture_frame(f"PutObject({put_obj}, {receptacle}) - Nothing held", False)
                return False

            held_object_id = inventory[0]["objectId"]
            logger.info(f"Robot is holding: {held_object_id}")

            # Step 2: Find NEAREST matching receptacle using AI2-THOR's built-in
            # distance field (accounts for walls and reachability, unlike
            # Euclidean distance which ignores obstacles)
            receptacle_obj = None
            min_dist = float('inf')

            for obj in objects:
                if re.match(receptacle, obj["objectId"], re.IGNORECASE):
                    dist = obj.get("distance", float('inf'))
                    if dist < min_dist:
                        min_dist = dist
                        receptacle_obj = obj

            if not receptacle_obj:
                logger.warning(f"Receptacle '{receptacle}' not found")
                self._capture_frame(f"PutObject({put_obj}, {receptacle}) - Not found", False)
                return False

            receptacle_id = receptacle_obj["objectId"]
            logger.info(f"Found nearest receptacle: {receptacle_id} ({min_dist:.2f}m away)")

            self._look_at_target(receptacle_id)

            # Step 3: Auto-open receptacle if it's openable and currently closed
            if receptacle_obj.get("openable", False) and not receptacle_obj.get("isOpen", False):
                logger.info(f"Auto-opening {receptacle} before placing")
                open_event = self.step_render(
                    action="OpenObject",
                    objectId=receptacle_id,
                    forceAction=True
                )
                if open_event.metadata.get("lastActionSuccess"):
                    logger.info(f"Successfully opened {receptacle}")
                    self._capture_frame(f"Auto-open {receptacle}", True)
                else:
                    logger.warning(f"Failed to auto-open {receptacle}: {open_event.metadata.get('errorMessage')}")
                    # Continue anyway - the put might still work with forceAction

            # Step 4: Put object in receptacle
            # Note: AI2-THOR PutObject takes objectId as the RECEPTACLE
            # and automatically puts whatever the agent is holding into it
            event = self.step_render(
                action="PutObject",
                objectId=receptacle_id,
                forceAction=True
            )

            success = event.metadata.get("lastActionSuccess", False)
            if success:
                logger.info(f"Put {put_obj} on {receptacle}")
                self._capture_frame(f"PutObject({put_obj}, {receptacle})", True)
            else:
                error_msg = event.metadata.get('errorMessage', 'Unknown error')
                logger.warning(f"Failed to put on {receptacle}: {error_msg}")
                self._capture_frame(f"PutObject({put_obj}, {receptacle})", False)

            return success

        except Exception as e:
            logger.error(f"Error in PutObject: {e}")
            return False

    def OpenObject(self, robot: str, obj_name: str) -> bool:
        """Open an object (door, drawer, etc.)."""
        if not obj_name:
            return False

        try:
            objects = self.controller.last_event.metadata.get("objects", [])

            target_id = None
            for obj in objects:
                if re.match(obj_name, obj["objectId"], re.IGNORECASE):
                    if obj.get("openable", False):
                        target_id = obj["objectId"]
                        break

            if not target_id:
                logger.warning(f"Openable object '{obj_name}' not found")
                return False

            self._look_at_target(target_id)

            event = self.step_render(
                action="OpenObject",
                objectId=target_id,
                forceAction=True
            )

            success = event.metadata.get("lastActionSuccess", False)
            if success:
                logger.info(f"Opened {obj_name}")
                self._capture_frame(f"OpenObject({obj_name})", True)
            else:
                logger.warning(f"Failed to open {obj_name}: {event.metadata.get('errorMessage')}")
                self._capture_frame(f"OpenObject({obj_name})", False)

            return success

        except Exception as e:
            logger.error(f"Error in OpenObject: {e}")
            return False

    def CloseObject(self, robot: str, obj_name: str) -> bool:
        """Close an object."""
        if not obj_name:
            return False

        try:
            objects = self.controller.last_event.metadata.get("objects", [])

            target_id = None
            for obj in objects:
                if re.match(obj_name, obj["objectId"], re.IGNORECASE):
                    if obj.get("openable", False):
                        target_id = obj["objectId"]
                        break

            if not target_id:
                logger.warning(f"Closeable object '{obj_name}' not found")
                return False

            self._look_at_target(target_id)

            event = self.step_render(
                action="CloseObject",
                objectId=target_id,
                forceAction=True
            )

            success = event.metadata.get("lastActionSuccess", False)
            if success:
                logger.info(f"Closed {obj_name}")
                self._capture_frame(f"CloseObject({obj_name})", True)
            else:
                logger.warning(f"Failed to close {obj_name}: {event.metadata.get('errorMessage')}")
                self._capture_frame(f"CloseObject({obj_name})", False)

            return success

        except Exception as e:
            logger.error(f"Error in CloseObject: {e}")
            return False

    def SwitchOn(self, robot: str, obj_name: str) -> bool:
        """Turn on an appliance."""
        if not obj_name:
            return False

        try:
            objects = self.controller.last_event.metadata.get("objects", [])

            target_id = None
            for obj in objects:
                if re.match(obj_name, obj["objectId"], re.IGNORECASE):
                    if obj.get("toggleable", False):
                        target_id = obj["objectId"]
                        break

            if not target_id:
                logger.warning(f"Toggleable object '{obj_name}' not found")
                return False

            self._look_at_target(target_id)

            event = self.step_render(
                action="ToggleObjectOn",
                objectId=target_id,
                forceAction=True
            )

            success = event.metadata.get("lastActionSuccess", False)
            if success:
                logger.info(f"Switched on {obj_name}")
                self._capture_frame(f"SwitchOn({obj_name})", True)
            else:
                logger.warning(f"Failed to switch on {obj_name}: {event.metadata.get('errorMessage')}")
                self._capture_frame(f"SwitchOn({obj_name})", False)

            return success

        except Exception as e:
            logger.error(f"Error in SwitchOn: {e}")
            return False

    def SwitchOff(self, robot: str, obj_name: str) -> bool:
        """Turn off an appliance."""
        if not obj_name:
            return False

        try:
            objects = self.controller.last_event.metadata.get("objects", [])

            target_id = None
            for obj in objects:
                if re.match(obj_name, obj["objectId"], re.IGNORECASE):
                    if obj.get("toggleable", False):
                        target_id = obj["objectId"]
                        break

            if not target_id:
                logger.warning(f"Toggleable object '{obj_name}' not found")
                return False

            self._look_at_target(target_id)

            event = self.step_render(
                action="ToggleObjectOff",
                objectId=target_id,
                forceAction=True
            )

            success = event.metadata.get("lastActionSuccess", False)
            if success:
                logger.info(f"Switched off {obj_name}")
                self._capture_frame(f"SwitchOff({obj_name})", True)
            else:
                logger.warning(f"Failed to switch off {obj_name}: {event.metadata.get('errorMessage')}")
                self._capture_frame(f"SwitchOff({obj_name})", False)

            return success

        except Exception as e:
            logger.error(f"Error in SwitchOff: {e}")
            return False

    def BreakObject(self, robot: str, obj_name: str) -> bool:
        """Break an object."""
        if not obj_name:
            return False

        try:
            objects = self.controller.last_event.metadata.get("objects", [])

            target_id = None
            for obj in objects:
                if re.match(obj_name, obj["objectId"], re.IGNORECASE):
                    if obj.get("breakable", False):
                        target_id = obj["objectId"]
                        break

            if not target_id:
                logger.warning(f"Breakable object '{obj_name}' not found")
                return False

            self._look_at_target(target_id)

            event = self.step_render(
                action="BreakObject",
                objectId=target_id,
                forceAction=True
            )

            success = event.metadata.get("lastActionSuccess", False)
            if success:
                logger.info(f"Broke {obj_name}")
                self._capture_frame(f"BreakObject({obj_name})", True)
            else:
                logger.warning(f"Failed to break {obj_name}: {event.metadata.get('errorMessage')}")
                self._capture_frame(f"BreakObject({obj_name})", False)

            return success

        except Exception as e:
            logger.error(f"Error in BreakObject: {e}")
            return False

    def SliceObject(self, robot: str, obj_name: str) -> bool:
        """Slice an object."""
        if not obj_name:
            return False

        try:
            objects = self.controller.last_event.metadata.get("objects", [])

            target_id = None
            for obj in objects:
                if re.match(obj_name, obj["objectId"], re.IGNORECASE):
                    if obj.get("sliceable", False):
                        target_id = obj["objectId"]
                        break

            if not target_id:
                logger.warning(f"Sliceable object '{obj_name}' not found")
                return False

            self._look_at_target(target_id)

            event = self.step_render(
                action="SliceObject",
                objectId=target_id,
                forceAction=True
            )

            success = event.metadata.get("lastActionSuccess", False)
            if success:
                logger.info(f"Sliced {obj_name}")
                self._capture_frame(f"SliceObject({obj_name})", True)
            else:
                logger.warning(f"Failed to slice {obj_name}: {event.metadata.get('errorMessage')}")
                self._capture_frame(f"SliceObject({obj_name})", False)

            return success

        except Exception as e:
            logger.error(f"Error in SliceObject: {e}")
            return False

    def ThrowObject(self, robot: str, obj_name: str) -> bool:
        """Throw an object."""
        result = self.DropHandObject(robot)
        self._capture_frame(f"ThrowObject({obj_name})", result)
        return result

    def PushObject(self, robot: str, obj_name: str) -> bool:
        """Push an object."""
        if not obj_name:
            return False

        try:
            objects = self.controller.last_event.metadata.get("objects", [])

            target_id = None
            for obj in objects:
                if re.match(obj_name, obj["objectId"], re.IGNORECASE):
                    if obj.get("moveable", False) or obj.get("pickupable", False):
                        target_id = obj["objectId"]
                        break

            if not target_id:
                logger.warning(f"Pushable object '{obj_name}' not found")
                return False

            self._look_at_target(target_id)

            event = self.step_render(
                action="PushObject",
                objectId=target_id,
                forceAction=True
            )

            success = event.metadata.get("lastActionSuccess", False)
            if success:
                logger.info(f"Pushed {obj_name}")
                self._capture_frame(f"PushObject({obj_name})", True)
            else:
                logger.warning(f"Failed to push {obj_name}: {event.metadata.get('errorMessage')}")
                self._capture_frame(f"PushObject({obj_name})", False)

            return success

        except Exception as e:
            logger.error(f"Error in PushObject: {e}")
            return False

    def PullObject(self, robot: str, obj_name: str) -> bool:
        """Pull an object."""
        if not obj_name:
            return False

        try:
            objects = self.controller.last_event.metadata.get("objects", [])

            target_id = None
            for obj in objects:
                if re.match(obj_name, obj["objectId"], re.IGNORECASE):
                    if obj.get("moveable", False) or obj.get("pickupable", False):
                        target_id = obj["objectId"]
                        break

            if not target_id:
                logger.warning(f"Pullable object '{obj_name}' not found")
                return False

            self._look_at_target(target_id)

            event = self.step_render(
                action="PullObject",
                objectId=target_id,
                forceAction=True
            )

            success = event.metadata.get("lastActionSuccess", False)
            if success:
                logger.info(f"Pulled {obj_name}")
                self._capture_frame(f"PullObject({obj_name})", True)
            else:
                logger.warning(f"Failed to pull {obj_name}: {event.metadata.get('errorMessage')}")
                self._capture_frame(f"PullObject({obj_name})", False)

            return success

        except Exception as e:
            logger.error(f"Error in PullObject: {e}")
            return False

    def DropHandObject(self, robot: str) -> bool:
        """Drop currently held object."""
        try:
            event = self.step_render(
                action="DropHandObject",
                forceAction=True
            )

            success = event.metadata.get("lastActionSuccess", False)
            if success:
                logger.info("Dropped held object")
                self._capture_frame("DropHandObject()", True)
            else:
                logger.warning(f"Failed to drop object: {event.metadata.get('errorMessage')}")
                self._capture_frame("DropHandObject()", False)

            return success

        except Exception as e:
            logger.error(f"Error in DropHandObject: {e}")
            return False

    def get_scene_objects(self) -> List[str]:
        """Get list of all objects currently in the scene."""
        try:
            objects = self.controller.last_event.metadata.get("objects", [])
            return [obj["objectType"] for obj in objects]
        except Exception as e:
            logger.error(f"Error getting scene objects: {e}")
            return []

    def get_scene_object_details(self) -> List[Dict]:
        """Get detailed information about all objects in the scene."""
        try:
            objects = self.controller.last_event.metadata.get("objects", [])
            return [{
                'objectId': obj['objectId'],
                'objectType': obj['objectType'],
                'position': obj.get('position'),
                'pickupable': obj.get('pickupable', False),
                'openable': obj.get('openable', False),
                'toggleable': obj.get('toggleable', False),
                'breakable': obj.get('breakable', False),
                'sliceable': obj.get('sliceable', False),
                'isOpen': obj.get('isOpen', False),
                'isToggled': obj.get('isToggled', False),
                'isBroken': obj.get('isBroken', False),
                'temperature': obj.get('temperature', 'RoomTemp'),
            } for obj in objects]
        except Exception as e:
            logger.error(f"Error getting scene object details: {e}")
            return []

    def get_robot_state(self) -> Dict:
        """Get current robot state including position and held object."""
        try:
            metadata = self.controller.last_event.metadata
            agent = metadata.get("agent", {})

            return {
                'position': agent.get('position'),
                'rotation': agent.get('rotation'),
                'held_object': metadata.get('inventoryObjects', [None])[0] if metadata.get('inventoryObjects') else None,
                'reachable_positions': len(self.reachable_positions)
            }
        except Exception as e:
            logger.error(f"Error getting robot state: {e}")
            return {}
