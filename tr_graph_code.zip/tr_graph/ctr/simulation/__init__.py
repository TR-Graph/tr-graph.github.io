# ctr/simulation/__init__.py
"""
TR-Graph Simulation Module

Provides AI2-THOR integration for executing TR-Graph-repaired tasks.

Components:
- AI2THORActionExecutor: Execute robot actions in AI2-THOR
- TRGraphExecutionAdapter: Dialect-aware execution with CanonicalAction IR
- CodeGenerator: Generate executable code from task descriptions
- TaskExecutor: Orchestrate task execution
- VideoRecorder: Record execution videos

Usage:
    from ctr.simulation import TaskExecutor

    executor = TaskExecutor(use_ai2thor=True, scene="FloorPlan1")
    result = executor.execute_task(repaired_task_variables)
"""

from ctr.simulation.ai2thor_actions import AI2THORActionExecutor
from ctr.simulation.code_generator import CodeGenerator
from ctr.simulation.task_executor import TaskExecutor, ExecutionResult
from ctr.simulation.execution_adapter import (
    TRGraphExecutionAdapter,
    CanonicalAction,
    ExecutionOutcome,
)
# Video recorder is optional (requires ffmpeg)
try:
    from ctr.simulation.video_recorder import VideoRecorder
    HAS_VIDEO = True
except ImportError:
    VideoRecorder = None
    HAS_VIDEO = False

__all__ = [
    "AI2THORActionExecutor",
    "TRGraphExecutionAdapter",
    "CanonicalAction",
    "ExecutionOutcome",
    "CodeGenerator",
    "TaskExecutor",
    "ExecutionResult",
    "VideoRecorder",
    "HAS_VIDEO",
]
