# ctr/simulation/video_recorder.py
"""
Video recording module for AI2-THOR task execution.

Records multi-view videos of AI2-THOR task execution.
Creates: agent.mp4, topdown.mp4, composite.mp4
"""

import subprocess
import shutil
from pathlib import Path
from typing import Dict, List, Optional
import logging

logger = logging.getLogger(__name__)

# Optional imports
try:
    import numpy as np
    from PIL import Image
    HAS_IMAGING = True
except ImportError:
    HAS_IMAGING = False
    logger.warning("numpy/PIL not available - video recording disabled")


class VideoRecorder:
    """
    Record multi-view videos of AI2-THOR execution.

    Creates three video streams:
    - agent.mp4: First-person view from robot
    - topdown.mp4: Overhead orthographic view
    - composite.mp4: Side-by-side view
    """

    def __init__(self, controller, session_id: str, config: dict = None):
        """
        Initialize video recorder.

        Args:
            controller: AI2-THOR controller
            session_id: Unique session identifier
            config: Optional configuration dict
        """
        if not HAS_IMAGING:
            raise RuntimeError("Video recording requires numpy and PIL")

        self.controller = controller
        self.session_id = session_id
        self.config = config or {}
        self.base_dir = Path(self.config.get("output_dir", "data/videos")) / session_id
        self.base_dir.mkdir(parents=True, exist_ok=True)

        self._topdown_id: Optional[int] = None
        self._writers_open = False
        self._fps = int(self.config.get("fps", 1))
        self._agent_size = None
        self._topdown_size = None
        self._composite_size = None

        self._ff_agent = None
        self._ff_top = None
        self._ff_comp = None

        self._target_h = int(self.config.get("target_height", 720))

        self.frame_count = 0

        self._frame_buffer = {'agent': [], 'topdown': [], 'composite': []}
        self._save_frames = self.config.get("export_gifs", True)

    def notify_scene_reset(self):
        """Must be called right after any controller.reset(...)."""
        self._topdown_id = None

    def setup_camera_after_scene_load(self, event=None):
        """
        Create a static orthographic top-down camera once per scene load.
        """
        self._ensure_topdown_camera_static(event)

        tp = getattr(self.controller.last_event, "third_party_camera_frames", None) or \
            getattr(self.controller.last_event, "third_party_frames", None)
        if not tp:
            raise RuntimeError("Top-down frames missing after AddThirdPartyCamera")

    def _ensure_topdown_camera_static(self, event=None):
        """Create static orthographic top-down camera."""
        if self._topdown_id is not None:
            return

        cx = cz = 0.0
        half_x = half_z = 5.0
        y_inside = 1.75

        if event is not None:
            sb = event.metadata.get("sceneBounds") or {}
            center = sb.get("center") or {}
            size = sb.get("size") or {}

            if center and size:
                cx = float(center.get("x", 0.0))
                cz = float(center.get("z", 0.0))
                half_x = float(size.get("x", 10.0)) / 2.0
                half_z = float(size.get("z", 10.0)) / 2.0

                cy = float(center.get("y", 0.0))
                half_y = float(size.get("y", 3.0)) / 2.0
                y_inside = cy + half_y - 0.05
            else:
                try:
                    rp = event.metadata.get("reachablePositions") or []
                    if rp:
                        cx = sum(p["x"] for p in rp) / len(rp)
                        cz = sum(p["z"] for p in rp) / len(rp)
                        xs = [p["x"] for p in rp]
                        zs = [p["z"] for p in rp]
                        span_x = max(xs) - min(xs)
                        span_z = max(zs) - min(zs)
                        half_x = span_x / 2.0
                        half_z = span_z / 2.0
                        y_inside = float(self.config.get("minimap_height", 1.75))
                except Exception:
                    pass

        y_inside = max(1.5, min(2.2, y_inside))
        ortho_size = max(2.2, min(6.5, max(half_x, half_z) * 0.80))

        td_event = self.controller.step(
            action="AddThirdPartyCamera",
            position={"x": cx, "y": y_inside, "z": cz},
            rotation={"x": 90.0, "y": 0.0, "z": 0.0},
            orthographic=True,
            orthographicSize=float(ortho_size),
            nearClippingPlane=0.02,
            farClippingPlane=15.0,
            renderImage=True,
        )

        cams = td_event.metadata.get("thirdPartyCameras", [])
        if not cams:
            raise RuntimeError("Failed to add third-party camera.")
        self._topdown_id = cams[-1].get("id", 0)

    @staticmethod
    def _get_topdown_frame_from_event(event):
        """Get top-down frame from event."""
        tp = getattr(event, "third_party_camera_frames", None)
        if tp is None:
            tp = getattr(event, "third_party_frames", None)
        if not tp:
            raise RuntimeError("Top-down frame not present")
        return tp[0]

    @staticmethod
    def _resize_to_height(img_np, target_h: int):
        """Resize image to target height."""
        im = Image.fromarray(img_np)
        w = int(round(im.width * (target_h / im.height)))
        im = im.resize((w, target_h), Image.BICUBIC)
        return np.asarray(im)

    @staticmethod
    def _compose_side_by_side(left_np, right_np):
        """Compose two images side by side."""
        L = Image.fromarray(left_np)
        R = Image.fromarray(right_np)
        h = min(L.height, R.height)
        if L.height != h:
            L = L.resize((int(L.width * h / L.height), h), Image.BICUBIC)
        if R.height != h:
            R = R.resize((int(R.width * h / R.height), h), Image.BICUBIC)
        out = Image.new("RGB", (L.width + R.width, h))
        out.paste(L, (0, 0))
        out.paste(R, (L.width, 0))
        return np.asarray(out)

    @staticmethod
    def _ffmpeg_exists() -> bool:
        """Check if ffmpeg is available."""
        return shutil.which("ffmpeg") is not None

    @staticmethod
    def _spawn_ffmpeg(path: Path, w: int, h: int, fps: int):
        """Spawn ffmpeg process for video encoding."""
        cmd = [
            "ffmpeg", "-y",
            "-f", "rawvideo",
            "-pix_fmt", "rgb24",
            "-s", f"{w}x{h}",
            "-r", str(fps),
            "-i", "pipe:0",
            "-vcodec", "libx264",
            "-pix_fmt", "yuv420p",
            "-preset", "veryfast",
            "-crf", "20",
            str(path),
        ]
        return subprocess.Popen(cmd, stdin=subprocess.PIPE, stderr=subprocess.PIPE)

    def _open_writers(self, agent_frame, top_frame, comp_frame):
        """Open video writers."""
        if not self._ffmpeg_exists():
            raise RuntimeError("ffmpeg not found on PATH")

        aw, ah = agent_frame.shape[1], agent_frame.shape[0]
        tw, th = top_frame.shape[1], top_frame.shape[0]
        cw, ch = comp_frame.shape[1], comp_frame.shape[0]
        self._agent_size = (aw, ah)
        self._topdown_size = (tw, th)
        self._composite_size = (cw, ch)

        self._ff_agent = self._spawn_ffmpeg(self.base_dir / "agent.mp4", aw, ah, self._fps)
        self._ff_top = self._spawn_ffmpeg(self.base_dir / "topdown.mp4", tw, th, self._fps)
        self._ff_comp = self._spawn_ffmpeg(self.base_dir / "composite.mp4", cw, ch, self._fps)
        self._writers_open = True
        logger.info(f"Opened writers: agent={aw}x{ah}, top={tw}x{th}, fps={self._fps}")

    def _write_frame(self, proc, frame_np):
        """Write frame to ffmpeg process."""
        if proc and proc.stdin:
            try:
                proc.stdin.write(frame_np.astype(np.uint8).tobytes())
            except BrokenPipeError:
                logger.error("FFmpeg pipe broken")

    def _close_writers(self):
        """Close all video writers."""
        for p in (self._ff_agent, self._ff_top, self._ff_comp):
            if p is not None:
                try:
                    if p.stdin:
                        p.stdin.flush()
                        p.stdin.close()
                    p.wait(timeout=10)
                except Exception as e:
                    logger.warning(f"Error closing ffmpeg: {e}")
        self._ff_agent = self._ff_top = self._ff_comp = None
        self._writers_open = False
        logger.info("Closed all video writers.")

    def start_episode(self):
        """Start recording episode."""
        if self._topdown_id is None:
            raise RuntimeError("Camera not initialized")

    def record_step(self, event):
        """Record a single step."""
        agent_np = event.frame

        tp = getattr(event, "third_party_camera_frames", None) or \
             getattr(event, "third_party_frames", None)
        if not tp:
            raise RuntimeError("Top-down frames missing")

        try:
            top_np = self._get_topdown_frame_from_event(event)
        except RuntimeError:
            top_np = agent_np

        agent_np = self._resize_to_height(agent_np, self._target_h)
        top_np = self._resize_to_height(top_np, self._target_h)
        comp_np = self._compose_side_by_side(agent_np, top_np)

        if not self._writers_open:
            self._open_writers(agent_np, top_np, comp_np)

        self._write_frame(self._ff_agent, agent_np)
        self._write_frame(self._ff_top, top_np)
        self._write_frame(self._ff_comp, comp_np)

        if self._save_frames:
            self._frame_buffer['agent'].append(Image.fromarray(agent_np))
            self._frame_buffer['topdown'].append(Image.fromarray(top_np))
            self._frame_buffer['composite'].append(Image.fromarray(comp_np))

        self.frame_count += 1

    def end_episode(self):
        """End recording episode."""
        if self._writers_open:
            self._close_writers()

    def compile_gifs(self) -> List[str]:
        """Compile buffered frames into GIFs."""
        gifs_created = []

        if not self._save_frames:
            return gifs_created

        for view_name, frames in self._frame_buffer.items():
            if not frames:
                continue

            try:
                output_path = self.base_dir / f"{view_name}.gif"
                duration_ms = int(1000 / self._fps)

                rgb_frames = []
                for frame in frames:
                    if frame.mode != 'RGB':
                        rgb_frames.append(frame.convert('RGB'))
                    else:
                        rgb_frames.append(frame)

                rgb_frames[0].save(
                    output_path,
                    save_all=True,
                    append_images=rgb_frames[1:],
                    duration=duration_ms,
                    loop=0,
                    optimize=True
                )

                if output_path.exists():
                    gifs_created.append(str(output_path))
                    logger.info(f"Created {view_name}.gif")

            except Exception as e:
                logger.error(f"Failed to compile {view_name} GIF: {e}")

        return gifs_created

    def _update_overhead_follow(self):
        """Backward compatibility - no-op for static camera."""
        pass

    def capture_frame(self, action_name: str = "", success: bool = True):
        """Backward compatibility wrapper."""
        event = self.controller.last_event

        if not self._writers_open and self._topdown_id is None:
            self.start_episode()

        self.record_step(event)

    def finalize(self) -> Dict:
        """Finalize recording and return results."""
        self.end_episode()
        gifs = self.compile_gifs()
        self._frame_buffer = {'agent': [], 'topdown': [], 'composite': []}

        videos = []
        for filename in ["agent.mp4", "topdown.mp4", "composite.mp4"]:
            video_path = self.base_dir / filename
            if video_path.exists():
                videos.append(str(video_path))

        duration = self.frame_count / self._fps if self.frame_count > 0 else 0

        result = {
            'session_id': self.session_id,
            'videos': videos,
            'gifs': gifs,
            'output_folder': str(self.base_dir),
            'total_frames': self.frame_count,
            'duration': duration,
        }

        logger.info(f"Recording finalized: {len(videos)} videos, {len(gifs)} GIFs")
        return result
