"""
Trace serialization utilities for reviewer artifact export.

Converts dataclass/enum objects to clean JSON-ready dicts and
prunes empty fields so traces read as curated scientific output
rather than raw Python debug dumps.
"""

import dataclasses
import enum
from typing import Any, Dict


# Default values per property dataclass — fields matching these are pruned.
_OBJECT_DEFAULTS = {
    'temperature': None, 'sharpness': None, 'mass': None, 'state': None,
    'affordances': set(), 'hazard_level': 'none', 'child_safe': True,
    'material': None, 'fragile': False, 'consumable': False,
    'contains': None, 'capacity': None,
}

_PERSON_DEFAULTS = {
    'age': None, 'age_group': None, 'name': None,
    'physical_capability': 'normal', 'cognitive_capability': 'normal',
    'safety_awareness': 'medium', 'allergies': set(),
    'mobility_limited': False, 'requires_supervision': False,
}

_AGENT_DEFAULTS = {
    'reach_distance': 1.0, 'gripper_capacity': 5.0,
    'current_holding': None, 'battery_level': 1.0,
}

_REGION_DEFAULTS = {
    'region_type': '', 'accessible': True, 'hazardous': False, 'bounds': None,
}


def serialize_trace_object(obj: Any) -> Any:
    """Convert dataclass/enum objects to clean JSON-ready dicts.

    Rules:
      - Dataclasses → dict (strip class names)
      - Enums → string value
      - Sets → sorted lists
      - None fields → omitted
      - Default-valued fields → omitted (for known property types)
      - Floats → rounded to 4 decimal places
      - Recursively applied to nested structures
    """
    if obj is None:
        return None

    if isinstance(obj, enum.Enum):
        return obj.value

    if isinstance(obj, set):
        return sorted(str(x) for x in obj) if obj else None

    if isinstance(obj, float):
        return round(obj, 4)

    if isinstance(obj, (int, str, bool)):
        return obj

    if isinstance(obj, bytes):
        return obj.decode('utf-8', errors='replace')

    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        result = {}
        defaults = _get_defaults_for(obj)
        for f in dataclasses.fields(obj):
            val = getattr(obj, f.name)
            serialized = serialize_trace_object(val)
            # Skip None and empty collections
            if serialized is None:
                continue
            if isinstance(serialized, (list, dict)) and len(serialized) == 0:
                continue
            # Skip default values for known property types
            if defaults and f.name in defaults:
                default_val = defaults[f.name]
                if isinstance(default_val, set):
                    default_val = sorted(str(x) for x in default_val) if default_val else None
                elif isinstance(default_val, enum.Enum):
                    default_val = default_val.value
                if serialized == default_val:
                    continue
            result[f.name] = serialized
        # Return empty dict (not None) for dataclasses — the object exists,
        # it just has all default values.
        return result

    if isinstance(obj, dict):
        result = {}
        for k, v in obj.items():
            serialized = serialize_trace_object(v)
            if serialized is not None:
                result[str(k)] = serialized
        return result if result else None

    if isinstance(obj, (list, tuple)):
        items = [serialize_trace_object(x) for x in obj]
        items = [x for x in items if x is not None]
        return items if items else None

    # Fallback: try str() but flag it
    return str(obj)


def _get_defaults_for(obj) -> Dict[str, Any]:
    """Return the default-value dict for known property dataclasses."""
    cls_name = type(obj).__name__
    return {
        'ObjectProperties': _OBJECT_DEFAULTS,
        'PersonProperties': _PERSON_DEFAULTS,
        'AgentProperties': _AGENT_DEFAULTS,
        'RegionProperties': _REGION_DEFAULTS,
    }.get(cls_name, {})


def prune_empty_fields(obj: Any) -> Any:
    """Remove null, empty string, empty list, empty dict fields recursively.

    Applied as a post-processing pass on trace data before saving.
    """
    if isinstance(obj, dict):
        result = {}
        for k, v in obj.items():
            pruned = prune_empty_fields(v)
            if pruned is None:
                continue
            if isinstance(pruned, str) and pruned == '':
                continue
            if isinstance(pruned, (list, dict)) and len(pruned) == 0:
                continue
            result[k] = pruned
        return result if result else None

    if isinstance(obj, list):
        items = [prune_empty_fields(x) for x in obj]
        items = [x for x in items if x is not None]
        return items if items else None

    return obj


def round_floats(obj: Any, decimals: int = 3) -> Any:
    """Walk JSON tree and round all floats."""
    if isinstance(obj, float):
        return round(obj, decimals)
    if isinstance(obj, dict):
        return {k: round_floats(v, decimals) for k, v in obj.items()}
    if isinstance(obj, list):
        return [round_floats(v, decimals) for v in obj]
    return obj


def compress_scene_edges(edges: list) -> dict:
    """Group uniform edges by type, show unique spatial relations individually.

    Transforms a flat list of edges into a structured summary that
    collapses repetitive located_in/reachable_by edges while preserving
    interesting spatial relations.
    """
    if not edges:
        return {"edge_summary": "0 edges", "edges_by_type": {}}

    # Group edges by relation type
    by_type = {}
    for e in edges:
        rel = e.get('relation', 'unknown')
        by_type.setdefault(rel, []).append(e)

    # Uniform edge types: all share the same target
    uniform_types = {'located_in', 'reachable_by'}
    result = {}
    spatial_relations = []
    counts = []

    for rel, group in sorted(by_type.items()):
        if rel in uniform_types and len(group) > 1:
            targets = set(e.get('target', '') for e in group)
            if len(targets) == 1:
                target = targets.pop()
                result[rel] = {
                    "count": len(group),
                    "target": target,
                    "objects": [e.get('source', '') for e in group],
                }
                prov = group[0].get('provenance', '')
                if prov:
                    result[rel]["provenance"] = prov
                counts.append(f"{len(group)} {rel}")
                continue
        # Spatial or non-uniform: keep individually
        for e in group:
            entry = {
                "source": e.get('source', ''),
                "target": e.get('target', ''),
                "relation": rel,
            }
            if e.get('confidence') is not None:
                entry["confidence"] = e['confidence']
            if e.get('provenance'):
                entry["provenance"] = e['provenance']
            spatial_relations.append(entry)
        counts.append(f"{len(group)} {rel}")

    total = sum(len(g) for g in by_type.values())
    summary = f"{total} edges: {', '.join(counts)}"

    output = {"edge_summary": summary, "edges_by_type": result}
    if spatial_relations:
        output["spatial_relations"] = spatial_relations
    return output


def collapse_diagnosis_layers(layers: dict) -> dict:
    """Collapse diagnosis layers if they share the same causal structure.

    If all layers have the same causal edges and similar decisions,
    show a shared summary with per-layer decisions only.
    If layers genuinely differ, show them individually.
    """
    if not layers:
        return layers

    decisions = {}
    edge_sets = {}
    for name, layer in layers.items():
        if not isinstance(layer, dict):
            return {"mode": "distinct", "layers": layers}
        decisions[name] = layer.get('decision', '')
        edges = layer.get('causal_edges', [])
        if isinstance(edges, list):
            edge_sets[name] = frozenset(
                (e.get('from', e.get('source', '')),
                 e.get('to', e.get('target', '')))
                for e in edges if isinstance(e, dict)
            )
        else:
            edge_sets[name] = frozenset()

    all_same_edges = len(set(edge_sets.values())) <= 1
    unique_decisions = set(decisions.values())

    if all_same_edges and len(unique_decisions) <= 1:
        representative = next(iter(layers.values()))
        return {
            "mode": "collapsed",
            "shared_decision": list(decisions.values())[0],
            "shared_causal_edges": representative.get('causal_edges', []),
            "per_layer": {
                name: {
                    "decision": layer.get('decision', ''),
                    "explanation": layer.get('explanation', ''),
                }
                for name, layer in layers.items()
            }
        }
    else:
        return {
            "mode": "distinct",
            "layers": layers,
        }


def deduplicate_weight_derivation(scored_candidates: list) -> tuple:
    """Extract shared weight derivation from scored candidates.

    Returns (shared_derivation, cleaned_candidates) where the per-candidate
    weight_derivation is removed and the shared one is returned separately.
    """
    if not scored_candidates:
        return None, scored_candidates

    derivations = [c.get('weight_derivation', {}) for c in scored_candidates]
    # Check if all derivations are identical
    if derivations and all(d == derivations[0] for d in derivations):
        shared = derivations[0]
        cleaned = []
        for i, c in enumerate(scored_candidates):
            c = dict(c)
            c.pop('weight_derivation', None)
            c['rank'] = i + 1
            cleaned.append(c)
        return shared, cleaned

    # Not identical — keep per-candidate but add rank
    ranked = []
    for i, c in enumerate(scored_candidates):
        c = dict(c)
        c['rank'] = i + 1
        ranked.append(c)
    return None, ranked


def label_operator_allocation(allocation: list, priorities=None) -> dict:
    """Convert index-ordered operator arrays to named dicts."""
    names = ["SUBSTITUTE", "CONSTRAIN", "DECOMPOSE", "RELAX", "REORDER", "RETARGET"]
    result = {}
    if allocation:
        result["candidate_allocation"] = {
            names[i]: v for i, v in enumerate(allocation) if i < len(names)
        }
    if priorities:
        result["operator_priorities"] = {
            names[i]: round(v, 4) for i, v in enumerate(priorities) if i < len(names)
        }
    return result
