"""
TR-Graph Task Repair: VLM Prompt Utilities

Provides prompt formatting functions and JSON response parsing
for Vision-Language Model interactions.
"""

from typing import Dict, Any, List, Optional, Union
import json
import logging

logger = logging.getLogger(__name__)


# GROUNDING PROMPTS

GROUNDING_SYSTEM_PROMPT = """You are a reference resolution system. Your task is to match linguistic references to specific entities in a scene.

Given a reference (like "the cup" or "Sara") and a list of candidate entities, determine which entity best matches the reference.

CRITICAL: Output ONLY valid JSON matching the specified schema."""


GROUNDING_USER_TEMPLATE = """Match this reference to an entity in the scene.

Reference: "{reference_text}"
Context: "{context}"

Candidate entities:
{candidates_json}

Output a JSON object:
{{
  "best_match_id": "id of best matching entity" or null if no good match,
  "confidence": 0.0 to 1.0,
  "reasoning": "brief explanation of why this match",
  "ambiguous": true if multiple strong candidates, false otherwise,
  "alternative_ids": ["other", "plausible", "matches"] or []
}}

Guidelines:
- Match by name if explicitly mentioned ("Sara" → person named Sara)
- Match by type and properties ("the hot coffee" → hot liquid)
- Match by context ("her cup" → cup near/associated with the person)
- Match by age group for people: "baby", "infant", "toddler" → person with age_group "infant" or "toddler"
  - "child", "kid", "little one" → person with age_group "toddler" or "child"
  - "teenager", "teen" → person with age_group "teen"
  - "elderly", "grandma", "grandpa", "senior" → person with age_group "elderly"
- If genuinely ambiguous, set ambiguous=true and list alternatives
- Confidence should reflect certainty (0.9+ for clear matches, <0.6 for uncertain)

Respond with ONLY the JSON object."""


# EXPLANATION PROMPTS

EXPLANATION_SYSTEM_PROMPT = """You are a friendly robot assistant explaining your actions to users.

When you cannot do exactly what was asked, you explain:
1. What was requested (acknowledge)
2. Why it's problematic (explain)
3. What you'll do instead (alternative)
4. Why the alternative is safe and still helpful (justify)

Be warm, clear, and concise. Don't be preachy or overly apologetic. Sound helpful, not robotic.

CRITICAL: Output ONLY valid JSON matching the specified schema."""


EXPLANATION_USER_TEMPLATE = """Generate an explanation for this repair.

Original request: "{original_request}"
Recipient: {recipient_info}

Safety violation:
- Type: {violation_type}
- Severity: {severity}
- Reason: {violation_reason}

Repair made:
- What changed: {changes_made}
- New action: {repaired_action}

Output a JSON object:
{{
  "acknowledgment": "one sentence acknowledging what was asked",
  "problem_explanation": "one sentence explaining the safety issue (be specific but not scary)",
  "repair_description": "one sentence describing what you'll do instead",
  "safety_justification": "one sentence explaining why this is safe",
  "intent_connection": "brief note connecting repair to original intent",
  "full_explanation": "complete 2-3 sentence explanation combining the above naturally",
  "tone": "friendly|apologetic|matter-of-fact"
}}

Guidelines:
- Keep it conversational, not clinical
- For children, don't blame ("Sara is too young") but focus on safety ("to keep Sara safe")
- Connect the repair to what they wanted ("she'll still get her drink")
- Be concise - users don't want a lecture

Respond with ONLY the JSON object."""


# MULTI-OPTION EXPLANATION PROMPTS

MULTI_OPTION_EXPLANATION_SYSTEM_PROMPT = """You are a friendly robot assistant presenting safe alternatives to users.

When you cannot do exactly what was asked, you:
1. Acknowledge what was requested
2. Briefly explain the safety concern
3. Present 2 safe alternatives with brief rationales
4. Ask the user which they prefer

Be warm, helpful, and concise. Frame options positively. Don't lecture about safety.

CRITICAL: Output ONLY valid JSON matching the specified schema."""


MULTI_OPTION_EXPLANATION_USER_TEMPLATE = """Generate a multi-option explanation for these repair alternatives.

Original request: "{original_request}"
Recipient: {recipient_info}

Safety concern: {safety_concern}

Option A:
- Description: {option_a_description}
- What changed: {option_a_changes}

Option B:
- Description: {option_b_description}
- What changed: {option_b_changes}

Output a JSON object:
{{
  "acknowledgment": "brief acknowledgment of what was asked",
  "safety_concern_brief": "one short phrase explaining the concern (e.g., 'hot liquids could burn a toddler')",
  "option_a_brief": "concise description for Option A (e.g., 'Pour lukewarm coffee into a sippy cup for Sara')",
  "option_a_rationale": "brief safety rationale in parentheses (e.g., 'so they can drink it safely')",
  "option_b_brief": "concise description for Option B",
  "option_b_rationale": "brief safety rationale in parentheses",
  "full_explanation": "complete explanation combining acknowledgment, concern, options, and question"
}}

Guidelines:
- Keep descriptions action-focused (start with verb)
- Rationales should be brief (4-8 words)
- The full_explanation should follow this format:
  "I noticed you asked me to [original]. Since [concern], here are some safe alternatives:

  Option A: [description]
            ([rationale])
  Option B: [description]
            ([rationale])

  Would you like me to proceed with Option A, Option B, or would you like to specify a different task for me to complete?"

Respond with ONLY the JSON object."""


# FORMAT FUNCTIONS

def format_grounding_prompt(
    reference_text: str,
    context: str,
    candidates: List[Dict[str, Any]]
) -> tuple[str, str]:
    """Format the grounding prompt. Returns (system_prompt, user_prompt)."""
    candidates_json = json.dumps(candidates, indent=2)
    user_prompt = GROUNDING_USER_TEMPLATE.format(
        reference_text=reference_text,
        context=context,
        candidates_json=candidates_json
    )
    return GROUNDING_SYSTEM_PROMPT, user_prompt


def format_explanation_prompt(
    original_request: str,
    recipient_info: str,
    violation_type: str,
    severity: str,
    violation_reason: str,
    changes_made: str,
    repaired_action: str
) -> tuple[str, str]:
    """Format the explanation generation prompt. Returns (system_prompt, user_prompt)."""
    user_prompt = EXPLANATION_USER_TEMPLATE.format(
        original_request=original_request,
        recipient_info=recipient_info,
        violation_type=violation_type,
        severity=severity,
        violation_reason=violation_reason,
        changes_made=changes_made,
        repaired_action=repaired_action
    )
    return EXPLANATION_SYSTEM_PROMPT, user_prompt


def format_multi_option_explanation_prompt(
    original_request: str,
    recipient_info: str,
    safety_concern: str,
    option_a_description: str,
    option_a_changes: str,
    option_b_description: str,
    option_b_changes: str
) -> tuple[str, str]:
    """Format the multi-option explanation prompt. Returns (system_prompt, user_prompt)."""
    user_prompt = MULTI_OPTION_EXPLANATION_USER_TEMPLATE.format(
        original_request=original_request,
        recipient_info=recipient_info,
        safety_concern=safety_concern,
        option_a_description=option_a_description,
        option_a_changes=option_a_changes,
        option_b_description=option_b_description,
        option_b_changes=option_b_changes
    )
    return MULTI_OPTION_EXPLANATION_SYSTEM_PROMPT, user_prompt


# RESPONSE PARSING

def parse_json_response(response: Union[str, Any]) -> Optional[Dict[str, Any]]:
    """
    Parse JSON from LLM response, handling common issues.

    Handles:
    - Responses wrapped in markdown code blocks
    - Leading/trailing whitespace
    - Common JSON errors
    - LLMResponse objects (extracts .text attribute)
    - Gemini "thinking" blocks mixed with JSON output
    """
    if response is None:
        return None

    # Extract text from response object
    if hasattr(response, 'text'):
        text = response.text
    elif isinstance(response, str):
        text = response
    else:
        text = str(response)

    if not text or not text.strip():
        return None

    text = text.strip()

    # Handle Gemini "thinking" blocks: strip everything before the JSON
    if '<think>' in text or '</think>' in text:
        import re
        text = re.sub(r'<think>.*?</think>', '', text, flags=re.DOTALL).strip()

    # Remove markdown code block wrappers
    if text.startswith('```'):
        lines = text.split('\n')
        # Remove first line (```json or ```) and last line (```)
        if lines[-1].strip() == '```':
            lines = lines[1:-1]
        elif lines[0].strip() in ('```json', '```JSON', '```'):
            lines = lines[1:]
        text = '\n'.join(lines).strip()

    # Remove trailing ``` if present
    if text.endswith('```'):
        text = text[:-3].strip()

    # Try parsing as-is
    try:
        result = json.loads(text)
        if isinstance(result, dict):
            return result
        elif isinstance(result, list) and result and isinstance(result[0], dict):
            return result[0]
        return None
    except json.JSONDecodeError:
        pass

    # Try to find JSON object in the text
    import re

    # Find the first { ... } block
    brace_depth = 0
    start = -1
    for i, ch in enumerate(text):
        if ch == '{':
            if brace_depth == 0:
                start = i
            brace_depth += 1
        elif ch == '}':
            brace_depth -= 1
            if brace_depth == 0 and start >= 0:
                candidate = text[start:i+1]
                try:
                    result = json.loads(candidate)
                    if isinstance(result, dict):
                        return result
                except json.JSONDecodeError:
                    pass
                start = -1

    # Try fixing common issues
    # Remove trailing commas before } or ]
    fixed = re.sub(r',\s*([}\]])', r'\1', text)
    try:
        result = json.loads(fixed)
        if isinstance(result, dict):
            return result
    except json.JSONDecodeError:
        pass

    # Try removing control characters
    cleaned = re.sub(r'[\x00-\x1f\x7f-\x9f]', ' ', text)
    cleaned = re.sub(r',\s*([}\]])', r'\1', cleaned)
    try:
        result = json.loads(cleaned)
        if isinstance(result, dict):
            return result
    except json.JSONDecodeError:
        pass

    logger.warning(f"Failed to parse JSON from response: {text[:200]}...")
    return None


# VLM INTERFACE (Abstract)

class VLMInterface:
    """
    Abstract interface for VLM interactions.

    Subclass this for specific VLM implementations
    (GPT-4V, Gemini, LLaVA, etc.)
    """

    def __init__(self, model_name: str = "gpt-4-vision-preview"):
        self.model_name = model_name

    def perceive_scene(self, image: Any, context_hint: str = "household") -> Optional[Dict]:
        """Process image and return scene graph."""
        raise NotImplementedError("Implement in subclass for specific VLM")

    def parse_task(self, utterance: str, available_objects: List[str]) -> Optional[Dict]:
        """Parse natural language command into task variables."""
        raise NotImplementedError("Implement in subclass for specific VLM")

    def resolve_reference(self, reference: str, context: str, candidates: List[Dict]) -> Optional[Dict]:
        """Resolve a reference to a scene entity."""
        raise NotImplementedError("Implement in subclass for specific VLM")

    def generate_explanation(self, original_request: str, recipient_info: str,
                             violation_type: str, severity: str, violation_reason: str,
                             changes_made: str, repaired_action: str) -> Optional[Dict]:
        """Generate natural language explanation."""
        raise NotImplementedError("Implement in subclass for specific VLM")
