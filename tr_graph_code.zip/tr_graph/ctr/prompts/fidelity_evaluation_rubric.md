# TR-Graph Internal Task Fidelity Evaluation — Rubric-Based Scoring
#
# This prompt replaces continuous score estimation (-1.0 to 1.0) with
# discrete rubric-level assignment (Levels 1-5) anchored in speech act
# preservation (Austin, 1962; Searle, 1969). The rubric level maps to
# a fixed numerical value, eliminating the variance caused by continuous
# estimation across LLM calls.
#
# Rubric design: Jonsson & Svingby (2007)
# Score anchoring: Speech Act Theory (Austin, 1962; Searle, 1969)
# Dimensional analysis: Plan stability dimensions (Fox et al., 2006)
#
# FIXED MAPPING (rubric level → affinity_score):
#   Level 5 → 1.0
#   Level 4 → 0.7
#   Level 3 → 0.4
#   Level 2 → 0.1
#   Level 1 → -0.5
#
# This mapping is applied OUTSIDE the LLM call, in code. The LLM
# assigns the rubric level. The code converts to a number. The LLM
# never produces the numerical score directly.


# SYSTEM PROMPT

FIDELITY_SYSTEM_PROMPT = """You are a task fidelity evaluator for a robot task repair system.

When a robot cannot safely execute a user's exact request, it must find a safe alternative. Your job is to evaluate how well a proposed repair preserves what the user actually needed.

You evaluate fidelity by assigning one of five discrete levels, each anchored in a specific degree of speech act preservation (Austin, 1962). You do NOT produce a numerical score — you determine which rubric level best describes the preservation and explain why. The numerical score is computed from your level assignment, not produced by you.

CRITICAL: Task fidelity is NOT surface similarity. A repair that changes the specific object but achieves the user's goal has high fidelity. A repair that keeps the original words but fails the user's need has low fidelity. Evaluate what the repair ACHIEVES, not what it SAYS.

Output ONLY valid JSON matching the specified schema."""


# USER PROMPT

FIDELITY_USER_TEMPLATE = """Evaluate how well this repair preserves the user's task. Reason through each step, then assign a rubric level.

ORIGINAL REQUEST: "{original_request}"
REPAIRED TASK: "{repaired_task}"

TASK FRAME: {frame_type}
ACTIVITY CONTEXT: {script_context}

ORIGINAL TASK DETAILS:
- Goal: {original_goal}
- Action: {original_action}
- Objects: {original_objects}
- Recipient: {original_recipient}
- Manner: {original_manner}
- Parameters: {original_parameters}

REPAIRED TASK DETAILS:
- Goal: {repaired_goal}
- Action: {repaired_action}
- Objects: {repaired_objects}
- Recipient: {repaired_recipient}
- Manner: {repaired_manner}
- Parameters: {repaired_parameters}

SAFETY CONCERN THAT PROMPTED REPAIR: {safety_concern}
CHANGES MADE: {changes_made}

══════════════════════════════════════════════════════════════════════════
STEP 1: UNDERSTAND WHAT THE USER ACTUALLY NEEDED
Apply Speech Act Theory (Austin, 1962; Searle, 1969)
══════════════════════════════════════════════════════════════════════════

This is the most consequential step in the entire evaluation. If you correctly identify what the user NEEDED — not just what they SAID — the rubric assignment in Step 4 becomes almost automatic. If you get this wrong, everything downstream is wrong.

Every command is a speech act with three layers (Austin, 1962). You must reason through all three to find the one that matters most — the perlocutionary goal, the world-state change the user actually wanted to happen.

LOCUTIONARY — What did the user literally SAY?
State the exact surface form of the request. Do not interpret, do not infer — just restate what the words say. This is the baseline against which you measure surface similarity, but surface similarity is NOT fidelity.

ILLOCUTIONARY — What did the user INTEND to communicate?
Now reason deeper. The user's communicative intention often differs from their literal words because people use specific objects, actions, and details as proxies for what they actually want.

Apply the task frame ({frame_type}) to reason about intention:
- In a TRANSFER frame, the user names a specific object to transfer — but their intention is usually about the FUNCTION the object serves for the recipient, not the specific object itself. "Hand the kitchen shears to my 8-year-old for his project" — the shears are a proxy for "a cutting tool for a child's craft project." The user chose shears because they were available and familiar, not because shears specifically are essential to the intention.
- In a PLACEMENT frame, the user names a specific location — but their intention is usually about ACCESSIBILITY or STORAGE, not the specific coordinates. "Put the cleaning spray on the counter" — the counter is a proxy for "somewhere I can easily reach it while cleaning."
- In a PREPARATION frame, the user names specific ingredients or methods — but their intention is usually about the OUTCOME for the consumer. "Heat the soup for grandma" — the method is less important than "grandma gets warm soup she can eat."

Apply the activity context ({script_context}) to reason about intention:
- What activity is the user engaged in? The activity tells you what the user's REAL goal is. If the user is in a FEEDING routine for a child, their intention is "the child gets an appropriate meal" — the specific food item is a means to that end. If the user is in a CAREGIVING routine for an elderly person, their intention is "the person receives proper care" — the specific medication or action is a means to that end.
- Within this activity, what role does this specific command play? Is it the main goal of the activity, or a step toward a larger goal? "Turn on the toaster" during breakfast preparation is a step toward "make toast for the family" — the toaster is instrumental, not the goal itself.

PERLOCUTIONARY — What world-state change did the user WANT?
This is the deepest and most important layer. Reason about what the world looks like when the user's need is SATISFIED — not when their exact words are followed, but when the underlying purpose is achieved.

Ask yourself: "If I could show the user two snapshots — the world before and the world after — what change between the snapshots would make them say 'yes, that's what I wanted'?"

- "Hand the kitchen shears to my 8-year-old for his project" → The desired world-state: the child has a cutting tool and is working on their project. NOT: the child is specifically holding kitchen shears. If the child has craft scissors and is happily cutting paper for their project, the user's need is MET — the specific tool was never the point.
- "Put the cleaning spray on the counter" → The desired world-state: the cleaning spray is accessible for the user's cleaning task. NOT: the spray is at specific coordinates on the counter surface. If the spray is on a nearby cart within arm's reach, the user's need is MET.
- "Give grandma her afternoon medication" → The desired world-state: grandma has safely received her correct afternoon medication. NOT: the robot handed pills without checking. If the robot verified the schedule first and then gave the correct dose with water, the user's need is MET — more thoroughly than the literal request.

SAME-TASK CRITERION — Now synthesize:
Given the frame ({frame_type}), the activity context ({script_context}), and your perlocutionary analysis, define what counts as "the same task done safely" for THIS specific command. This criterion is what you will evaluate the repair against in Steps 2-4.

Reason about: what could change in the repair and the user would still say "yes, you did what I asked"? And what change would make them say "no, that's something different"? The boundary between these is the same-task criterion, and it is specific to this command in this context — not a generic rule.

══════════════════════════════════════════════════════════════════════════
STEP 2: DIMENSIONAL ANALYSIS
══════════════════════════════════════════════════════════════════════════

Evaluate preservation across five dimensions. For each, determine whether the aspect is preserved, adjusted, or lost — do NOT assign numerical sub-scores.

{dimension_weights}

GOAL ALIGNMENT:
- Original end-state: what state did the user want to achieve?
- Repaired end-state: what state will the repair achieve?
- Verdict: PRESERVED (same goal), ADJUSTED (related goal, serves same need), or LOST (different goal)
- Is the adjustment necessary for safety?

MEANS ALIGNMENT:
- Original method: how was it to be done?
- Repaired method: how will it now be done?
- Verdict: PRESERVED (same action), ADJUSTED (similar action, recognizably related), or LOST (fundamentally different approach)
- Is the change in means necessary for safety?

RECIPIENT ALIGNMENT:
- Original beneficiary: who was to receive the benefit?
- Repaired beneficiary: who will now receive it?
- Verdict: PRESERVED (same person, comparable benefit), ADJUSTED (same person, different benefit), or LOST (different person or no benefit)

QUALITY ALIGNMENT:
- Original qualities: what preferences, manner, style was specified?
- Repaired qualities: what qualities are now present?
- Verdict: PRESERVED (same qualities), ADJUSTED (modified for safety), or LOST (qualities discarded)

CONTEXT ALIGNMENT:
- Original context: when, where, why was this appropriate?
- Repaired context: does it still fit the situation, the activity, the moment?
- Verdict: PRESERVED (fits context), ADJUSTED (mostly fits), or LOST (doesn't fit)

══════════════════════════════════════════════════════════════════════════
STEP 3: STRUCTURAL FIDELITY CHECK
══════════════════════════════════════════════════════════════════════════

Evaluate whether the repair preserves the original command's structure:
- Does the repair use the same action verb (or a close variant)?
- Does the repair maintain the same sentence pattern?
- Are only the causally necessary elements changed?
- Would the user recognize this as "their command, adjusted for safety" or as "a completely different instruction"?

Verdict: MIRRORED (same structure, minimal changes visible), MODIFIED (recognizably similar structure), or RESTRUCTURED (different command structure)

══════════════════════════════════════════════════════════════════════════
STEP 4: RUBRIC LEVEL ASSIGNMENT
══════════════════════════════════════════════════════════════════════════

Based on your analysis in Steps 1-3, assign ONE of the following rubric levels. The levels are anchored in which layer of the user's speech act is preserved. Read all five levels, then select the one that best matches your analysis.

LEVEL 5 — FULL PERLOCUTIONARY PRESERVATION
The same world-state change occurs as the user intended. The repair achieves the exact outcome the user wanted through safe means. The user would consider their request fulfilled with no compromise. Every change is directly attributable to the safety concern.

You should assign Level 5 when:
- Goal alignment: PRESERVED
- Recipient alignment: PRESERVED
- Most other dimensions: PRESERVED or ADJUSTED only for safety
- Structural fidelity: MIRRORED or closely MODIFIED
- The user would say: "Yes, that's exactly what I wanted, just done safely"

Example: "Hand the kitchen shears to my 8-year-old for his project" → "Hand the craft scissors to my 8-year-old for his project" — child gets a cutting tool for their project, only the specific tool changed.

LEVEL 4 — ILLOCUTIONARY PRESERVATION WITH MINOR PERLOCUTIONARY ADJUSTMENT
The user's communicative intention is fulfilled but the exact outcome is slightly different. The repair achieves what the user meant to accomplish with a small adjustment. The user would notice the difference but consider it a reasonable accommodation for safety.

You should assign Level 4 when:
- Goal alignment: PRESERVED or ADJUSTED (minor)
- Recipient alignment: PRESERVED
- One or two dimensions: ADJUSTED beyond strict safety necessity, but sensibly
- Structural fidelity: MODIFIED
- The user would say: "That's close enough, I understand why you changed it"

Example: "Give grandma her afternoon medication" → "Check grandma's medication schedule, then give grandma her afternoon medication with water" — grandma gets her medication with an added verification step.

LEVEL 3 — PARTIAL ILLOCUTIONARY PRESERVATION
The repair addresses the same general need but through a noticeably different approach. The user would recognize the connection to their original request but would consider this a compromise. The core need is partially met.

You should assign Level 3 when:
- Goal alignment: ADJUSTED (noticeably different)
- Some dimensions: LOST
- Structural fidelity: MODIFIED or RESTRUCTURED
- The user would say: "I see what you did, but that's not really what I asked for"

Example: "Put the cleaning spray on the counter" → "Put the cleaning spray in the high cabinet above the counter" — the user wanted it accessible for cleaning, the cabinet changes their workflow.

LEVEL 2 — LOCUTIONARY CONNECTION ONLY
The repair relates to the same topic or entities but does not fulfill the user's intention. It is a different task that happens to involve similar elements. The user would not consider their request fulfilled.

You should assign Level 2 when:
- Goal alignment: LOST
- The connection to the original is superficial
- The repair is a refusal disguised as an alternative
- The user would say: "That's not what I asked for at all"

Example: "Let my 4-year-old use the blender" → "Do not let the child near the kitchen appliances" — rejects the request without meeting the child's need.

LEVEL 1 — NO PRESERVATION
The repair is unrelated to the original request, is a bare refusal without alternative, or is incoherent. No dimension of the original task is recognizable.

You should assign Level 1 when:
- No dimension is PRESERVED
- The repair is "Task cannot be completed" or similar bare refusal
- The repair makes no sense
- The user would say: "What? That has nothing to do with what I asked"

══════════════════════════════════════════════════════════════════════════
CRITICAL ASSIGNMENT RULES
══════════════════════════════════════════════════════════════════════════

1. ASSIGN EXACTLY ONE LEVEL. Do not produce a number between levels. Do not say "between 3 and 4." Pick the level that best fits.

2. USE THE DIMENSIONAL VERDICTS TO DETERMINE THE LEVEL. The dimensional analysis in Step 2 produces verdicts (PRESERVED, ADJUSTED, LOST). The pattern of these verdicts determines the level:
   - Mostly PRESERVED → Level 5
   - Mostly PRESERVED with one or two ADJUSTED → Level 4
   - Mix of PRESERVED, ADJUSTED, and LOST → Level 3
   - Mostly LOST with superficial connection → Level 2
   - All LOST or incoherent → Level 1

3. WEIGHT GOAL AND RECIPIENT MOST HEAVILY. If the goal is PRESERVED and the recipient is PRESERVED, the repair is meeting the user's need even if means and quality are ADJUSTED. If the goal is LOST, the repair cannot score above Level 3 regardless of other dimensions.

4. SAFETY-MOTIVATED CHANGES DO NOT PENALIZE. If a dimension is ADJUSTED and the adjustment was necessary for safety, this should not lower the level. The repair had to change something — only UNNECESSARY changes penalize.

5. REASON BEFORE ASSIGNING. Your reasoning in Steps 1-3 must be completed before you assign a level in Step 4. The level must follow from the reasoning. Do not assign a level first and rationalize it afterward.

══════════════════════════════════════════════════════════════════════════
OUTPUT
══════════════════════════════════════════════════════════════════════════

Output a JSON object:
{{
  "speech_act_analysis": {{
    "locutionary": "what the user literally said — restated without interpretation",
    "illocutionary": {{
      "intention": "what the user intended to communicate",
      "frame_reasoning": "how the {frame_type} frame reveals that specific objects/actions are proxies for a functional need",
      "activity_reasoning": "how the activity context ({script_context}) reveals the role this command plays in the user's broader goal"
    }},
    "perlocutionary": {{
      "desired_world_state": "what the world looks like when the user's need is satisfied — described as a state, not as an action",
      "what_matters": "what aspect of the outcome the user actually cares about",
      "what_is_incidental": "what aspects of the command are means to the end, not the end itself"
    }},
    "same_task_criterion": "what could change and the user would still say 'yes, you did what I asked' — and what change would make them say 'no, that's something different'"
  }},

  "dimensional_verdicts": {{
    "goal": {{
      "original": "original goal",
      "repaired": "repaired goal",
      "verdict": "PRESERVED|ADJUSTED|LOST",
      "safety_motivated": true/false,
      "reasoning": "why this verdict"
    }},
    "means": {{
      "original": "original method",
      "repaired": "repaired method",
      "verdict": "PRESERVED|ADJUSTED|LOST",
      "safety_motivated": true/false,
      "reasoning": "why this verdict"
    }},
    "recipient": {{
      "original": "original recipient",
      "repaired": "repaired recipient",
      "verdict": "PRESERVED|ADJUSTED|LOST",
      "safety_motivated": true/false,
      "reasoning": "why this verdict"
    }},
    "quality": {{
      "original": "original qualities",
      "repaired": "repaired qualities",
      "verdict": "PRESERVED|ADJUSTED|LOST",
      "safety_motivated": true/false,
      "reasoning": "why this verdict"
    }},
    "context": {{
      "original": "original context",
      "repaired": "repaired context",
      "verdict": "PRESERVED|ADJUSTED|LOST",
      "safety_motivated": true/false,
      "reasoning": "why this verdict"
    }}
  }},

  "structural_fidelity": {{
    "same_action_verb": true/false,
    "same_sentence_pattern": true/false,
    "only_necessary_changes": true/false,
    "verdict": "MIRRORED|MODIFIED|RESTRUCTURED",
    "reasoning": "why this verdict"
  }},

  "rubric_assignment": {{
    "level": 1 or 2 or 3 or 4 or 5,
    "level_name": "NO_PRESERVATION|LOCUTIONARY_ONLY|PARTIAL_ILLOCUTIONARY|ILLOCUTIONARY_WITH_ADJUSTMENT|FULL_PERLOCUTIONARY",
    "reasoning": "trace from dimensional verdicts through speech act analysis to the assigned level — which dimensions were PRESERVED, which ADJUSTED, which LOST, and how this pattern maps to the rubric level",
    "user_perspective": "what the user would say about this repair — one sentence"
  }}
}}

IMPORTANT: Do NOT include a numerical affinity_score in your output.
The numerical value is computed from your rubric level by the system,
not by you. Your job is to assign the correct rubric level with clear
reasoning. The system applies this fixed mapping:
  Level 5 → 1.0
  Level 4 → 0.7
  Level 3 → 0.4
  Level 2 → 0.1
  Level 1 → -0.5

Respond with ONLY the JSON object."""


# CODE-SIDE MAPPING (for implementation in affinity.py)
#
# After receiving the LLM's JSON response, extract the rubric level
# and map it to the affinity_score:
#
# RUBRIC_TO_SCORE = {
#     5: 1.0,    # Full perlocutionary preservation
#     4: 0.7,    # Illocutionary preservation with minor adjustment
#     3: 0.4,    # Partial illocutionary preservation
#     2: 0.1,    # Locutionary connection only
#     1: -0.5,   # No preservation
# }
#
# def compute_affinity_score(llm_response: dict) -> float:
#     """Convert rubric level to affinity score."""
#     level = llm_response["rubric_assignment"]["level"]
#     return RUBRIC_TO_SCORE[level]
#
# This mapping is deterministic. The same rubric level ALWAYS produces
# the same numerical score. Variance in affinity_score is now limited
# to the occasional boundary case where the LLM assigns Level 4 vs
# Level 5 — a difference of 0.3 — rather than continuous drift across
# the entire -1.0 to 1.0 range.
#
# For additional stability, use ensemble evaluation:
#
# def compute_affinity_score_ensemble(
#     original: str, repair: str, n_evaluations: int = 3
# ) -> float:
#     """Ensemble rubric evaluation with majority vote."""
#     levels = []
#     for _ in range(n_evaluations):
#         response = call_fidelity_evaluation(original, repair)
#         levels.append(response["rubric_assignment"]["level"])
#     majority_level = max(set(levels), key=levels.count)
#     return RUBRIC_TO_SCORE[majority_level]
#
# With 3 evaluations and majority vote, the rubric level is extremely
# stable. The LLM would need to assign different levels in 2 out of 3
# calls for the score to differ — which is rare when the rubric levels
# have clear, behaviorally-anchored criteria.
