"""
TR-Graph Prompts Module

Prompt loading is handled by enriched_prompts.py, which extracts prompts from
dedicated .md files. Generation utilities are in generation_prompts.py.
"""

from ctr.prompts.generation_prompts import (
    format_causal_paths,
    format_operator_priorities,
)
