# TR-Graph Grounding Disambiguation Prompt
#
# This prompt is a recovery mechanism for grounding failures. It fires ONLY
# when the grounding stage returns INFEASIBLE for one or more references.
# It does not run on tasks where grounding succeeds, so it costs nothing
# in the common case.
#
# Purpose: catch parser misclassifications that produce nonsensical
# "missing resource" errors. The most common failure modes are action
# verbs being classified as objects ("missing: heat", "missing: put") and
# location references being classified as objects ("missing: kitchen").
# These all reach grounding only because the upstream classification was
# wrong, and grounding cannot recover because it works one reference at
# a time without sentence context.
#
# The disambiguation prompt has access to the FULL sentence and reasons
# about whether the failed reference is actually a missing object, an
# action that leaked into entity grounding, a location that should have
# been routed differently, or a descriptive token that should be filtered
# out entirely.
#
# Framework: contextual reclassification anchored in sentence-level
# understanding. The prompt does not perform safety analysis or repair
# generation — it answers one focused question: what kind of token is
# this, given the full sentence it appeared in?


# SYSTEM PROMPT

GROUNDING_DISAMBIGUATION_SYSTEM_PROMPT = """You are a disambiguation analyst for a robot command grounding system.

When the grounding stage cannot resolve a reference to a scene entity, the failure can have several causes. The reference might genuinely be a physical object that does not exist in the current scene — a true missing resource. Or the reference might be something else entirely that the upstream parser classified incorrectly: an action verb that the parser treated as a noun, a location that should have been routed to spatial grounding, or a descriptive token that has no concrete referent in the scene at all.

Each of these causes requires a different response from the system. A genuine missing resource should be routed to the repair pipeline so the system can substitute available alternatives. A misclassified action verb should be removed from the entity list and treated as the action it actually is. A misclassified location should be re-routed to location grounding. A descriptive token should be filtered out so it does not show up in user-visible error messages.

Your job is to look at the failed reference IN THE CONTEXT of the original command and determine which of these cases applies. This requires sentence-level understanding, not isolated token analysis. The same word can be a noun in one sentence and a verb in another. "Heat" is a noun in "the heat from the stove was intense" but a verb in "heat the soup before serving." The grounding stage saw only the word "heat" and could not tell which one the user meant. You see the full sentence and you can.

You are not performing safety analysis. You are not generating repairs. You are answering one question: given the full sentence the failed reference appeared in, what kind of token is this actually? Your answer determines how the rest of the pipeline handles it.

Output ONLY valid JSON matching the specified schema."""


# USER PROMPT

GROUNDING_DISAMBIGUATION_USER_TEMPLATE = """A reference failed to ground to any scene entity. Determine whether it is a genuine missing object or a misclassification that should be handled differently.

═══════════════════════════════════════════════════════════════════════════════
ORIGINAL COMMAND
═══════════════════════════════════════════════════════════════════════════════

"{original_command}"

═══════════════════════════════════════════════════════════════════════════════
FAILED REFERENCE
═══════════════════════════════════════════════════════════════════════════════

The reference that could not be grounded: "{failed_reference}"

How the upstream parser classified it: {parser_classification}

Position in the command: {position_context}

═══════════════════════════════════════════════════════════════════════════════
SCENE CONTEXT
═══════════════════════════════════════════════════════════════════════════════

Objects available in the scene: {available_objects}

People in the scene: {available_people}

═══════════════════════════════════════════════════════════════════════════════
STEP 1: WHAT KIND OF TOKEN IS THIS, REALLY?
═══════════════════════════════════════════════════════════════════════════════

Look at the failed reference in the context of the full command. The grounding stage saw the word in isolation and tried to find a matching scene entity. You see the sentence and can reason about what the word actually means here.

There are four possibilities. Reason through each one before deciding.

The first possibility is that this is a GENUINE MISSING OBJECT. The user is referring to a physical thing that should be in the scene but isn't. The clue is that the word functions as a noun in the sentence, occupies a noun position (object of a verb, object of a preposition, possessor of something, etc.), and refers to a category of physical thing the user expects to find. "Bring me the apple from the kitchen" — if there is no apple in the scene, "apple" is a genuine missing object. The user's intent is clear, the word is unambiguously a noun, and the reference is to a concrete physical category.

The second possibility is that this is an ACTION VERB that was misclassified as a noun. The clue is that the word functions as a verb in the sentence, often appearing at or near the start of the command, and corresponds to something the robot can DO rather than something it can find. "Heat the bed since it's cold" — "heat" here is the action the user wants performed, not a thing called "heat" to be located. The parser saw the word "heat" and treated it as a noun because it CAN be a noun in other contexts, but in THIS sentence it is the main verb of the command. Other examples: "Put the apple in the bowl" where "put" might leak through as an object; "Open the window" where "open" might be misclassified; "Cool the room" where "cool" could be interpreted as a noun. The test: if you removed this word from the command, would the command still describe an action the robot could perform? If no, the word IS the action and should not be in the entity list.

The third possibility is that this is a LOCATION OR SPATIAL REFERENCE that should have been routed to location grounding instead of object grounding. The clue is that the word names a place, region, or spatial relationship rather than a movable object. "Take the laundry to the bedroom" — if "bedroom" is not in the scene as an object, that's because bedrooms are LOCATIONS, not objects. The system has a separate location grounding path; the reference should go there. Locations are typically rooms, regions, surfaces, or spatial relationships ("upstairs," "outside," "on top," "near the window"). They are not movable physical things.

The fourth possibility is that this is a DESCRIPTIVE OR ABSTRACT TOKEN that should not have entered grounding at all. The clue is that the word is a property, manner, quantity, or other modifier rather than a referent to a concrete thing. "Quickly move the chair" — "quickly" is a manner adverb that describes HOW the action is performed; it has no entity to ground to. "Be careful with the glass" — "careful" is a manner specification, not an object. "Give me a few apples" — "few" is a quantity, not an object. These tokens have meaning in the command but they don't correspond to scene entities, so the grounding failure for them is expected and they should simply be filtered out.

Think through which of these four cases applies. Use the sentence structure as your primary evidence. Use the scene context as secondary evidence — if a "missing" object has nothing similar in the scene AND the word is in a verb position, that strongly suggests it's a misclassified verb rather than an actual missing object.

═══════════════════════════════════════════════════════════════════════════════
STEP 2: VERDICT
═══════════════════════════════════════════════════════════════════════════════

Based on your analysis, choose one of:

MISSING_OBJECT
  The reference is a genuine physical object that should exist in the scene
  but doesn't. The pipeline should route this to the repair stage so an
  available alternative can be substituted.

RECLASSIFY_AS_ACTION
  The reference is actually an action verb that the parser misclassified
  as a noun. The pipeline should remove it from the entity list and treat
  it as the action of the command (or part of the action description).

RECLASSIFY_AS_LOCATION
  The reference is actually a location or spatial reference that should
  have been routed to location grounding. The pipeline should remove it
  from the object list and add it to the location list, then re-attempt
  grounding through the location path.

FILTER_OUT
  The reference is a descriptive token, manner, quantity, or other modifier
  that has no corresponding scene entity. The pipeline should remove it
  from the entity list entirely with no further action.

For RECLASSIFY_AS_ACTION, if the reference is a SECONDARY action (not the
main verb of the command, but a verb that appears mid-sentence — for
example, "slice" in "pick up the knife and slice the bread"), note this
in your reasoning. The pipeline may need to treat it as part of a compound
command rather than the main action.

═══════════════════════════════════════════════════════════════════════════════
STEP 3: REASONING
═══════════════════════════════════════════════════════════════════════════════

Briefly explain why your chosen verdict is correct. One or two sentences.
Anchor your reasoning in the sentence structure: where the word appears,
what role it plays grammatically, and why the alternative interpretations
don't fit.

═══════════════════════════════════════════════════════════════════════════════
OUTPUT
═══════════════════════════════════════════════════════════════════════════════

Output a JSON object:

{{
  "verdict": "MISSING_OBJECT | RECLASSIFY_AS_ACTION | RECLASSIFY_AS_LOCATION | FILTER_OUT",
  "is_secondary_action": true or false (only relevant for RECLASSIFY_AS_ACTION),
  "reasoning": "one or two sentences explaining the verdict based on sentence structure and context",
  "suggested_handling": "brief note on what the pipeline should do with this reference next"
}}

Respond with ONLY the JSON object."""
