"""
TR-Graph Task Repair: Generation Prompt Utilities

Formatting helpers for the diagnosis-guided repair generation prompt.
"""

import logging
from typing import List, Optional

logger = logging.getLogger(__name__)


def format_causal_paths(graph, diagnosis) -> str:
    """
    13C: Format critical causal paths from the graph for the generation prompt.

    Shows paths from causal variables through hazard mechanisms to violation sinks,
    helping the LLM understand exactly what needs to change and why.
    """
    if not graph or not graph.edges:
        causal_vars = getattr(diagnosis, 'causal_variables', []) or []
        if causal_vars:
            return f"Causal variables: {', '.join(causal_vars)}"
        return "No causal analysis available."

    lines = ["Causal paths to violation:"]
    for edge in graph.edges:
        lines.append(f"  {edge.source} \u2192 {edge.target} ({edge.relationship})")

    # Use violation sinks for repair guidance
    try:
        sink_nodes = graph.get_nodes_by_type("violation_sink") if hasattr(graph, 'get_nodes_by_type') else []

        if sink_nodes:
            lines.append(f"\nViolation outcomes: {', '.join(sink_nodes)}")

            # Find which causal variables are closest to sinks (most critical to address)
            from ctr.cost import CostWeights
            importance = CostWeights._compute_importance_to_sinks(graph, sink_nodes)
            causal_vars = getattr(diagnosis, 'causal_variables', []) or []
            causal_imp = {v: importance.get(v, 0) for v in causal_vars if v in importance}
            if causal_imp:
                # Sort by importance — highest first (closest to violation)
                sorted_vars = sorted(causal_imp.items(), key=lambda x: x[1], reverse=True)
                most_critical = sorted_vars[0][0]
                least_critical = sorted_vars[-1][0]
                lines.append(f"Most critical variable (closest to violation): {most_critical}")
                lines.append(f"Least disruptive variable to change: {least_critical}")
    except Exception:
        pass

    return "\n".join(lines)



def format_operator_priorities(priorities, allocation) -> str:
    """
    13A: Format bandit-derived operator allocation as explicit generation instructions.

    Instead of giving priorities as context, this tells the LLM exactly how many
    candidates to generate with each operator. This makes the bandit's allocation
    directly control what types of candidates are produced, which makes the credit
    assignment fix (11A) meaningful.

    Args:
        priorities: Array of probabilities from the bandit.
        allocation: List of integer slot allocations.

    Returns:
        Explicit generation instructions string.
    """
    if priorities is None or allocation is None:
        return "Use your best judgment to select repair strategies."

    operator_names = ["SUBSTITUTE", "CONSTRAIN", "DECOMPOSE", "RELAX", "REORDER", "RETARGET"]
    total = sum(allocation)

    # Build explicit allocation instructions
    instructions = []
    for idx in sorted(range(len(allocation)), key=lambda i: allocation[i], reverse=True):
        count = allocation[idx]
        if count > 0:
            instructions.append(f"  - Generate {count} candidate(s) using {operator_names[idx]}")

    if not instructions:
        return "Use your best judgment to select repair strategies."

    lines = [
        f"Generate exactly {total} candidates distributed as follows:",
        ""
    ]
    lines.extend(instructions)
    lines.append("")
    lines.append(
        "Each candidate MUST primarily use its assigned operator. "
        "You may combine operators (e.g., SUBSTITUTE + CONSTRAIN) but the assigned "
        "operator should be the primary strategy driving the repair."
    )
    return "\n".join(lines)




