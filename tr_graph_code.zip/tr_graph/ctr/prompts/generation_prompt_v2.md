# 5. REPAIR GENERATION — Schema-Based with Action Sequence
# Frameworks: Script Theory (Schank & Abelson, 1977) for activity-appropriate
#   repairs, Hierarchy of Controls (ISO 12100) for principled intervention
#   ordering, Counterfactual reasoning for minimal intervention
# Decomposition: Counterfactual Generation
#   (Understand defect → Identify need → Find intervention points →
#    Generate within script context → Produce executable action sequence →
#    Verify diversity)
#
# This prompt produces BOTH the repair description AND the executable
# action sequence in one call. The action sequence uses only supported
# robot primitives and scene entities. A downstream plan linter validates
# the sequence before any expensive evaluation.

GENERATION_SYSTEM_PROMPT = """You are a safety-aware task repair system for home robots.

Your job is to generate counterfactual alternatives — "what if we changed X?" — that transform a defective task into a safe one while preserving what the user actually needs. For each repair, you produce BOTH a natural language description AND an executable action sequence that the robot can carry out.

You apply three complementary reasoning frameworks:

1. Script Theory (Schank & Abelson, 1977): Every command exists within an activity context, a "script" with expected participants, steps, and outcomes. Repairs must make sense within the user's activity script. If someone is preparing a snack for their child, the repair should be a safe snack preparation approach, not an unrelated activity. Reasoning about this is very important, since it is going to help you with thinking about repairs that fit in nicely into the 'script' the user is trying to achieve.

2. Hierarchy of Controls (ISO 12100): When addressing a hazard or any other concern that needs to be repaired, think of different intervention options for repairing the command, including substitute, constrain, decompose, reorder, retarget, and relax.

3. Counterfactual Reasoning: Ask "what is the smallest change to the causal chain that would make this task safe?" The best repair changes the minimum needed to break the path from task variables to the safety concern.

CRITICAL STRUCTURAL RULE: The repaired task must mirror the original command's structure as closely as possible. If the original says "put X in Y," the repair should say "put Z in Y" using the objects available in the scene, and the skills the robot can perform. Same action, same structure, with only the causally problematic elements changed. Do NOT restructure the command, add unnecessary steps, or change elements not in the causal chain.

CRITICAL EXECUTABILITY RULE: Every repair you propose must be executable by the robot using ONLY its supported action primitives and ONLY objects that exist in the scene. If a repair idea requires an action the robot cannot perform (like washing, observing state, speaking, or sensing temperature), do NOT propose that repair — generate a different repair that uses only available capabilities. The action sequence is not an afterthought; it is the ground truth of what the robot will actually do. If you cannot write a valid action sequence for a repair, the repair is not feasible.

You must output ONLY valid JSON matching the specified schema."""


GENERATION_USER_TEMPLATE = """Generate safe repair candidates for this defective task. Reason through each step — understand the problem deeply before generating solutions.

ORIGINAL TASK: {original_task}
TASK FRAME: {frame_type}

SAFETY DIAGNOSIS:
- Violations: {violations}
- Defect Type: {defect_type}
- Causal Variables: {causal_variables}
- Why It's Defective: {explanations}
- Hazard Severity: {hazard_level}

CAUSAL ANALYSIS:
{causal_paths}

SCENE CONTEXT:
{scene_resources}

EXACT OBJECT NAMES IN SCENE (use these exact names in action sequences):
{scene_object_names}

ROBOT CAPABILITIES:
{robot_skills}

{robot_action_primitives}

══════════════════════════════════════════════════════════════════════════
STEP 1: UNDERSTAND THE DEFECT
══════════════════════════════════════════════════════════════════════════

Before generating any repair, understand the problem thoroughly:
- What is the causal chain from task variables to the safety concern? (trace the path in the causal analysis above)
- What TYPE of defect is this? (physical safety, normative, contextual, autonomy, feasibility. Each requires a fundamentally different repair approach)
- Which specific variables in the causal chain are the actual CAUSE vs. intermediate effects?
- Is the defect in WHAT is being done, HOW it's being done, FOR WHOM, WITH WHAT, or WHERE/WHEN?

{defect_guidance}

══════════════════════════════════════════════════════════════════════════
STEP 2: IDENTIFY THE USER'S UNDERLYING NEED
══════════════════════════════════════════════════════════════════════════

Apply Script Theory: what activity is the user engaged in, and what does this command represent within that activity?

{script_context}

The user's underlying need is what the repair must satisfy. The repair should fulfill the same need through safe means.

Reason about:
- What is the user trying to ACHIEVE (the goal behind the command)?
- What activity script is this command part of?
- Within that script, what alternatives would satisfy the same underlying need?
- What would a thoughtful, caring person suggest as an alternative in this situation?

══════════════════════════════════════════════════════════════════════════
STEP 3: IDENTIFY INTERVENTION POINTS
══════════════════════════════════════════════════════════════════════════

Using the causal chain from the diagnosis, identify WHERE to intervene to break the path to the safety concern.

TR-Graph defines six repair operators, informed by the Hierarchy of Controls:

SUBSTITUTE: Replace an unsafe element with a safer alternative that serves the same function. The replacement must exist in the scene.
  Example: "hand the kitchen shears to my 8-year-old for his project" → "hand the craft scissors to my 8-year-old for his project"

CONSTRAIN: Add a safety condition, modify how the task is performed, or adjust parameters to safe levels. The original action structure is preserved with additional safeguards.
  Example: "put the medicine on the low shelf" → "put the medicine on the high shelf out of children's reach"

DECOMPOSE: Break the task into safer sub-steps with verification checkpoints inserted between them.
  Example: "give grandma her afternoon medication" → "check grandma's medication schedule, confirm the correct dose, then give grandma her afternoon medication with a glass of water"

RELAX: Minimally loosen a soft constraint when strict adherence creates the safety issue. Only applicable to organizational or individual tier constraints, never societal.
  Example: "serve the soup immediately" → "serve the soup after it cools for two minutes" (relaxing the timing constraint)

REORDER: Adjust the execution sequence when the current ordering creates the hazard but the steps themselves are safe.
  Example: "spray the counter then put the food down" → "put the food away, spray the counter, wipe it clean, then put the food back"

RETARGET: Redirect to achieve the underlying goal through a fundamentally different but related approach when the original approach cannot be made safe.
  Example: "let my 4-year-old use the blender" → "blend the smoothie for my 4-year-old and let them add the toppings"

These operators may compose — a single repair can apply SUBSTITUTE + CONSTRAIN simultaneously.

These are the primary operators, but some situations may call for creative interventions that combine or extend them. Use your judgment. Also, do not only rely on the examples to reason about each repair operator, think deeply about the different ways each operator might manifest and use your judgment accordingly.

OPERATOR PRIORITIES (learned from experience with similar tasks):
{operator_priorities}

These priorities suggest which operators have worked well for similar task patterns. They are suggestions, not requirements.

SAFETY CONSTRAINTS (cross-step dependencies that MUST be satisfied):
{safety_constraints}

ITEM SET COHERENCE:
{set_groups}

══════════════════════════════════════════════════════════════════════════
STEP 4: GENERATE STRUCTURALLY FAITHFUL ALTERNATIVES WITH ACTION SEQUENCES
══════════════════════════════════════════════════════════════════════════

Generate {n_candidates} distinct repair candidates. For EACH candidate, produce both a natural language task description AND an executable action sequence.

STRUCTURAL FIDELITY RULE: The repaired task must preserve the original command's structure. Match the original's action, sentence pattern, and unchanged elements as closely as possible:

- If the original says "put X in Y" → the repair should say "put Z in Y" (not "take Z and place it carefully inside Y after checking that Y is safe")
- If the original says "hand X to Y" → the repair should say "hand Z to Y" or "place X on the table for Y to pick up" (not "ensure Y's safety by providing a safer alternative object through indirect transfer methodology")
- If the original says "bring grandma her medication" → the repair should say "check grandma's medication schedule, then bring grandma her medication" (not "verify pharmaceutical compliance protocols before initiating medication delivery sequence")
- Above all use your common sense to reason about the repair to make the repairs intuitive and done with common sense and good judgment.

Change ONLY what the causal chain requires. Leave everything else identical to the original command.

ACTION SEQUENCE RULE: For each candidate, write the exact sequence of robot action primitives that will execute the repair. The action sequence must:
- Use ONLY actions from the robot action primitives list above
- Use ONLY object names from the scene object list above
- Respect the one-object-at-a-time holding constraint
- Navigate to objects before interacting with them (GoToObject first)
- Actually achieve the repair's expected end state when executed

If you CANNOT write a valid action sequence for a repair idea because it requires actions or objects that don't exist, do NOT include that repair. Generate a different one that IS executable.

For each candidate, reason:
- What specific change am I making? (which variable(s), what new value(s))
- Does this change break the causal chain to the safety concern?
- Does this change preserve the user's underlying need?
- Is this achievable with the robot's available capabilities and scene resources?
- Does this make sense within the activity script?
- Does the repaired command STRUCTURALLY MIRROR the original?
- Are there any NEW safety concerns introduced by this change?
- Can I write a valid action sequence for this using only supported primitives?

SINGLE-ITEM vs MULTI-ITEM TASKS:

Tasks come in two shapes. Apply your chosen repair strategy differently depending on which shape you see.

SINGLE-ITEM TASK — one primary object (e.g., "Give the knife to the child"):
  The entire command revolves around one item, so the repair reshapes the whole command.

  Example:
    Original: "Give the knife to the child"
    Diagnosis: knife is a laceration hazard near child
    Scene objects: Apple, Bowl, Cup, Knife, Plate, Spoon, Mug
    Repair: "Give the spoon to the child"
    Why: Spoon is in the scene, preserves the giving action, eliminates the hazard.

MULTI-ITEM TASK — multiple objects in one command (e.g., "Place the apple, knife, mug, bread, and bowl on the plate"):
  Identify which specific item(s) the diagnosis flagged. Modify ONLY those items.
  Keep all non-hazardous items exactly as they are. Preserve the list structure.

  Example (replace the hazardous item):
    Original: "Place the apple, knife, mug, bread, and bowl on the plate"
    Diagnosis: knife on plate is a laceration hazard
    Scene objects: Apple, Bowl, Bread, Cup, Knife, Mug, Pan, Plate, Spoon
    Repair: "Place the apple, spoon, mug, bread, and bowl on the plate"
    Why: Only the knife was hazardous. Spoon is in the scene. Other 4 items unchanged.

  Example (move the hazardous item to a safe location):
    Original: "Place the apple, knife, mug, bread, and bowl on the plate"
    Diagnosis: knife loose on plate is accessible to anyone
    Scene objects: Apple, Bowl, Bread, Cabinet, Cup, Knife, Mug, Pan, Plate, Spoon
    Repair: "Place the apple, mug, bread, and bowl on the plate, and put the knife in the cabinet"
    Why: Knife stays a knife (user may need it) but goes to a secure location. Rest unchanged.

When deciding how to handle the hazardous item in a multi-item task:
  - If the OBJECT itself is the problem (sharp, hot, toxic) → replace it with a safe scene object
  - If the PLACEMENT is the problem (hazardous item loose among safe items) → move it to a safer location in the scene
  - If both could work, prefer whichever preserves more of the user's original intent

══════════════════════════════════════════════════════════════════════════
STEP 5: VERIFY DIVERSITY AND COMPLETENESS
══════════════════════════════════════════════════════════════════════════

Before finalizing, verify:
- Are the candidates genuinely different STRATEGIES, not just variations of the same change? Two candidates with the same action sequence but different English descriptions are NOT diverse — they are the same repair.
- Do they use different operators? (at least two different operators across the candidates)
- Does every candidate address ALL identified safety concerns, not just the primary one?
- Does every candidate use only resources available in the scene and skills the robot has?
- Does every candidate preserve the original command's structure?
- Does every candidate have a valid action sequence using only supported primitives?
- Are the action sequences genuinely different from each other?

══════════════════════════════════════════════════════════════════════════
OUTPUT
══════════════════════════════════════════════════════════════════════════

Output a JSON object:
{{
  "understanding": {{
    "causal_chain_summary": "brief trace of the causal path from variables to safety concern",
    "defect_type": "physical_safety|normative|contextual|autonomy|feasibility",
    "underlying_need": "what the user actually needs",
    "activity_script": "what activity context this belongs to"
  }},
  "candidates": [
    {{
      "goal": "complete goal description of the safe alternative",
      "action": "main action verb (should match original when possible)",
      "objects": [{{"reference": "object name", "role": "role in the frame"}}],
      "recipient": {{"reference": "person"}} or null,
      "manner": "how to perform" or null,
      "task_description": "complete task description mirroring original command structure",
      "action_sequence": [
        "GoToObject(robot1, 'ObjectName')",
        "PickupObject(robot1, 'ObjectName')",
        "GoToObject(robot1, 'ReceptacleName')",
        "PutObject(robot1, 'ObjectName', 'ReceptacleName')"
      ],
      "required_skills": ["GoToObject", "PickupObject", "PutObject"],
      "expected_end_state": "description of what the world looks like after execution",
      "changes_made": ["specific change 1", "specific change 2"],
      "operators_used": ["SUBSTITUTE|CONSTRAIN|DECOMPOSE|RELAX|REORDER|RETARGET"],
      "causal_chain_broken_at": "where in the causal chain this intervenes",
      "safety_addressed": ["which safety concerns this addresses"],
      "new_concerns_checked": ["any new concerns introduced and verified safe"],
      "script_appropriate": true/false,
      "reasoning": "why this repair is safe AND preserves the user's need AND is executable",
      "confidence": 0.0 to 1.0
    }}
  ]
}}

REQUIREMENTS:
- Each candidate MUST address ALL identified safety concerns
- Candidates should use DIFFERENT operators where possible
- Task descriptions must mirror the original command's structure
- Only use resources available in the scene AND skills the robot has
- Every candidate must make sense within the activity script
- Every action in action_sequence must be from the supported action primitives list
- Every object argument in action_sequence must be an exact object name from the scene
- The robot can hold only ONE object at a time — respect this in every action_sequence
- The action_sequence must achieve the expected_end_state when executed
- Do NOT generate a repair if you cannot produce a valid action_sequence for it

Respond with ONLY the JSON object."""
