"""
TR-Graph Enriched Prompt Suite
=========================

Each prompt uses conceptual frameworks as reasoning methodologies,
chain-of-thought decomposition, and open-ended categories.

Frameworks integrated:
- Situation Awareness (Endsley, 1995) — Scene perception
- Frame Semantics (Fillmore, 1976) — Task classification
- Grounded Language Understanding (Harnad, 1990) — Reference resolution
- Relational Affordance Theory (Gibson, 1977) — Safety evaluation framing
- ISO 12100 / ISO/TS 15066 / ANSI R15.806 — Safety evaluation criteria
- Script Theory (Schank & Abelson, 1977) — Activity-appropriate repairs
- Hierarchy of Controls (ISO 12100) — Operator ordering
- Speech Act Theory (Austin, 1962; Searle, 1969) — Fidelity evaluation
- Automated Repair Quality (Monperrus, 2014) — Repair quality assessment

All prompts follow the same pattern:
1. Decompose first (understand before judging)
2. Reason through numbered steps (each builds on previous)
3. Output JSON that mirrors the reasoning trace (auditable)
4. Categories are illustrative, not exhaustive (LLM reasons beyond them)
"""

# The actual prompt texts are loaded from the markdown source files
# to keep this module as the single import point while the prompt
# content lives in version-controlled, human-readable markdown.
#
# This module reads from three source files:
# - enriched_prompts.md (perception, frame, parsing, grounding, generation, fidelity)
# - combined_safety_prompt.md (safety evaluation)
# - defect_feasibility_evaluation.md (judge, defect guidance, feasibility)

import re
import os
import logging

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))  # ctr/prompts/
_PROMPT_DIR = os.path.dirname(_THIS_DIR)                  # ctr/
_PROJECT_ROOT = os.path.dirname(_PROMPT_DIR)               # project root


def _extract_prompt(filepath: str, variable_name: str) -> str:
    """Extract a prompt string from a markdown file by variable name."""
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    # Match: VARIABLE_NAME = """...""" or VARIABLE_NAME = '''...'''
    pattern = rf'{variable_name}\s*=\s*"""(.*?)"""'
    match = re.search(pattern, content, re.DOTALL)
    if match:
        return match.group(1).strip()

    pattern = rf"{variable_name}\s*=\s*'''(.*?)'''"
    match = re.search(pattern, content, re.DOTALL)
    if match:
        return match.group(1).strip()

    raise ValueError(f"Prompt '{variable_name}' not found in {filepath}")




# Source file paths

def _find_prompt_file(filename: str) -> str:
    """Find a prompt markdown file, checking package dir first, then project root."""
    pkg_path = os.path.join(_THIS_DIR, filename)
    if os.path.exists(pkg_path):
        return pkg_path
    root_path = os.path.join(_PROJECT_ROOT, filename)
    if os.path.exists(root_path):
        return root_path
    raise FileNotFoundError(
        f"Prompt file '{filename}' not found in {_THIS_DIR} or {_PROJECT_ROOT}"
    )

_ENRICHED = _find_prompt_file('enriched_prompts.md')
_SAFETY = _find_prompt_file('combined_safety_prompt.md')
_JUDGE = _find_prompt_file('defect_feasibility_evaluation.md')


# . SCENE PERCEPTION (Situation Awareness — Endsley, 1995)

SCENE_PERCEPTION_SYSTEM_PROMPT = _extract_prompt(_ENRICHED, 'SCENE_PERCEPTION_SYSTEM_PROMPT')
SCENE_PERCEPTION_USER_TEMPLATE = _extract_prompt(_ENRICHED, 'SCENE_PERCEPTION_USER_TEMPLATE')


# . FRAME CLASSIFICATION (Frame Semantics — Fillmore, 1976)

FRAME_CLASSIFICATION_SYSTEM_PROMPT = _extract_prompt(_ENRICHED, 'FRAME_CLASSIFICATION_SYSTEM_PROMPT')
FRAME_CLASSIFICATION_USER_TEMPLATE = _extract_prompt(_ENRICHED, 'FRAME_CLASSIFICATION_USER_TEMPLATE')


# . TASK PARSING (Construction Grammar + SOMA/CORA + Frame Semantics + Grounded Language)

_PARSING = _find_prompt_file('task_parsing_v3.md')
TASK_PARSING_SYSTEM_PROMPT = _extract_prompt(_PARSING, 'TASK_PARSING_SYSTEM_PROMPT')
TASK_PARSING_USER_TEMPLATE = _extract_prompt(_PARSING, 'TASK_PARSING_USER_TEMPLATE')


# . GROUNDING (Grounded Language Understanding — Harnad, 1990)

GROUNDING_SYSTEM_PROMPT = _extract_prompt(_ENRICHED, 'GROUNDING_SYSTEM_PROMPT')
GROUNDING_USER_TEMPLATE = _extract_prompt(_ENRICHED, 'GROUNDING_USER_TEMPLATE')


# . SAFETY EVALUATION (ISO 12100 + ISO/TS 15066 + ANSI R15.806 + Gibson)

SAFETY_SYSTEM_PROMPT = _extract_prompt(_SAFETY, 'SAFETY_SYSTEM_PROMPT')
SAFETY_USER_TEMPLATE = _extract_prompt(_SAFETY, 'SAFETY_USER_TEMPLATE')


# . REPAIR GENERATION (Script Theory + Hierarchy of Controls + Counterfactual)

# Schema-based generation prompt v2 (includes action sequence output)
_GENERATION_V2 = _find_prompt_file('generation_prompt_v2.md')
GENERATION_SYSTEM_PROMPT = _extract_prompt(_GENERATION_V2, 'GENERATION_SYSTEM_PROMPT')
GENERATION_USER_TEMPLATE = _extract_prompt(_GENERATION_V2, 'GENERATION_USER_TEMPLATE')


# . TASK FIDELITY EVALUATION (Rubric-based — Speech Act Theory + Frame-aware)

_FIDELITY_RUBRIC = _find_prompt_file('fidelity_evaluation_rubric.md')
FIDELITY_SYSTEM_PROMPT = _extract_prompt(_FIDELITY_RUBRIC, 'FIDELITY_SYSTEM_PROMPT')
FIDELITY_USER_TEMPLATE = _extract_prompt(_FIDELITY_RUBRIC, 'FIDELITY_USER_TEMPLATE')


# . REPAIR SAFETY VERIFICATION (B4 — targeted verification for candidates)

try:
    _REPAIR_VERIFY = _find_prompt_file('repair_safety_verification.md')
    REPAIR_VERIFICATION_SYSTEM_PROMPT = _extract_prompt(_REPAIR_VERIFY, 'REPAIR_VERIFICATION_SYSTEM_PROMPT')
    REPAIR_VERIFICATION_USER_TEMPLATE = _extract_prompt(_REPAIR_VERIFY, 'REPAIR_VERIFICATION_USER_TEMPLATE')
except FileNotFoundError:
    # Fallback if prompt file not found — verification disabled gracefully
    REPAIR_VERIFICATION_SYSTEM_PROMPT = None
    REPAIR_VERIFICATION_USER_TEMPLATE = None


# . TASK ROUTER (C1 — atomic vs compound classification + decomposition)

try:
    _TASK_ROUTER = _find_prompt_file('task_router.md')
    TASK_ROUTER_SYSTEM_PROMPT = _extract_prompt(_TASK_ROUTER, 'TASK_ROUTER_SYSTEM_PROMPT')
    TASK_ROUTER_USER_TEMPLATE = _extract_prompt(_TASK_ROUTER, 'TASK_ROUTER_USER_TEMPLATE')
except FileNotFoundError:
    TASK_ROUTER_SYSTEM_PROMPT = None
    TASK_ROUTER_USER_TEMPLATE = None


# . CONSTRAINT GENERATION (C4 — standalone, compound commands only)

CONSTRAINT_GENERATION_SYSTEM_PROMPT = """You are a safety constraint analyst for a robot task repair system.

You receive a compound command that has already been evaluated for safety. The safety evaluation identified hazards and causal variables. Your job is to identify cross-step dependencies — cases where the outcome of one step affects the safety of a later step — and express them as executable constraints that the plan linter can verify.

You are NOT evaluating safety. That has already been done. You are looking specifically for CROSS-STEP STATE DEPENDENCIES that create hazards when steps are combined, even though each step might be safe in isolation.

Output ONLY valid JSON matching the specified schema."""

CONSTRAINT_GENERATION_USER_TEMPLATE = """Analyze this compound command for cross-step safety dependencies.

COMMAND: "{command}"

SUB-TASKS:
{sub_tasks}

DIAGNOSED HAZARDS:
{hazard_summary}

CAUSAL VARIABLES: {causal_variables}

Look for these cross-step dependency patterns:
1. CONTAMINATION TRANSFER — tool/surface picks up contamination, then contacts clean item
2. THERMAL PERSISTENCE — object heated, then handled by vulnerable person
3. SHARP STATE PERSISTENCE — tool exposed, then accessible to child/vulnerable person
4. CHEMICAL EXPOSURE — surface treated with chemicals, then used for food/contact
5. ACCESS GRANTING — secured item opened/unlocked, then left accessible

For each dependency found, specify:
- trigger: the action that creates the hazardous state
- effect: what state change occurs
- required_action: the mitigating action (use robot action primitives like CleanObject, etc.)
- must_occur_before: the deadline action that cannot happen without mitigation
- severity: "critical" (physical harm) or "advisory" (preference/hygiene)

If no cross-step dependencies exist, return an empty array.

Output JSON:
{{
  "safety_constraints": [
    {{
      "trigger": "action that creates hazardous state",
      "effect": "state change description",
      "required_action": "mitigating action",
      "must_occur_before": "deadline action",
      "severity": "critical | advisory"
    }}
  ]
}}

Respond with ONLY the JSON object."""


# . GROUNDING DISAMBIGUATION (recovery mechanism for grounding failures)

try:
    _GROUNDING_DISAMBIG = _find_prompt_file('grounding_disambiguation.md')
    GROUNDING_DISAMBIGUATION_SYSTEM_PROMPT = _extract_prompt(_GROUNDING_DISAMBIG, 'GROUNDING_DISAMBIGUATION_SYSTEM_PROMPT')
    GROUNDING_DISAMBIGUATION_USER_TEMPLATE = _extract_prompt(_GROUNDING_DISAMBIG, 'GROUNDING_DISAMBIGUATION_USER_TEMPLATE')
except FileNotFoundError:
    GROUNDING_DISAMBIGUATION_SYSTEM_PROMPT = None
    GROUNDING_DISAMBIGUATION_USER_TEMPLATE = None


# . DEFECT-TYPE-SPECIFIC GUIDANCE

# Import the get_defect_guidance function from the judge file
# The guidance dict is defined in the markdown but we need to load it as Python

def get_defect_guidance(defect_type: str) -> str:
    """Returns defect-type-specific repair guidance for the generation prompt."""
    _GUIDANCE = {
        'physical_safety': None,
    }

    # The defect guidance is a complex dict in the markdown file.
    # Rather than parsing Python dict syntax from markdown, we define
    # the guidance strings directly here, extracted from the source.
    try:
        # Try to load from the judge file's DEFECT_GUIDANCE dict
        with open(_JUDGE, 'r', encoding='utf-8') as f:
            content = f.read()

        # Find the specific defect type's guidance
        pattern = rf'"{defect_type}":\s*"""(.*?)"""'
        match = re.search(pattern, content, re.DOTALL)
        if match:
            return match.group(1).strip()
    except Exception:
        pass

    return (
        f"The safety evaluation identified a {defect_type} concern. "
        f"Reason carefully about what specifically is the concern, "
        f"what is the smallest change that addresses it, and does the "
        f"repair preserve the user's underlying need."
    )



# ROBOT SKILLS HELPER

def get_robot_skills(mode: str = "ai2thor") -> str:
    """
    Return the robot's available action primitives as a formatted string
    for inclusion in prompts.

    Args:
        mode: The robot/simulation mode (ai2thor, safeagentbench, franka, etc.)

    Returns:
        Formatted string listing available capabilities.
    """
    if mode == "ai2thor":
        return (
            "Available robot capabilities (AI2-THOR):\n"
            "- GoToObject(object_name): Navigate to an object in the scene\n"
            "- PickupObject(object_name): Pick up an object (must be near it)\n"
            "- PutObject(object_name, receptacle_name): Place held object on/in a receptacle\n"
            "- OpenObject(object_name): Open a container, cabinet, or door\n"
            "- CloseObject(object_name): Close a container, cabinet, or door\n"
            "- ToggleObjectOn(object_name): Turn on an appliance or device\n"
            "- ToggleObjectOff(object_name): Turn off an appliance or device\n"
            "- SliceObject(object_name): Slice a sliceable object (requires knife held)\n"
            "- BreakObject(object_name): Break a breakable object\n"
            "- ThrowObject(object_name): Throw a held object\n"
            "- PushObject(object_name): Push an object\n"
            "- PullObject(object_name): Pull an object\n"
            "- DropHandObject(): Drop the currently held object\n"
            "\n"
            "Constraints:\n"
            "- The robot can hold only ONE object at a time\n"
            "- The robot must be near an object to interact with it\n"
            "- The robot cannot speak, gesture, or communicate verbally\n"
            "- The robot cannot apply force beyond what these actions provide"
        )
    elif mode == "safeagentbench":
        return (
            "Available robot capabilities (AI2-THOR — SafeAgentBench extended set):\n"
            "- find(object_name): Navigate to an object in the scene\n"
            "- pick(object_name): Pick up an object (must be near it)\n"
            "- put(receptacle_name): Place held object on/in a receptacle\n"
            "- open(object_name): Open a container, cabinet, or door\n"
            "- close(object_name): Close a container, cabinet, or door\n"
            "- turn_on(object_name): Turn on an appliance or device\n"
            "- turn_off(object_name): Turn off an appliance or device\n"
            "- slice(object_name): Slice a sliceable object\n"
            "- break(object_name): Break a breakable object\n"
            "- throw(): Throw the currently held object\n"
            "- drop(): Drop the currently held object\n"
            "- cook(object_name): Cook an object (e.g., on stove, in microwave)\n"
            "- dirty(object_name): Make an object dirty\n"
            "- clean(object_name): Clean an object\n"
            "- pour(): Pour liquid from a held container\n"
            "- fillLiquid(object_name, liquid_type): Fill a container with liquid\n"
            "- emptyLiquid(object_name): Empty liquid from a container\n"
            "\n"
            "Constraints:\n"
            "- The robot can hold only ONE object at a time\n"
            "- The robot must be near an object to interact with it\n"
            "- The robot cannot speak, gesture, or communicate verbally\n"
            "- The robot cannot apply force beyond what these actions provide"
        )
    elif mode == "franka":
        return (
            "Available robot capabilities (Franka Research 3 Robot — 7-DOF manipulator):\n"
            "- move_to(object_name): Move gripper above an object on the workspace\n"
            "- pick(object_name): Grasp an object (move to it, close gripper, lift)\n"
            "- place(object_name, location): Place held object at a named location or next to another object\n"
            "- push(object_name, direction): Push an object in a direction (left, right, forward, back)\n"
            "- open_gripper(): Release whatever is currently held\n"
            "\n"
            "STRICT ACTION CONSTRAINT: The robot can ONLY perform the 5 actions listed above.\n"
            "Do NOT assume the robot can perform any other action. Specifically, the robot CANNOT:\n"
            "- wash, rinse, clean, wipe, scrub, or sanitize objects\n"
            "- peel, slice, cut, chop, dice, or prepare food\n"
            "- cook, heat, microwave, boil, fry, or change temperature\n"
            "- pour, fill, empty, or transfer liquids\n"
            "- turn knobs, press buttons, flip switches, or operate appliances\n"
            "- open/close containers, drawers, cabinets, or doors\n"
            "- fold, wrap, tie, or manipulate flexible materials\n"
            "- speak, gesture, signal, or communicate in any way\n"
            "- sense temperature, weight, texture, or chemical properties\n"
            "- walk, navigate, or move to a different location\n"
            "\n"
            "If a task requires ANY action not in the 5-action list above, the task\n"
            "is NOT feasible for this robot. The repair must use ONLY pick, place,\n"
            "move_to, push, and open_gripper.\n"
            "\n"
            "Additional constraints:\n"
            "- The robot is a FIXED-BASE arm mounted at one end of the workspace\n"
            "- It can only reach objects within its ~85cm workspace radius\n"
            "- It can hold only ONE object at a time with its parallel jaw gripper\n"
            "- All actions happen on a single countertop/table surface"
        )
    elif mode == "spot":
        return (
            "Available robot capabilities (Boston Dynamics Spot — mobile quadruped):\n"
            "- navigate(location): Walk to a named location in the environment\n"
            "- pick(object_name): Grasp an object with the arm (if equipped)\n"
            "- place(object_name, location): Place held object at a location\n"
            "- inspect(object_name): Move close to an object and capture image\n"
            "- open_door(door_name): Open a door using the arm\n"
            "- sit(): Lower the body to sitting position\n"
            "- stand(): Rise to standing position\n"
            "\n"
            "Constraints:\n"
            "- The robot is a mobile quadruped with optional arm attachment\n"
            "- It CAN navigate between rooms and across terrain\n"
            "- Manipulation is limited — single arm with basic grasp\n"
            "- It CANNOT perform fine manipulation (turning knobs, using tools)\n"
            "- It CANNOT speak or communicate verbally\n"
            "- It CANNOT sense temperature, weight, or chemical properties\n"
            "- It can carry only ONE small/medium object at a time"
        )
    return (
            "Robot capabilities not specified. Assume the robot can:\n"
            "- Navigate to locations\n"
            "- Pick up and place objects\n"
            "- Open and close containers\n"
            "- Toggle devices on/off"
        )


def get_robot_action_primitives(mode: str = "ai2thor") -> str:
    """Return the action primitives block for the generation prompt.

    This is separate from get_robot_skills() because the generation prompt
    needs explicit function signatures with parameter names for action
    sequence generation, plus a deny-list of invalid actions.

    Args:
        mode: The robot/simulation mode

    Returns:
        Formatted string with action primitives and constraints for the
        generation prompt's action_sequence section.
    """
    if mode == "ai2thor":
        return (
            "ROBOT ACTION PRIMITIVES (use ONLY these in your action_sequence):\n"
            "- GoToObject(robot1, 'ObjectName') -- Navigate to an object or location\n"
            "- PickupObject(robot1, 'ObjectName') -- Pick up an object (must be near it first)\n"
            "- PutObject(robot1, 'ObjectName', 'ReceptacleName') -- Place the held object on/in a receptacle\n"
            "- OpenObject(robot1, 'ObjectName') -- Open a container, cabinet, fridge, or door\n"
            "- CloseObject(robot1, 'ObjectName') -- Close a container, cabinet, fridge, or door\n"
            "- ToggleObjectOn(robot1, 'ObjectName') -- Turn on an appliance or device\n"
            "- ToggleObjectOff(robot1, 'ObjectName') -- Turn off an appliance or device\n"
            "- SliceObject(robot1, 'ObjectName') -- Slice a sliceable object (requires knife held)\n"
            "- BreakObject(robot1, 'ObjectName') -- Break a breakable object\n"
            "- ThrowObject(robot1, 'ObjectName') -- Throw the currently held object\n"
            "- PushObject(robot1, 'ObjectName') -- Push an object\n"
            "- PullObject(robot1, 'ObjectName') -- Pull an object\n"
            "- DropHandObject(robot1) -- Drop the currently held object\n"
            "\n"
            "ACTION CONSTRAINTS:\n"
            "- Use ONLY the actions listed above. Do NOT invent actions like \"Observe\", \"WashObject\", \"InspectState\", \"CheckObject\", \"CleanObject\", or any other action not in the list.\n"
            "- Use 'robot1' as the robot identifier in every action.\n"
            "- Every 'ObjectName' in your action_sequence must be an EXACT name from the scene object list above. Do not use names that are not in the scene.\n"
            "- The robot can hold only ONE object at a time. You must PutObject or DropHandObject before picking up another object.\n"
            "- The robot must GoToObject before it can interact with that object (pickup, open, toggle, etc.)."
        )
    elif mode == "safeagentbench":
        return (
            "ROBOT ACTION PRIMITIVES (use ONLY these in your action_sequence):\n"
            "- find(robot1, 'ObjectName') -- Navigate to an object in the scene\n"
            "- pick(robot1, 'ObjectName') -- Pick up an object (must be near it)\n"
            "- put(robot1, 'ReceptacleName') -- Place held object on/in a receptacle\n"
            "- open(robot1, 'ObjectName') -- Open a container, cabinet, or door\n"
            "- close(robot1, 'ObjectName') -- Close a container, cabinet, or door\n"
            "- turn_on(robot1, 'ObjectName') -- Turn on an appliance or device\n"
            "- turn_off(robot1, 'ObjectName') -- Turn off an appliance or device\n"
            "- slice(robot1, 'ObjectName') -- Slice a sliceable object\n"
            "- break(robot1, 'ObjectName') -- Break a breakable object\n"
            "- throw(robot1) -- Throw the currently held object\n"
            "- drop(robot1) -- Drop the currently held object\n"
            "- cook(robot1, 'ObjectName') -- Cook an object\n"
            "- dirty(robot1, 'ObjectName') -- Make an object dirty\n"
            "- clean(robot1, 'ObjectName') -- Clean an object\n"
            "- pour(robot1) -- Pour liquid from a held container\n"
            "- fillLiquid(robot1, 'ObjectName', 'LiquidType') -- Fill with liquid\n"
            "- emptyLiquid(robot1, 'ObjectName') -- Empty liquid from a container\n"
            "\n"
            "ACTION CONSTRAINTS:\n"
            "- Use ONLY the actions listed above.\n"
            "- Every 'ObjectName' must be an EXACT name from the scene object list above.\n"
            "- The robot can hold only ONE object at a time.\n"
            "- The robot must find an object before interacting with it."
        )
    elif mode == "franka":
        return (
            "ROBOT ACTION PRIMITIVES (use ONLY these in your action_sequence):\n"
            "- move_to(robot1, 'ObjectName') -- Move gripper above an object on the workspace\n"
            "- pick(robot1, 'ObjectName') -- Grasp an object (move to it, close gripper, lift)\n"
            "- place(robot1, 'ObjectName', 'Location') -- Place held object at a location or next to another object\n"
            "- push(robot1, 'ObjectName', 'Direction') -- Push an object (left, right, forward, back)\n"
            "- open_gripper(robot1) -- Release whatever is currently held\n"
            "\n"
            "ACTION CONSTRAINTS:\n"
            "- Use ONLY the 5 actions listed above. The robot CANNOT perform any other action.\n"
            "- Do NOT use actions like wash, peel, slice, cut, cook, heat, pour, fill, clean, wipe, turn_on, turn_off, open, close, or any action not in the list.\n"
            "- Every 'ObjectName' must be an EXACT name from the scene object list above.\n"
            "- The robot can hold only ONE object at a time. It must place or release before picking another.\n"
            "- The robot is fixed-base -- it CANNOT navigate to other rooms or locations.\n"
            "- All actions happen on a single countertop/table surface.\n"
            "- If the task requires an action not in the list, the repair must transform it into a sequence of pick/place/push that achieves the user's underlying need."
        )
    elif mode == "spot":
        return (
            "ROBOT ACTION PRIMITIVES (use ONLY these in your action_sequence):\n"
            "- navigate(robot1, 'Location') -- Walk to a named location\n"
            "- pick(robot1, 'ObjectName') -- Grasp an object with the arm\n"
            "- place(robot1, 'ObjectName', 'Location') -- Place held object at a location\n"
            "- inspect(robot1, 'ObjectName') -- Move close and capture image\n"
            "- open_door(robot1, 'DoorName') -- Open a door using the arm\n"
            "- sit(robot1) -- Lower body to sitting position\n"
            "- stand(robot1) -- Rise to standing position\n"
            "\n"
            "ACTION CONSTRAINTS:\n"
            "- Use ONLY the 7 actions listed above.\n"
            "- Do NOT use actions like wash, slice, cook, pour, turn_on, or any action not in the list.\n"
            "- Manipulation is limited -- single arm with basic grasp.\n"
            "- The robot CANNOT perform fine manipulation (turning knobs, using tools).\n"
            "- The robot can carry only ONE small/medium object at a time."
        )
    else:
        return (
            "ROBOT ACTION PRIMITIVES:\n"
            "- navigate(robot1, 'Location') -- Move to a location\n"
            "- pick(robot1, 'ObjectName') -- Pick up an object\n"
            "- place(robot1, 'ObjectName', 'Location') -- Place held object\n"
            "\n"
            "ACTION CONSTRAINTS:\n"
            "- Use ONLY the actions listed above.\n"
            "- Every 'ObjectName' must exist in the scene."
        )
