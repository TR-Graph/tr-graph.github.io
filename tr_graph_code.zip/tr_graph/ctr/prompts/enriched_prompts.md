# TR-Graph Enriched Prompt Suite
# Each prompt uses conceptual frameworks as reasoning methodologies,
# chain-of-thought decomposition, and open-ended categories.
# Categories listed are ILLUSTRATIVE — the LLM is always instructed
# to reason beyond them.

# ============================================================================
# 1. SCENE PERCEPTION
# Framework: Situation Awareness (Endsley, 1995)
# Decomposition: Leveled Perception (Entity → Comprehension → Projection)
# ============================================================================

SCENE_PERCEPTION_SYSTEM_PROMPT = """You are a robot perception system that applies Situation Awareness analysis (Endsley, 1995) to understand domestic environments at three levels: perceiving what exists, comprehending what is happening, and projecting what will happen.

Your analysis must go beyond inventorying objects. A kitchen with a coffee pot, a toddler, and a counter are not just three entities, this is a situation where a hot beverage is accessible to a small child during a morning routine. Your job is to perceive the entities, understand the situation they create, and anticipate what is likely to happen next.

CRITICAL: Output ONLY valid JSON matching the specified schema."""


SCENE_PERCEPTION_USER_TEMPLATE = """You are applying Situation Awareness analysis (Endsley, 1995) to understand and analyze this scene using the three-level Situation Awareness framework. Reason through each level before moving to the next, as each level builds on what the previous one established.

Context: This is a {context_hint} environment. The robot has been asked to: "{task_description}"

══════════════════════════════════════════════════════════════════════════
LEVEL 1: PERCEPTION — What exists in this scene?
══════════════════════════════════════════════════════════════════════════

Systematically identify every entity relevant to household tasks and safety. For each entity, extract properties that could matter for safety and not just what the entity IS, but what it COULD DO in interaction with people and other objects.

For objects, reason about:
- Physical properties that affect safety: temperature (look for steam, heating elements, refrigeration), sharpness, weight, fragility, chemical nature, electrical state, material composition
- Functional state: is it on/off, open/closed, full/empty, in use/stored, hot/cooling/cold?
- Contents: if it's a container, what does it hold? The container may be safe but its contents may not be.
- Packaging or wrapping: is the object wrapped, sealed, or covered in something that affects how it can be used? (foil wrapping near microwaves, sealed medication bottles, shrink-wrapped items)
- Child-safety: could a small child safely interact with this object unsupervised?
- Affordances: what actions does this object enable or invite? A low shelf affords climbing for a toddler. An open drawer affords reaching in. Think about what each object AFFORDS different people, not just what it's designed for.

For people, reason about:
- Age: estimate carefully — this is safety-critical. Look for size relative to furniture, posture, clothing, activity patterns.
- Current activity: what are they doing RIGHT NOW? Sitting, reaching, playing, sleeping, cooking, walking? Their current activity determines what they're likely to interact with next.
- Capability indicators: mobility, alertness, whether they're using assistive devices, whether they appear to be supervised or independent.
- Proximity to hazards: are they near hot objects, sharp objects, chemicals, edges, water?

For spatial relationships, prioritize those with safety implications:
- What is within reach of each person (especially children)?
- What is near heat sources, water, or edges?
- What pathways exist and are any blocked?
- What surfaces are objects on and how stable are they?

Note: The categories above are illustrative. Every scene has unique features that no category list will be able to cover it fully. Henco, if you observe something safety-relevant that doesn't fit these categories, like unusual objects, environmental conditions, animal presence, construction or maintenance in progress, weather effects visible through windows, include it. Your perception should be comprehensive, not constrained by this list, so use your common sense for edge cases.

══════════════════════════════════════════════════════════════════════════
LEVEL 2: COMPREHENSION — What is happening in this scene?
══════════════════════════════════════════════════════════════════════════

Now synthesize the entities you identified into a situational understanding. This is not a list of objects, instead it is a description of the SITUATION the objects and people create together.

Reason about:
- What activity or routine is underway? (meal preparation, cleaning, childcare, relaxation, work, play, or something these labels don't capture)
- What phase is the activity in? (just starting, in progress, wrapping up)
- What is the emotional and social context? (busy morning rush, calm afternoon, supervised play, someone working alone)
- Are there any existing tensions or risks in the scene INDEPENDENT of the requested task? (a pot left on a hot stove, a child unsupervised near stairs, cleaning chemicals left out)
- What is the overall "safety state" of the environment right now?

Describe the situation in 2-3 sentences that capture what a thoughtful human observer would notice walking into this scene.

══════════════════════════════════════════════════════════════════════════
LEVEL 3: PROJECTION — What will happen if the task is executed?
══════════════════════════════════════════════════════════════════════════

Given the task "{task_description}" and the situation you've comprehended, project forward in time:

- Immediately during execution: What will the scene look like as the robot performs the task? Who or what will be affected directly?
- Seconds after completion: What state will the environment be in when the robot finishes and moves on? Where will objects be? Who will be near them?
- Minutes later: What is likely to happen in the minutes following? Will people move toward the affected area? Will children discover new objects? Will temperatures change? Will the scene state evolve?

Think about the MOST LIKELY sequence of events, not the worst case. But also consider: who is the most vulnerable person in the environment, and what is their most likely interaction with the resulting state?

Describe the projected outcome in 2-3 sentences.

══════════════════════════════════════════════════════════════════════════
OUTPUT
══════════════════════════════════════════════════════════════════════════

Output a JSON object:
{{
  "nodes": [
    {{
      "id": "unique_string_id",
      "type": "object|person|region",
      "label": "human readable name",
      "properties": {{
        // For objects: temperature (celsius or null), sharpness (null|dull|moderate|sharp),
        // state (null|on|off|open|closed|full|empty), affordances (list),
        // hazard_level (none|low|medium|high), child_safe (true|false),
        // material (string or null), contains (string or null),
        // wrapping (string or null — e.g., "foil wrapped", "sealed bottle")
        //
        // For persons: age (integer estimate), age_group (infant|toddler|child|teen|adult|elderly),
        // name (string or null), physical_capability (limited|normal),
        // safety_awareness (low|medium|high), current_activity (string)
        //
        // For regions: region_type (string), current_state (string)
        //
        // Include any additional properties you observe that are safety-relevant,
        // even if they don't fit the categories above.
      }},
      "position_description": "brief spatial description"
    }}
  ],
  "edges": [
    {{
      "source_id": "id",
      "target_id": "id",
      "relation": "located_in|adjacent_to|holding|near|on|inside|interacting_with|above|below|within_reach_of",
      "safety_relevant": true or false
    }}
  ],
  "scene_summary": "one sentence factual description of the scene",
  "situation_description": "2-3 sentences describing what is HAPPENING — the activity, the dynamics, the context",
  "projected_outcome": "2-3 sentences projecting what will happen if the task is executed as stated"
}}

Important:
- Estimate ages for children carefully — this is the most safety-critical perception task
- Note any visible hazards (hot items, sharp objects, chemicals, unstable arrangements)
- Steam/vapor indicates hot temperature (estimate 60-90°C)
- Include ALL entities relevant to household tasks and safety
- The situation_description and projected_outcome should read like a thoughtful human observer's assessment, not a list of facts

Respond with ONLY the JSON object."""


# ============================================================================
# 2. FRAME CLASSIFICATION
# Framework: Frame Semantics (Fillmore, 1976)
# Decomposition: Semantic Role Analysis
#   (Action → Participant structure → Frame identification → Safety focus)
# ============================================================================

FRAME_CLASSIFICATION_SYSTEM_PROMPT = """You are applying Frame Semantics (Fillmore, 1976) to analyze robot task commands. In Frame Semantics, every utterance evokes a structured situation which is called a "frame" with defined participants, roles, and relationships. The frame is not just a label, instead it reveals the participant structure of the action and identifies which relationships between participants are most relevant for safety evaluation.

Your job is to identify the semantic frame a command evokes by analyzing its action semantics and participant structure, extract the frame-specific roles, and determine which interaction between participants is the primary safety concern.

CRITICAL: Output ONLY valid JSON matching the specified schema."""


FRAME_CLASSIFICATION_USER_TEMPLATE = """Analyze this robot task command using Frame Semantics. Reason through each step and do not jump to a frame label without first analyzing the action and participant structure.

COMMAND: "{command}"

══════════════════════════════════════════════════════════════════════════
STEP 1: ACTION ANALYSIS
══════════════════════════════════════════════════════════════════════════

What is the core action in this command? Look beyond the surface verb to the underlying action semantics:
- What kind of change does this action produce in the world? (transfer of possession, change of state, change of location, transformation of material, creation of something new, observation of something existing)
- Is there a secondary or implied action? ("pour coffee for the toddler" involves both POURING and SERVING)
- What is the agent's relationship to the action? (performing it directly, causing it to happen, enabling someone else to do it)

══════════════════════════════════════════════════════════════════════════
STEP 2: PARTICIPANT STRUCTURE
══════════════════════════════════════════════════════════════════════════

Who and what are the participants in this action? Identify each participant and the ROLE it plays and not just what it is, but what role it occupies in the action's structure:
- Agent: who performs the action?
- What is being acted upon, moved, transferred, transformed, or observed?
- Who receives, benefits from, or is affected by the result?
- What instruments, tools, or means are involved?
- What locations (source, destination, path) are involved?
- Are there participants who are implied but not explicitly mentioned?

══════════════════════════════════════════════════════════════════════════
STEP 3: FRAME IDENTIFICATION
══════════════════════════════════════════════════════════════════════════

Given the action semantics and participant structure, what semantic frame does this command evoke?

Here are common frames in household robotics to illustrate how frames are structured, but please note that commands may evoke frames not listed here. If this command doesn't fit any of these, apply the same analytical process and describe the frame you identify:

TRANSFER: An Agent causes an item to move to a Recipient. The safety-critical interaction is between the item and the Recipient. The question becomes, is what's being given safe for who's receiving it? Examples: handing, delivering, serving, bringing, passing, giving.

MANIPULATION: An Agent uses an Instrument to act on a Patient/Material. The safety-critical interaction is between the Instrument and the Material, and between the Agent and the Instrument. The question becomes, is the tool safe for this material? Is it safe for the person using it? Examples: cutting, stirring, pouring, opening, mixing, assembling.

PLACEMENT: An Agent causes an item to be located at a Goal. The safety-critical interaction is between the item, the Goal location, and the broader Environment — is the placed object safe in that location for everyone who might encounter it later? Examples: putting, placing, setting down, storing, shelving, positioning.

NAVIGATION: An Agent moves along a Path from Source to Goal. The safety-critical interaction is between the Path and any Hazards along it, and between the Agent's movement and nearby Persons. Examples: going, moving, navigating, approaching, returning, following.

PREPARATION: An Agent transforms Ingredients through a Process into a Product. The safety-critical interactions involve the Process safety (temperatures, chemicals, equipment), the Ingredient handling (allergens, contamination), and the Product safety for its intended consumer. Examples: cooking, baking, mixing, assembling, brewing, preparing.

MONITORING: An Agent observes a Phenomenon for a Purpose. The safety-critical interaction is between the Observation and the observed party's Privacy and Consent. Examples: watching, checking, guarding, photographing, recording, inspecting.

STATE_CHANGE: An Agent causes an Entity to transition from one State to another. The safety-critical interaction depends on what the new state enables or prevents. Turning on a stove creates heat hazards. Unlocking a door changes access. Turning off a light changes visibility. Examples: switching on/off, opening/closing, locking/unlocking, starting/stopping.

If this command evokes a frame not listed above, such as CAREGIVING, INSTRUCTION, COMMUNICATION, RETRIEVAL, DISPOSAL, CLEANING, ENTERTAINMENT, or among other possible frames, identify it by applying the same reasoning: what is the action structure, what roles exist, and what interaction is safety-critical?

══════════════════════════════════════════════════════════════════════════
STEP 4: SAFETY FOCUS DERIVATION
══════════════════════════════════════════════════════════════════════════

Based on the frame you identified, what is the PRIMARY interaction that determines safety for this specific command? This is the relationship between participants that the safety evaluation should scrutinize most carefully.

Reason about:
- Which participants are in a relationship that could produce harm?
- What makes this specific interaction potentially risky? (the properties of the participants, the nature of their interaction, the context)
- What would a thoughtful safety evaluator focus on first when assessing this command?

Express the safety focus as a specific instruction: "For this task, pay particular attention to the [interaction type] between [participant A] and [participant B], because [reason]."

══════════════════════════════════════════════════════════════════════════
OUTPUT
══════════════════════════════════════════════════════════════════════════

Output a JSON object:
{{
  "action_analysis": {{
    "core_action": "the underlying action semantics",
    "world_change": "what change this produces in the world",
    "secondary_actions": ["any implied or secondary actions"]
  }},
  "participant_structure": {{
    "participants": [
      {{"entity": "who/what", "role": "the role in the action structure", "mentioned_explicitly": true/false}}
    ]
  }},
  "frame": {{
    "name": "FRAME_NAME (use standard name if it matches, or describe a new one)",
    "confidence": 0.0 to 1.0,
    "description": "brief description of this frame's structure",
    "is_standard_frame": true if matches a common frame above, false if novel,
    "frame_roles": {{
      "role_name": "entity filling this role"
    }}
  }},
  "safety_focus": {{
    "primary_interaction": "which participant-participant relationship is safety-critical",
    "focus_instruction": "For this task, pay particular attention to...",
    "reasoning": "why this interaction is the primary safety concern"
  }}
}}

Respond with ONLY the JSON object."""


# ============================================================================
# 3. TASK PARSING
# Frameworks: Frame Semantics (role extraction) + Grounded Language
#   Understanding (connecting language to concrete meaning)
# Decomposition: Comprehension → Frame-guided role extraction →
#   Property extraction with completeness flagging → Constraint separation
# ============================================================================

GROUNDING_SYSTEM_PROMPT = """You are a reference resolution and capability verification system that applies Grounded Language Understanding (Harnad, 1990) to connect linguistic references to concrete entities and robot capabilities.

The core principle of grounded understanding is that symbols words like "the apple," "grandma," "the counter" are meaningless until connected to real-world referents with actual physical properties. Your job is to make these connections, verify the robot can actually perform the requested action, and be honest when you cannot.

You perform three types of grounding in a single pass:
1. ENTITY GROUNDING: Do the referenced objects and people exist in the scene?
2. SKILL GROUNDING: Can the robot physically perform the requested action with its available capabilities?
3. COMPLETENESS GROUNDING: Are all safety-relevant attributes known?

Critically, you resolve ALL references TOGETHER in the context of the full command, not independently. References make sense in relation to each other and the command. "The tray" in "put the medicine on the tray for grandma" is the tray associated with grandma's care routine the command context disambiguates.

CRITICAL: Output ONLY valid JSON matching the specified schema."""


GROUNDING_USER_TEMPLATE = """Resolve all references in this command, verify the robot's capability to execute it, and check completeness of safety-relevant information. Reason through the resolution holistically.

COMMAND: "{command}"
TASK FRAME: {frame_type}
FRAME ROLES: {frame_roles_json}

PARSED TASK:
- Goal: {parsed_goal}
- Action: {parsed_action}
- Objects referenced: {object_references}
- Recipient referenced: {recipient_reference}
- Unknown safety properties flagged by parser: {unknown_properties}

SCENE ENTITIES:
{scene_entities_json}

SCENE SPATIAL RELATIONS:
{scene_relations_json}

ROBOT CAPABILITIES:
{robot_skills}

The robot can ONLY perform the actions listed above. If the task requires an action not in this list, the robot cannot execute it regardless of whether the objects exist and the task is safe.

══════════════════════════════════════════════════════════════════════════
STEP 1: REFERENCE INVENTORY
══════════════════════════════════════════════════════════════════════════

List every reference in the command that needs to be connected to a scene entity. For each reference, note:
- What type of entity it should be (object, person, location)
- What the command context tells us about it (its role in the frame, properties mentioned or implied)
- What other references it relates to

══════════════════════════════════════════════════════════════════════════
STEP 2: SKILL VERIFICATION
══════════════════════════════════════════════════════════════════════════

Before resolving entity references, verify that the robot can perform the core action:

- Does the parsed action ("{parsed_action}") map to one or more of the robot's available capabilities listed above?
- If the action is abstract (e.g., "prepare," "clean," "organize"), can it be decomposed into a sequence of available capabilities?
- If the action requires a capability the robot does not have (e.g., the task requires slicing but the robot has no slicing capability, or the task requires speech but the robot cannot speak), this is a skill-level infeasibility.
- Are there physical constraints that prevent execution? (object too heavy, location too high, object too small for gripper)

If the robot cannot perform the requested action:
- Identify the specific capability gap
- List which of the robot's available capabilities COULD partially address the user's underlying need
- Example: if the robot cannot slice bread but can pick up and transport objects, it could bring the bread and a knife to the user

══════════════════════════════════════════════════════════════════════════
STEP 3: JOINT ENTITY RESOLUTION
══════════════════════════════════════════════════════════════════════════

Now resolve all entity references together, using the command context and frame structure to inform each match:

For each reference, consider:
- Which scene entity best matches this reference given the FULL command context?
- Does the frame role help disambiguate? (In a TRANSFER frame, the object filling the Theme role is the thing being transferred — this narrows the match.)
- Do relationships between references help? (If grandma is the recipient and there's a medicine bottle near grandma's chair, that bottle is more likely "the medicine" than an identical bottle in the bathroom cabinet.)
- How confident are you in this match? (0.9+ for clear matches, 0.6-0.8 for reasonable but uncertain, below 0.6 for guesses)

CRITICAL — VERB vs NOUN CHECK BEFORE MATCHING:

Before attempting to match each reference to a scene entity, first ask yourself: "In this specific sentence, is this reference being used as a VERB (the action to perform) or as a NOUN (a thing to find)?" Only try to match NOUNs. If a reference is the command's action verb, SKIP it entirely — do not return it as INFEASIBLE, do not try to find it in the scene. It is not a scene entity.

This matters because imperative commands often start with an action verb that can also function as a noun or adjective in other contexts. The upstream parser sometimes includes these in the reference list by mistake. You must catch this by reading the full sentence and understanding the grammatical role of each word:

- "Warm the milk before serving" — "warm" is the VERB (heat the milk). Do NOT try to find "warm" in the scene. Only resolve "the milk."
- "Dry the dishes on the rack" — "dry" is the VERB. Only resolve "the dishes" and "the rack."
- "Dust the shelf carefully" — "dust" is the VERB (remove dust from the shelf). Only resolve "the shelf."
- "Iron the shirt" — "iron" is the VERB. Only resolve "the shirt."
- "Water the plant near the window" — "water" is the VERB. Resolve "the plant" and "the window."
- "Polish the table with the cloth" — "polish" is the VERB. Resolve "the table" and "the cloth."
- "Light the candle on the mantle" — "light" is the VERB. Resolve "the candle" and "the mantle."
- "Mop the floor in the hallway" — "mop" is the VERB. Resolve "the floor" and "the hallway."
- "Sand the wooden shelf" — "sand" is the VERB. Only resolve "the wooden shelf."

Contrast with cases where similar words ARE nouns or adjectives:
- "Carry the warm blanket to the bedroom" — "warm" is an ADJECTIVE modifying "blanket", not the action. The action is "carry." Resolve "the warm blanket" and "the bedroom."
- "Pour the water into the cup" — "water" is a NOUN (the substance being poured). The action is "pour." Resolve "the water" and "the cup."
- "Use the iron to press the shirt" — "iron" is a NOUN (the appliance). The action is "use." Resolve "the iron" and "the shirt."
- "Wipe the dust off the shelf" — "dust" is a NOUN (the substance to remove). The action is "wipe." Resolve "the dust" and "the shelf."

The underlying principle: in English imperative commands, the FIRST word (or first phrase) is almost always the verb — what the robot should DO. Any subsequent words are the objects — what the robot should act ON. If a reference appears in the verb position and the sentence makes sense with it as an action, it IS the action. Do not try to ground it as a scene entity.

The test: read the sentence aloud. Identify the main verb — what is the robot being asked to DO? Any reference that IS the main verb (or part of a compound verb) should be skipped, not grounded.

For any reference you skip as an action verb, classify it as outcome: "RESOLVED" with matched_entity_id: null, confidence: 1.0, and include in your reasoning: "Skipped — this is the action verb of the command, not a scene entity."

CRITICAL — COMMON-SENSE EQUIVALENCE FOR MATCHING:

When matching a reference to a scene entity, use COMMON-SENSE EQUIVALENCE — not literal string matching. The reference text and the scene entity labels may differ in formatting, capitalization, word boundaries, plurals, articles, typos, or synonyms while clearly referring to the same thing. A human reader would instantly see these as the same — you must do the same.

Apply these equivalence rules generously:

- CASE differences: "soap bottle" matches "SoapBottle" (the same words, different capitalization)
- WORD BOUNDARY differences: "soap bottle" matches "SoapBottle" or "soap_bottle" (same words, different separators)
- ARTICLE stripping: "the apple" matches "Apple", "an orange" matches "Orange"
- PLURALS: "knives" matches "Knife", "cups" matches "Cup"
- TYPOS: "knfe" matches "Knife", "appel" matches "Apple"
- ABBREVIATIONS: "fridge" matches "Refrigerator", "remote" matches "RemoteControl", "TV" matches "Television"
- SYNONYMS: "pot" matches "Pan" if no Pot exists, "couch" matches "Sofa", "cup" matches "Mug" when context suggests interchangeability
- PARTIAL MATCHES: "the bread knife" matches "Knife" if no more specific knife exists
- COMPOUND REFERENCES: "kitchen knife" matches "Knife" in a kitchen context

DO NOT return INFEASIBLE just because the reference doesn't appear in the entity list with the EXACT same formatting. Always normalize mentally before deciding. The principle is: would a person reading the user's command and seeing the scene entities say "yes, that's clearly the same thing"? If yes, classify as RESOLVED. The system depends on you applying this — if you're too strict with literal matching, valid tasks will be wrongly rejected.

If NO scene entity matches a reference (after applying common-sense equivalence):
- Is this a physical entity that should be in the scene but isn't? (The user asked for scissors but there are no scissors and nothing equivalent → the entity is missing.)
- List what IS available in the scene that could potentially serve a similar function.

When a reference cannot be matched to a scene entity, you must distinguish two fundamentally different failure modes before classifying it. The user could be referring to (a) a SPECIFIC named thing or person that should exist but doesn't, or (b) something VAGUE that depends on context you don't have. These look identical at the surface — both produce a reference with no scene match — but they require completely different responses from the system.

A SPECIFIC reference uses a concrete noun the user expects you to recognize. Examples: "the basket", "the paring knife", "Tommy", "the bedroom", "the kettle", "grandma". The user named a particular thing or person they expect to be there. If the scene doesn't contain it, the WORLD is incomplete. The system can attempt to repair this by substituting an available alternative — bowl for basket, spoon for knife, sofa room for bedroom. Classify these as INFEASIBLE.

A VAGUE reference uses a pronoun, deictic expression, or context-dependent phrase that assumes shared context the system doesn't have. Examples: "that thing", "this", "it", "the one", "the stuff", "him", "her", "them", "that guy", "the kid", "my friend" (when no friend appears in scene), "over there", "in here", "the place I mentioned", "what I asked for". The user assumed you would know what they meant from context. Without that context, the COMMAND is incomplete — there is no specific thing for the system to substitute, because there is no specific thing the user identified in the first place. Classify these as CLARIFY and ask the user to specify.

The reasoning principle is: a SPECIFIC reference fails because the WORLD lacks the right thing (repairable by substitution); a VAGUE reference fails because the COMMAND lacks the right information (only the user can resolve it).

Examples across reference types:

Object — SPECIFIC missing:
  Command: "Put the apple in the basket"
  Scene has: Apple, Bowl, Plate, Cup
  Reference: "basket"
  Classification: INFEASIBLE
  Reason: "basket" is a specific named container; bowl is a viable substitute.

Object — VAGUE deictic:
  Command: "Put that thing on the countertop"
  Scene has: Apple, Bowl, Knife, CounterTop
  Reference: "that thing"
  Classification: CLARIFY
  Reason: "that thing" is a vague pronoun. The user assumed shared context. The system cannot substitute because no specific item was named.
  Clarification: "Could you tell me which object you mean by 'that thing'? I see Apple, Bowl, Knife on the counter."

Person — SPECIFIC missing:
  Command: "Bring the medication to grandma"
  Scene has: Bed, Pillow, Lamp, Toddler
  Reference: "grandma"
  Classification: INFEASIBLE
  Reason: "grandma" is a specific named person not present in the scene; toddler is a different person, not a substitute.

Person — VAGUE pronoun:
  Command: "Hand it to him"
  Scene has: Bed, Toddler, Adult Male
  Reference: "him"
  Classification: CLARIFY
  Reason: "him" could refer to the toddler or the adult male. Without context, the system cannot determine which person was meant.
  Clarification: "Who do you mean by 'him' — the toddler or the adult male?"

Location — SPECIFIC missing:
  Command: "Take the laundry to the bedroom"
  Scene has: Kitchen, LivingRoom, Bathroom
  Reference: "bedroom"
  Classification: INFEASIBLE
  Reason: "bedroom" is a specific named room not present in the available locations.

Location — VAGUE spatial:
  Command: "Put it over there"
  Scene has: CounterTop, DiningTable, Sink
  Reference: "over there"
  Classification: CLARIFY
  Reason: "over there" is a vague spatial reference. The system cannot determine which location was meant.
  Clarification: "Where exactly do you want me to put it — the counter, the dining table, or the sink?"

If you classify a reference as CLARIFY for vagueness, the clarification_question field should ask the user to specify what they meant, not ask about safety attributes (the safety attribute checks in STEP 4 only apply to references that successfully resolved to a scene entity).

CRITICAL — RECIPIENT PRESENCE REQUIREMENT:

There is one more case to handle separately. When a person reference fills the RECIPIENT role of an action (the person receiving an object, being given something, being handed something, or being interacted with directly), that person must be physically present in the scene for the action to be executable. Giving an apple to a baby that isn't there is physically impossible — the robot has no one to walk to and no one to hand the apple to. This is different from cases where a person is mentioned for safety reasoning context (e.g., "Don't put the knife on the counter where the baby plays"), in which the baby is a contextual concern but not the action target.

If a reference is the action recipient AND no scene entity matches AND the reference is a SPECIFIC named person (not a vague pronoun), classify it as INFEASIBLE — not CLARIFY, not RESOLVED. The action cannot happen because the recipient is not physically present. The pipeline can attempt to repair this by checking if there is another suitable person in the scene, or by surfacing it to the user as "this person is not here." Do NOT synthesize a recipient from the command text alone — the action requires physical presence, which the command text cannot provide.

The distinction:
- "Don't pour hot coffee for the baby" — baby is a contextual safety concern, not the action target. The action is on the coffee. Even if the baby is not visible, the safety reasoning should proceed (treat the baby as a hypothetical recipient whose age determines the safety constraints).
- "Give the apple to the baby" — baby IS the action target. The action is the give-to-baby operation. If the baby is not in the scene, the action is INFEASIBLE.

How to distinguish: look at the frame role and the verb. Verbs like "give", "hand", "pass", "bring (to)", "deliver (to)", "show (to)" make the recipient the action target. Verbs like "don't", "avoid", "keep away from", "make sure not to" mention the person for context but the action target is something else.

Examples:

Recipient required and present:
  Command: "Give the apple to the baby"
  Scene has: Apple, Bowl, Baby
  Reference: "the baby"
  Classification: RESOLVED (baby is in scene)

Recipient required and absent:
  Command: "Give the apple to the baby"
  Scene has: Apple, Bowl, Knife (no baby)
  Reference: "the baby"
  Classification: INFEASIBLE
  Reason: The action requires giving the apple to the baby, but no baby is present in the scene. The action cannot be executed.
  available_alternatives: list other people in the scene if any (in this example, none)

Recipient is contextual (not action target):
  Command: "Don't pour the hot coffee where the baby plays"
  Scene has: Coffee, Counter (no baby visible)
  Reference: "the baby"
  Frame role: not the recipient — the action is "pour" with "coffee" as theme and "where the baby plays" as a manner/location modifier
  Classification: This depends on the frame analysis. If the frame correctly identifies "the baby" as a contextual safety concern (not the recipient), then RESOLVED is acceptable for safety reasoning purposes (treat as hypothetical present-but-unseen). If it's classified as a recipient, then INFEASIBLE applies.

══════════════════════════════════════════════════════════════════════════
STEP 4: COMPLETENESS VERIFICATION
══════════════════════════════════════════════════════════════════════════

For each resolved reference, verify that all SAFETY-RELEVANT attributes are known:

For persons:
- Is their age or age group known? (from scene perception or from the command text, "my 8-year-old" provides this, "my son" does not)
- Is their physical capability known?
- Are there any medical conditions, allergies, or vulnerabilities that would affect safety?

For objects:
- Are hazard-relevant properties known? (temperature, sharpness, chemical nature, weight, material composition)
- Is the specific TYPE known when it matters? ("the scissors" — craft scissors or kitchen shears?)

For locations:
- Is the current state of the location known? (wet floor? active stove? accessible to children?)

If a safety-relevant attribute is unknown AND it could change the safety assessment:
- Generate a specific clarification question explaining WHAT is unknown, WHY it matters for safety, and WHAT DIFFERENCE it would make.
- Example: "You asked me to hand the scissors to your son for his school project. I want to make sure I pick the right ones, could you tell me how old he is? For a younger child I'd choose the safety scissors, while an older child can handle the craft scissors."

══════════════════════════════════════════════════════════════════════════
STEP 5: OUTCOME CLASSIFICATION
══════════════════════════════════════════════════════════════════════════

Classify the overall grounding outcome:

ALL_RESOLVED: Every reference matches a scene entity with high confidence, the robot has the required skills, and all safety-relevant attributes are known. The system can proceed to safety evaluation.

SKILL_INFEASIBLE: The robot lacks a capability required for this task. Report the capability gap and available alternative capabilities. The system will attempt to repair using skills the robot has.

ENTITY_INFEASIBLE: One or more physical entities required for the task do not exist in the scene. Report what's missing and what alternatives are available. The system will attempt repair using available resources.

NEEDS_CLARIFICATION: The system needs more information from the user before it can proceed safely. This applies in two situations: (a) entities are identified and skills are available, but safety-critical attributes are unknown (e.g., a child's age is needed to choose between safety scissors and craft scissors); (b) one or more references are vague, deictic, or context-dependent and the system cannot determine what the user meant (e.g., "that thing", "him", "over there"). In either case, report exactly what is unknown and why it matters, then ask the user before proceeding. Do NOT attempt repair when references are vague — substituting random items for an unidentified reference produces nonsensical results.

Also classify each individual reference's outcome (RESOLVED, INFEASIBLE, or CLARIFY). Remember the distinction from STEP 3: SPECIFIC missing references are INFEASIBLE (repairable by substitution), VAGUE references are CLARIFY (require user input).

══════════════════════════════════════════════════════════════════════════
OUTPUT
══════════════════════════════════════════════════════════════════════════

Output a JSON object:
{{
  "reference_inventory": [
    {{
      "reference_text": "the text from the command",
      "expected_type": "object|person|location",
      "frame_role": "what role this fills in the frame",
      "contextual_clues": "what the command context tells us about it"
    }}
  ],
  "skill_verification": {{
    "action": "{parsed_action}",
    "skill_available": true/false,
    "mapped_capabilities": ["which robot capabilities this maps to"],
    "capability_gap": "what's missing, if anything" or null,
    "alternative_capabilities": ["what the robot COULD do instead"] or [],
    "physical_constraints": ["any physical limitations"] or [],
    "reasoning": "explanation of skill assessment"
  }},
  "resolutions": [
    {{
      "reference_text": "the reference",
      "outcome": "RESOLVED|INFEASIBLE|CLARIFY",
      "matched_entity_id": "scene entity id" or null,
      "confidence": 0.0 to 1.0,
      "reasoning": "why this match, considering the full command context",
      "ambiguous": true/false,
      "alternative_ids": ["other plausible matches"] or [],
      "missing_safety_attributes": [
        {{"attribute": "what's unknown", "why_it_matters": "safety relevance", "would_change_assessment": "how"}}
      ],
      "available_alternatives": ["if INFEASIBLE, what's available in the scene"],
      "clarification_question": "if CLARIFY, the specific question to ask" or null
    }}
  ],
  "overall_outcome": "ALL_RESOLVED|SKILL_INFEASIBLE|ENTITY_INFEASIBLE|NEEDS_CLARIFICATION",
  "summary": "brief natural language summary of the grounding result"
}}

Respond with ONLY the JSON object."""


# ============================================================================
# 5. REPAIR GENERATION
# Frameworks: Script Theory (Schank & Abelson, 1977) for activity-appropriate
#   repairs, Hierarchy of Controls (ISO 12100) for principled intervention
#   ordering, Counterfactual reasoning for minimal intervention
# Decomposition: Counterfactual Generation
#   (Understand defect → Identify need → Find intervention points →
#    Generate within script context → Verify diversity)
# ============================================================================

