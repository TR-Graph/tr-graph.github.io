"""
TR-Graph Task Repair: Repair Operators
=============================================

This module implements the six repair operators:
1. Substitute - Replace unsafe objects/actions with alternatives
2. Constrain - Add missing safety guards
3. Decompose - Split task into safer subgoals
4. Relax - Minimally relax conflicting constraints
5. Reorder - Adjust execution order
6. Retarget - Redirect goal to safe proxy

All operators use LLM-generated knowledge (affordances, relations) rather than
hardcoded mappings.

Architecture (per reviewer feedback):
- LLM proposes operator instance in strict JSON schema
- Deterministic precondition function validates proposal
- If invalid: reject and retry with feedback
- If valid: apply deterministic effect function

This ensures LLM is only generating hypotheses, not deciding validity.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Tuple, Set
from enum import Enum
from copy import deepcopy
import json


# OPERATOR TYPES — canonical definition is in data_structures.py

from ctr.data_structures import OperatorType


@dataclass
class Intervention:
    """A single change to task variables."""
    variable_path: str           # e.g., "object.temperature", "container"
    original_value: Any
    new_value: Any
    operator: OperatorType
    rationale: str = ""


@dataclass
class OperatorResult:
    """Result of applying an operator."""
    success: bool
    operator: OperatorType
    interventions: List[Intervention] = field(default_factory=list)
    modified_task: Optional[Any] = None  # Modified TaskVariables
    explanation: str = ""
    confidence: float = 1.0
    validation_passed: bool = True
    validation_message: str = ""


@dataclass
class PreconditionResult:
    """Result of precondition check."""
    valid: bool
    reason: str
    failed_checks: List[str] = field(default_factory=list)


# PRECONDITION FUNCTIONS (DETERMINISTIC)

class OperatorPreconditions:
    """
    Deterministic precondition checks for each operator.
    
    These functions validate LLM proposals before application.
    The LLM proposes, these functions validate.
    """
    
    @staticmethod
    def check_substitute(
        proposal: Dict[str, Any],
        task_variables: Any,
        scene_graph: Any,
        knowledge_generator: Any = None
    ) -> PreconditionResult:
        """
        Validate substitute operator proposal.
        
        Checks:
        1. Replacement exists in scene
        2. Replacement affords required action (if knowledge_generator available)
        3. Replacement has lower or equal hazard
        4. Type compatibility
        """
        failed_checks = []
        
        replacement_id = proposal.get("replacement_id")
        replacement_label = proposal.get("replacement_label")
        target_variable = proposal.get("target_variable")
        
        # Check 1: Replacement exists in scene
        if scene_graph:
            exists = False
            replacement_node = None
            for node_id, node in scene_graph.nodes.items():
                if node_id == replacement_id or node.label == replacement_label:
                    exists = True
                    replacement_node = node
                    break
            
            if not exists:
                failed_checks.append(f"replacement '{replacement_id or replacement_label}' not found in scene")
        
        # Check 2: Affordance check (if we have knowledge generator)
        if knowledge_generator and replacement_node:
            required_action = proposal.get("required_action")
            if required_action:
                affordances = knowledge_generator.affordance_gen.generate(
                    replacement_node.label,
                    {"type": replacement_node.type.value if hasattr(replacement_node.type, 'value') else str(replacement_node.type)}
                )
                action_afforded = any(
                    required_action.lower() in aff.get("action", "").lower()
                    for aff in affordances
                )
                if not action_afforded:
                    failed_checks.append(f"replacement cannot perform action '{required_action}'")
        
        # Check 3: Hazard reduction
        original_hazard = proposal.get("original_hazard_level", 0)
        replacement_hazard = proposal.get("replacement_hazard_level", 0)
        
        # Convert string hazard levels to numeric
        hazard_order = {"none": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}
        if isinstance(original_hazard, str):
            original_hazard = hazard_order.get(original_hazard.lower(), 2)
        if isinstance(replacement_hazard, str):
            replacement_hazard = hazard_order.get(replacement_hazard.lower(), 2)
        
        if replacement_hazard > original_hazard:
            failed_checks.append(f"replacement has higher hazard ({replacement_hazard}) than original ({original_hazard})")
        
        # Check 4: Type compatibility
        # This check is lenient - only reject clear category mismatches
        # For unrecognized types, trust the LLM's judgment from the proposal
        original_type = proposal.get("original_type")
        replacement_type = proposal.get("replacement_type")

        if original_type and replacement_type:
            # Expanded type categories covering common household objects
            compatible_types = {
                "container": {
                    "container", "cup", "mug", "glass", "bowl", "bottle",
                    "jar", "pitcher", "thermos", "sippy_cup", "tumbler",
                    "pot", "pan", "kettle", "vase", "bucket", "bin"
                },
                "tool": {
                    "tool", "utensil", "implement", "knife", "scissors",
                    "screwdriver", "hammer", "wrench", "pliers", "saw",
                    "spatula", "ladle", "tongs", "whisk", "peeler"
                },
                "food": {
                    "food", "beverage", "drink", "snack", "meal",
                    "fruit", "vegetable", "meat", "dairy", "grain"
                },
                "medication": {
                    "medication", "medicine", "drug", "pill", "tablet",
                    "capsule", "syrup", "drops", "ointment", "cream",
                    "supplement", "vitamin", "prescription"
                },
                "cleaning": {
                    "cleaning", "cleaner", "detergent", "soap", "disinfectant",
                    "bleach", "chemical", "spray", "solution"
                },
                "electronic": {
                    "electronic", "device", "appliance", "gadget",
                    "phone", "tablet", "computer", "charger", "cable",
                    "remote", "controller", "battery"
                },
                "furniture": {
                    "furniture", "chair", "table", "desk", "bed",
                    "couch", "sofa", "shelf", "cabinet", "drawer"
                },
                "clothing": {
                    "clothing", "clothes", "shirt", "pants", "dress",
                    "jacket", "coat", "shoes", "hat", "gloves"
                },
                "toy": {
                    "toy", "game", "puzzle", "doll", "ball",
                    "block", "stuffed_animal", "action_figure"
                }
            }

            orig_category = None
            repl_category = None

            orig_lower = original_type.lower()
            repl_lower = replacement_type.lower()

            for category, types in compatible_types.items():
                # Check if type matches category or any term in the category
                if orig_lower in types or category in orig_lower:
                    orig_category = category
                # Also check for partial matches (e.g., "coffee_mug" contains "mug")
                if orig_category is None:
                    for type_term in types:
                        if type_term in orig_lower or orig_lower in type_term:
                            orig_category = category
                            break

                if repl_lower in types or category in repl_lower:
                    repl_category = category
                if repl_category is None:
                    for type_term in types:
                        if type_term in repl_lower or repl_lower in type_term:
                            repl_category = category
                            break

            # Only reject if BOTH types are recognized AND they're in different categories
            # If either type is unrecognized, trust the LLM's judgment
            if orig_category and repl_category and orig_category != repl_category:
                failed_checks.append(f"type mismatch: {original_type} ({orig_category}) -> {replacement_type} ({repl_category})")
        
        # Check 5: Replacement is different from original
        original_id = proposal.get("original_id")
        if original_id and original_id == replacement_id:
            failed_checks.append("replacement is same as original")
        
        if failed_checks:
            return PreconditionResult(
                valid=False,
                reason="; ".join(failed_checks),
                failed_checks=failed_checks
            )
        
        return PreconditionResult(valid=True, reason="all preconditions satisfied")
    
    @staticmethod
    def check_constrain(
        proposal: Dict[str, Any],
        task_variables: Any,
        scene_graph: Any,
        llm_client: Any = None
    ) -> PreconditionResult:
        """
        Validate constrain operator proposal.

        Checks:
        1. Constraint is satisfiable in current scene
        2. Constraint doesn't contradict existing constraints (LLM-driven if available)
        3. Required equipment/resources exist (if specified)
        """
        failed_checks = []

        constraints_to_add = proposal.get("constraints_to_add", [])
        task_desc = task_variables.original_utterance if hasattr(task_variables, 'original_utterance') else str(task_variables.goal)

        for constraint in constraints_to_add:
            constraint_type = constraint.get("type", "")
            description = constraint.get("description", "")
            how_to_satisfy = constraint.get("how_to_satisfy", "")

            # Check equipment constraints
            if constraint_type == "equipment":
                required_item = constraint.get("required_item")
                if required_item and scene_graph:
                    # Check if equipment exists in scene
                    exists = any(
                        required_item.lower() in node.label.lower()
                        for node in scene_graph.nodes.values()
                    )
                    if not exists:
                        failed_checks.append(f"required equipment '{required_item}' not in scene")

            # Check environmental constraints
            if constraint_type == "environmental":
                required_location = constraint.get("required_location")
                if required_location and scene_graph:
                    exists = any(
                        required_location.lower() in node.label.lower()
                        for node in scene_graph.nodes.values()
                        if hasattr(node.type, 'value') and node.type.value == "region"
                    )
                    # Environmental constraints are soft - don't fail, just warn

            # Check for contradictions with existing constraints
            if task_variables.constraints:
                for existing in task_variables.constraints:
                    existing_desc = existing.description if hasattr(existing, 'description') else str(existing)

                    # Use LLM for contradiction detection if available
                    if llm_client:
                        try:
                            user_prompt = CONTRADICTION_CHECK_USER_TEMPLATE.format(
                                existing_constraint=existing_desc,
                                new_constraint=description,
                                task_description=task_desc,
                                retry_feedback=""
                            )
                            response = llm_client.generate(
                                CONTRADICTION_CHECK_SYSTEM_PROMPT,
                                user_prompt
                            )
                            # Parse response - handle LLMResponse objects
                            if hasattr(response, 'text'):
                                text = response.text
                            elif isinstance(response, str):
                                text = response
                            else:
                                text = str(response)
                            text = text.strip()
                            if text.startswith("```"):
                                text = text.split("```")[1]
                                if text.startswith("json"):
                                    text = text[4:]
                            text = text.strip()
                            import json as json_module
                            try:
                                result = json_module.loads(text)
                            except:
                                start = text.find('{')
                                end = text.rfind('}')
                                if start != -1 and end != -1:
                                    result = json_module.loads(text[start:end+1])
                                else:
                                    result = None

                            if result and result.get("contradicts", False):
                                explanation = result.get("explanation", "LLM detected contradiction")
                                failed_checks.append(f"constraint '{description}' contradicts '{existing_desc}': {explanation}")

                        except Exception as e:
                            # Fall back to basic check
                            OperatorPreconditions._basic_contradiction_check(
                                existing_desc.lower(), description.lower(), description, existing_desc, failed_checks
                            )
                    else:
                        # Basic contradiction check without LLM
                        OperatorPreconditions._basic_contradiction_check(
                            existing_desc.lower(), description.lower(), description, existing_desc, failed_checks
                        )
        
        if failed_checks:
            return PreconditionResult(
                valid=False,
                reason="; ".join(failed_checks),
                failed_checks=failed_checks
            )
        
        return PreconditionResult(valid=True, reason="constraints are satisfiable")

    @staticmethod
    def _basic_contradiction_check(
        existing_desc_lower: str,
        new_desc_lower: str,
        new_desc_original: str,
        existing_desc_original: str,
        failed_checks: List[str]
    ):
        """
        Basic contradiction check using expanded antonym pairs.
        Used as fallback when LLM is not available.
        """
        # Expanded list of common antonym pairs
        contradiction_pairs = [
            # Temperature
            ("hot", "cold"), ("warm", "cool"), ("heated", "chilled"),
            # Speed/Time
            ("fast", "slow"), ("quick", "gradual"), ("immediate", "delayed"),
            # State
            ("open", "closed"), ("on", "off"), ("locked", "unlocked"),
            ("sealed", "unsealed"), ("covered", "uncovered"),
            # Position/Distance
            ("near", "far"), ("close", "distant"), ("high", "low"),
            ("inside", "outside"),
            # Sound
            ("loud", "quiet"), ("noisy", "silent"),
            # Physical properties
            ("heavy", "light"), ("wet", "dry"), ("sharp", "blunt"),
            ("hard", "soft"), ("full", "empty"),
            # Safety
            ("safe", "dangerous"), ("gentle", "forceful"),
            # Boolean concepts
            ("allow", "forbid"), ("permit", "prohibit"),
            ("start", "stop"), ("enable", "disable"),
            ("connect", "disconnect"), ("attach", "detach"),
        ]

        for word1, word2 in contradiction_pairs:
            if word1 in existing_desc_lower and word2 in new_desc_lower:
                failed_checks.append(f"constraint '{new_desc_original}' contradicts existing '{existing_desc_original}'")
                break
            if word2 in existing_desc_lower and word1 in new_desc_lower:
                failed_checks.append(f"constraint '{new_desc_original}' contradicts existing '{existing_desc_original}'")
                break

    @staticmethod
    def check_decompose(
        proposal: Dict[str, Any],
        task_variables: Any,
        scene_graph: Any
    ) -> PreconditionResult:
        """
        Validate decompose operator proposal.
        
        Checks:
        1. All subgoals have valid actions
        2. Dependencies form a valid DAG (no cycles)
        3. Objects referenced exist in scene
        4. Safety checkpoints come before risky steps
        """
        failed_checks = []
        
        subgoals = proposal.get("subgoals", [])
        safety_checkpoints = proposal.get("safety_checkpoints", [])
        
        if not subgoals:
            failed_checks.append("no subgoals provided")
            return PreconditionResult(valid=False, reason="no subgoals", failed_checks=failed_checks)
        
        # Check 1: Valid actions
        invalid_actions = {"", None, "undefined", "unknown"}
        for sg in subgoals:
            action = sg.get("action", "")
            if action.lower() in invalid_actions or not action:
                failed_checks.append(f"subgoal step {sg.get('step')} has invalid action")
        
        # Check 2: DAG validity (no cycles)
        step_deps = {}
        for sg in subgoals:
            step = sg.get("step")
            deps = sg.get("dependencies", [])
            step_deps[step] = deps
        
        # Simple cycle detection
        def has_cycle(step, visited, rec_stack):
            visited.add(step)
            rec_stack.add(step)
            
            for dep in step_deps.get(step, []):
                if dep not in visited:
                    if has_cycle(dep, visited, rec_stack):
                        return True
                elif dep in rec_stack:
                    return True
            
            rec_stack.remove(step)
            return False
        
        visited = set()
        for step in step_deps:
            if step not in visited:
                if has_cycle(step, visited, set()):
                    failed_checks.append("dependency cycle detected in subgoals")
                    break
        
        # Check 3: Objects exist in scene
        if scene_graph:
            scene_labels = {node.label.lower() for node in scene_graph.nodes.values()}
            for sg in subgoals:
                for obj in sg.get("objects", []):
                    if obj.lower() not in scene_labels:
                        # Not a hard failure, just a warning
                        pass
        
        # Check 4: Safety checkpoints ordering
        if safety_checkpoints:
            non_safety_steps = [sg.get("step") for sg in subgoals if sg.get("step") not in safety_checkpoints]
            for checkpoint in safety_checkpoints:
                # Find steps that depend on this checkpoint
                dependent_steps = [
                    step for step, deps in step_deps.items()
                    if checkpoint in deps and step in non_safety_steps
                ]
                # This is informational, not a failure
        
        if failed_checks:
            return PreconditionResult(
                valid=False,
                reason="; ".join(failed_checks),
                failed_checks=failed_checks
            )
        
        return PreconditionResult(valid=True, reason="decomposition is valid")
    
    @staticmethod
    def check_relax(
        proposal: Dict[str, Any],
        task_variables: Any
    ) -> PreconditionResult:
        """
        Validate relax operator proposal.
        
        Checks:
        1. Constraint to relax exists
        2. Constraint is not marked as safety-critical
        3. Relaxation degree is within bounds
        """
        failed_checks = []
        
        constraint_to_relax = proposal.get("constraint_description", "")
        is_safety_critical = proposal.get("is_safety_critical", False)
        relaxation_degree = proposal.get("relaxation_degree", 0.5)
        
        # Check 1: Constraint exists
        constraint_found = False
        constraint_is_hard = False
        
        if task_variables.constraints:
            for c in task_variables.constraints:
                desc = c.description if hasattr(c, 'description') else str(c)
                if constraint_to_relax.lower() in desc.lower():
                    constraint_found = True
                    constraint_is_hard = c.hard if hasattr(c, 'hard') else False
                    break
        
        if not constraint_found:
            # Also check preferences
            if task_variables.preferences:
                for p in task_variables.preferences:
                    desc = p.description if hasattr(p, 'description') else str(p)
                    if constraint_to_relax.lower() in desc.lower():
                        constraint_found = True
                        break
        
        if not constraint_found:
            failed_checks.append(f"constraint '{constraint_to_relax}' not found")
        
        # Check 2: Not safety-critical
        if is_safety_critical:
            failed_checks.append("cannot relax safety-critical constraint")
        
        if constraint_is_hard:
            failed_checks.append("constraint is marked as hard (non-relaxable)")
        
        # Check 3: Relaxation bounds
        if relaxation_degree < 0 or relaxation_degree > 1:
            failed_checks.append(f"relaxation degree {relaxation_degree} out of bounds [0,1]")
        
        if failed_checks:
            return PreconditionResult(
                valid=False,
                reason="; ".join(failed_checks),
                failed_checks=failed_checks
            )
        
        return PreconditionResult(valid=True, reason="constraint can be relaxed")
    
    @staticmethod
    def check_reorder(
        proposal: Dict[str, Any],
        task_variables: Any
    ) -> PreconditionResult:
        """
        Validate reorder operator proposal.
        
        Checks:
        1. New ordering contains same steps as original
        2. Dependencies are still satisfied
        3. Safety steps are not moved after risky steps
        """
        failed_checks = []
        
        new_order = proposal.get("new_order", [])
        original_plan = task_variables.plan or []
        safety_steps = proposal.get("safety_steps", [])
        
        # Check 1: Same steps
        if len(new_order) != len(original_plan):
            failed_checks.append(f"new order has {len(new_order)} steps, original has {len(original_plan)}")
        
        # Check that all original steps are present
        original_steps = set()
        for step in original_plan:
            if hasattr(step, 'action'):
                original_steps.add(step.action)
            elif isinstance(step, dict):
                original_steps.add(step.get('action', str(step)))
            else:
                original_steps.add(str(step))
        
        new_steps = set()
        for step in new_order:
            if isinstance(step, dict):
                new_steps.add(step.get('action', str(step)))
            else:
                new_steps.add(str(step))
        
        missing = original_steps - new_steps
        extra = new_steps - original_steps
        
        if missing:
            failed_checks.append(f"missing steps in new order: {missing}")
        if extra:
            failed_checks.append(f"extra steps in new order: {extra}")
        
        # Check 3: Safety steps ordering
        if safety_steps:
            safety_positions = []
            non_safety_positions = []
            
            for i, step in enumerate(new_order):
                step_id = step.get('step') if isinstance(step, dict) else i
                if step_id in safety_steps:
                    safety_positions.append(i)
                else:
                    non_safety_positions.append(i)
            
            # Safety steps should generally come first
            if safety_positions and non_safety_positions:
                if max(safety_positions) > min(non_safety_positions):
                    # This is a warning, not necessarily a failure
                    pass
        
        if failed_checks:
            return PreconditionResult(
                valid=False,
                reason="; ".join(failed_checks),
                failed_checks=failed_checks
            )
        
        return PreconditionResult(valid=True, reason="reordering is valid")
    
    @staticmethod
    def check_retarget(
        proposal: Dict[str, Any],
        task_variables: Any,
        scene_graph: Any
    ) -> PreconditionResult:
        """
        Validate retarget operator proposal.
        
        Checks:
        1. Proxy goal is different from original
        2. Proxy goal is achievable with available resources
        3. User satisfaction estimate is reasonable
        """
        failed_checks = []
        
        original_goal = task_variables.goal
        proxy_goal = proposal.get("proxy_goal", "")
        user_satisfaction = proposal.get("user_satisfaction", 0.5)
        required_resources = proposal.get("required_resources", [])
        
        # Check 1: Different from original
        if proxy_goal.lower() == original_goal.lower():
            failed_checks.append("proxy goal is identical to original")
        
        # Check 2: Resources available
        if required_resources and scene_graph:
            scene_labels = {node.label.lower() for node in scene_graph.nodes.values()}
            for resource in required_resources:
                if resource.lower() not in scene_labels:
                    failed_checks.append(f"required resource '{resource}' not in scene")
        
        # Check 3: Satisfaction bounds
        if user_satisfaction < 0 or user_satisfaction > 1:
            failed_checks.append(f"user satisfaction {user_satisfaction} out of bounds [0,1]")
        
        # Check 4: Proxy goal is not empty
        if not proxy_goal or proxy_goal.strip() == "":
            failed_checks.append("proxy goal is empty")
        
        if failed_checks:
            return PreconditionResult(
                valid=False,
                reason="; ".join(failed_checks),
                failed_checks=failed_checks
            )
        
        return PreconditionResult(valid=True, reason="proxy goal is valid")


# LLM PROMPTS FOR OPERATORS

SUBSTITUTE_SYSTEM_PROMPT = """You are a task repair assistant. Given an unsafe object or action, find safe substitutes that preserve the user's intent.

Consider:
- Functional equivalence (can substitute perform the same role?)
- Safety improvement (is substitute safer?)
- Availability (is substitute present in scene?)
- Intent preservation (does substitute still achieve the goal?)

Output ONLY valid JSON matching the exact schema provided."""


SUBSTITUTE_USER_TEMPLATE = """Find substitutes for this unsafe element.

Original: {original}
Original ID: {original_id}
Original Type: {original_type}
Original Hazard Level: {original_hazard}
Properties: {properties}
Problem: {problem}
Required capability/action: {required_capability}

Available alternatives in scene:
{alternatives_json}

User's intent: {user_intent}

{retry_feedback}

Output JSON:
{{
  "replacement_id": "id of best substitute",
  "replacement_label": "name of substitute",
  "replacement_type": "type category",
  "replacement_hazard_level": "none|low|medium|high",
  "target_variable": "{target_variable}",
  "original_id": "{original_id}",
  "original_type": "{original_type}",
  "original_hazard_level": "{original_hazard}",
  "required_action": "{required_capability}",
  "why_suitable": "explanation of why this substitute works",
  "safety_improvement": "how it reduces hazard",
  "intent_preservation": 0.0 to 1.0,
  "confidence": 0.0 to 1.0
}}

Choose the substitute that best preserves intent while improving safety.
Respond with ONLY the JSON object."""


DECOMPOSE_SYSTEM_PROMPT = """You are a task decomposition assistant. Break complex or unsafe tasks into safer subgoals.

Principles:
- Safety checks should come before risky actions
- Preparation steps should come before execution
- Each subgoal should be independently safe
- Preserve the overall goal
- Dependencies must form a valid DAG (no cycles)

Output ONLY valid JSON matching the exact schema provided."""


DECOMPOSE_USER_TEMPLATE = """Decompose this task into safer subgoals.

Task: {task_description}
Action: {action}
Objects: {objects}
Safety concern: {safety_concern}

{retry_feedback}

Output JSON:
{{
  "subgoals": [
    {{
      "step": 1,
      "action": "action verb",
      "description": "what this step does",
      "objects": ["objects involved"],
      "safety_purpose": "why this step helps safety (or null)",
      "dependencies": [list of step numbers this depends on]
    }}
  ],
  "safety_checkpoints": [step numbers that are safety checks],
  "original_goal_achieved_at": step number
}}

Ensure safety checks come before risky actions.
Ensure dependencies form a valid DAG (no cycles).
Respond with ONLY the JSON object."""


RETARGET_SYSTEM_PROMPT = """You are a goal adaptation assistant. When a goal can't be safely achieved, find acceptable proxy goals.

Principles:
- Proxy should address the user's underlying need
- Proxy should be clearly safer
- Proxy should be achievable with available resources
- Be honest about what's different

Output ONLY valid JSON matching the exact schema provided."""


RETARGET_USER_TEMPLATE = """Find a safe proxy goal for this unsafe goal.

Original goal: {original_goal}
Why unsafe: {safety_concern}
User's underlying need: {underlying_need}
Available resources: {resources}

{retry_feedback}

Output JSON:
{{
  "proxy_goal": "description of proxy goal",
  "how_it_helps": "how it addresses underlying need",
  "what_differs": "what's different from original",
  "safety_improvement": "why it's safer",
  "user_satisfaction": 0.0 to 1.0,
  "required_resources": ["list of resources needed"],
  "explanation_for_user": "how to explain this to user"
}}

Focus on underlying need, not literal request.
Respond with ONLY the JSON object."""


CONSTRAIN_SYSTEM_PROMPT = """You are a safety constraint assistant. Add guards and preconditions to make tasks safe.

Types of constraints:
- Precondition (check before doing)
- Manner (how to do it)
- Environmental (prepare the space)
- Equipment (what to use)

Output ONLY valid JSON matching the exact schema provided."""


CONSTRAIN_USER_TEMPLATE = """Add safety constraints to this task.

Task: {task_description}
Current safety issue: {safety_issue}
Objects involved: {objects}
Recipient: {recipient}

Available objects in scene: {available_objects}

{retry_feedback}

Output JSON:
{{
  "constraints_to_add": [
    {{
      "type": "precondition|manner|environmental|equipment",
      "description": "what the constraint is",
      "how_to_satisfy": "how to meet this constraint",
      "required": true or false,
      "required_item": "specific item needed (or null)",
      "required_location": "specific location needed (or null)",
      "addresses_hazard": "which hazard this addresses"
    }}
  ],
  "modified_task_description": "task with constraints integrated",
  "residual_risk": "any remaining risk after constraints"
}}

Respond with ONLY the JSON object."""


RELAX_SYSTEM_PROMPT = """You are a constraint relaxation assistant. When constraints conflict with safety, find minimal relaxations.

Principles:
- NEVER relax safety-critical constraints
- Minimize the degree of relaxation
- Prefer relaxing preferences over hard constraints
- Maintain the spirit of the original constraint

Output ONLY valid JSON."""


RELAX_USER_TEMPLATE = """Determine how to relax this conflicting constraint.

Constraint: {constraint_description}
Why it conflicts: {conflict_reason}
Current task: {task_description}

Is this constraint safety-critical? Consider: does relaxing it create physical danger?

{retry_feedback}

Output JSON:
{{
  "constraint_description": "{constraint_description}",
  "is_safety_critical": true or false,
  "can_relax": true or false,
  "relaxation_degree": 0.0 to 1.0,
  "relaxed_form": "new form of constraint after relaxation",
  "justification": "why this relaxation is acceptable"
}}

Respond with ONLY the JSON object."""


REORDER_SYSTEM_PROMPT = """You are a task reordering assistant. Adjust step ordering to improve safety.

Principles:
- Safety checks should come first
- Preparation before execution
- Maintain necessary dependencies
- Don't remove any steps

Output ONLY valid JSON."""


REORDER_USER_TEMPLATE = """Reorder these steps to improve safety.

Current plan:
{current_plan}

Safety concern: {safety_concern}

{retry_feedback}

Output JSON:
{{
  "new_order": [
    {{"step": 1, "action": "action", "original_position": N}},
    ...
  ],
  "safety_steps": [step numbers that are safety-related],
  "rationale": "why this ordering is safer"
}}

Keep all original steps, just reorder them.
Respond with ONLY the JSON object."""


# LLM-DRIVEN VALIDATION PROMPTS

PROPERTY_RELEVANCE_SYSTEM_PROMPT = """You are a safety analysis assistant. Given a safety concern and a list of object properties, identify which properties are relevant to evaluating safety.

Focus on properties that directly relate to the hazard or could affect the safety assessment.

Output ONLY valid JSON."""


PROPERTY_RELEVANCE_USER_TEMPLATE = """Given this safety concern, which object properties are relevant?

Safety concern: {safety_concern}
Task: {task_description}

Available properties across objects: {all_properties}

{retry_feedback}

Output JSON:
{{
  "relevant_properties": ["list", "of", "relevant", "property", "names"],
  "reasoning": "brief explanation of why these properties matter for this safety concern"
}}

Respond with ONLY the JSON object."""


CONTRADICTION_CHECK_SYSTEM_PROMPT = """You are a constraint analysis assistant. Determine if two constraints contradict each other.

Constraints contradict if:
- They require opposite conditions (hot vs cold, open vs closed)
- Satisfying one makes it impossible to satisfy the other
- They have logically incompatible requirements

Output ONLY valid JSON."""


CONTRADICTION_CHECK_USER_TEMPLATE = """Do these two constraints contradict each other?

Existing constraint: {existing_constraint}
New constraint: {new_constraint}

Task context: {task_description}

{retry_feedback}

Output JSON:
{{
  "contradicts": true or false,
  "explanation": "why they do or do not contradict",
  "conflict_type": "direct_opposite | logical_incompatibility | resource_conflict | none"
}}

Respond with ONLY the JSON object."""


ATOMIC_ACTION_CHECK_SYSTEM_PROMPT = """You are a task analysis assistant. Determine if an action is atomic (cannot be meaningfully decomposed into sub-steps).

Atomic actions are single, indivisible operations like:
- Perceptual actions: look, listen, observe, watch
- Simple state changes: wait, stop, pause, hold
- Acknowledgments: confirm, acknowledge, accept, agree

Non-atomic actions can be broken into meaningful sub-steps.

Output ONLY valid JSON."""


ATOMIC_ACTION_CHECK_USER_TEMPLATE = """Is this action atomic (indivisible) or can it be decomposed?

Action: {action}
Task context: {task_description}

{retry_feedback}

Output JSON:
{{
  "is_atomic": true or false,
  "reasoning": "why this action is or is not atomic",
  "similar_to": "name of a common atomic action if applicable, or null"
}}

Respond with ONLY the JSON object."""


# REPAIR OPERATORS

class RepairOperators:
    """
    Implements the six repair operators using LLM-generated knowledge.
    
    Architecture:
    1. LLM proposes operator instance (structured JSON)
    2. Deterministic precondition validates proposal
    3. If invalid: retry with feedback (up to max_retries)
    4. If valid: apply deterministic effect
    """
    
    MAX_RETRIES = 2
    
    def __init__(self, llm_client=None, knowledge_generator=None):
        """
        Initialize operators.
        
        Args:
            llm_client: LLM client for generating repairs
            knowledge_generator: KnowledgeGenerator for affordances/relations
        """
        self.llm_client = llm_client
        self.knowledge_gen = knowledge_generator
        self.preconditions = OperatorPreconditions()
    
    # SUBSTITUTE OPERATOR
    
    def substitute(
        self,
        task_variables: Any,
        scene_graph: Any,
        target_variable: str,       # Which variable to substitute (e.g., "container")
        problem: str,               # Why current value is problematic
        required_capability: str    # What substitute must be able to do
    ) -> OperatorResult:
        """
        Replace an unsafe object/value with a safe alternative.
        
        Precondition: Alternative must exist with required affordance and lower hazard.
        """
        # Get current value
        original = self._get_variable(task_variables, target_variable)
        if original is None:
            return OperatorResult(
                success=False,
                operator=OperatorType.SUBSTITUTE,
                explanation=f"Variable '{target_variable}' not found",
                validation_passed=False,
                validation_message="target variable not found"
            )
        
        # Get alternatives from scene
        alternatives = self._get_alternatives(scene_graph, target_variable, original)
        if not alternatives:
            return OperatorResult(
                success=False,
                operator=OperatorType.SUBSTITUTE,
                explanation="No alternative objects available in scene",
                validation_passed=False,
                validation_message="no alternatives in scene"
            )

        # Filter properties to those relevant to the safety concern
        task_desc = task_variables.original_utterance or task_variables.goal
        alternatives = self.filter_relevant_properties(
            alternatives,
            safety_concern=problem,
            task_description=task_desc
        )


        # Extract original info
        original_id = ""
        original_label = ""
        original_type = "object"
        original_hazard = "medium"
        
        if hasattr(original, 'id'):
            original_id = original.id
        if hasattr(original, 'label'):
            original_label = original.label
        elif hasattr(original, 'reference_text'):
            original_label = original.reference_text
        if hasattr(original, 'grounded_id'):
            original_id = original.grounded_id or original_id
        
        # Get hazard from scene node
        if original_id and scene_graph and original_id in scene_graph.nodes:
            node = scene_graph.nodes[original_id]
            if hasattr(node.properties, 'hazard_level') and node.properties.hazard_level:
                original_hazard = node.properties.hazard_level.value
        
        # Get user intent
        user_intent = task_variables.original_utterance or task_variables.goal
        
        # Retry loop
        retry_feedback = ""
        for attempt in range(self.MAX_RETRIES + 1):
            # Generate proposal via LLM
            user_prompt = SUBSTITUTE_USER_TEMPLATE.format(
                original=original_label or str(original),
                original_id=original_id,
                original_type=original_type,
                original_hazard=original_hazard,
                properties=self._get_properties(original),
                problem=problem,
                required_capability=required_capability,
                alternatives_json=json.dumps(alternatives, indent=2),
                user_intent=user_intent,
                target_variable=target_variable,
                retry_feedback=retry_feedback
            )
            
            response = self.llm_client.generate(SUBSTITUTE_SYSTEM_PROMPT, user_prompt)
            proposal = self._parse_json(response)
            
            if not proposal:
                retry_feedback = "RETRY: Your previous response was not valid JSON. Please output only valid JSON."
                continue
            
            # Add context to proposal for validation
            proposal["target_variable"] = target_variable
            proposal["original_id"] = original_id
            proposal["original_type"] = original_type
            proposal["original_hazard_level"] = original_hazard
            proposal["required_action"] = required_capability
            
            # Validate proposal
            validation = self.preconditions.check_substitute(
                proposal, task_variables, scene_graph, self.knowledge_gen
            )
            
            if validation.valid:
                # Apply the substitution
                return self._apply_substitute(
                    task_variables, target_variable, original, proposal, validation
                )
            else:
                # Prepare feedback for retry
                retry_feedback = f"RETRY: Your previous proposal was invalid. Issues: {validation.reason}. Please propose a different substitute that addresses these issues."
        
        # All retries failed
        return OperatorResult(
            success=False,
            operator=OperatorType.SUBSTITUTE,
            explanation=f"Could not find valid substitute after {self.MAX_RETRIES + 1} attempts",
            validation_passed=False,
            validation_message=validation.reason if validation else "proposal parsing failed"
        )
    
    def _apply_substitute(
        self,
        task_variables: Any,
        target_variable: str,
        original: Any,
        proposal: Dict,
        validation: PreconditionResult
    ) -> OperatorResult:
        """Apply a validated substitute proposal."""
        modified_task = deepcopy(task_variables)
        
        replacement_id = proposal.get("replacement_id")
        replacement_label = proposal.get("replacement_label")
        
        # Create new object reference
        from ctr.data_structures import ObjectReference
        new_ref = ObjectReference(
            reference_text=replacement_label,
            grounded_id=replacement_id,
            role=original.role if hasattr(original, 'role') else ""
        )
        
        # Apply substitution
        if target_variable == "objects" or "object" in target_variable:
            # Replace in objects list
            for i, obj in enumerate(modified_task.objects):
                obj_id = obj.grounded_id if hasattr(obj, 'grounded_id') else None
                obj_text = obj.reference_text if hasattr(obj, 'reference_text') else str(obj)
                
                orig_id = proposal.get("original_id", "")
                if obj_id == orig_id or orig_id in obj_text:
                    modified_task.objects[i] = new_ref
                    break
        else:
            self._set_variable(modified_task, target_variable, new_ref)
        
        intervention = Intervention(
            variable_path=target_variable,
            original_value=str(original),
            new_value=replacement_label,
            operator=OperatorType.SUBSTITUTE,
            rationale=proposal.get("why_suitable", "")
        )
        
        return OperatorResult(
            success=True,
            operator=OperatorType.SUBSTITUTE,
            interventions=[intervention],
            modified_task=modified_task,
            explanation=f"Substituted {original} with {replacement_label}: {proposal.get('safety_improvement', '')}",
            confidence=proposal.get("confidence", 0.8),
            validation_passed=True,
            validation_message=validation.reason
        )
    
    # CONSTRAIN OPERATOR
    
    def constrain(
        self,
        task_variables: Any,
        safety_issue: str,
        scene_graph: Any = None
    ) -> OperatorResult:
        """
        Add safety constraints to the task.
        
        Precondition: Added constraint must be satisfiable.
        """
        # Get task info
        task_desc = task_variables.original_utterance or task_variables.goal
        objects = [
            obj.reference_text if hasattr(obj, 'reference_text') else str(obj)
            for obj in (task_variables.objects or [])
        ]
        recipient = ""
        if task_variables.recipient:
            recipient = task_variables.recipient.reference_text if hasattr(task_variables.recipient, 'reference_text') else str(task_variables.recipient)
        
        # Get available objects from scene
        available_objects = []
        if scene_graph:
            available_objects = [node.label for node in scene_graph.nodes.values()]
        
        # Retry loop
        retry_feedback = ""
        validation = None
        
        for attempt in range(self.MAX_RETRIES + 1):
            user_prompt = CONSTRAIN_USER_TEMPLATE.format(
                task_description=task_desc,
                safety_issue=safety_issue,
                objects=", ".join(objects),
                recipient=recipient or "none specified",
                available_objects=", ".join(available_objects) if available_objects else "unknown",
                retry_feedback=retry_feedback
            )
            
            response = self.llm_client.generate(CONSTRAIN_SYSTEM_PROMPT, user_prompt)
            proposal = self._parse_json(response)
            
            if not proposal:
                retry_feedback = "RETRY: Invalid JSON. Please output only valid JSON."
                continue
            
            # Validate proposal (with LLM-driven contradiction detection if available)
            validation = self.preconditions.check_constrain(
                proposal, task_variables, scene_graph, self.llm_client
            )
            
            if validation.valid:
                return self._apply_constrain(task_variables, proposal, validation)
            else:
                retry_feedback = f"RETRY: Invalid proposal. Issues: {validation.reason}. Please address these issues."
        
        # All retries failed
        return OperatorResult(
            success=False,
            operator=OperatorType.CONSTRAIN,
            explanation=f"Could not generate valid constraints after {self.MAX_RETRIES + 1} attempts",
            validation_passed=False,
            validation_message=validation.reason if validation else "parsing failed"
        )
    
    def _apply_constrain(
        self,
        task_variables: Any,
        proposal: Dict,
        validation: PreconditionResult
    ) -> OperatorResult:
        """Apply validated constraints."""
        from ctr.data_structures import TaskConstraint
        
        modified_task = deepcopy(task_variables)
        interventions = []
        
        for constraint_data in proposal.get("constraints_to_add", []):
            new_constraint = TaskConstraint(
                description=constraint_data.get("description", ""),
                constraint_type=constraint_data.get("type", ""),
                hard=constraint_data.get("required", True)
            )
            modified_task.constraints.append(new_constraint)
            
            interventions.append(Intervention(
                variable_path="constraints",
                original_value=None,
                new_value=new_constraint.description,
                operator=OperatorType.CONSTRAIN,
                rationale=constraint_data.get("addresses_hazard", "")
            ))
        
        return OperatorResult(
            success=True,
            operator=OperatorType.CONSTRAIN,
            interventions=interventions,
            modified_task=modified_task,
            explanation=f"Added {len(interventions)} safety constraint(s)",
            confidence=0.85,
            validation_passed=True,
            validation_message=validation.reason
        )
    
    # DECOMPOSE OPERATOR
    
    def decompose(
        self,
        task_variables: Any,
        safety_concern: str
    ) -> OperatorResult:
        """
        Break task into safer subgoals.
        
        Precondition: Task has decomposable structure.
        """
        task_desc = task_variables.original_utterance or task_variables.goal
        action = task_variables.action
        objects = [
            obj.reference_text if hasattr(obj, 'reference_text') else str(obj)
            for obj in (task_variables.objects or [])
        ]
        
        # Retry loop
        retry_feedback = ""
        validation = None
        
        for attempt in range(self.MAX_RETRIES + 1):
            user_prompt = DECOMPOSE_USER_TEMPLATE.format(
                task_description=task_desc,
                action=action,
                objects=", ".join(objects),
                safety_concern=safety_concern,
                retry_feedback=retry_feedback
            )
            
            response = self.llm_client.generate(DECOMPOSE_SYSTEM_PROMPT, user_prompt)
            proposal = self._parse_json(response)
            
            if not proposal:
                retry_feedback = "RETRY: Invalid JSON. Please output only valid JSON."
                continue
            
            # Validate proposal
            validation = self.preconditions.check_decompose(
                proposal, task_variables, None
            )
            
            if validation.valid:
                return self._apply_decompose(task_variables, proposal, validation)
            else:
                retry_feedback = f"RETRY: Invalid proposal. Issues: {validation.reason}. Please fix these issues."
        
        return OperatorResult(
            success=False,
            operator=OperatorType.DECOMPOSE,
            explanation=f"Could not generate valid decomposition after {self.MAX_RETRIES + 1} attempts",
            validation_passed=False,
            validation_message=validation.reason if validation else "parsing failed"
        )
    
    def _apply_decompose(
        self,
        task_variables: Any,
        proposal: Dict,
        validation: PreconditionResult
    ) -> OperatorResult:
        """Apply validated decomposition."""
        from ctr.data_structures import SubGoal
        
        modified_task = deepcopy(task_variables)
        modified_task.plan = []
        
        for sg_data in proposal.get("subgoals", []):
            subgoal = SubGoal(
                action=sg_data.get("action", ""),
                objects=sg_data.get("objects", []),
                description=sg_data.get("description", ""),
                is_safety_critical=sg_data.get("step") in proposal.get("safety_checkpoints", [])
            )
            modified_task.plan.append(subgoal)
        
        intervention = Intervention(
            variable_path="plan",
            original_value=task_variables.plan,
            new_value=modified_task.plan,
            operator=OperatorType.DECOMPOSE,
            rationale=f"Decomposed into {len(modified_task.plan)} steps with safety checkpoints"
        )
        
        return OperatorResult(
            success=True,
            operator=OperatorType.DECOMPOSE,
            interventions=[intervention],
            modified_task=modified_task,
            explanation=f"Decomposed task into {len(modified_task.plan)} subgoals",
            confidence=0.8,
            validation_passed=True,
            validation_message=validation.reason
        )
    
    # RELAX OPERATOR
    
    def relax(
        self,
        task_variables: Any,
        constraint_description: str,
        conflict_reason: str
    ) -> OperatorResult:
        """
        Minimally relax a conflicting constraint.
        
        Precondition: Constraint is NOT safety-critical.
        """
        task_desc = task_variables.original_utterance or task_variables.goal
        
        # Retry loop
        retry_feedback = ""
        validation = None
        
        for attempt in range(self.MAX_RETRIES + 1):
            user_prompt = RELAX_USER_TEMPLATE.format(
                constraint_description=constraint_description,
                conflict_reason=conflict_reason,
                task_description=task_desc,
                retry_feedback=retry_feedback
            )
            
            response = self.llm_client.generate(RELAX_SYSTEM_PROMPT, user_prompt)
            proposal = self._parse_json(response)
            
            if not proposal:
                retry_feedback = "RETRY: Invalid JSON."
                continue
            
            # Ensure constraint_description is in proposal
            proposal["constraint_description"] = constraint_description
            
            # Validate
            validation = self.preconditions.check_relax(proposal, task_variables)
            
            if validation.valid:
                return self._apply_relax(task_variables, proposal, validation)
            else:
                retry_feedback = f"RETRY: {validation.reason}"
        
        return OperatorResult(
            success=False,
            operator=OperatorType.RELAX,
            explanation=f"Could not relax constraint: {validation.reason if validation else 'unknown'}",
            validation_passed=False,
            validation_message=validation.reason if validation else "parsing failed"
        )
    
    def _apply_relax(
        self,
        task_variables: Any,
        proposal: Dict,
        validation: PreconditionResult
    ) -> OperatorResult:
        """Apply validated relaxation."""
        modified_task = deepcopy(task_variables)
        
        constraint_desc = proposal.get("constraint_description", "")
        relaxed_form = proposal.get("relaxed_form", "")
        
        # Find and modify the constraint
        original_desc = constraint_desc
        for i, c in enumerate(modified_task.constraints):
            desc = c.description if hasattr(c, 'description') else str(c)
            if constraint_desc.lower() in desc.lower():
                if hasattr(c, 'description'):
                    original_desc = c.description
                    c.description = relaxed_form
                break
        
        # Also check preferences
        for i, p in enumerate(modified_task.preferences):
            desc = p.description if hasattr(p, 'description') else str(p)
            if constraint_desc.lower() in desc.lower():
                if hasattr(p, 'description'):
                    original_desc = p.description
                    p.description = relaxed_form
                break
        
        intervention = Intervention(
            variable_path="constraints",
            original_value=constraint_desc,
            new_value=relaxed_form,
            operator=OperatorType.RELAX,
            rationale=proposal.get("justification", "")
        )
        
        return OperatorResult(
            success=True,
            operator=OperatorType.RELAX,
            interventions=[intervention],
            modified_task=modified_task,
            explanation=f"Relaxed constraint: {constraint_desc} → {relaxed_form}",
            confidence=0.7,
            validation_passed=True,
            validation_message=validation.reason
        )
    
    # REORDER OPERATOR
    
    def reorder(
        self,
        task_variables: Any,
        safety_concern: str
    ) -> OperatorResult:
        """
        Reorder plan steps to improve safety.
        
        Precondition: Task has a plan with multiple steps.
        """
        if not task_variables.plan or len(task_variables.plan) < 2:
            return OperatorResult(
                success=False,
                operator=OperatorType.REORDER,
                explanation="Task has no plan or only one step",
                validation_passed=False,
                validation_message="insufficient steps to reorder"
            )
        
        # Format current plan
        current_plan_str = ""
        for i, step in enumerate(task_variables.plan):
            if hasattr(step, 'action'):
                current_plan_str += f"{i+1}. {step.action}: {step.description if hasattr(step, 'description') else ''}\n"
            else:
                current_plan_str += f"{i+1}. {step}\n"
        
        # Retry loop
        retry_feedback = ""
        validation = None
        
        for attempt in range(self.MAX_RETRIES + 1):
            user_prompt = REORDER_USER_TEMPLATE.format(
                current_plan=current_plan_str,
                safety_concern=safety_concern,
                retry_feedback=retry_feedback
            )
            
            response = self.llm_client.generate(REORDER_SYSTEM_PROMPT, user_prompt)
            proposal = self._parse_json(response)
            
            if not proposal:
                retry_feedback = "RETRY: Invalid JSON."
                continue
            
            # Validate
            validation = self.preconditions.check_reorder(proposal, task_variables)
            
            if validation.valid:
                return self._apply_reorder(task_variables, proposal, validation)
            else:
                retry_feedback = f"RETRY: {validation.reason}"
        
        return OperatorResult(
            success=False,
            operator=OperatorType.REORDER,
            explanation=f"Could not generate valid reordering: {validation.reason if validation else 'unknown'}",
            validation_passed=False,
            validation_message=validation.reason if validation else "parsing failed"
        )
    
    def _apply_reorder(
        self,
        task_variables: Any,
        proposal: Dict,
        validation: PreconditionResult
    ) -> OperatorResult:
        """Apply validated reordering."""
        modified_task = deepcopy(task_variables)
        
        new_order = proposal.get("new_order", [])
        original_plan = task_variables.plan
        
        # Reorder based on original_position
        reordered_plan = []
        for new_step in new_order:
            orig_pos = new_step.get("original_position", 0) - 1  # Convert to 0-indexed
            if 0 <= orig_pos < len(original_plan):
                reordered_plan.append(original_plan[orig_pos])
        
        modified_task.plan = reordered_plan
        
        intervention = Intervention(
            variable_path="plan",
            original_value=[str(s) for s in original_plan],
            new_value=[str(s) for s in reordered_plan],
            operator=OperatorType.REORDER,
            rationale=proposal.get("rationale", "")
        )
        
        return OperatorResult(
            success=True,
            operator=OperatorType.REORDER,
            interventions=[intervention],
            modified_task=modified_task,
            explanation=f"Reordered {len(reordered_plan)} steps for safety",
            confidence=0.75,
            validation_passed=True,
            validation_message=validation.reason
        )
    
    # RETARGET OPERATOR
    
    def retarget(
        self,
        task_variables: Any,
        safety_concern: str,
        available_resources: List[str] = None,
        scene_graph: Any = None
    ) -> OperatorResult:
        """
        Find a safe proxy goal.
        
        Precondition: Proxy goal achievable with available resources.
        """
        original_goal = task_variables.goal
        underlying_need = self._infer_underlying_need(task_variables)
        
        if available_resources is None:
            available_resources = []
            if scene_graph:
                available_resources = [node.label for node in scene_graph.nodes.values()]
        
        # Retry loop
        retry_feedback = ""
        validation = None
        
        for attempt in range(self.MAX_RETRIES + 1):
            user_prompt = RETARGET_USER_TEMPLATE.format(
                original_goal=original_goal,
                safety_concern=safety_concern,
                underlying_need=underlying_need,
                resources=", ".join(available_resources) if available_resources else "unknown",
                retry_feedback=retry_feedback
            )
            
            response = self.llm_client.generate(RETARGET_SYSTEM_PROMPT, user_prompt)
            proposal = self._parse_json(response)
            
            if not proposal:
                retry_feedback = "RETRY: Invalid JSON."
                continue
            
            # Validate
            validation = self.preconditions.check_retarget(
                proposal, task_variables, scene_graph
            )
            
            if validation.valid:
                return self._apply_retarget(task_variables, proposal, validation)
            else:
                retry_feedback = f"RETRY: {validation.reason}"
        
        return OperatorResult(
            success=False,
            operator=OperatorType.RETARGET,
            explanation=f"Could not find valid proxy goal: {validation.reason if validation else 'unknown'}",
            validation_passed=False,
            validation_message=validation.reason if validation else "parsing failed"
        )
    
    def _apply_retarget(
        self,
        task_variables: Any,
        proposal: Dict,
        validation: PreconditionResult
    ) -> OperatorResult:
        """Apply validated retargeting."""
        modified_task = deepcopy(task_variables)
        original_goal = modified_task.goal
        modified_task.goal = proposal.get("proxy_goal", original_goal)
        
        intervention = Intervention(
            variable_path="goal",
            original_value=original_goal,
            new_value=modified_task.goal,
            operator=OperatorType.RETARGET,
            rationale=proposal.get("explanation_for_user", "")
        )
        
        return OperatorResult(
            success=True,
            operator=OperatorType.RETARGET,
            interventions=[intervention],
            modified_task=modified_task,
            explanation=f"Retargeted: {original_goal} → {modified_task.goal}",
            confidence=proposal.get("user_satisfaction", 0.7),
            validation_passed=True,
            validation_message=validation.reason
        )
    
    def _infer_underlying_need(self, task_variables: Any) -> str:
        """Infer the user's underlying need from task.

        Uses the LLM-parsed underlying_need from the v3 parsing prompt if available,
        falling back to heuristics only when the parsed value is not present.
        """
        # Use LLM-parsed underlying need if available (from v3 comprehension)
        parsed_need = getattr(task_variables, 'underlying_need', '')
        if parsed_need and len(parsed_need) > 5:
            return parsed_need

        # Fallback: simple heuristics
        goal = task_variables.goal or ""
        action = task_variables.action or ""

        if "pour" in action.lower() or "give" in action.lower():
            if task_variables.recipient:
                recipient = task_variables.recipient.reference_text if hasattr(task_variables.recipient, 'reference_text') else str(task_variables.recipient)
                return f"provide something to {recipient}"

        if "get" in action.lower() or "bring" in action.lower():
            return "obtain or deliver an item"

        return f"accomplish: {goal}"
    
    # HELPER METHODS
    
    def _get_variable(self, task_variables: Any, path: str) -> Any:
        """Get a variable from task by path (e.g., 'container', 'object.temperature')."""
        parts = path.split(".")
        current = task_variables
        
        for part in parts:
            if hasattr(current, part):
                current = getattr(current, part)
            elif isinstance(current, dict) and part in current:
                current = current[part]
            else:
                return None
        
        return current
    
    def _set_variable(self, task_variables: Any, path: str, value: Any):
        """Set a variable in task by path."""
        parts = path.split(".")
        
        if len(parts) == 1:
            if hasattr(task_variables, parts[0]):
                setattr(task_variables, parts[0], value)
        else:
            current = task_variables
            for part in parts[:-1]:
                if hasattr(current, part):
                    current = getattr(current, part)
                elif isinstance(current, dict) and part in current:
                    current = current[part]
            
            final_part = parts[-1]
            if hasattr(current, final_part):
                setattr(current, final_part, value)
            elif isinstance(current, dict):
                current[final_part] = value
    
    def _get_alternatives(
        self,
        scene_graph: Any,
        variable_type: str,
        original_value: Any
    ) -> List[Dict]:
        """
        Get alternative objects from scene for substitution.

        Searches ALL objects in the scene, not just specific types.
        The LLM in substitute() will determine which alternatives are suitable.
        """
        alternatives = []

        if not scene_graph or not hasattr(scene_graph, 'nodes'):
            return alternatives

        # Get original object identifiers to skip
        original_ids = set()
        if hasattr(original_value, 'id') and original_value.id:
            original_ids.add(original_value.id)
        if hasattr(original_value, 'grounded_id') and original_value.grounded_id:
            original_ids.add(original_value.grounded_id)
        if isinstance(original_value, dict) and original_value.get('id'):
            original_ids.add(original_value.get('id'))

        # Search ALL objects in the scene - let the LLM determine suitability
        for node in scene_graph.nodes.values():
            # Skip non-object nodes (regions, persons, etc.) unless they could be relevant
            node_type = node.type.value if hasattr(node.type, 'value') else str(node.type)
            if node_type not in ["object", "container", "tool", "food", "device", "substance"]:
                # Still include if it's an unrecognized type - let LLM decide
                if node_type in ["region", "location", "area"]:
                    continue

            # Skip if it's the original object
            if node.id in original_ids:
                continue

            # Build alternative entry with ALL available properties
            alt = {
                "id": node.id,
                "label": node.label,
                "type": node_type,
                "properties": {}
            }

            # Extract ALL properties from the node, not just a fixed list
            if hasattr(node, 'properties') and node.properties:
                props = node.properties
                # Iterate over all attributes of the properties object
                for attr in dir(props):
                    if attr.startswith('_'):
                        continue
                    try:
                        val = getattr(props, attr)
                        if val is not None and not callable(val):
                            # Handle enum values
                            if hasattr(val, 'value'):
                                alt["properties"][attr] = val.value
                            else:
                                alt["properties"][attr] = val
                    except Exception:
                        continue

            # Set hazard_level at top level for easy access (backwards compatibility)
            if "hazard_level" in alt["properties"]:
                alt["hazard_level"] = alt["properties"]["hazard_level"]
            else:
                alt["hazard_level"] = "unknown"

            alternatives.append(alt)

        return alternatives

    def _get_properties(self, obj: Any) -> str:
        """
        Get ALL properties of an object as a JSON string.

        Extracts all available properties, not just a predefined list.
        """
        if obj is None:
            return "{}"

        props = {}

        # Try to get properties from the object
        if hasattr(obj, 'properties') and obj.properties:
            obj_props = obj.properties
            # Iterate over all attributes, not just a fixed list
            for attr in dir(obj_props):
                if attr.startswith('_'):
                    continue
                try:
                    val = getattr(obj_props, attr)
                    if val is not None and not callable(val):
                        # Handle enum values
                        if hasattr(val, 'value'):
                            props[attr] = val.value
                        else:
                            props[attr] = val
                except Exception:
                    continue

        # Also check for direct attributes on the object itself
        for attr in ['temperature', 'hazard_level', 'weight', 'sharpness',
                     'child_safe', 'state', 'dosage', 'voltage', 'contents']:
            if hasattr(obj, attr):
                val = getattr(obj, attr)
                if val is not None and attr not in props:
                    if hasattr(val, 'value'):
                        props[attr] = val.value
                    else:
                        props[attr] = val

        return json.dumps(props)
    
    def _parse_json(self, response) -> Optional[Dict]:
        """Parse JSON from LLM response (handles both str and LLMResponse objects)."""
        # Handle LLMResponse objects (they have a .text attribute)
        if hasattr(response, 'text'):
            text = response.text
        elif isinstance(response, str):
            text = response
        else:
            text = str(response)

        text = text.strip()
        if text.startswith("```"):
            text = text.split("```")[1]
            if text.startswith("json"):
                text = text[4:]
        text = text.strip()

        try:
            result = json.loads(text)
            if isinstance(result, dict):
                return result
        except json.JSONDecodeError:
            pass

        start = text.find('{')
        end = text.rfind('}')
        if start != -1 and end != -1:
            try:
                result = json.loads(text[start:end+1])
                if isinstance(result, dict):
                    return result
            except:
                pass
        return None

    # LLM-DRIVEN VALIDATION HELPERS

    def filter_relevant_properties(
        self,
        alternatives: List[Dict],
        safety_concern: str,
        task_description: str
    ) -> List[Dict]:
        """
        Use LLM to filter object properties to only those relevant to the safety concern.

        This helps focus the substitution reasoning on what matters.
        """
        if not self.llm_client or not alternatives:
            return alternatives


        # Collect all unique property names across alternatives
        all_properties = set()
        for alt in alternatives:
            all_properties.update(alt.get("properties", {}).keys())

        if not all_properties:
            return alternatives

        # Ask LLM which properties are relevant
        user_prompt = PROPERTY_RELEVANCE_USER_TEMPLATE.format(
            safety_concern=safety_concern,
            task_description=task_description,
            all_properties=", ".join(sorted(all_properties)),
            retry_feedback=""
        )

        try:
            response = self.llm_client.generate(
                PROPERTY_RELEVANCE_SYSTEM_PROMPT,
                user_prompt
            )
            result = self._parse_json(response)

            if result and "relevant_properties" in result:
                relevant = set(result["relevant_properties"])

                # Filter each alternative's properties
                for alt in alternatives:
                    if "properties" in alt:
                        alt["properties"] = {
                            k: v for k, v in alt["properties"].items()
                            if k in relevant
                        }

        except Exception:
            pass

        return alternatives

    def check_contradiction_llm(
        self,
        existing_constraint: str,
        new_constraint: str,
        task_description: str
    ) -> Tuple[bool, str]:
        """
        Use LLM to check if two constraints contradict each other.

        Returns:
            Tuple of (contradicts: bool, explanation: str)
        """
        if not self.llm_client:
            return False, "LLM not available for contradiction check"


        user_prompt = CONTRADICTION_CHECK_USER_TEMPLATE.format(
            existing_constraint=existing_constraint,
            new_constraint=new_constraint,
            task_description=task_description,
            retry_feedback=""
        )

        try:
            response = self.llm_client.generate(
                CONTRADICTION_CHECK_SYSTEM_PROMPT,
                user_prompt
            )
            result = self._parse_json(response)

            if result:
                contradicts = result.get("contradicts", False)
                explanation = result.get("explanation", "")
                conflict_type = result.get("conflict_type", "none")

                if contradicts:
                    return contradicts, explanation

        except Exception:
            pass

        return False, "Could not determine contradiction"

    def check_atomic_action_llm(
        self,
        action: str,
        task_description: str
    ) -> Tuple[bool, str]:
        """
        Use LLM to determine if an action is atomic (cannot be decomposed).

        Returns:
            Tuple of (is_atomic: bool, reasoning: str)
        """
        if not self.llm_client:
            # Fallback to basic check
            basic_atomic = {"look", "wait", "stop", "acknowledge", "listen",
                          "observe", "watch", "pause", "hold", "confirm"}
            is_atomic = action.lower() in basic_atomic
            return is_atomic, "Basic check (LLM not available)"


        user_prompt = ATOMIC_ACTION_CHECK_USER_TEMPLATE.format(
            action=action,
            task_description=task_description,
            retry_feedback=""
        )

        try:
            response = self.llm_client.generate(
                ATOMIC_ACTION_CHECK_SYSTEM_PROMPT,
                user_prompt
            )
            result = self._parse_json(response)

            if result:
                is_atomic = result.get("is_atomic", False)
                reasoning = result.get("reasoning", "")
                return is_atomic, reasoning

        except Exception:
            pass

        return False, "Could not determine if atomic"


# OPERATOR CLASSIFICATION (For Diagnosis-Guided Generation)

def classify_operators(
    original: Any,  # TaskVariables
    repaired: Any,  # TaskVariables
    scene_graph: Any = None
) -> List['OperatorClassification']:
    """
    Classify which operators were applied by analyzing differences.

    After LLM generates a repair, we analyze the changes to identify
    which formal operators were used. 

    Args:
        original: Original task variables
        repaired: Repaired task variables
        scene_graph: Scene graph for context

    Returns:
        List of OperatorClassification objects
    """
    from ctr.data_structures import OperatorClassification, OperatorType

    classifications = []

    # Check for SUBSTITUTE
    sub_result = _detect_substitute(original, repaired, scene_graph)
    if sub_result:
        classifications.append(sub_result)

    # Check for CONSTRAIN
    const_result = _detect_constrain(original, repaired)
    if const_result:
        classifications.append(const_result)

    # Check for DECOMPOSE
    decomp_result = _detect_decompose(original, repaired)
    if decomp_result:
        classifications.append(decomp_result)

    # Check for RETARGET
    retarget_result = _detect_retarget(original, repaired)
    if retarget_result:
        classifications.append(retarget_result)

    # Check for REORDER
    reorder_result = _detect_reorder(original, repaired)
    if reorder_result:
        classifications.append(reorder_result)

    # Check for RELAX
    relax_result = _detect_relax(original, repaired)
    if relax_result:
        classifications.append(relax_result)

    return classifications


def _detect_substitute(original: Any, repaired: Any, scene_graph: Any = None) -> Optional['OperatorClassification']:
    """Detect if SUBSTITUTE operator was applied."""
    from ctr.data_structures import OperatorClassification, OperatorType

    # Compare objects
    orig_objects = set()
    repair_objects = set()

    for obj in (original.objects or []):
        text = obj.reference_text if hasattr(obj, 'reference_text') else str(obj)
        orig_objects.add(text.lower())

    for obj in (repaired.objects or []):
        text = obj.reference_text if hasattr(obj, 'reference_text') else str(obj)
        repair_objects.add(text.lower())

    # Check if objects changed
    removed = orig_objects - repair_objects
    added = repair_objects - orig_objects

    if removed and added:
        # Objects were substituted
        evidence = f"Replaced {removed} with {added}"
        return OperatorClassification(
            operator_type=OperatorType.SUBSTITUTE,
            confidence=0.9,
            evidence=evidence,
            variables_affected=['objects']
        )

    # Also check for action substitution
    orig_action = original.action.lower() if original.action else ""
    repair_action = repaired.action.lower() if repaired.action else ""

    if orig_action and repair_action and orig_action != repair_action:
        # Action verbs that indicate similar intent
        similar_actions = {
            ('hand', 'place'), ('hand', 'put'), ('give', 'place'),
            ('pour', 'serve'), ('bring', 'deliver'), ('get', 'fetch')
        }
        for a1, a2 in similar_actions:
            if (a1 in orig_action and a2 in repair_action) or (a2 in orig_action and a1 in repair_action):
                return OperatorClassification(
                    operator_type=OperatorType.SUBSTITUTE,
                    confidence=0.7,
                    evidence=f"Action changed from '{orig_action}' to '{repair_action}'",
                    variables_affected=['action']
                )

    return None


def _detect_constrain(original: Any, repaired: Any) -> Optional['OperatorClassification']:
    """Detect if CONSTRAIN operator was applied."""
    from ctr.data_structures import OperatorClassification, OperatorType

    # Check if constraints were added
    orig_constraints = len(original.constraints) if original.constraints else 0
    repair_constraints = len(repaired.constraints) if repaired.constraints else 0

    if repair_constraints > orig_constraints:
        return OperatorClassification(
            operator_type=OperatorType.CONSTRAIN,
            confidence=0.9,
            evidence=f"Added {repair_constraints - orig_constraints} constraint(s)",
            variables_affected=['constraints']
        )

    # Check for manner changes (often indicates constraint)
    orig_manner = original.manner.lower() if original.manner else ""
    repair_manner = repaired.manner.lower() if repaired.manner else ""

    if not orig_manner and repair_manner:
        return OperatorClassification(
            operator_type=OperatorType.CONSTRAIN,
            confidence=0.8,
            evidence=f"Added manner constraint: '{repair_manner}'",
            variables_affected=['manner']
        )

    # Check for parameter changes (temperature, quantity, etc.)
    orig_params = {p.name: p.value for p in (original.parameters or [])}
    repair_params = {p.name: p.value for p in (repaired.parameters or [])}

    new_params = set(repair_params.keys()) - set(orig_params.keys())
    changed_params = [k for k in orig_params if k in repair_params and orig_params[k] != repair_params[k]]

    if new_params or changed_params:
        return OperatorClassification(
            operator_type=OperatorType.CONSTRAIN,
            confidence=0.8,
            evidence=f"Parameter changes: new={new_params}, changed={changed_params}",
            variables_affected=['parameters']
        )

    return None


def _detect_decompose(original: Any, repaired: Any) -> Optional['OperatorClassification']:
    """Detect if DECOMPOSE operator was applied."""
    from ctr.data_structures import OperatorClassification, OperatorType

    orig_plan_len = len(original.plan) if original.plan else 0
    repair_plan_len = len(repaired.plan) if repaired.plan else 0

    if repair_plan_len > orig_plan_len and repair_plan_len > 1:
        return OperatorClassification(
            operator_type=OperatorType.DECOMPOSE,
            confidence=0.9,
            evidence=f"Task decomposed into {repair_plan_len} steps (was {orig_plan_len})",
            variables_affected=['plan']
        )

    return None


def _detect_retarget(original: Any, repaired: Any) -> Optional['OperatorClassification']:
    """Detect if RETARGET operator was applied."""
    from ctr.data_structures import OperatorClassification, OperatorType

    orig_goal = original.goal.lower() if original.goal else ""
    repair_goal = repaired.goal.lower() if repaired.goal else ""

    if not orig_goal or not repair_goal:
        return None

    # Compute similarity (simple word overlap)
    orig_words = set(orig_goal.split())
    repair_words = set(repair_goal.split())

    if not orig_words:
        return None

    overlap = len(orig_words & repair_words)
    similarity = overlap / len(orig_words)

    # If goal changed significantly but some intent preserved
    if similarity < 0.5 and similarity > 0.1:
        return OperatorClassification(
            operator_type=OperatorType.RETARGET,
            confidence=0.7,
            evidence=f"Goal significantly changed (similarity: {similarity:.2f})",
            variables_affected=['goal']
        )

    return None


def _detect_reorder(original: Any, repaired: Any) -> Optional['OperatorClassification']:
    """Detect if REORDER operator was applied."""
    from ctr.data_structures import OperatorClassification, OperatorType

    orig_plan = original.plan or []
    repair_plan = repaired.plan or []

    if len(orig_plan) < 2 or len(repair_plan) < 2:
        return None

    if len(orig_plan) != len(repair_plan):
        return None  # Different length suggests decompose, not reorder

    # Extract actions from plans
    orig_actions = []
    for step in orig_plan:
        action = step.action if hasattr(step, 'action') else str(step)
        orig_actions.append(action)

    repair_actions = []
    for step in repair_plan:
        action = step.action if hasattr(step, 'action') else str(step)
        repair_actions.append(action)

    # Check if same actions in different order
    if set(orig_actions) == set(repair_actions) and orig_actions != repair_actions:
        return OperatorClassification(
            operator_type=OperatorType.REORDER,
            confidence=0.85,
            evidence="Plan steps reordered",
            variables_affected=['plan']
        )

    return None


def _detect_relax(original: Any, repaired: Any) -> Optional['OperatorClassification']:
    """Detect if RELAX operator was applied."""
    from ctr.data_structures import OperatorClassification, OperatorType

    orig_constraints = original.constraints or []
    repair_constraints = repaired.constraints or []

    # Check if any hard constraint became soft
    for orig_c in orig_constraints:
        orig_desc = orig_c.description if hasattr(orig_c, 'description') else str(orig_c)
        orig_hard = orig_c.hard if hasattr(orig_c, 'hard') else True

        for repair_c in repair_constraints:
            repair_desc = repair_c.description if hasattr(repair_c, 'description') else str(repair_c)
            repair_hard = repair_c.hard if hasattr(repair_c, 'hard') else True

            # Same constraint but changed from hard to soft
            if orig_desc.lower() in repair_desc.lower() and orig_hard and not repair_hard:
                return OperatorClassification(
                    operator_type=OperatorType.RELAX,
                    confidence=0.8,
                    evidence=f"Constraint '{orig_desc}' relaxed from hard to soft",
                    variables_affected=['constraints']
                )

    # Check if constraints were removed
    if len(repair_constraints) < len(orig_constraints):
        return OperatorClassification(
            operator_type=OperatorType.RELAX,
            confidence=0.7,
            evidence=f"Removed {len(orig_constraints) - len(repair_constraints)} constraint(s)",
            variables_affected=['constraints']
        )

    return None


# OPERATOR VALIDATION (For Diagnosis-Guided Generation)

def validate_operator(
    classification: 'OperatorClassification',
    original: Any,
    repaired: Any,
    scene_graph: Any = None
) -> 'OperatorValidation':
    """
    Validate that an operator's preconditions hold for this repair.

    Even though the repair was generated by LLM (not by applying operators),
    we validate that the formal preconditions are satisfied, providing
    certification that this is a well-formed intervention.

    Args:
        classification: The classified operator
        original: Original task variables
        repaired: Repaired task variables
        scene_graph: Scene graph for context

    Returns:
        OperatorValidation with checks and explanation
    """
    from ctr.data_structures import OperatorValidation, OperatorType

    op_type = classification.operator_type

    if op_type == OperatorType.SUBSTITUTE:
        return _validate_substitute(classification, original, repaired, scene_graph)
    elif op_type == OperatorType.CONSTRAIN:
        return _validate_constrain(classification, original, repaired, scene_graph)
    elif op_type == OperatorType.DECOMPOSE:
        return _validate_decompose(classification, original, repaired)
    elif op_type == OperatorType.RETARGET:
        return _validate_retarget(classification, original, repaired, scene_graph)
    elif op_type == OperatorType.REORDER:
        return _validate_reorder(classification, original, repaired)
    elif op_type == OperatorType.RELAX:
        return _validate_relax(classification, original, repaired)
    else:
        return OperatorValidation(
            operator_type=op_type,
            valid=True,
            checks=[],
            explanation="Unknown operator type - validation skipped"
        )


def _validate_substitute(
    classification: 'OperatorClassification',
    original: Any,
    repaired: Any,
    scene_graph: Any
) -> 'OperatorValidation':
    """Validate SUBSTITUTE operator preconditions."""
    from ctr.data_structures import OperatorValidation, OperatorType

    checks = []

    # Check 1: Replacement exists in scene (if scene available)
    replacement_exists = True
    if scene_graph and repaired.objects:
        scene_labels = {node.label.lower() for node in scene_graph.nodes.values()}
        for obj in repaired.objects:
            text = obj.reference_text if hasattr(obj, 'reference_text') else str(obj)
            if text.lower() not in scene_labels:
                # Allow if it's a generic term
                generic_terms = {'item', 'object', 'thing', 'alternative'}
                if text.lower() not in generic_terms:
                    replacement_exists = False
    checks.append(("replacement_exists_in_scene", replacement_exists))

    # Check 2: Replacement is different from original
    is_different = True
    orig_obj_texts = {(obj.reference_text if hasattr(obj, 'reference_text') else str(obj)).lower()
                      for obj in (original.objects or [])}
    repair_obj_texts = {(obj.reference_text if hasattr(obj, 'reference_text') else str(obj)).lower()
                        for obj in (repaired.objects or [])}
    if orig_obj_texts == repair_obj_texts:
        is_different = False
    checks.append(("replacement_differs_from_original", is_different))

    all_valid = all(v for _, v in checks)

    return OperatorValidation(
        operator_type=OperatorType.SUBSTITUTE,
        valid=all_valid,
        checks=checks,
        explanation="Substitute validation: " + (
            "all checks passed" if all_valid else
            f"failed: {[n for n, v in checks if not v]}"
        )
    )


def _validate_constrain(
    classification: 'OperatorClassification',
    original: Any,
    repaired: Any,
    scene_graph: Any
) -> 'OperatorValidation':
    """Validate CONSTRAIN operator preconditions."""
    from ctr.data_structures import OperatorValidation, OperatorType

    checks = []

    # Check 1: New constraints don't contradict existing ones
    no_contradictions = True
    # (Simplified check - would need LLM for thorough contradiction detection)
    checks.append(("no_contradictions", no_contradictions))

    # Check 2: Constraints are satisfiable (basic check)
    satisfiable = True
    checks.append(("constraints_satisfiable", satisfiable))

    all_valid = all(v for _, v in checks)

    return OperatorValidation(
        operator_type=OperatorType.CONSTRAIN,
        valid=all_valid,
        checks=checks,
        explanation="Constrain validation: all checks passed" if all_valid else "some checks failed"
    )


def _validate_decompose(
    classification: 'OperatorClassification',
    original: Any,
    repaired: Any
) -> 'OperatorValidation':
    """Validate DECOMPOSE operator preconditions."""
    from ctr.data_structures import OperatorValidation, OperatorType

    checks = []

    # Check 1: Plan has multiple steps
    has_multiple_steps = len(repaired.plan or []) > 1
    checks.append(("has_multiple_steps", has_multiple_steps))

    # Check 2: No circular dependencies (simplified)
    no_cycles = True  # Would need full DAG check for thorough validation
    checks.append(("no_dependency_cycles", no_cycles))

    all_valid = all(v for _, v in checks)

    return OperatorValidation(
        operator_type=OperatorType.DECOMPOSE,
        valid=all_valid,
        checks=checks,
        explanation="Decompose validation: all checks passed" if all_valid else "some checks failed"
    )


def _validate_retarget(
    classification: 'OperatorClassification',
    original: Any,
    repaired: Any,
    scene_graph: Any
) -> 'OperatorValidation':
    """Validate RETARGET operator preconditions."""
    from ctr.data_structures import OperatorValidation, OperatorType

    checks = []

    # Check 1: Goal is different
    goal_changed = (original.goal or "").lower() != (repaired.goal or "").lower()
    checks.append(("goal_changed", goal_changed))

    # Check 2: Some intent preserved (goal isn't completely unrelated)
    intent_preserved = True
    if original.goal and repaired.goal:
        orig_words = set(original.goal.lower().split())
        repair_words = set(repaired.goal.lower().split())
        # At least some overlap or related terms
        overlap = len(orig_words & repair_words)
        intent_preserved = overlap > 0 or len(orig_words) < 3
    checks.append(("intent_preserved", intent_preserved))

    all_valid = all(v for _, v in checks)

    return OperatorValidation(
        operator_type=OperatorType.RETARGET,
        valid=all_valid,
        checks=checks,
        explanation="Retarget validation: all checks passed" if all_valid else "some checks failed"
    )


def _validate_reorder(
    classification: 'OperatorClassification',
    original: Any,
    repaired: Any
) -> 'OperatorValidation':
    """Validate REORDER operator preconditions."""
    from ctr.data_structures import OperatorValidation, OperatorType

    checks = []

    # Check 1: Same steps present
    orig_steps = len(original.plan or [])
    repair_steps = len(repaired.plan or [])
    same_count = orig_steps == repair_steps
    checks.append(("same_step_count", same_count))

    all_valid = all(v for _, v in checks)

    return OperatorValidation(
        operator_type=OperatorType.REORDER,
        valid=all_valid,
        checks=checks,
        explanation="Reorder validation: all checks passed" if all_valid else "some checks failed"
    )


def _validate_relax(
    classification: 'OperatorClassification',
    original: Any,
    repaired: Any
) -> 'OperatorValidation':
    """Validate RELAX operator preconditions."""
    from ctr.data_structures import OperatorValidation, OperatorType

    checks = []

    # Check 1: Only non-safety-critical constraints relaxed
    # (Would need safety analysis to check thoroughly)
    only_non_critical = True
    checks.append(("only_non_critical_relaxed", only_non_critical))

    all_valid = all(v for _, v in checks)

    return OperatorValidation(
        operator_type=OperatorType.RELAX,
        valid=all_valid,
        checks=checks,
        explanation="Relax validation: all checks passed" if all_valid else "some checks failed"
    )


# OPERATOR GUIDANCE FOR GENERATION

def get_operator_guidance() -> str:
    """
    Return natural language guidance about operators for generation prompt.

    This is included in the LLM prompt to guide repair generation.
    """
    return """Consider these repair strategies:

SUBSTITUTE: Replace unsafe objects/actions with safer alternatives that serve the same purpose.
  - Example: sharp knife → butter knife (both can cut, but one is safer for children)
  - The replacement must exist in the scene or be flagged as needed

CONSTRAIN: Add safety guards, preconditions, or modify how the task is performed.
  - Example: "hand hot coffee" → "place lukewarm coffee in sippy cup on low table"
  - Modify parameters (temperature, speed, force) to safe levels

DECOMPOSE: Break complex tasks into smaller, individually safe steps with checkpoints.
  - Example: "give medicine" → "1. verify prescription 2. check dosage 3. administer with water"
  - Insert verification steps before risky actions

RETARGET: Redirect to a safer proxy goal that still satisfies the underlying need.
  - Example: "child wants to use sharp scissors" → "provide child-safe scissors"
  - Address the real need, not just the literal request

You may combine multiple strategies in a single repair."""
