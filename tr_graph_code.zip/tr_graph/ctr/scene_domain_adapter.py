"""
Domain adapter protocol for scene graph construction.

Each adapter encapsulates source-specific knowledge for populating
the paper's typed scene graph schema. The core SceneGraphBuilder
calls adapter methods during construction — it never hardcodes
domain assumptions like "CounterTop is a surface" or "Knife is sharp."

Adapters:
  AI2ThorSceneAdapter       — simulator metadata (deterministic, highest quality)
  VLMSceneAdapter           — VLM perception output (evidence-scored)
  GenericObjectListAdapter  — text object list (weak priors, lowest quality)
  TabletopSceneAdapter      — real-robot tabletop scenes (structured setup)
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional, Set, Tuple
from ctr.data_structures import (
    ObjectProperties, PersonProperties, HazardLevel, Sharpness
)


class SceneDomainAdapter(ABC):
    """Protocol for domain-specific scene graph population.

    The builder calls these methods to populate the paper's relation
    types: location, support, containment, proximity, accessibility.
    Domain-specific knowledge lives here, not in the builder.
    """

    @abstractmethod
    def infer_region(self, source_data: Any) -> Optional[str]:
        """Infer the region type (kitchen, bedroom, etc.) from source data."""
        ...

    @abstractmethod
    def classify_receptacle(self, obj_type: str) -> Optional[str]:
        """Classify a receptacle as 'surface', 'container', or None.

        Returns:
            'surface'   — supports ON edges (table, counter, shelf)
            'container' — supports INSIDE/CONTAINS edges (fridge, drawer)
            None        — not a receptacle
        """
        ...

    @abstractmethod
    def infer_object_properties(
        self, obj_type: str, metadata: Dict[str, Any]
    ) -> ObjectProperties:
        """Build ObjectProperties from source-specific metadata."""
        ...

    @abstractmethod
    def infer_affordances(self, obj_type: str) -> Set[str]:
        """Infer action affordances for an object type.

        Affordances are node properties (not edges). They describe
        what actions an object can participate in.
        """
        ...

    @abstractmethod
    def infer_reachability(
        self, obj_data: Dict[str, Any], agent_data: Optional[Dict]
    ) -> Tuple[bool, float, str]:
        """Determine if an object is reachable by the robot.

        Returns:
            (is_reachable, confidence, evidence_string)
        """
        ...

    @abstractmethod
    def is_person(self, obj_name: str) -> bool:
        """Check if a name refers to a person rather than an object."""
        ...

    @abstractmethod
    def infer_person_properties(self, name: str) -> PersonProperties:
        """Build PersonProperties from a person name/label."""
        ...

    def get_near_threshold(self) -> float:
        """Distance threshold for NEAR edges (meters). Override per domain."""
        return 1.5

    def get_source_label(self) -> str:
        """Label for edge metadata source field."""
        return "unknown"
