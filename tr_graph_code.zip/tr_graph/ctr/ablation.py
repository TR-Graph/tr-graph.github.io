"""
Ablation configuration for TR-Graph experiments.

Each ablation variant is defined as a configuration that specifies
exactly which mechanisms are active. The full system enables everything;
each ablation disables exactly one mechanism (or, in the case of no-graph,
the entire graph-guided framework and its downstream dependents).
"""

from dataclasses import dataclass


@dataclass
class AblationConfig:
    name: str = "full"

    # Graph construction and structural reasoning
    use_repair_graph: bool = True

    # Graph-derived features for bandit context (density, centrality, etc.)
    use_graph_features: bool = True

    # LinUCB bandit for operator allocation
    use_graph_conditioned_bandit: bool = True

    # Gate 2: graph consistency validation
    use_graph_consistency_gate: bool = True

    # Gate 3: operator precondition validation
    use_operator_validation_gate: bool = True

    # Graph-conditioned affinity dimension weights
    use_graph_aware_affinity: bool = True

    # Graph-derived variable importance for cost weights
    use_graph_aware_cost: bool = True

    # Graph path-based causal minimality scoring
    use_graph_local_minimality: bool = True

    # Fixed candidate budget across all variants
    candidate_budget: int = 5


# Pre-defined ablation variants

ABLATIONS = {
    "full": AblationConfig(
        name="full",
    ),

    "no_graph": AblationConfig(
        name="no_graph",
        use_repair_graph=False,
        use_graph_features=False,
        use_graph_conditioned_bandit=False,
        use_graph_consistency_gate=False,
        use_graph_aware_affinity=False,
        use_graph_aware_cost=False,
        use_graph_local_minimality=False,
    ),

    "no_bandit": AblationConfig(
        name="no_bandit",
        use_graph_conditioned_bandit=False,
    ),

    "no_consistency": AblationConfig(
        name="no_consistency",
        use_graph_consistency_gate=False,
    ),

    "no_operator_val": AblationConfig(
        name="no_operator_val",
        use_operator_validation_gate=False,
    ),
}


def get_ablation(name: str) -> AblationConfig:
    """Get ablation config by name. Raises KeyError for unknown names."""
    if name not in ABLATIONS:
        raise KeyError(
            f"Unknown ablation: '{name}'. "
            f"Valid options: {list(ABLATIONS.keys())}"
        )
    return ABLATIONS[name]
