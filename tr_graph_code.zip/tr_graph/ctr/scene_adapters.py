"""
Domain adapter implementations for scene graph construction.

Each adapter encapsulates the domain knowledge for one perception source.
Hardcoded object taxonomies, keyword lists, and floor plan mappings live
here — they are domain-specific priors, not core method logic.
"""

import math
from typing import Dict, Any, Optional, Set, Tuple, List
from ctr.data_structures import (
    ObjectProperties, PersonProperties,
    AgeGroup, Capability, Awareness, HazardLevel, Sharpness,
)
from ctr.scene_domain_adapter import SceneDomainAdapter


class AI2ThorSceneAdapter(SceneDomainAdapter):
    """Adapter for AI2-THOR simulator metadata.

    Uses ground-truth positions, parentReceptacles, receptacleObjectIds,
    temperature, and visibility to derive edges deterministically.
    No LLM calls. No hallucination risk.
    """

    # AI2-THOR receptacle types that are surfaces (ON relationship)
    SURFACE_TYPES = {
        'CounterTop', 'DiningTable', 'CoffeeTable', 'SideTable',
        'Desk', 'Dresser', 'Shelf', 'Ottoman', 'Bed',
        'Toilet', 'BathtubBasin', 'SinkBasin', 'StoveBurner',
        'ShelvingUnit',
    }

    # AI2-THOR receptacle types that are enclosing containers
    CONTAINER_TYPES = {
        'Fridge', 'Cabinet', 'Drawer', 'Microwave', 'Safe',
        'Box', 'LaundryHamper', 'GarbageCan', 'Toaster',
    }

    CONSUMABLE_TYPES = {
        'Apple', 'Banana', 'Bread', 'Carrot', 'Egg', 'Lettuce',
        'Pear', 'Potato', 'Tomato',
    }

    AFFORDANCE_MAP = {
        'Cup': {'contain_liquid', 'pour', 'drink_from'},
        'Mug': {'contain_liquid', 'pour', 'drink_from'},
        'Bowl': {'contain', 'serve'},
        'Plate': {'support', 'serve_on'},
        'Bottle': {'contain_liquid', 'pour'},
        'WaterBottle': {'contain_liquid', 'pour', 'drink_from'},
        'Pan': {'contain', 'cook_in'},
        'Pot': {'contain_liquid', 'cook_in'},
        'Knife': {'cut', 'slice'},
        'ButterKnife': {'spread', 'cut_soft'},
        'Fork': {'pick_up_food', 'eat_with'},
        'Spoon': {'scoop', 'stir', 'eat_with'},
        'Spatula': {'flip', 'stir'},
        'Kettle': {'contain_liquid', 'pour', 'boil'},
    }

    # AI2-THOR floor plan ranges
    FLOOR_PLAN_REGIONS = {
        range(1, 31): "kitchen",
        range(201, 231): "living_room",
        range(301, 331): "bedroom",
        range(401, 431): "bathroom",
    }

    def get_source_label(self) -> str:
        return "ai2thor"

    def get_near_threshold(self) -> float:
        return 1.5

    def infer_region(self, source_data: Any) -> Optional[str]:
        floor_plan = source_data if isinstance(source_data, int) else 0
        for fp_range, region in self.FLOOR_PLAN_REGIONS.items():
            if floor_plan in fp_range:
                return region
        return None

    def classify_receptacle(self, obj_type: str) -> Optional[str]:
        if obj_type in self.SURFACE_TYPES:
            return "surface"
        if obj_type in self.CONTAINER_TYPES:
            return "container"
        return None

    def infer_object_properties(
        self, obj_type: str, metadata: Dict[str, Any]
    ) -> ObjectProperties:
        temp_map = {'Hot': 80.0, 'Cold': 5.0, 'RoomTemp': None}
        temperature = temp_map.get(metadata.get('temperature'), None)

        sharp_types = {'Knife', 'ButterKnife', 'Fork'}
        sharpness = Sharpness.SHARP if obj_type in sharp_types else Sharpness.DULL

        consumable = obj_type in self.CONSUMABLE_TYPES
        affordances = self.infer_affordances(obj_type)

        hazard = HazardLevel.NONE
        if temperature and temperature > 60:
            hazard = HazardLevel.MEDIUM
        if sharpness == Sharpness.SHARP:
            hazard = HazardLevel.HIGH

        contains = None
        if metadata.get('isFilledWithLiquid') and metadata.get('fillLiquid'):
            contains = metadata['fillLiquid']

        return ObjectProperties(
            temperature=temperature,
            sharpness=sharpness,
            mass=metadata.get('mass'),
            affordances=affordances,
            hazard_level=hazard,
            consumable=consumable,
            contains=contains,
            child_safe=(hazard == HazardLevel.NONE),
        )

    def infer_affordances(self, obj_type: str) -> Set[str]:
        return self.AFFORDANCE_MAP.get(obj_type, set())

    def infer_reachability(
        self, obj_data: Dict[str, Any], agent_data: Optional[Dict]
    ) -> Tuple[bool, float, str]:
        if not agent_data or obj_data.get('distance') is None:
            return False, 0.0, "no agent data"

        reach = agent_data.get('reach_distance', 1.5)
        dist = obj_data['distance']
        visible = obj_data.get('visible', False)

        # Check if inside a closed container
        is_enclosed = False
        for parent_id in obj_data.get('parentReceptacles') or []:
            # Caller passes obj_by_id lookup; simplified here
            pass

        is_reachable = dist <= reach and visible and not is_enclosed
        confidence = 0.95 if is_reachable else 0.1
        evidence = f"distance={dist:.2f}m, visible={visible}"
        return is_reachable, confidence, evidence

    def is_person(self, obj_name: str) -> bool:
        return False  # AI2-THOR objects are never persons

    def infer_person_properties(self, name: str) -> PersonProperties:
        return PersonProperties()


class VLMSceneAdapter(SceneDomainAdapter):
    """Adapter for VLM perception output.

    Mostly passes through VLM-generated edges (which carry their own
    confidence and evidence). Adds enrichment for missing edge types.
    """

    def get_source_label(self) -> str:
        return "vlm"

    def infer_region(self, source_data: Any) -> Optional[str]:
        # VLM output may include region nodes directly
        if isinstance(source_data, dict):
            return source_data.get('region_type')
        return None

    def classify_receptacle(self, obj_type: str) -> Optional[str]:
        # VLM edges already encode support/containment directly
        # No need to classify — edges come from VLM output
        return None

    def infer_object_properties(
        self, obj_type: str, metadata: Dict[str, Any]
    ) -> ObjectProperties:
        # VLM provides properties directly in node output
        return ObjectProperties(
            temperature=metadata.get('temperature'),
            sharpness=Sharpness(metadata['sharpness']) if metadata.get('sharpness') else None,
            hazard_level=HazardLevel(metadata['hazard_level']) if metadata.get('hazard_level') else HazardLevel.NONE,
            child_safe=metadata.get('child_safe', True),
            affordances=set(metadata.get('affordances', [])),
        )

    def infer_affordances(self, obj_type: str) -> Set[str]:
        return set()  # VLM provides affordances in node properties

    def infer_reachability(
        self, obj_data: Dict[str, Any], agent_data: Optional[Dict]
    ) -> Tuple[bool, float, str]:
        # VLM may produce reachable_by edges directly
        # Enrichment step adds missing ones
        return True, 0.6, "VLM did not produce reachability — enrichment default"

    def is_person(self, obj_name: str) -> bool:
        # VLM output has explicit type: "person"
        return False  # Type comes from VLM node data, not name matching

    def infer_person_properties(self, name: str) -> PersonProperties:
        return PersonProperties()


class GenericObjectListAdapter(SceneDomainAdapter):
    """Adapter for flat object name lists (benchmark/text-only mode).

    Uses keyword-based heuristics to infer properties from object names.
    All edges are marked source='semantic_prior' with moderate confidence.
    This is the weakest adapter — used only when no richer perception
    is available.
    """

    PERSON_KEYWORDS = [
        'person', 'child', 'toddler', 'baby', 'infant', 'adult',
        'elderly', 'man', 'woman', 'boy', 'girl',
        'grandmother', 'grandfather', 'mother', 'father',
        'daughter', 'son',
    ]

    HOT_KEYWORDS = ['hot', 'boiling', 'coffee', 'tea', 'stove', 'oven', 'kettle']
    SHARP_KEYWORDS = ['knife', 'scissors', 'blade', 'razor']
    CHEMICAL_KEYWORDS = ['chemical', 'medicine', 'cleaning', 'bleach', 'poison']

    CONSUMABLE_KEYWORDS = [
        'apple', 'banana', 'bread', 'carrot', 'pear', 'potato',
        'tomato', 'egg', 'lettuce',
    ]

    FLOOR_PLAN_REGIONS = AI2ThorSceneAdapter.FLOOR_PLAN_REGIONS

    def get_source_label(self) -> str:
        return "semantic_prior"

    def infer_region(self, source_data: Any) -> Optional[str]:
        floor_plan = source_data if isinstance(source_data, int) else 0
        for fp_range, region in self.FLOOR_PLAN_REGIONS.items():
            if floor_plan in fp_range:
                return region
        return None

    def classify_receptacle(self, obj_type: str) -> Optional[str]:
        return None  # No spatial data to classify receptacles

    def infer_object_properties(
        self, obj_type: str, metadata: Dict[str, Any]
    ) -> ObjectProperties:
        name_lower = obj_type.lower()

        hazard = HazardLevel.NONE
        temperature = None
        sharpness = Sharpness.DULL

        if any(kw in name_lower for kw in self.HOT_KEYWORDS):
            hazard = HazardLevel.MEDIUM
            temperature = 70.0
        if any(kw in name_lower for kw in self.SHARP_KEYWORDS):
            hazard = HazardLevel.HIGH
            sharpness = Sharpness.SHARP
        if any(kw in name_lower for kw in self.CHEMICAL_KEYWORDS):
            hazard = HazardLevel.HIGH

        consumable = any(kw in name_lower for kw in self.CONSUMABLE_KEYWORDS)

        return ObjectProperties(
            hazard_level=hazard,
            temperature=temperature,
            sharpness=sharpness,
            consumable=consumable,
            child_safe=(hazard == HazardLevel.NONE),
        )

    def infer_affordances(self, obj_type: str) -> Set[str]:
        return set()  # No affordance knowledge without domain taxonomy

    def infer_reachability(
        self, obj_data: Dict[str, Any], agent_data: Optional[Dict]
    ) -> Tuple[bool, float, str]:
        return True, 0.7, "tabletop scene assumption — all objects reachable"

    def is_person(self, obj_name: str) -> bool:
        return any(kw in obj_name.lower() for kw in self.PERSON_KEYWORDS)

    def infer_person_properties(self, name: str) -> PersonProperties:
        name_lower = name.lower()
        if any(kw in name_lower for kw in ['baby', 'infant', 'toddler']):
            age_group = AgeGroup.INFANT
        elif any(kw in name_lower for kw in ['child', 'boy', 'girl', 'kid']):
            age_group = AgeGroup.CHILD
        elif any(kw in name_lower for kw in ['teen', 'teenager']):
            age_group = AgeGroup.TEEN
        elif any(kw in name_lower for kw in ['elderly', 'grandmother', 'grandfather']):
            age_group = AgeGroup.ELDERLY
        else:
            age_group = AgeGroup.ADULT

        return PersonProperties(
            age_group=age_group,
            physical_capability=(
                Capability.LIMITED
                if age_group in (AgeGroup.INFANT, AgeGroup.CHILD, AgeGroup.ELDERLY)
                else Capability.NORMAL),
            cognitive_capability=(
                Capability.LIMITED
                if age_group in (AgeGroup.INFANT, AgeGroup.CHILD)
                else Capability.NORMAL),
            safety_awareness=(
                Awareness.LOW
                if age_group in (AgeGroup.INFANT, AgeGroup.CHILD)
                else Awareness.HIGH),
        )


class TabletopSceneAdapter(SceneDomainAdapter):
    """Adapter for real-robot tabletop scenes (e.g., Franka Research 3).

    Assumes a structured workspace: one table surface, objects on the table,
    robot manipulator with known reach.

    Franka Research 3 specs:
      - Max reach: 855mm (0.855m)
      - Payload: 3kg (with Franka Hand)
      - Fixed-base manipulator (no navigation)
    """

    # Fixtures the robot can interact with but not pick up
    FIXTURE_KEYWORDS = {
        'table', 'counter', 'stove', 'oven', 'microwave', 'fridge',
        'sink', 'cabinet', 'shelf', 'rack', 'dishwasher',
    }

    FRANKA_REACH = 0.855  # meters
    FRANKA_PAYLOAD = 3.0  # kg

    def get_source_label(self) -> str:
        return "tabletop"

    def get_near_threshold(self) -> float:
        return 0.5  # Tabletop scenes are smaller than room-scale

    def get_agent_properties(self):
        """Return Franka Research 3 specific agent properties."""
        from ctr.data_structures import AgentProperties
        return AgentProperties(
            reach_distance=self.FRANKA_REACH,
            gripper_capacity=self.FRANKA_PAYLOAD,
        )

    def infer_region(self, source_data: Any) -> Optional[str]:
        return "workspace"

    def classify_receptacle(self, obj_type: str) -> Optional[str]:
        surfaces = {'table', 'tray', 'board', 'mat'}
        containers = {'box', 'bin', 'cup', 'bowl', 'basket'}
        obj_lower = obj_type.lower()
        if any(s in obj_lower for s in surfaces):
            return "surface"
        if any(c in obj_lower for c in containers):
            return "container"
        return None

    def infer_object_properties(
        self, obj_type: str, metadata: Dict[str, Any]
    ) -> ObjectProperties:
        return GenericObjectListAdapter().infer_object_properties(obj_type, metadata)

    def infer_affordances(self, obj_type: str) -> Set[str]:
        return set()

    def _is_fixture(self, obj_name: str) -> bool:
        """Check if object is a fixture (not pickupable)."""
        return any(kw in obj_name.lower() for kw in self.FIXTURE_KEYWORDS)

    def infer_reachability(
        self, obj_data: Dict[str, Any], agent_data: Optional[Dict]
    ) -> Tuple[bool, float, str]:
        obj_name = obj_data.get('label', obj_data.get('objectType', ''))
        if self._is_fixture(obj_name):
            return False, 0.3, f"fixture ({obj_name}) — not manipulable by Franka gripper"
        return True, 0.9, f"tabletop object within Franka reach ({self.FRANKA_REACH}m)"

    def is_person(self, obj_name: str) -> bool:
        return GenericObjectListAdapter().is_person(obj_name)

    def infer_person_properties(self, name: str) -> PersonProperties:
        return GenericObjectListAdapter().infer_person_properties(name)
