"""
TR-Graph Task Repair: Diagnosis-Guided Repair Generation
===============================================================

This module implements the diagnosis-guided approach to repair generation.
Instead of searching over operator applications, we:

1. Extract a diagnosis from safety evaluation (what's wrong and why)
2. Guide an LLM to generate repair candidates informed by the diagnosis
3. Validate candidates using formal safety checks and operator preconditions

This approach is more robust than beam search because:
- It never fails due to operator preconditions not being satisfiable
- It can propose repairs involving objects not in the scene (flagged for acquisition)
- It leverages LLM's commonsense reasoning while maintaining formal guarantees
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Tuple, TYPE_CHECKING
from copy import deepcopy
import json
import re

if TYPE_CHECKING:
    from ctr.data_structures import Diagnosis, RepairCandidate, ValidatedRepair


# GENERATION PROMPTS — imported from enriched prompts

from ctr.prompts.enriched_prompts import (
    GENERATION_SYSTEM_PROMPT,
    GENERATION_USER_TEMPLATE,
    get_defect_guidance,
    get_robot_skills,
    get_robot_action_primitives,
)
from ctr.prompts.generation_prompts import (
    format_causal_paths,
    format_operator_priorities,
)


def _get_retry_prompt(n_candidates: int, robot_mode: str = "ai2thor") -> str:
    """Build a retry prompt using the same action dialect as the main prompt.

    This ensures retries don't contradict the initial generation by
    switching action formats or banning valid actions.
    """
    from ctr.prompts.enriched_prompts import get_robot_action_primitives
    action_block = get_robot_action_primitives(robot_mode)

    return f"""Your previous response was not valid JSON or was missing required fields.

Please output ONLY a valid JSON object. Every candidate MUST include both a task_description AND an action_sequence using only supported robot actions.

{action_block}

{{
  "candidates": [
    {{
      "goal": "Complete goal description of the safe task",
      "action": "main action verb",
      "objects": [{{"reference": "object name", "role": "instrument"}}],
      "recipient": null,
      "manner": null,
      "task_description": "complete task description",
      "action_sequence": ["action1", "action2"],
      "required_skills": ["skill1", "skill2"],
      "expected_end_state": "what the world looks like after",
      "changes_made": ["change 1"],
      "operators_used": ["SUBSTITUTE"],
      "safety_addressed": ["concern"],
      "reasoning": "why this is safe and executable",
      "confidence": 0.8
    }}
  ]
}}

Generate {n_candidates} candidates. Start with {{ and end with }}.

CRITICAL: If you cannot write a valid action_sequence using only the supported actions and scene objects, do NOT include that repair."""


# GUIDED GENERATOR

class GuidedGenerator:
    """
    Generate repair candidates guided by safety diagnosis.

    This is the core of the diagnosis-guided approach:
    1. Build a prompt with diagnosis and operator guidance
    2. LLM generates candidate repairs
    3. Parse and return structured candidates for validation
    """

    def __init__(self, llm_client, config: Optional['GenerationConfig'] = None):
        """
        Initialize the generator.

        Args:
            llm_client: LLM client for generation
            config: Generation configuration
        """
        self.llm_client = llm_client
        self.config = config or GenerationConfig()

    def _format_safety_constraints(self, constraints: List[Dict]) -> str:
        """C4: Format safety constraints as numbered human-readable text."""
        if not constraints:
            return "No cross-step safety constraints for this task."

        lines = ["The following safety constraints MUST be satisfied in the action sequence:"]
        for i, c in enumerate(constraints, 1):
            lines.append(
                f"\n{i}. AFTER: {c.get('trigger', '?')}\n"
                f"   EFFECT: {c.get('effect', 'state change')}\n"
                f"   REQUIRED: {c.get('required_action', '?')}\n"
                f"   BEFORE: {c.get('must_occur_before', '?')}\n"
                f"   SEVERITY: {c.get('severity', 'critical')}"
            )
        return '\n'.join(lines)

    def _format_set_groups(self, set_groups: List[Dict]) -> str:
        """C4: Format set groups as human-readable text."""
        if not set_groups:
            return "No item sets — treat each object independently."

        lines = ["The following items form coherent sets. When substituting one item, "
                 "ensure the others remain consistent with the set's purpose:"]
        for sg in set_groups:
            name = sg.get('name', 'unnamed set')
            items = ', '.join(sg.get('items', []))
            coherence = sg.get('coherence_property', '')
            lines.append(f"\n  SET: {name}")
            lines.append(f"  ITEMS: {items}")
            if coherence:
                lines.append(f"  COHERENCE: {coherence}")
        return '\n'.join(lines)

    def generate(
        self,
        original_task: str,
        diagnosis: 'Diagnosis',
        scene_graph: Any = None,
        n_candidates: int = None,
        strict_mode: bool = False,
        available_objects: List[str] = None,
        causal_graph: Any = None,
        operator_priorities: Any = None,
        operator_allocation: List[int] = None,
        safety_constraints: List[Dict] = None,
        set_groups: List[Dict] = None,
    ) -> List['RepairCandidate']:
        """
        Generate repair candidates guided by diagnosis.

        Args:
            original_task: The original unsafe task description
            diagnosis: Safety diagnosis from evaluation
            scene_graph: Scene graph for available resources
            n_candidates: Number of candidates to generate (default from config)
            strict_mode: If True, only use objects from available_objects list
            available_objects: List of objects that can be used in repairs
            causal_graph: CausalGraph for causal path traces in prompt
            operator_priorities: Bandit-derived operator priority distribution
            operator_allocation: Integer slot allocation per operator

        Returns:
            List of RepairCandidate objects
        """
        n = n_candidates or self.config.n_candidates

        # Store strict mode context for validation
        self._strict_mode = strict_mode
        self._available_objects = available_objects or []

        # Build prompt with strict mode consideration and bandit guidance
        prompt = self._build_prompt(
            original_task, diagnosis, scene_graph, n,
            strict_mode=strict_mode,
            available_objects=available_objects,
            causal_graph=causal_graph,
            operator_priorities=operator_priorities,
            operator_allocation=operator_allocation,
            safety_constraints=safety_constraints,
            set_groups=set_groups,
        )

        # Generate with retries
        candidates = []
        retry_feedback = ""

        for attempt in range(self.config.max_retries + 1):
            if attempt == 0:
                response = self.llm_client.generate(GENERATION_SYSTEM_PROMPT, prompt)
            else:
                mode = getattr(self, '_robot_mode', 'ai2thor')
                retry_prompt = _get_retry_prompt(n, mode) + f"\n\nPrevious issue: {retry_feedback}"
                response = self.llm_client.generate(GENERATION_SYSTEM_PROMPT, retry_prompt)

            parsed = self._parse_response(response)

            if parsed and 'candidates' in parsed:
                candidates = self._build_candidates(parsed['candidates'], original_task)
                if candidates:
                    break
                else:
                    retry_feedback = "Candidates list was empty or malformed."
            else:
                retry_feedback = "Response was not valid JSON with 'candidates' array."

        return candidates

    def generate_with_feedback(
        self,
        original_task: str,
        diagnosis: 'Diagnosis',
        failed_candidates: List['ValidatedRepair'],
        scene_graph: Any = None,
        n_candidates: int = None
    ) -> List['RepairCandidate']:
        """
        Regenerate candidates with feedback about why previous ones failed.

        This is called when all initial candidates fail validation.

        Args:
            original_task: The original unsafe task
            diagnosis: Safety diagnosis
            failed_candidates: Previous candidates that failed validation
            scene_graph: Scene graph
            n_candidates: Number to generate

        Returns:
            New list of RepairCandidate objects
        """
        n = n_candidates or self.config.n_candidates

        # Build failure feedback grouped by rejection stage
        failure_reasons = []
        for fc in failed_candidates[:5]:  # Top 5 failures
            task_text = fc.task_text[:80] if fc.task_text else 'unknown'
            if fc.safety_violations:
                for v in fc.safety_violations[:2]:
                    stage = v.layer if v.layer else 'validation'
                    reason = v.explanation if v.explanation else v.rule
                    failure_reasons.append(
                        f"- \"{task_text}\" REJECTED at {stage}: {reason}"
                    )
            else:
                failure_reasons.append(f"- \"{task_text}\" REJECTED")

        feedback = (
            "CRITICAL: The following repairs were already attempted and REJECTED. "
            "Do NOT generate similar repairs. Study WHY each was rejected and "
            "generate fundamentally different alternatives.\n\n"
            + "\n".join(failure_reasons)
            + "\n\nGenerate candidates that take a DIFFERENT approach from all of the above."
        )

        # Build enhanced prompt
        prompt = self._build_prompt(original_task, diagnosis, scene_graph, n)
        prompt += f"\n\nFEEDBACK FROM PREVIOUS ATTEMPT:\n{feedback}"

        # Generate
        response = self.llm_client.generate(GENERATION_SYSTEM_PROMPT, prompt)
        parsed = self._parse_response(response)

        if parsed and 'candidates' in parsed:
            return self._build_candidates(parsed['candidates'], original_task)

        return []

    def _build_prompt(
        self,
        original_task: str,
        diagnosis: 'Diagnosis',
        scene_graph: Any,
        n_candidates: int,
        strict_mode: bool = False,
        available_objects: List[str] = None,
        causal_graph: Any = None,
        operator_priorities: Any = None,
        operator_allocation: List[int] = None,
        safety_constraints: List[Dict] = None,
        set_groups: List[Dict] = None,
    ) -> str:
        """Build the generation prompt with all context."""
        # Format violations
        violations_str = diagnosis.get_violation_summary() if diagnosis.violations else "Safety concerns detected"

        # Format causal variables
        causal_str = ", ".join(diagnosis.causal_variables) if diagnosis.causal_variables else "unspecified variables"

        # Format explanations
        explanations_str = " | ".join(diagnosis.explanations) if diagnosis.explanations else "Safety evaluation flagged concerns"

        # Format hazard level
        if diagnosis.max_hazard >= 0.8:
            hazard_str = "CRITICAL - Task poses serious safety risk"
        elif diagnosis.max_hazard >= 0.5:
            hazard_str = "HIGH - Significant safety concerns"
        else:
            hazard_str = "MODERATE - Safety improvements needed"

        # Format scene resources with strict mode constraint
        resources_str = self._format_scene_resources(
            scene_graph,
            strict_mode=strict_mode,
            available_objects=available_objects
        )

        # Format causal paths from graph
        graph = causal_graph or getattr(diagnosis, 'causal_graph', None)
        causal_paths_str = format_causal_paths(graph, diagnosis)

        # Format operator priorities from bandit
        priorities_str = format_operator_priorities(operator_priorities, operator_allocation)

        # Defect-type-specific guidance from enriched prompts
        defect_type = diagnosis.defect_type
        defect_type_str = defect_type.value if defect_type else "unknown"
        defect_guidance_str = get_defect_guidance(defect_type_str)

        # Frame type
        frame_type = getattr(diagnosis, '_frame_type', None)
        frame_str = frame_type.value.upper() if frame_type and hasattr(frame_type, 'value') else "GENERAL"

        # Activity context from task parsing (replaces hardcoded script mapping)
        script_context_str = getattr(diagnosis, '_activity_context', '') or getattr(diagnosis, 'activity_context', '') or ''

        # Robot skills and action primitives
        mode = getattr(self, '_robot_mode', 'ai2thor')
        robot_skills_str = get_robot_skills(mode)
        robot_action_primitives_str = get_robot_action_primitives(mode)

        # Build exact object names list for action sequence writing
        from ctr.data_structures import NodeType
        if scene_graph and hasattr(scene_graph, 'nodes'):
            scene_object_names = ', '.join(sorted(set(
                node.label for node in scene_graph.nodes.values()
                if node.type in (NodeType.OBJECT, NodeType.REGION)
            )))
        else:
            scene_object_names = 'None detected'

        # Format safety constraints and set groups
        constraints_str = self._format_safety_constraints(safety_constraints or [])
        set_groups_str = self._format_set_groups(set_groups or [])

        try:
            return GENERATION_USER_TEMPLATE.format(
                original_task=original_task,
                frame_type=frame_str,
                violations=violations_str,
                defect_type=defect_type_str,
                causal_variables=causal_str,
                explanations=explanations_str,
                hazard_level=hazard_str,
                defect_guidance=defect_guidance_str,
                script_context=script_context_str,
                causal_paths=causal_paths_str,
                scene_resources=resources_str,
                scene_object_names=scene_object_names,
                robot_skills=robot_skills_str,
                robot_action_primitives=robot_action_primitives_str,
                operator_priorities=priorities_str,
                n_candidates=n_candidates,
                safety_constraints=constraints_str,
                set_groups=set_groups_str,
            )
        except KeyError:
            # Template doesn't have some placeholders — fall back
            return GENERATION_USER_TEMPLATE.format(
                original_task=original_task,
                frame_type=frame_str,
                violations=violations_str,
                defect_type=defect_type_str,
                causal_variables=causal_str,
                explanations=explanations_str,
                hazard_level=hazard_str,
                defect_guidance=defect_guidance_str,
                script_context=script_context_str,
                causal_paths=causal_paths_str,
                scene_resources=resources_str,
                scene_object_names=scene_object_names,
                robot_skills=robot_skills_str,
                robot_action_primitives=robot_action_primitives_str,
                operator_priorities=priorities_str,
                n_candidates=n_candidates,
            )

    def _format_scene_resources(
        self,
        scene_graph: Any,
        strict_mode: bool = False,
        available_objects: List[str] = None
    ) -> str:
        """Format available resources from scene graph with strict mode constraints."""

        # In strict mode with explicit available objects, emphasize the constraint
        if strict_mode and available_objects:
            result = "**STRICT MODE: You may ONLY use these objects in your repairs:**\n"
            result += f"Available objects: {', '.join(available_objects)}\n\n"
            result += "CRITICAL: Do NOT suggest objects that are not in this list.\n"
            result += "If no safe repair is possible with available objects, indicate this.\n\n"

            # Still show people from scene graph if available
            if scene_graph and hasattr(scene_graph, 'nodes'):
                people = []
                for node in scene_graph.nodes.values():
                    node_type = node.type.value if hasattr(node.type, 'value') else str(node.type)
                    if node_type == 'person':
                        person_info = node.label
                        if hasattr(node, 'properties') and node.properties:
                            if hasattr(node.properties, 'age') and node.properties.age:
                                person_info += f" (age: {node.properties.age})"
                            elif hasattr(node.properties, 'age_group') and node.properties.age_group:
                                age_group = node.properties.age_group.value if hasattr(node.properties.age_group, 'value') else str(node.properties.age_group)
                                person_info += f" ({age_group})"
                        people.append(person_info)
                if people:
                    result += f"People in scene: {', '.join(people)}"

            return result

        # Standard (permissive) mode
        if not scene_graph or not hasattr(scene_graph, 'nodes'):
            return "Scene resources unknown - assume standard household items available"

        resources = []
        people = []

        for node in scene_graph.nodes.values():
            node_type = node.type.value if hasattr(node.type, 'value') else str(node.type)

            if node_type == 'person':
                person_info = node.label
                if hasattr(node, 'properties') and node.properties:
                    if hasattr(node.properties, 'age') and node.properties.age:
                        person_info += f" (age: {node.properties.age})"
                    elif hasattr(node.properties, 'age_group') and node.properties.age_group:
                        age_group = node.properties.age_group.value if hasattr(node.properties.age_group, 'value') else str(node.properties.age_group)
                        person_info += f" ({age_group})"
                people.append(person_info)

            elif node_type in ['object', 'container', 'tool']:
                obj_info = node.label
                if hasattr(node, 'properties') and node.properties:
                    props = []
                    if hasattr(node.properties, 'hazard_level') and node.properties.hazard_level:
                        hazard = node.properties.hazard_level.value if hasattr(node.properties.hazard_level, 'value') else str(node.properties.hazard_level)
                        if hazard != 'none':
                            props.append(f"hazard: {hazard}")
                    if hasattr(node.properties, 'child_safe'):
                        if not node.properties.child_safe:
                            props.append("not child-safe")
                    if props:
                        obj_info += f" ({', '.join(props)})"
                resources.append(obj_info)

        # Include location/region information
        locations = []
        for node in scene_graph.nodes.values():
            node_type = node.type.value if hasattr(node.type, 'value') else str(node.type)
            if node_type == 'region':
                loc_info = node.label
                if hasattr(node, 'properties') and node.properties:
                    region_type = getattr(node.properties, 'region_type', '')
                    if region_type:
                        loc_info += f" ({region_type})"
                locations.append(loc_info)

        result = ""
        if locations:
            result += f"Location: {', '.join(locations)}\n"
        if people:
            result += f"People: {', '.join(people)}\n"
        if resources:
            result += f"Objects: {', '.join(resources)}"
        if not result:
            result = "No specific resources detected - assume standard household items"

        return result

    def _parse_response(self, response) -> Optional[Dict]:
        """Parse JSON from LLM response."""
        # Handle LLMResponse objects
        if hasattr(response, 'text'):
            text = response.text
        elif isinstance(response, str):
            text = response
        else:
            text = str(response)

        text = text.strip()

        # Remove markdown code blocks
        if text.startswith("```json"):
            text = text[7:]
        elif text.startswith("```"):
            text = text[3:]
        if text.endswith("```"):
            text = text[:-3]
        text = text.strip()

        try:
            result = json.loads(text)
            # Only return if it's a dict (not a string, list, etc.)
            if isinstance(result, dict):
                return result
        except json.JSONDecodeError:
            pass

        # Try to find JSON object
        start = text.find('{')
        end = text.rfind('}')
        if start != -1 and end != -1:
            try:
                result = json.loads(text[start:end+1])
                if isinstance(result, dict):
                    return result
            except json.JSONDecodeError:
                pass

        return None

    def _build_candidates(
        self,
        parsed_candidates: List[Dict],
        original_task: str
    ) -> List['RepairCandidate']:
        """Build RepairCandidate objects from parsed structured response."""
        from ctr.data_structures import RepairCandidate, TaskVariables, ObjectReference

        candidates = []

        for i, cand_data in enumerate(parsed_candidates):
            if not isinstance(cand_data, dict):
                continue

            # Prefer task_description (mirrors original command structure) over goal (abstract description)
            goal = cand_data.get('task_description') or cand_data.get('goal', '')
            if not goal:
                continue

            # Get action - from structured output or extract from goal
            action = cand_data.get('action') or self._extract_action(goal)

            # Build objects list from structured output
            objects = []
            objects_data = cand_data.get('objects', [])
            for obj_data in objects_data:
                if isinstance(obj_data, dict):
                    obj_ref = ObjectReference(
                        reference_text=obj_data.get('reference', obj_data.get('name', '')),
                        role=obj_data.get('role', 'instrument')
                    )
                    objects.append(obj_ref)
                elif isinstance(obj_data, str):
                    objects.append(ObjectReference(reference_text=obj_data, role='instrument'))

            # Build recipient from structured output
            recipient = None
            recipient_data = cand_data.get('recipient')
            if recipient_data:
                if isinstance(recipient_data, dict):
                    recipient = ObjectReference(
                        reference_text=recipient_data.get('reference', recipient_data.get('name', ''))
                    )
                elif isinstance(recipient_data, str):
                    recipient = ObjectReference(reference_text=recipient_data)

            # Get manner if provided
            manner = cand_data.get('manner')

            # Create fully structured TaskVariables for the repair
            repaired_task = TaskVariables(
                goal=goal,
                action=action,
                objects=objects,
                recipient=recipient,
                manner=manner,
                original_utterance=goal
            )

            # Create RepairCandidate
            candidate = RepairCandidate(
                id=f"guided_{i}",
                original_task=TaskVariables(
                    goal=original_task,
                    action=self._extract_action(original_task),
                    original_utterance=original_task
                ),
                repaired_task=repaired_task,
                confidence=cand_data.get('confidence', 0.7)
            )

            # Extract action sequence, required skills, expected end state
            action_seq = cand_data.get('action_sequence', [])
            if isinstance(action_seq, list) and action_seq:
                candidate.action_sequence = action_seq

            req_skills = cand_data.get('required_skills', [])
            if isinstance(req_skills, list) and req_skills:
                candidate.required_skills = req_skills

            end_state = cand_data.get('expected_end_state', '')
            if end_state:
                candidate.expected_end_state = end_state

            # Store generation metadata
            candidate._generation_data = {
                'changes_made': cand_data.get('changes_made', []),
                'safety_addressed': cand_data.get('safety_addressed', []),
                'reasoning': cand_data.get('reasoning', ''),
                'operators_used': cand_data.get('operators_used', []),
                'causal_chain_broken_at': cand_data.get('causal_chain_broken_at', ''),
            }

            candidates.append(candidate)

        return candidates

    def _extract_action(self, task_description: str) -> str:
        """Extract the main action verb from a task description."""
        if not task_description:
            return "do"

        # Common action verbs
        action_verbs = [
            'pour', 'give', 'hand', 'place', 'put', 'bring', 'take', 'get',
            'make', 'prepare', 'serve', 'deliver', 'provide', 'offer',
            'help', 'assist', 'support', 'guide', 'show', 'demonstrate'
        ]

        words = task_description.lower().split()
        for word in words:
            # Clean punctuation
            clean_word = re.sub(r'[^\w]', '', word)
            if clean_word in action_verbs:
                return clean_word

        # Default to first word if it looks like a verb
        if words:
            return words[0]

        return "do"


# CONFIGURATION

@dataclass
class GenerationConfig:
    """Configuration for guided repair generation."""
    n_candidates: int = 5                    # Number of candidates to generate
    temperature: float = 0.7                 # LLM temperature (if supported)
    max_retries: int = 2                     # Retries for unparseable responses
    include_operator_guidance: bool = True   # Include operator hints in prompt
    require_reasoning: bool = True           # Require LLM to explain reasoning
