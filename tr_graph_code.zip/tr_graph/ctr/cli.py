"""
TR-Graph - Command Line Interface

Usage:
    # Single task processing
    tr-graph repair "Pour hot coffee for the baby"
    tr-graph repair "Pour hot coffee for the baby" --method tr-graph --model gpt-4o

    # Start web interface
    tr-graph web

    # Benchmarks (use dedicated scripts)
    python -m ctr.benchmarks.run_safeagentbench --num-tasks 100 --model gpt-4o
    python -m ctr.benchmarks.run_earbench --num-tasks 100 --model gpt-4o
"""

import argparse
import json
import sys
import logging
from typing import Optional

logger = logging.getLogger(__name__)


def main(args: Optional[list] = None) -> int:
    """Main CLI entry point for TR-Graph."""
    parser = argparse.ArgumentParser(
        prog="tr-graph",
        description="TR-Graph: Task Command Repair for Safe LLM-Controlled Robot Systems",
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # REPAIR command (single task)
    repair_parser = subparsers.add_parser(
        "repair",
        help="Repair a single unsafe task"
    )
    repair_parser.add_argument(
        "task",
        help="The task to process (e.g., 'Pour hot coffee for the baby')",
    )
    repair_parser.add_argument(
        "--method",
        type=str,
        choices=["tr-graph", "baseline"],
        default="tr-graph",
        help="Repair method: 'tr-graph' (structured) or 'baseline' (LLM only)",
    )
    repair_parser.add_argument(
        "--model",
        type=str,
        default="gpt-4o",
        help="LLM model to use (default: gpt-4o)",
    )
    repair_parser.add_argument(
        "--provider",
        type=str,
        choices=["openai", "anthropic", "google"],
        default="openai",
        help="LLM provider (default: openai)",
    )
    repair_parser.add_argument(
        "--scene",
        type=str,
        default="kitchen",
        help="Scene context (default: kitchen)",
    )
    repair_parser.add_argument(
        "--output",
        type=str,
        choices=["text", "json"],
        default="text",
        help="Output format (default: text)",
    )
    repair_parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Enable verbose output",
    )

    # WEB command
    web_parser = subparsers.add_parser(
        "web",
        help="Start the web interface"
    )
    web_parser.add_argument(
        "--port", "-p",
        type=int,
        default=5000,
        help="Port to run the server on (default: 5000)",
    )
    web_parser.add_argument(
        "--host",
        type=str,
        default="0.0.0.0",
        help="Host to bind to (default: 0.0.0.0)",
    )
    web_parser.add_argument(
        "--no-browser",
        action="store_true",
        help="Don't open browser automatically",
    )
    web_parser.add_argument(
        "--debug",
        action="store_true",
        help="Run in debug mode",
    )
    # VERSION
    parser.add_argument(
        "--version",
        action="version",
        version="%(prog)s 0.1.0",
    )

    # Parse arguments
    parsed_args = parser.parse_args(args)

    if not parsed_args.command:
        parser.print_help()
        return 0

    # Route to appropriate handler
    if parsed_args.command == "repair":
        return handle_repair(parsed_args)
    elif parsed_args.command == "web":
        return handle_web(parsed_args)
    else:
        parser.print_help()
        return 0


def handle_repair(args) -> int:
    """Handle single task repair."""
    try:
        from ctr.llm_client import create_client
        from ctr.baseline import BaselineLLMRepair

        if args.verbose:
            logging.basicConfig(level=logging.INFO)

        # Create LLM client
        llm_client = create_client(
            provider=args.provider,
            model=args.model
        )

        if args.method == "baseline":
            # Use baseline LLM repair
            baseline = BaselineLLMRepair(llm_client, model=args.model)
            result = baseline.repair(
                task=args.task,
                scene=args.scene
            )

            if args.output == "json":
                output = {
                    "task": args.task,
                    "method": "baseline",
                    "model": result.model,
                    "repaired_task": result.repaired_task,
                    "analysis": result.analysis,
                    "what_changed": result.what_changed,
                    "latency_ms": result.latency_ms
                }
                print(json.dumps(output, indent=2))
            else:
                print(f"\nOriginal: {args.task}")
                print(f"Method: Baseline LLM ({result.model})")
                print(f"\nAnalysis: {result.analysis}")
                print(f"\nRepaired: {result.repaired_task}")
                print(f"\nWhat changed: {result.what_changed}")

        else:
            # Use TR-Graph pipeline
            try:
                from ctr.pipeline import CTRPipeline, CTRConfig

                config = CTRConfig()
                # CTRConfig contains search parameters, not LLM settings
                # LLM settings are passed via llm_client

                pipeline = CTRPipeline(llm_client, config)
                result = pipeline.process(args.task)

                if args.output == "json":
                    output = {
                        "task": args.task,
                        "method": "ctr",
                        "model": args.model,
                        "is_original_safe": result.is_original_safe,
                        "repair_performed": result.repair_performed,
                        "explanation": result.explanation,
                    }
                    if result.repair_options:
                        output["options"] = [
                            {
                                "label": opt.option_label,
                                "description": opt.brief_description,
                            }
                            for opt in result.repair_options
                        ]
                    print(json.dumps(output, indent=2))
                else:
                    print(f"\nOriginal: {args.task}")
                    print(f"Method: TR-Graph ({args.model})")
                    print(f"\nOriginal Safe: {result.is_original_safe}")
                    print(f"Repair Performed: {result.repair_performed}")
                    print(f"\n{result.explanation}")

            except ImportError as e:
                print(f"TR-Graph pipeline not available: {e}", file=sys.stderr)
                print("Falling back to baseline method...", file=sys.stderr)
                return handle_repair(argparse.Namespace(
                    **{**vars(args), 'method': 'baseline'}
                ))

        return 0

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        if args.verbose:
            import traceback
            traceback.print_exc()
        return 1






def handle_web(args) -> int:
    """Handle web interface."""
    try:
        from ctr.interface.app import run_server


        print(f"Starting TR-Graph Web Interface...")
        print(f"Server will run on http://{args.host}:{args.port}")

        run_server(
            host=args.host,
            port=args.port,
            debug=args.debug,
            open_browser=not args.no_browser,
        )

        return 0

    except ImportError as e:
        print(f"Error: Web interface dependencies not installed.", file=sys.stderr)
        print(f"Install with: pip install flask flask-cors", file=sys.stderr)
        print(f"Details: {e}", file=sys.stderr)
        return 1

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
