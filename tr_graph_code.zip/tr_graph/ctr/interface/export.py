"""
HTML snapshot renderer for reviewer artifact export.

Produces a self-contained HTML page from a pipeline result dict,
with an optional collapsible backend trace section. The visual
structure mirrors the Flask interface.
"""

import json
import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

_CSS = """
body { font-family: 'Noto Sans', Arial, sans-serif; margin: 2rem auto; max-width: 900px; color: #1a1a2e; line-height: 1.6; }
h1 { font-size: 1.4rem; border-bottom: 2px solid #005461; padding-bottom: 0.5rem; }
h2 { font-size: 1.1rem; margin-top: 1.5rem; color: #005461; }
h3 { font-size: 0.95rem; margin-top: 1rem; }
.card { border: 1px solid #e2e6ea; border-radius: 8px; padding: 1rem; margin: 1rem 0; background: #fff; }
.card-header { font-weight: 600; font-size: 0.85rem; text-transform: uppercase; letter-spacing: 0.05em; color: #005461; margin-bottom: 0.5rem; }
.safe { border-left: 4px solid #27ae60; }
.unsafe { border-left: 4px solid #e74c3c; }
.repaired { border-left: 4px solid #005461; }
.tag { display: inline-block; padding: 0.15rem 0.5rem; border-radius: 4px; font-size: 0.75rem; font-weight: 600; margin-right: 0.3rem; }
.tag-safe { background: #d4edda; color: #155724; }
.tag-unsafe { background: #f8d7da; color: #721c24; }
.tag-repaired { background: #d1ecf1; color: #0c5460; }
.tag-operator { background: #e0f2f1; color: #004d40; }
.metric { display: inline-block; margin-right: 1.5rem; font-size: 0.85rem; }
.metric-label { color: #666; }
.metric-value { font-weight: 600; }
pre { background: #f4f6f8; padding: 0.75rem; border-radius: 6px; font-size: 0.8rem; overflow-x: auto; white-space: pre-wrap; word-break: break-word; }
details { margin: 0.5rem 0; }
summary { cursor: pointer; font-weight: 600; font-size: 0.85rem; color: #005461; padding: 0.3rem 0; }
.trace-file { margin: 0.5rem 0; }
.trace-file-name { font-family: monospace; font-size: 0.8rem; color: #666; }
"""


def export_task_html(
    result: dict,
    output_path: str,
    trace_dir: Optional[str] = None
):
    """Render a self-contained HTML page from a pipeline result.

    Args:
        result: Pipeline result dict (from session log or /process response)
        output_path: Where to write the HTML file
        trace_dir: Optional path to trace directory for collapsible backend traces
    """
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)

    task = result.get('task', result.get('instruction', ''))
    status = result.get('final_status', 'UNKNOWN')
    is_safe = result.get('is_safe', False)
    repaired_task = result.get('repaired_task', '')
    explanation = result.get('explanation', '')

    # Status styling
    if status == 'SAFE':
        status_class = 'safe'
        status_tag = 'tag-safe'
    elif status == 'REPAIRED':
        status_class = 'repaired'
        status_tag = 'tag-repaired'
    else:
        status_class = 'unsafe'
        status_tag = 'tag-unsafe'

    # Build HTML
    mode = result.get('mode', 'tr-graph')
    mode_label = 'TR-Graph' if mode in ('ctr', 'tr-graph') else mode

    parts = [
        '<!DOCTYPE html><html><head><meta charset="utf-8">',
        f'<title>TR-Graph: {task[:60]}</title>',
        f'<style>{_CSS}</style></head><body>',
        '<h1>TR-Graph Execution Backend Trace</h1>',
    ]

    # Combined task card: original (defective) + repaired in one box
    parts.append('<div class="card">')
    parts.append('<div style="margin-bottom: 12px;">')
    parts.append('<span class="tag tag-unsafe">Defective Task Command</span>')
    parts.append(f'<p style="margin-top: 8px; margin-bottom: 0;"><strong>{task}</strong></p>')
    parts.append('</div>')

    if repaired_task and status == 'REPAIRED':
        parts.append('<div style="border-top: 1px solid #e2e6ea; padding-top: 12px;">')
        parts.append('<span class="tag tag-repaired">Repaired Task Command</span>')
        parts.append(f'<p style="margin-top: 8px; margin-bottom: 0;"><strong>{repaired_task}</strong></p>')

        # Metrics
        repair_data = result.get('stages', {}).get('repair', {})
        affinity = repair_data.get('affinity', result.get('repair_affinity', 0))
        cost = repair_data.get('cost', result.get('repair_cost', 0))
        if affinity or cost:
            parts.append('<div style="margin-top: 8px;">')
            parts.append(f'<span class="metric"><span class="metric-label">Affinity:</span> <span class="metric-value">{affinity:.3f}</span></span>')
            parts.append(f'<span class="metric"><span class="metric-label">Cost:</span> <span class="metric-value">{cost:.3f}</span></span>')
            parts.append('</div>')

        # Operators
        operators = repair_data.get('operator_used', '')
        if operators:
            parts.append(f'<p style="margin-top: 8px; margin-bottom: 0;">Operator(s): ')
            for op in operators.split(', '):
                parts.append(f'<span class="tag tag-operator">{op}</span>')
            parts.append('</p>')

        parts.append('</div>')
    elif status == 'SAFE':
        parts.append('<div style="border-top: 1px solid #e2e6ea; padding-top: 12px;">')
        parts.append('<span class="tag tag-safe">Safe Task Command</span>')
        parts.append('<p style="margin-top: 8px; margin-bottom: 0;">Task is safe — no repair needed.</p>')
        parts.append('</div>')

    parts.append('</div>')

    # Backend trace (collapsible)
    if trace_dir:
        trace_path = Path(trace_dir)
        if trace_path.exists() and trace_path.is_dir():
            trace_files = sorted(trace_path.iterdir())
            if trace_files:
                parts.append('<h2>Backend Trace</h2>')
                parts.append('<p style="font-size:0.8rem;color:#666;">Click on any execution output below to expand. Execution traces are ordered by pipeline stage.</p>')
                for tf in trace_files:
                    if tf.name.startswith('.'):
                        continue
                    parts.append('<details class="trace-file">')
                    parts.append(f'<summary class="trace-file-name">{tf.name}</summary>')
                    try:
                        content = tf.read_text(encoding='utf-8')
                        if tf.suffix == '.json':
                            # Pretty-print JSON
                            try:
                                obj = json.loads(content)
                                content = json.dumps(obj, indent=2, ensure_ascii=False)
                            except json.JSONDecodeError:
                                pass
                        parts.append(f'<pre>{_escape_html(content)}</pre>')
                    except Exception:
                        parts.append('<pre>(Unable to read file)</pre>')
                    parts.append('</details>')

    # Metadata (no timestamp or timing)
    parts.append('<h2>Metadata</h2>')
    parts.append('<div class="card">')
    for key in ['task_id', 'model']:
        val = result.get(key, '')
        if val:
            parts.append(f'<span class="metric"><span class="metric-label">{key}:</span> <span class="metric-value">{val}</span></span>')
    parts.append(f'<span class="metric"><span class="metric-label">mode:</span> <span class="metric-value">{mode_label}</span></span>')
    parts.append('</div>')

    parts.append('</body></html>')

    output.write_text('\n'.join(parts), encoding='utf-8')
    logger.info(f"[Export] HTML snapshot saved: {output}")


def _escape_html(text: str) -> str:
    """Escape HTML special characters."""
    return (text
            .replace('&', '&amp;')
            .replace('<', '&lt;')
            .replace('>', '&gt;')
            .replace('"', '&quot;'))
