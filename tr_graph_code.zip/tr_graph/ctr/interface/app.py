"""
TR-Graph Web Interface - Flask Application.

Provides a web interface for:
- Task input and scene configuration
- Mode selection (TR-Graph vs Base LLM)
- Model selection
- Repair visualization
- AI2-THOR execution
"""

import os
import sys
import time
import json
import uuid
import logging
import webbrowser
import traceback
from pathlib import Path
from datetime import datetime
from threading import Thread
from typing import Dict, List, Optional, Any

# Load environment variables from .env file 
try:
    from dotenv import load_dotenv
    # Load from project root (.env file)
    env_path = Path(__file__).parent.parent.parent / '.env'
    load_dotenv(env_path)
    # Also try current directory as fallback
    load_dotenv()
except ImportError:
    pass

from flask import Flask, render_template, request, jsonify, send_from_directory, send_file, Response, make_response
from flask_cors import CORS

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


# GLOBAL STATE


llm_client = None
ctr_pipeline = None
baseline_repair = None
ai2thor_controller = None

system_ready = False
ai2thor_ready = False
initialization_error = None

# Cache for VLM-detected scene graph — reused when processing tasks in camera mode.
# Key: image hash or session marker. Value: SceneGraph object from VLM perception.
_vlm_scene_graph_cache = None




# INITIALIZATION


def print_banner():
    """Print startup banner."""
    print("\n" + "=" * 60)
    print("  TR-Graph: Task Command Repair for Safe LLM-Controlled Robot Systems")
    print("=" * 60)
    print("Initializing...")
    print()


def print_progress(step: int, total: int, message: str, success: bool = True, time_taken: float = None):
    """Print initialization progress."""
    status = "OK" if success else "FAILED"
    time_str = f" ({time_taken:.1f}s)" if time_taken else ""
    print(f"[{step}/{total}] {message}... {status}{time_str}")


def init_components():
    """Initialize all system components."""
    global llm_client, ctr_pipeline, baseline_repair
    global ai2thor_controller, system_ready, ai2thor_ready, initialization_error

    start_time = time.time()

    try:
        # Step 1: Initialize LLM client
        step_start = time.time()
        try:
            from ctr.llm_client import create_client
            llm_client = create_client(provider='openai')
            print_progress(1, 5, "LLM client initialized", True, time.time() - step_start)
        except Exception as e:
            logger.warning(f"LLM client initialization failed: {e}")
            print_progress(1, 5, f"LLM client (will use on-demand)", False)

        # Step 2: Initialize Baseline Repair
        step_start = time.time()
        try:
            from ctr.baseline import BaselineLLMRepair
            if llm_client:
                baseline_repair = BaselineLLMRepair(llm_client)
            print_progress(2, 5, "Baseline repair ready", True, time.time() - step_start)
        except Exception as e:
            logger.warning(f"Baseline repair initialization failed: {e}")
            print_progress(2, 5, "Baseline repair (will init on-demand)", False)

        # Step 3: Initialize TR-Graph Pipeline
        step_start = time.time()
        try:
            from ctr.pipeline import CTRPipeline, CTRConfig
            if llm_client:
                config = _interface_config()
                ctr_pipeline = CTRPipeline(llm_client, config)
            print_progress(3, 5, "TR-Graph pipeline ready", True, time.time() - step_start)
        except Exception as e:
            logger.warning(f"TR-Graph pipeline initialization failed: {e}")
            print_progress(3, 5, "TR-Graph pipeline (will init on-demand)", False)

        # Step 5: Initialize AI2-THOR (optional)
        step_start = time.time()
        ai2thor_controller = init_ai2thor_controller()
        if ai2thor_controller:
            ai2thor_ready = True
            print_progress(5, 5, "AI2-THOR ready", True, time.time() - step_start)
        else:
            ai2thor_ready = False
            print_progress(5, 5, "AI2-THOR not available (optional)", False)

        # Create data directories
        data_dir = Path(__file__).parent.parent.parent / 'data'
        (data_dir / 'logs' / 'sessions').mkdir(parents=True, exist_ok=True)
        (data_dir / 'screenshots').mkdir(parents=True, exist_ok=True)
        (data_dir / 'videos').mkdir(parents=True, exist_ok=True)

        total_time = time.time() - start_time
        print()
        print("=" * 60)
        print(f"  System ready! ({total_time:.1f}s)")
        print("  Starting web interface...")
        print("=" * 60)
        print()

        system_ready = True

    except Exception as e:
        initialization_error = str(e)
        system_ready = False
        logger.error(f"Initialization failed: {e}")
        traceback.print_exc()


def init_ai2thor_controller():
    """Initialize AI2-THOR controller if available."""
    # AI2-THOR not available on Windows
    if os.name == 'nt':
        logger.info("AI2-THOR not available on Windows")
        return None

    try:
        import ai2thor
        from ai2thor.controller import Controller

        controller = Controller(height=720, width=1280)
        controller.reset("FloorPlan1")

        logger.info(f"AI2-THOR initialized: {ai2thor.__version__}")
        return controller

    except ImportError:
        logger.info("AI2-THOR not installed")
        return None
    except Exception as e:
        logger.warning(f"AI2-THOR initialization failed: {e}")
        return None



# FLASK APP


def _interface_config(strict_mode: bool = False):
    """Create CTRConfig with explicit interface settings."""
    from ctr.pipeline import CTRConfig
    config = CTRConfig()
    config.enable_result_cache = True
    config.generate_explanation = True
    config.use_deterministic_grounding = True
    config.enable_compound_handling = False
    config.strict_grounding = strict_mode
    # Embedding-based grounding validation: logging on (zero-risk observation
    # of LLM vs embedding disagreements), override off (conservative while the
    # stream is being observed). Flip override on once logs show clean agreement.
    config.enable_embedding_validation_logging = True
    config.enable_embedding_validation_override = False
    return config


def create_app():
    """Create and configure the Flask application."""
    app = Flask(__name__,
                template_folder=str(Path(__file__).parent / 'templates'),
                static_folder=str(Path(__file__).parent / 'static'))

    CORS(app, resources={
        r"/*": {
            "origins": ["http://localhost:*", "http://127.0.0.1:*"],
            "methods": ["GET", "POST", "OPTIONS"],
            "allow_headers": ["Content-Type", "Authorization"]
        }
    })

    # ROUTES

    @app.route('/')
    def index():
        """Serve the main page."""
        response = make_response(render_template('index.html'))
        response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
        response.headers['Pragma'] = 'no-cache'
        response.headers['Expires'] = '0'
        return response

    @app.route('/health')
    def health():
        """Health check endpoint."""
        return jsonify({
            'status': 'ok',
            'ready': system_ready,
            'ai2thor_ready': ai2thor_ready,
            'error': initialization_error
        })

    @app.route('/status')
    def status():
        """Get detailed system status."""
        return jsonify({
            'ready': system_ready,
            'ai2thor_ready': ai2thor_ready,
            'error': initialization_error,
            'components': {
                'llm_client': llm_client is not None,
                'ctr_pipeline': ctr_pipeline is not None,
                'baseline_repair': baseline_repair is not None,
                'ai2thor': ai2thor_controller is not None
            }
        })

    @app.route('/models')
    def get_models():
        """Get available LLM models ."""
        try:
            # Model registry 
            models = {
                # OpenAI models
                'gpt-4o': {
                    'name': 'GPT-4o',
                    'provider': 'openai',
                    'description': 'OpenAI model with vision capabilities (recommended)'
                },
                'gpt-4-turbo': {
                    'name': 'GPT-4 Turbo',
                    'provider': 'openai',
                    'description': 'OpenAI GPT-4 Turbo 128K (for comparison with published baselines)'
                },
                'gpt-4o-mini': {
                    'name': 'GPT-4o Mini',
                    'provider': 'openai',
                    'description': 'OpenAI fast and affordable model'
                },
                'gpt-5.2': {
                    'name': 'GPT-5.2',
                    'provider': 'openai',
                    'description': 'Latest OpenAI flagship model'
                },
                'gpt-5.1': {
                    'name': 'GPT-5.1',
                    'provider': 'openai',
                    'description': 'OpenAI advanced model'
                },
                # Google/Gemini models
                'gemini-2.5-pro': {
                    'name': 'Gemini 2.5 Pro',
                    'provider': 'google',
                    'description': "Google's advanced model"
                },
                'gemini-2.5-flash': {
                    'name': 'Gemini 2.5 Flash',
                    'provider': 'google',
                    'description': "Google's fast model"
                },
            }

            # Check which providers have API keys
            api_keys = {
                'openai': bool(os.environ.get('OPENAI_API_KEY')),
                'anthropic': bool(os.environ.get('ANTHROPIC_API_KEY')),
                'google': bool(os.environ.get('GOOGLE_API_KEY')),
            }

            # Filter to only show models for providers with valid API keys
            available = {}
            for model_id, info in models.items():
                if api_keys.get(info['provider'], False):
                    available[model_id] = info

            # Determine default model
            default_model = None
            if api_keys.get('openai'):
                default_model = 'gpt-4o'
            elif api_keys.get('google'):
                default_model = 'gemini-2.5-pro'
            elif available:
                default_model = list(available.keys())[0]

            return jsonify({
                'models': available,
                'api_keys': api_keys,
                'default': default_model
            })

        except Exception as e:
            logger.error(f"Error getting models: {e}")
            return jsonify({'error': str(e)}), 500

    # =========================================================================
    @app.route('/process', methods=['POST'])
    def process_task():
        """Process a task through TR-Graph or Baseline."""
        start_time = time.time()

        try:
            data = request.get_json()
            if not data:
                return jsonify({'error': 'No JSON data provided'}), 400

            # Extract parameters
            task = data.get('task', '').strip()
            scene = data.get('scene', '').strip()
            scene_objects = data.get('scene_objects', [])
            scene_mode = data.get('scene_mode', 'ai2thor')  # 'ai2thor', 'object_list', 'camera', 'hypothetical'
            robot_type = data.get('robot_type', None)  # franka, spot, ai2thor, generic
            mode = data.get('mode', 'ctr')  # 'ctr' or 'baseline'
            model = data.get('model', 'gpt-4o')
            floor_plan = data.get('floor_plan', 1)


            if not task:
                return jsonify({'error': 'No task provided'}), 400

            # Create session
            session_id = str(uuid.uuid4())
            timestamp = datetime.now().isoformat()

            logger.info(f"[{session_id[:8]}] Processing: '{task[:50]}...' (mode={mode}, model={model})")

            # Create LLM client for this request
            from ctr.llm_client import create_client
            request_client = create_client(provider=get_provider_for_model(model), model=model)

            result = {
                'session_id': session_id,
                'timestamp': timestamp,
                'task': task,
                'scene': scene,
                'scene_objects': scene_objects,
                'scene_mode': scene_mode,
                'mode': mode,
                'model': model,
                'floor_plan': floor_plan,
                'stages': {},
                'processing_times': {}
            }

            if mode == 'baseline':
                # Run LLM-CoT baseline
                result = process_baseline(request_client, task, scene, scene_objects, result)
            elif mode in ('safeplan', 'selp-lite'):
                # Run SafePlan or SELP-lite baseline
                result = process_benchmark_baseline(request_client, task, scene, scene_objects, result, baseline=mode, robot_type=robot_type)
            else:
                # Run TR-Graph pipeline
                result = process_ctr(request_client, task, scene, scene_objects, scene_mode, result, floor_plan=floor_plan, robot_type=robot_type)

            # Calculate total time
            result['total_time_ms'] = (time.time() - start_time) * 1000

            # Save session log (legacy, all sessions)
            save_session_log(result)


            return jsonify(result)

        except Exception as e:
            logger.error(f"Processing error: {e}")
            traceback.print_exc()
            return jsonify({
                'error': str(e),
                'final_status': 'ERROR'
            }), 500

    @app.route('/process-stream', methods=['POST'])
    def process_task_stream():
        """
        Process a task with streaming results (Server-Sent Events).

        Returns results progressively:
        1. Safety evaluation as soon as it's complete
        2. Full repair results when complete
        """
        try:
            data = request.get_json()
            if not data:
                return jsonify({'error': 'No JSON data provided'}), 400

            # Extract parameters
            task = data.get('task', '').strip()
            scene = data.get('scene', '').strip()
            scene_objects = data.get('scene_objects', [])
            scene_mode = data.get('scene_mode', 'ai2thor')
            robot_type = data.get('robot_type', None)  # franka, spot, ai2thor, generic
            mode = data.get('mode', 'ctr')
            model = data.get('model', 'gpt-4o')
            floor_plan = data.get('floor_plan', 1)


            if not task:
                return jsonify({'error': 'No task provided'}), 400

            # For baseline modes, fall back to non-streaming
            if mode in ('baseline', 'safeplan', 'selp-lite'):
                return process_task()

            # Determine strict mode
            strict_mode = scene_mode != 'hypothetical'

            # Create session
            session_id = str(uuid.uuid4())
            timestamp = datetime.now().isoformat()

            logger.info(f"[{session_id[:8]}] Streaming process: '{task[:50]}...' (mode={scene_mode}, model={model})")

            def generate_sse():
                """Generator for Server-Sent Events."""
                try:
                    from ctr.llm_client import create_client
                    from ctr.pipeline import CTRPipeline, CTRConfig

                    # Create client and pipeline
                    request_client = create_client(
                        provider=get_provider_for_model(model),
                        model=model
                    )

                    config = _interface_config(strict_mode=strict_mode)

                    # Enable reviewer artifact export for interface runs
                    config.export_reviewer_artifacts = True
                    config.artifact_dir = str(
                        Path(config.artifact_dir) / "interface_runs"
                    )

                    pipeline = CTRPipeline(request_client, config)

                    # Set robot mode for skill-aware prompts
                    if robot_type:
                        pipeline._robot_mode = robot_type

                    # Create scene graph based on mode
                    effective_objects = list(scene_objects) if scene_objects else []

                    # Diagnostic: log scene graph construction path
                    logger.info(f"[process] Scene graph construction: scene_mode={scene_mode}, "
                                f"vlm_cache={'YES' if _vlm_scene_graph_cache is not None else 'NO'}, "
                                f"scene_objects={len(scene_objects) if scene_objects else 0}, "
                                f"robot_type={robot_type}")

                    if _vlm_scene_graph_cache is not None and scene_mode == 'camera':
                        # Reuse the rich VLM scene graph from /detect-objects
                        # (has spatial edges: on, near, inside, reachable_by)
                        scene_graph = _vlm_scene_graph_cache
                        logger.info(f"[process] PATH: Using cached VLM scene graph: {len(scene_graph.nodes)} nodes, {len(scene_graph.edges)} edges")
                    elif scene_objects:
                        # Build from flat object list — use TabletopSceneAdapter for robot mode
                        if robot_type and robot_type not in ('ai2thor', 'safeagentbench'):
                            from ctr.scene_graph_builder import SceneGraphBuilder
                            from ctr.scene_adapters import TabletopSceneAdapter
                            effective_objects = [_normalize_object_name(obj) for obj in scene_objects]
                            builder = SceneGraphBuilder(adapter=TabletopSceneAdapter())
                            scene_graph = builder.build_from_object_list(effective_objects, floor_plan=floor_plan, task=task)
                            logger.info(f"[process] PATH: Built TabletopSceneAdapter graph: {len(scene_graph.nodes)} nodes, {len(scene_graph.edges)} edges")
                        else:
                            scene_graph = create_scene_graph_from_objects(scene_objects, scene, task, floor_plan=floor_plan)
                            logger.info(f"[process] PATH: Built GenericObjectListAdapter graph: {len(scene_graph.nodes)} nodes, {len(scene_graph.edges)} edges")
                    elif scene_mode == 'hypothetical':
                        # Hypothetical mode: parse objects from scene description text
                        parsed_objects = parse_objects_from_description(scene)
                        effective_objects = parsed_objects
                        scene_graph = create_scene_graph_from_objects([], scene, task, floor_plan=floor_plan)
                        logger.info("[process] PATH: Hypothetical mode")
                    else:
                        scene_graph = None
                        logger.info("[process] PATH: No scene graph")

                    # Process with streaming
                    for phase, result in pipeline.process_streaming(
                        task,
                        scene_graph=scene_graph,
                        context=scene,
                        strict_mode=strict_mode,
                        available_objects=effective_objects
                    ):
                        if phase == 'safety':
                            # Safety evaluation complete - send immediately
                            # Enrich safety_details with diagnosis fields
                            safety_details = dict(result['safety_details'])
                            try:
                                safety_result_obj = result.get('_safety_result')
                                if safety_result_obj:
                                    from ctr.safety_evaluation import extract_diagnosis
                                    diag = extract_diagnosis(safety_result_obj)
                                    if diag:
                                        dt = getattr(diag, 'defect_type', None)
                                        ht = getattr(diag, 'hazard_type', None)
                                        edges = getattr(diag, 'causal_edges', None) or []
                                        safety_details['defect_type'] = dt.value if dt else None
                                        safety_details['hazard_type'] = ht.value if ht else None
                                        safety_details['hazard_severity'] = getattr(diag, 'hazard_severity', None)
                                        safety_details['hazard_probability'] = getattr(diag, 'hazard_probability', None)
                                        safety_details['causal_edges'] = [
                                            {'from': getattr(e, 'source', ''), 'to': getattr(e, 'target', ''), 'relationship': getattr(e, 'relationship', '')}
                                            for e in edges
                                        ]
                            except Exception:
                                pass
                            # safety_details is already a clean copy
                            safety_event = {
                                'phase': 'safety',
                                'session_id': session_id,
                                'timestamp': timestamp,
                                'task': task,
                                'is_safe': result['is_safe'],
                                'safety_details': safety_details,
                                'processing_time_ms': result['processing_time_ms']
                            }
                            yield f"event: safety\ndata: {json.dumps(safety_event)}\n\n"

                        elif phase == 'complete':
                            # Full result - build final response
                            pipeline_result = result
                            final_result = build_streaming_final_result(
                                pipeline_result=pipeline_result,
                                session_id=session_id,
                                timestamp=timestamp,
                                task=task,
                                scene=scene,
                                scene_objects=scene_objects,
                                mode=mode,
                                model=model,
                                floor_plan=floor_plan
                            )

                            # Save session log
                            save_session_log(final_result)

                            # Auto-export HTML snapshot if artifacts enabled
                            if getattr(pipeline.config, 'export_reviewer_artifacts', False):
                                try:
                                    from ctr.interface.export import export_task_html
                                    task_id = final_result.get('task_id') or getattr(pipeline, '_current_task_id', None) or session_id[:12]
                                    trace_dir = Path(pipeline.config.artifact_dir) / 'traces' / task_id
                                    export_path = (
                                        Path(pipeline.config.artifact_dir) /
                                        'interface_snapshots' / task_id / 'interface_rendered.html'
                                    )
                                    export_task_html(
                                        result=final_result,
                                        output_path=str(export_path),
                                        trace_dir=str(trace_dir) if trace_dir.exists() else None,
                                    )
                                except Exception as e:
                                    logger.warning(f"[Export] HTML export failed: {e}")

                            yield f"event: complete\ndata: {json.dumps(final_result)}\n\n"

                except Exception as e:
                    logger.error(f"Streaming error: {e}")
                    traceback.print_exc()
                    error_event = {
                        'phase': 'error',
                        'error': str(e),
                        'session_id': session_id
                    }
                    yield f"event: error\ndata: {json.dumps(error_event)}\n\n"

            return Response(
                generate_sse(),
                mimetype='text/event-stream',
                headers={
                    'Cache-Control': 'no-cache',
                    'Connection': 'keep-alive',
                    'X-Accel-Buffering': 'no'  # Disable nginx buffering
                }
            )

        except Exception as e:
            logger.error(f"Stream setup error: {e}")
            traceback.print_exc()
            return jsonify({'error': str(e)}), 500

    @app.route('/export-package', methods=['POST'])
    def export_package():
        """Package the current session HTML + media files into a zip download."""
        import zipfile
        import io
        import re

        try:
            data = request.get_json()
            dom_html = data.get('dom_html', '')
            task_text = data.get('task_text', 'task')

            if not dom_html:
                return jsonify({'error': 'No HTML provided'}), 400

            # Note: no sanitization on DOM HTML — it's user-facing content
            # that doesn't contain API keys. Sanitization was causing regex
            # backtracking on large HTML strings (275KB+).

            # Find all media references in the HTML
            media_paths = set()
            for match in re.finditer(r'/static/videos/([^"\'>\s]+)', dom_html):
                media_paths.add(('videos', match.group(1)))
            for match in re.finditer(r'/static/screenshots/([^"\'>\s]+)', dom_html):
                media_paths.add(('screenshots', match.group(1)))

            # Build zip in memory
            zip_buffer = io.BytesIO()
            clean_task = re.sub(r'[^a-zA-Z0-9]', '_', task_text)[:40]
            folder_name = f"TR-Graph_{clean_task}"

            with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zf:
                # Rewrite media paths in HTML to be relative
                export_html = dom_html
                for media_type, media_path in media_paths:
                    old_path = f'/static/{media_type}/{media_path}'
                    new_path = f'media/{Path(media_path).name}'
                    export_html = export_html.replace(old_path, new_path)

                # Write HTML
                zf.writestr(f'{folder_name}/index.html', export_html)

                # Copy media files from data/ directory
                data_dir = Path(__file__).parent.parent.parent / 'data'
                found_count = 0
                for media_type, media_path in media_paths:
                    file_path = data_dir / media_type / media_path
                    if file_path.exists():
                        zf.write(file_path, f'{folder_name}/media/{file_path.name}')
                        found_count += 1
                    else:
                        logger.warning(f"[export] Media not found: {data_dir / media_type / media_path}")
                logger.info(f"[export] Packaged {found_count}/{len(media_paths)} media files")

            zip_buffer.seek(0)
            return send_file(
                zip_buffer,
                mimetype='application/zip',
                as_attachment=True,
                download_name=f'{folder_name}.zip'
            )

        except Exception as e:
            logger.error(f"[export] Package export failed: {e}")
            import traceback
            traceback.print_exc()
            return jsonify({'error': str(e)}), 500

    @app.route('/execute-option', methods=['POST'])
    def execute_option():
        """
        Execute the selected repair option.

        This endpoint:
        1. Prepares the execution plan for the selected task
        2. Generates executable code
        3. Executes on robot if available (Linux + AI2-THOR)

        Returns the execution plan, code, and execution status.
        """
        try:
            data = request.get_json()
            if not data:
                return jsonify({'error': 'No JSON data provided'}), 400

            selected_task = data.get('selected_task', '').strip()
            original_task = data.get('original_task', '').strip()
            scene = data.get('scene', '').strip()
            scene_objects = data.get('scene_objects', [])
            scene_mode = data.get('scene_mode', 'ai2thor')
            robot_type = data.get('robot_type', None)
            model = data.get('model', 'gpt-4o')
            floor_plan = data.get('floor_plan', 1)
            repair_constraints = data.get('repair_constraints', {})

            if not selected_task:
                return jsonify({'error': 'No task selected'}), 400

            # Determine strict mode
            strict_mode = scene_mode != 'hypothetical'

            logger.info(f"Executing option: '{selected_task[:50]}...' (mode={scene_mode}, model={model})")

            # Create LLM client
            from ctr.llm_client import create_client
            request_client = create_client(
                provider=get_provider_for_model(model),
                model=model
            )

            result = {
                'selected_task': selected_task,
                'original_task': original_task,
                'execution_plan': None,
                'code': None,
                'execution': None
            }

            # Read action sequence from request body (sent by frontend from repair option)
            action_sequence = data.get('action_sequence', [])
            required_skills = data.get('required_skills', [])
            expected_end_state = data.get('expected_end_state', '')

            result['execution_plan'] = {
                'execution_plan': action_sequence,
                'required_skills': required_skills,
                'expected_end_state': expected_end_state,
            }

            # Format action sequence as code
            if action_sequence:
                result['code'] = '\n'.join(action_sequence)
                logger.info(f"Using pre-generated action sequence: {len(action_sequence)} steps")
            else:
                # A4: Fallback warning — action_sequence missing, using legacy code generator
                logger.warning(
                    "[TR-Graph] No action_sequence provided for execution — falling back to CodeGenerator. "
                    "This may produce drift from schema-based generation."
                )
                try:
                    from ctr.simulation.code_generator import CodeGenerator
                    code_gen = CodeGenerator(request_client)
                    code = code_gen.generate(
                        task=selected_task,
                        scene_objects=scene_objects,
                        repair_constraints=repair_constraints
                    )
                    result['code'] = code
                    logger.info(f"Generated code via fallback: {len(code)} chars")
                except Exception as e:
                    logger.error(f"Code generation failed: {e}")
                    result['code'] = f"# No action sequence available"

            # Translate action sequence for target robot if needed
            if robot_type and robot_type not in ('ai2thor', 'safeagentbench') and result['code']:
                try:
                    from ctr.simulation.code_generator import CodeGenerator
                    translator = CodeGenerator.__new__(CodeGenerator)
                    translated, trans_valid, trans_errors = translator.translate_for_robot(
                        result['code'], robot_type
                    )
                    if trans_valid:
                        result['code'] = translated
                        logger.info(f"Translated action sequence to {robot_type} format")
                    else:
                        result['code'] = f"# Translation errors for {robot_type}:\n" + \
                            '\n'.join(f'# {e}' for e in trans_errors) + \
                            f"\n\n# Original (AI2-THOR):\n{result['code']}"
                        logger.warning(f"Action translation to {robot_type} had errors: {trans_errors}")
                except Exception as e:
                    logger.error(f"Action translation failed: {e}")

            # Step 3: Execute if on Linux with AI2-THOR
            import platform
            if platform.system() == 'Linux':
                try:
                    from ctr.simulation import TaskExecutor

                    executor = TaskExecutor(
                        use_ai2thor=True,
                        scene=f"FloorPlan{floor_plan}",
                        headless=False,
                        enable_video=True
                    )
                    execution_result = executor.execute_code(result['code'])

                    # Build video data 
                    video_data = None
                    video_info = execution_result.video_info
                    if video_info and video_info.get('output_folder'):
                        folder_path = Path(video_info['output_folder'])

                        # Extract GIF paths relative to data/videos directory
                        gif_paths = []
                        for gif_full_path in video_info.get('gifs', []):
                            gif_path_obj = Path(gif_full_path)
                            if gif_path_obj.exists():
                                try:
                                    rel_to_videos = gif_path_obj.relative_to(Path('data/videos'))
                                    gif_paths.append(str(rel_to_videos).replace('\\', '/'))
                                except ValueError:
                                    # If not under data/videos, use session_id/filename
                                    gif_paths.append(f"{video_info.get('session_id', '')}/{gif_path_obj.name}")

                        # Extract video paths relative to data/videos directory
                        video_paths = []
                        for vid_full_path in video_info.get('videos', []):
                            vid_path_obj = Path(vid_full_path)
                            if vid_path_obj.exists():
                                try:
                                    rel_to_videos = vid_path_obj.relative_to(Path('data/videos'))
                                    video_paths.append(str(rel_to_videos).replace('\\', '/'))
                                except ValueError:
                                    video_paths.append(f"{video_info.get('session_id', '')}/{vid_path_obj.name}")

                        video_data = {
                            'folder_path': str(folder_path),
                            'gifs': gif_paths,
                            'videos': video_paths,
                            'total_frames': video_info.get('total_frames', 0),
                            'duration': video_info.get('duration', 0),
                        }
                        logger.info(f"Video data: {len(gif_paths)} GIFs, {len(video_paths)} videos")

                    result['execution'] = {
                        'available': True,
                        'success': execution_result.success,
                        'message': execution_result.error or 'Execution completed',
                        'video': video_data
                    }
                    logger.info(f"Execution result: {execution_result.success}")

                    # Cleanup
                    executor.cleanup()

                except ImportError as e:
                    logger.error(f"Import error: {e}")
                    result['execution'] = {
                        'available': False,
                        'success': False,
                        'message': f'AI2-THOR import failed: {str(e)}. Install with: pip install ai2thor'
                    }
                except Exception as e:
                    logger.error(f"Execution failed: {e}")
                    result['execution'] = {
                        'available': True,
                        'success': False,
                        'message': f'Execution failed: {str(e)}'
                    }
            else:
                result['execution'] = {
                    'available': False,
                    'success': False,
                    'message': f'AI2-THOR simulation requires Linux. Current platform: {platform.system()}. '
                               'The generated code can be executed on a Linux machine with AI2-THOR installed.'
                }

            return jsonify(result)

        except Exception as e:
            logger.error(f"Execute option error: {e}")
            traceback.print_exc()
            return jsonify({'error': str(e)}), 500

    @app.route('/detect-objects', methods=['POST'])
    def detect_objects():
        """Detect objects in an uploaded image using VLM perception.

        Receives a base64-encoded image, runs the VLM perception pipeline,
        and returns detected objects with properties and spatial relationships.
        """
        try:
            data = request.get_json()
            if not data:
                return jsonify({'error': 'No JSON data provided'}), 400

            image_data = data.get('image', '')  # base64 string
            task_hint = data.get('task', '')     # optional task context
            model = data.get('model', 'gpt-4o')
            robot_type = data.get('robot_type', 'franka')

            if not image_data:
                return jsonify({'error': 'No image provided'}), 400

            # Strip data URL prefix if present (e.g., "data:image/jpeg;base64,...")
            if ',' in image_data:
                image_data = image_data.split(',', 1)[1]

            from ctr.llm_client import create_client
            from ctr.pipeline import CTRPipeline
            from ctr.prompts.enriched_prompts import get_robot_skills

            client = create_client(
                provider=get_provider_for_model(model),
                model=model
            )

            config = _interface_config(strict_mode=True)
            # Increase max_tokens for perception — scene descriptions with
            # many objects and properties need more output space than default 2000
            client.config.max_tokens = max(client.config.max_tokens, 8192)

            pipeline = CTRPipeline(client, config)
            if robot_type:
                pipeline._robot_mode = robot_type

            # Run VLM perception
            context = "countertop workspace" if robot_type == 'franka' else "indoor environment"
            scene_graph = pipeline._perceive_scene(
                image=image_data,
                context=context,
                task_description=task_hint or "Detect all objects in the scene"
            )

            # Cache the rich VLM scene graph for reuse during task processing.
            # This avoids rebuilding an impoverished graph from the flat object list.
            global _vlm_scene_graph_cache
            _vlm_scene_graph_cache = scene_graph
            from collections import Counter as _Counter
            _edge_counts = _Counter(e.relation.value if hasattr(e.relation, 'value') else str(e.relation) for e in scene_graph.edges)
            logger.info(f"[detect-objects] Cached VLM scene graph: {len(scene_graph.nodes)} nodes, {len(scene_graph.edges)} edges, types={dict(_edge_counts)}")

            # Extract objects and relationships from scene graph
            from ctr.data_structures import NodeType
            objects = []
            relationships = []

            for node_id, node in scene_graph.nodes.items():
                obj_info = {
                    'id': node_id,
                    'label': node.label,
                    'type': node.type.value if hasattr(node.type, 'value') else str(node.type),
                }
                # Add properties
                if hasattr(node, 'properties') and node.properties:
                    props = node.properties
                    if hasattr(props, 'temperature') and props.temperature:
                        obj_info['temperature'] = props.temperature
                    if hasattr(props, 'hazard_level') and props.hazard_level:
                        obj_info['hazard_level'] = props.hazard_level.value if hasattr(props.hazard_level, 'value') else str(props.hazard_level)
                    if hasattr(props, 'child_safe'):
                        obj_info['child_safe'] = props.child_safe
                objects.append(obj_info)

            for edge in scene_graph.edges:
                relationships.append({
                    'source': edge.source_id,
                    'target': edge.target_id,
                    'relation': edge.relation.value if hasattr(edge.relation, 'value') else str(edge.relation),
                })

            # Extract object labels and normalize to PascalCase
            object_labels = [
                _normalize_object_name(node.label)
                for node in scene_graph.nodes.values()
                if node.type == NodeType.OBJECT
            ]

            # Situation awareness
            situation = getattr(scene_graph, 'situation_description', '')
            projection = getattr(scene_graph, 'projected_outcome', '')

            logger.info(
                f"[detect-objects] Detected {len(object_labels)} objects, "
                f"{len(relationships)} relationships using {model}"
            )

            return jsonify({
                'success': True,
                'objects': object_labels,
                'object_details': objects,
                'relationships': relationships,
                'situation': situation,
                'projection': projection,
            })

        except Exception as e:
            logger.error(f"Object detection failed: {e}")
            import traceback
            traceback.print_exc()
            return jsonify({
                'success': False,
                'error': str(e),
                'objects': [],
            }), 500

    @app.route('/scene_objects')
    def get_scene_objects():
        """Get objects for a floor plan."""
        floor_plan = request.args.get('floor_plan', 1, type=int)

        # Try AI2-THOR first
        if ai2thor_controller:
            try:
                target_scene = f"FloorPlan{floor_plan}"
                current_scene = ai2thor_controller.last_event.metadata.get('sceneName', '')

                if current_scene != target_scene:
                    ai2thor_controller.reset(scene=target_scene)

                objects = ai2thor_controller.last_event.metadata['objects']
                object_types = sorted(list(set([obj['objectType'] for obj in objects])))

                return jsonify({
                    'objects': object_types,
                    'floor_plan': floor_plan,
                    'source': 'ai2thor'
                })
            except Exception as e:
                logger.warning(f"AI2-THOR query failed: {e}")

        # Fall back to cache or mock data
        cache_path = Path(__file__).parent.parent.parent / 'data' / 'scene_cache.json'
        if cache_path.exists():
            try:
                with open(cache_path) as f:
                    cache = json.load(f)
                    scene_key = f"floorplan_{floor_plan}"
                    if scene_key in cache:
                        return jsonify({
                            'objects': cache[scene_key].get('objects', []),
                            'floor_plan': floor_plan,
                            'source': 'cache'
                        })
            except Exception:
                pass

        # Mock data
        mock_objects = get_mock_scene_objects(floor_plan)
        return jsonify({
            'objects': mock_objects,
            'floor_plan': floor_plan,
            'source': 'mock'
        })

    @app.route('/ai2thor/status')
    def ai2thor_status():
        """Get AI2-THOR status."""
        if not ai2thor_controller:
            return jsonify({
                'connected': False,
                'error': 'AI2-THOR not available'
            })

        try:
            scene_info = ai2thor_controller.last_event.metadata
            return jsonify({
                'connected': True,
                'scene': scene_info.get('sceneName', 'Unknown'),
                'objects_count': len(scene_info.get('objects', []))
            })
        except Exception as e:
            return jsonify({
                'connected': False,
                'error': str(e)
            })

    @app.route('/execute', methods=['POST'])
    def execute_task():
        """Execute a task in AI2-THOR."""
        if not ai2thor_controller:
            return jsonify({
                'success': False,
                'error': 'AI2-THOR not available'
            }), 503

        try:
            data = request.get_json()
            code = data.get('code', '')
            floor_plan = data.get('floor_plan', 1)

            if not code:
                return jsonify({'error': 'No code provided'}), 400

            # Execute in AI2-THOR
            result = execute_in_ai2thor(code, floor_plan)
            return jsonify(result)

        except Exception as e:
            logger.error(f"Execution error: {e}")
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500

    @app.route('/static/screenshots/<filename>')
    def serve_screenshot(filename):
        """Serve screenshot files."""
        screenshot_dir = Path(__file__).parent.parent.parent / 'data' / 'screenshots'
        return send_from_directory(str(screenshot_dir), filename)

    @app.route('/static/videos/<path:filepath>')
    def serve_video(filepath):
        """Serve video files."""
        videos_dir = Path(__file__).parent.parent.parent / 'data' / 'videos'
        return send_from_directory(str(videos_dir), filepath)

    @app.errorhandler(404)
    def not_found(error):
        return jsonify({'error': 'Endpoint not found'}), 404

    @app.errorhandler(500)
    def internal_error(error):
        return jsonify({'error': 'Internal server error'}), 500

    return app



# PROCESSING FUNCTIONS


def process_baseline(client, task: str, scene: str, scene_objects: List[str], result: Dict) -> Dict:
    """Process task with baseline LLM repair."""
    stage_start = time.time()

    try:
        from ctr.baseline import BaselineLLMRepair

        repair = BaselineLLMRepair(client)
        repair_result = repair.repair(task, scene, scene_objects)

        result['processing_times']['repair'] = (time.time() - stage_start) * 1000

        result['stages']['repair'] = {
            'original_task': repair_result.original_task,
            'repaired_task': repair_result.repaired_task,
            'analysis': repair_result.analysis,
            'what_changed': repair_result.what_changed,
            'success': repair_result.success,
            'error': repair_result.error
        }

        # Determine if task was safe (no change needed)
        is_safe = repair_result.original_task.lower().strip() == repair_result.repaired_task.lower().strip()

        if is_safe:
            result['is_safe'] = True
            result['repair_performed'] = False
            result['repaired_task'] = repair_result.repaired_task
            result['explanation'] = repair_result.analysis
            result['final_status'] = 'SAFE'
        elif repair_result.repaired_task and repair_result.repaired_task.strip():
            result['is_safe'] = False
            result['repair_performed'] = True
            result['repaired_task'] = repair_result.repaired_task
            result['explanation'] = repair_result.analysis
            result['final_status'] = 'REPAIRED'
        else:
            # Flagged as unsafe but no alternative suggested
            result['is_safe'] = False
            result['repair_performed'] = False
            result['repaired_task'] = task
            result['explanation'] = repair_result.analysis
            result['final_status'] = 'INFEASIBLE'
            result['is_infeasible'] = True
            result['missing_references'] = []

        logger.info(f"CoT baseline completed: status={result['final_status']}")

    except Exception as e:
        logger.error(f"Baseline repair failed: {e}")
        result['stages']['repair'] = {
            'success': False,
            'error': str(e)
        }
        result['final_status'] = 'ERROR'
        result['error'] = str(e)

    return result


def process_benchmark_baseline(client, task: str, scene: str, scene_objects: List[str], result: Dict, baseline: str = 'safeplan', robot_type: str = None) -> Dict:
    """Process task with SafePlan or SELP-lite baseline."""
    stage_start = time.time()

    try:
        from ctr.benchmarks.baseline_runners import (
            _run_safeplan_single, _run_selp_lite_single, _infer_scene_type
        )
        from ctr.benchmarks.safeagentbench_loader import SafeAgentBenchTask

        # Build a minimal task object for the baseline runners
        # Use the full scene description as-is (provided by VLM or user)
        scene_type = scene if scene else 'unknown environment'
        mock_task = SafeAgentBenchTask(
            task_id=result.get('session_id', 'ui_task'),
            split='ui',
            index_in_split=0,
            instruction=task,
            scene_name=scene_type,
            is_hazardous=True,
        )

        model = client.model if hasattr(client, 'model') else 'gpt-4o'

        if baseline == 'safeplan':
            baseline_result = _run_safeplan_single(mock_task, model, scene_objects, scene_type)
        elif baseline == 'selp-lite':
            baseline_result = _run_selp_lite_single(mock_task, model, scene_objects, scene_type)
        else:
            raise ValueError(f"Unknown baseline: {baseline}")

        result['processing_times']['repair'] = (time.time() - stage_start) * 1000

        result['stages']['repair'] = {
            'original_task': task,
            'repaired_task': baseline_result.repaired_task or task,
            'analysis': baseline_result.error_message or '',
            'what_changed': baseline_result.operator_used or '',
            'success': baseline_result.final_status != 'ERROR',
            'method': baseline,
        }

        result['is_safe'] = baseline_result.tr_graph_safe
        result['repair_performed'] = baseline_result.repair_performed
        result['repaired_task'] = baseline_result.repaired_task or task
        result['explanation'] = baseline_result.error_message or ''
        result['final_status'] = baseline_result.final_status

        # Map INFEASIBLE/CLARIFY so the frontend displays them correctly
        if baseline_result.final_status == 'INFEASIBLE':
            result['is_infeasible'] = True
            result['missing_references'] = []
        elif baseline_result.final_status == 'CLARIFY':
            result['needs_clarification'] = True
            result['clarification_questions'] = [baseline_result.error_message or 'More information is needed.']

        if baseline == 'safeplan':
            result['stages']['repair']['method_detail'] = 'SafePlan three-layer deontic detection + naive LLM repair'
        elif baseline == 'selp-lite':
            result['stages']['repair']['method_detail'] = 'SELP-lite NL->LTL verification + feedback regeneration'

        logger.info(f"{baseline} completed: status={baseline_result.final_status}")

    except Exception as e:
        logger.error(f"{baseline} failed: {e}")
        import traceback
        traceback.print_exc()
        result['stages']['repair'] = {
            'success': False,
            'error': str(e)
        }
        result['final_status'] = 'ERROR'
        result['error'] = str(e)

    return result


def parse_objects_from_description(description: str) -> List[str]:
    """
    Parse object and person names from a natural language scene description.

    Handles descriptions like:
    - "A lab with scissors, clippers, a kitchen knife and Jean"
    - "Room contains: hammer, screwdriver, tape"
    - "Objects: knife, scissors. People: John, Mary"

    Returns:
        List of extracted entity names (objects and people)
    """
    import re

    if not description:
        return []

    entities = []

    # Common tool/object keywords to look for
    # IMPORTANT: Multi-word items must come FIRST to avoid partial matches
    # e.g., "kitchen knife" before "knife" so we don't match both
    known_objects = [
        # Multi-word tools first (more specific)
        'kitchen knife', 'box cutter', 'paper clipper',
        # Single-word tools
        'knife', 'scissors', 'clippers', 'clipper',
        'hammer', 'screwdriver', 'wrench', 'pliers', 'tape', 'paper', 'cardboard',
        'rope', 'saw', 'drill', 'axe', 'chisel', 'file', 'sandpaper',
        'bottle', 'cup', 'mug', 'plate', 'bowl', 'pan', 'pot', 'kettle',
        'chair', 'table', 'desk', 'shelf', 'cabinet', 'drawer',
        'pen', 'pencil', 'marker', 'eraser', 'ruler', 'stapler',
        'phone', 'laptop', 'computer', 'tablet', 'remote',
        'key', 'lock', 'door', 'window', 'lamp', 'light',
        'book', 'notebook', 'folder', 'binder', 'envelope',
        'bag', 'box', 'container', 'basket', 'bin',
        'towel', 'cloth', 'rag', 'sponge', 'brush',
        'medicine', 'pills', 'medication', 'bandage', 'thermometer',
        'cleaner', 'detergent', 'bleach', 'spray', 'chemical',
    ]

    # Track which parts of description have been matched to avoid duplicates
    # e.g., don't match "knife" if we already matched "kitchen knife"
    matched_spans = []

    # Check for known objects (case-insensitive)
    desc_lower = description.lower()
    for obj in known_objects:
        # Use word boundary matching to avoid partial matches
        pattern = r'\b' + re.escape(obj) + r'\b'
        match = re.search(pattern, desc_lower)
        if match:
            # Check if this span overlaps with an already-matched span
            start, end = match.start(), match.end()
            is_overlapping = any(
                not (end <= ms or start >= me)  # Not overlapping if completely before or after
                for ms, me in matched_spans
            )
            if not is_overlapping:
                entities.append(obj)
                matched_spans.append((start, end))

    # Extract items from list patterns like "with X, Y, and Z" or "contains: X, Y, Z"
    list_patterns = [
        r'(?:with|contains?|includes?|has|have|holding|featuring)[:\s]+([^.!?]+)',
        r'(?:objects?|items?|tools?|things?)[:\s]+([^.!?]+)',
    ]

    # Words to skip when cleaning up parsed items
    filler_words = ['is', 'are', 'was', 'were', 'be', 'with', 'has', 'have', 'lab', 'room', 'scene', 'area']

    for pattern in list_patterns:
        matches = re.findall(pattern, desc_lower, re.IGNORECASE)
        for match in matches:
            # Split the matched text on commas, "and", semicolons
            items = re.split(r'[,;]|\band\b', match)
            for item in items:
                item = item.strip()
                # Clean up articles and prepositions at start
                item = re.sub(r'^(?:a|an|the|some|with)\s+', '', item)
                # Remove trailing prepositions/conjunctions
                item = re.sub(r'\s+(?:to|for|from|in|on|at|with)$', '', item)
                # Remove leading filler words (like "lab with" -> "with" -> skip)
                item = re.sub(r'^(?:' + '|'.join(filler_words) + r')\s*', '', item)
                item = item.strip()

                # Check if already exists (case-insensitive)
                item_lower = item.lower()
                existing_lower = [e.lower() for e in entities]

                if item and len(item) > 1 and item_lower not in existing_lower:
                    # Skip if it's just a number or common word
                    if not re.match(r'^[\d\s]+$', item) and item_lower not in filler_words:
                        entities.append(item)

    # Extract capitalized names (likely people) - e.g., "Jean", "Mary", "Dr. Smith"
    # Look for capitalized words that follow commas, "and", or whitespace
    # Use multiple fixed-width patterns since lookbehind requires fixed width
    name_patterns = [
        r'(?<=,\s)([A-Z][a-z]+)',           # After comma+space: ", Jean"
        r'(?<=\sand\s)([A-Z][a-z]+)',       # After " and ": " and Jean"
        r'(?<=\s)([A-Z][a-z]+)(?=\s|$|[,.])', # Capitalized word mid-sentence
    ]
    skip_words = ['The', 'A', 'An', 'This', 'That', 'Room', 'Lab', 'Area', 'Scene', 'Objects', 'Items',
                  'With', 'Contains', 'Has', 'Have', 'Is', 'Are', 'And', 'Or', 'For', 'To', 'In', 'On']

    for pattern in name_patterns:
        name_matches = re.findall(pattern, description)
        for name in name_matches:
            name = name.strip()
            name_lower = name.lower()
            existing_lower = [e.lower() for e in entities]
            if name and name not in skip_words and name_lower not in existing_lower:
                entities.append(name)

    # Also check for teacher/student/worker patterns with names
    role_patterns = [
        r'(?:teacher|professor|dr\.?|mr\.?|mrs\.?|ms\.?)\s+([A-Z][a-z]+)',
        r'([A-Z][a-z]+)(?:\s+the\s+)?(?:teacher|student|worker|assistant)',
    ]
    for pattern in role_patterns:
        matches = re.findall(pattern, description, re.IGNORECASE)
        for match in matches:
            match_lower = match.lower()
            existing_lower = [e.lower() for e in entities]
            if match and match_lower not in existing_lower:
                entities.append(match)

    return entities


def _normalize_object_name(name: str) -> str:
    """Normalize an object name to PascalCase for consistent matching.

    Converts natural language object names (from VLM detection or manual input)
    to the same PascalCase convention AI2-THOR uses, so the grounding, generation,
    and plan linting stages all work with one naming convention.

    Examples:
        "water bottle"    -> "WaterBottle"
        "red plate"       -> "RedPlate"
        "bag of fruits"   -> "BagOfFruits"
        "loaf of bread"   -> "LoafOfBread"
        "remote control"  -> "RemoteControl"
        "Apple"           -> "Apple" (already PascalCase)
        "CounterTop"      -> "CounterTop" (already PascalCase)
    """
    name = name.strip()
    if not name:
        return name

    # Already PascalCase (AI2-THOR style) — leave as-is
    if name[0].isupper() and ' ' not in name and '_' not in name:
        return name

    # Convert: split on spaces/underscores/hyphens, title-case each word, join
    import re as _re
    words = _re.split(r'[\s_\-]+', name)
    return ''.join(w.capitalize() for w in words if w)


def create_scene_graph_from_objects(scene_objects: List[str], scene_description: str = "", task: str = "", floor_plan: int = 0) -> Any:
    """Create a scene graph from object names and task description.

    This allows the TR-Graph pipeline to work in text-only mode by creating
    a scene graph from the user-provided scene objects list and extracting
    people mentioned in the task. If scene_objects is empty but scene_description
    is provided, objects will be extracted from the description text.

    For real-robot tabletop sessions (robot_type == "franka" or camera mode),
    uses TabletopSceneAdapter. For AI2-THOR mode, uses GenericObjectListAdapter.
    """
    from ctr.scene_graph_builder import SceneGraphBuilder
    from ctr.scene_adapters import GenericObjectListAdapter, TabletopSceneAdapter

    effective_objects = list(scene_objects) if scene_objects else []
    if not effective_objects and scene_description:
        parsed_entities = parse_objects_from_description(scene_description)
        effective_objects = parsed_entities
        logger.info(f"Parsed {len(parsed_entities)} entities from scene description: {parsed_entities}")

    # Normalize object names to PascalCase (same convention as AI2-THOR)
    effective_objects = [_normalize_object_name(obj) for obj in effective_objects]

    # Choose adapter based on context (caller can override for franka/camera)
    builder = SceneGraphBuilder(adapter=GenericObjectListAdapter())
    return builder.build_from_object_list(
        effective_objects,
        floor_plan=floor_plan,
        task=task,
    )


def _extract_diagnosis_fields(pipeline_result) -> Dict:
    """Extract diagnosis fields from a pipeline result for frontend serialization.

    Returns a dict with defect_type, hazard_type, hazard_severity,
    hazard_probability, and causal_edges.  All values are None-safe.
    """
    diagnosis = None
    if pipeline_result.safety_result:
        try:
            from ctr.safety_evaluation import extract_diagnosis
            diagnosis = extract_diagnosis(pipeline_result.safety_result)
        except Exception:
            pass

    if diagnosis is None:
        return {
            'defect_type': None,
            'hazard_type': None,
            'hazard_severity': None,
            'hazard_probability': None,
            'causal_edges': [],
        }

    dt = getattr(diagnosis, 'defect_type', None)
    ht = getattr(diagnosis, 'hazard_type', None)
    edges = getattr(diagnosis, 'causal_edges', None) or []

    return {
        'defect_type': dt.value if dt is not None else None,
        'hazard_type': ht.value if ht is not None else None,
        'hazard_severity': getattr(diagnosis, 'hazard_severity', None),
        'hazard_probability': getattr(diagnosis, 'hazard_probability', None),
        'causal_edges': [
            {
                'from': getattr(edge, 'source', None),
                'to': getattr(edge, 'target', None),
                'relationship': getattr(edge, 'relationship', ''),
            }
            for edge in edges
        ],
    }


def _build_intervention_trace(pipeline_result) -> Dict[str, Any]:
    """Build an explicit trace of which causal variables were intervened on
    during the repair, and which causal edges those interventions target.

    This enriches the session log with auditable counterfactual reasoning:
    for each attribute that differs between the original and repaired task,
    we record the change and cross-reference it with the causal edges from
    the safety diagnosis, so a reviewer can see exactly which causal path
    was severed by which intervention.

    Returns a dict with:
      - variables_changed: list of {variable, original_value, repaired_value, operator}
      - targeted_causal_edges: list of causal edges that involve any changed variable
    """
    trace: Dict[str, Any] = {
        'variables_changed': [],
        'targeted_causal_edges': [],
    }

    try:
        original = pipeline_result.original_task if hasattr(pipeline_result, 'original_task') else None
        repaired = pipeline_result.final_task if hasattr(pipeline_result, 'final_task') else None

        # Fall back to selected_repair.repaired_task
        if repaired is None and hasattr(pipeline_result, 'selected_repair') and pipeline_result.selected_repair:
            repaired = getattr(pipeline_result.selected_repair, 'repaired_task', None)

        if not original or not repaired:
            return trace

        # Compare task variable attributes
        compare_attrs = ['goal', 'action', 'manner', 'recipient']
        for attr in compare_attrs:
            orig_val = getattr(original, attr, None)
            rep_val = getattr(repaired, attr, None)

            # Normalize to strings for comparison
            orig_str = ''
            rep_str = ''
            if orig_val:
                orig_str = orig_val.reference_text if hasattr(orig_val, 'reference_text') else str(orig_val)
            if rep_val:
                rep_str = rep_val.reference_text if hasattr(rep_val, 'reference_text') else str(rep_val)

            if orig_str and rep_str and orig_str.lower().strip() != rep_str.lower().strip():
                trace['variables_changed'].append({
                    'variable': attr,
                    'original_value': orig_str,
                    'repaired_value': rep_str,
                })

        # Compare objects lists
        orig_objs = [o.reference_text for o in (getattr(original, 'objects', []) or []) if o.reference_text]
        rep_objs = [o.reference_text for o in (getattr(repaired, 'objects', []) or []) if o.reference_text]
        if orig_objs != rep_objs:
            trace['variables_changed'].append({
                'variable': 'objects',
                'original_value': ', '.join(orig_objs) if orig_objs else '(none)',
                'repaired_value': ', '.join(rep_objs) if rep_objs else '(none)',
            })

        # Determine operator for each change (if available)
        operator_used = 'AUTO'
        if hasattr(pipeline_result, 'selected_repair') and pipeline_result.selected_repair:
            sr = pipeline_result.selected_repair
            if hasattr(sr, 'operators_applied') and sr.operators_applied:
                ops = [op.operator_type.value if hasattr(op.operator_type, 'value') else str(op.operator_type)
                       for op in sr.operators_applied]
                operator_used = ', '.join(ops) if ops else 'AUTO'
            elif hasattr(sr, 'operator') and sr.operator:
                operator_used = sr.operator.value if hasattr(sr.operator, 'value') else str(sr.operator)
        for entry in trace['variables_changed']:
            entry['operator'] = operator_used

        # Cross-reference changed variables with causal edges from the diagnosis
        if trace['variables_changed']:
            diag_fields = _extract_diagnosis_fields(pipeline_result)
            causal_edges = diag_fields.get('causal_edges', [])

            # Build a set of changed variable keywords for fuzzy matching
            changed_keywords = set()
            for entry in trace['variables_changed']:
                for val in [entry.get('original_value', ''), entry.get('repaired_value', '')]:
                    for word in str(val).lower().replace(',', ' ').split():
                        if len(word) > 2:  # skip tiny words
                            changed_keywords.add(word)
                # Also add the variable name itself (e.g., "action", "objects")
                changed_keywords.add(entry['variable'].lower())

            for edge in causal_edges:
                edge_from = str(edge.get('from', '')).lower()
                edge_to = str(edge.get('to', '')).lower()
                edge_rel = str(edge.get('relationship', '')).lower()
                edge_text = f"{edge_from} {edge_to} {edge_rel}"

                # Check if any changed variable keyword appears in the edge
                if any(kw in edge_text for kw in changed_keywords):
                    trace['targeted_causal_edges'].append(edge)

    except Exception as e:
        logger.debug(f"_build_intervention_trace: {e}")

    return trace


def process_ctr(client, task: str, scene: str, scene_objects: List[str], scene_mode: str, result: Dict, floor_plan: int = 1, robot_type: str = None) -> Dict:
    """Process task with TR-Graph pipeline.

    Args:
        client: LLM client
        task: Task description
        scene: Scene description text
        scene_objects: List of objects in the scene
        scene_mode: Scene source mode ('ai2thor', 'object_list', 'camera', 'hypothetical')
        result: Result dict to populate
        floor_plan: AI2-THOR floor plan number for region inference
        robot_type: Robot type for skill-aware prompts (franka, spot, etc.)
    """
    try:
        from ctr.pipeline import CTRPipeline, CTRConfig

        # Determine if we're in strict mode (no hypotheticals allowed)
        strict_mode = scene_mode != 'hypothetical'

        config = _interface_config(strict_mode=strict_mode)
        pipeline = CTRPipeline(client, config)

        # Set robot mode for skill-aware prompts
        if robot_type:
            pipeline._robot_mode = robot_type

        # Create scene graph from provided objects and task (enables text-only mode)
        # Pass the task to extract people mentioned in it (e.g., "my 2-year-old daughter")
        # In strict mode with no objects, we still create minimal scene but grounding will fail
        effective_objects = list(scene_objects) if scene_objects else []

        if scene_objects:
            scene_graph = create_scene_graph_from_objects(scene_objects, scene, task, floor_plan=floor_plan)
        elif scene_mode == 'hypothetical':
            # Hypothetical mode: parse objects from scene description text
            parsed_objects = parse_objects_from_description(scene)
            effective_objects = parsed_objects
            scene_graph = create_scene_graph_from_objects([], scene, task, floor_plan=floor_plan)
            logger.info(f"Hypothetical mode: parsed {len(parsed_objects)} objects from scene description")
        else:
            # Strict mode with no objects - will fail during grounding
            scene_graph = None

        # Process through pipeline with scene mode context
        stage_start = time.time()
        pipeline_result = pipeline.process(
            task,
            scene_graph=scene_graph,
            context=scene,
            strict_mode=strict_mode,
            available_objects=effective_objects
        )
        result['processing_times']['pipeline'] = (time.time() - stage_start) * 1000

        # Extract results
        result['is_safe'] = pipeline_result.is_original_safe
        result['repair_performed'] = pipeline_result.repair_performed
        result['explanation'] = pipeline_result.explanation

        # Safety evaluation stage - extract detailed info
        # NOTE: Use safety-specific explanation, NOT pipeline_result.explanation
        # (which may be the repair explanation, not the safety analysis)
        safety_explanation = ""
        if pipeline_result.safety_result:
            sr = pipeline_result.safety_result
            # Collect layer explanations as the safety explanation
            layer_explanations = []
            for layer_name in ['societal', 'organizational', 'individual']:
                layer = getattr(sr, layer_name, None)
                if layer and hasattr(layer, 'explanation') and layer.explanation:
                    layer_explanations.append(layer.explanation)
            safety_explanation = ' '.join(layer_explanations) if layer_explanations else pipeline_result.explanation

        safety_details = {
            'passed': pipeline_result.is_original_safe,
            'explanation': safety_explanation
        }

        # Extract detailed safety information if available
        if pipeline_result.safety_result:
            sr = pipeline_result.safety_result
            safety_details['layers'] = {
                'societal': {
                    'decision': sr.societal.decision.value if hasattr(sr.societal, 'decision') else 'unknown',
                    'triggered_conditions': sr.societal.triggered_conditions if hasattr(sr.societal, 'triggered_conditions') else [],
                    'explanation': sr.societal.explanation if hasattr(sr.societal, 'explanation') else ''
                },
                'organizational': {
                    'decision': sr.organizational.decision.value if hasattr(sr.organizational, 'decision') else 'unknown',
                    'triggered_conditions': sr.organizational.triggered_conditions if hasattr(sr.organizational, 'triggered_conditions') else [],
                    'explanation': sr.organizational.explanation if hasattr(sr.organizational, 'explanation') else ''
                },
                'individual': {
                    'decision': sr.individual.decision.value if hasattr(sr.individual, 'decision') else 'unknown',
                    'triggered_conditions': sr.individual.triggered_conditions if hasattr(sr.individual, 'triggered_conditions') else [],
                    'explanation': sr.individual.explanation if hasattr(sr.individual, 'explanation') else ''
                }
            }
            safety_details['causal_variables'] = sr.all_causal_variables if hasattr(sr, 'all_causal_variables') else []
            safety_details['hazards'] = []

            # Extract hazard descriptions from each layer's explanation
            # Filter out meaningless triggered conditions (Roman numerals from prompt)
            meaningless_conditions = {'i', 'ii', 'iii', 'iv', 'v', 'vi', 'vii', 'viii', 'ix', 'x', ''}

            for layer_name in ['societal', 'organizational', 'individual']:
                layer = getattr(sr, layer_name, None)
                if layer:
                    if hasattr(layer, 'explanation') and layer.explanation:
                        safety_details['hazards'].append(layer.explanation)
                    if hasattr(layer, 'triggered_conditions'):
                        for condition in (layer.triggered_conditions or []):
                            cond_str = str(condition).strip().lower()
                            # Only include meaningful conditions (not Roman numerals)
                            if cond_str not in meaningless_conditions and len(cond_str) > 3:
                                safety_details['hazards'].append(str(condition))

        # Add reasoning trace from safety evaluation
        if hasattr(sr, 'reasoning_trace') and sr.reasoning_trace:
            safety_details['reasoning_trace'] = sr.reasoning_trace

        # Add diagnosis fields to safety stage
        diag_fields = _extract_diagnosis_fields(pipeline_result)
        safety_details.update(diag_fields)

        result['stages']['safety'] = safety_details

        # Grounding stage — always surface when available, regardless of repair outcome.
        # This lets researchers see reference resolution even for cases where the safety
        # evaluator rejected the task and no repair was accepted.
        if hasattr(pipeline_result, 'trace') and pipeline_result.trace and 'grounding' in pipeline_result.trace:
            g_trace_nc = pipeline_result.trace['grounding']
            result['stages']['grounding'] = {
                'fully_grounded': g_trace_nc.get('fully_grounded'),
                'confidence': g_trace_nc.get('confidence'),
                'per_ref': g_trace_nc.get('per_ref', []),
                'infeasible': g_trace_nc.get('infeasible', []),
            }
            if 'embedding_validation' in g_trace_nc:
                result['stages']['grounding']['embedding_validation'] = g_trace_nc['embedding_validation']

        # If repair was performed, add repair details
        if pipeline_result.repair_performed:
            # Extract repaired task string - prefer specific task from selected repair
            repaired_task_str = ''

            # First, try to get the specific repaired task from selected_repair
            if pipeline_result.selected_repair:
                sr = pipeline_result.selected_repair
                # Try task_text first (most specific)
                if hasattr(sr, 'task_text') and sr.task_text:
                    repaired_task_str = sr.task_text
                # Then try repaired_task.goal
                elif hasattr(sr, 'repaired_task') and sr.repaired_task:
                    rt = sr.repaired_task
                    if hasattr(rt, 'goal') and rt.goal:
                        repaired_task_str = rt.goal
                    elif hasattr(rt, 'original_utterance') and rt.original_utterance:
                        repaired_task_str = rt.original_utterance
                # Then try task_variables
                elif hasattr(sr, 'task_variables') and sr.task_variables:
                    tv = sr.task_variables
                    if hasattr(tv, 'goal') and tv.goal:
                        repaired_task_str = tv.goal

            # Fallback to final_task if selected_repair didn't have specific task
            if not repaired_task_str and pipeline_result.final_task:
                if hasattr(pipeline_result.final_task, 'goal'):
                    repaired_task_str = pipeline_result.final_task.goal or ''
                elif hasattr(pipeline_result.final_task, 'original_utterance'):
                    repaired_task_str = pipeline_result.final_task.original_utterance or ''
                else:
                    repaired_task_str = str(pipeline_result.final_task)

            # Extract operator from selected_repair (new diagnosis-guided approach)
            operator_used = 'AUTO'
            operators_applied = []

            if pipeline_result.selected_repair:
                # New approach: operators_applied from ValidatedRepair
                if hasattr(pipeline_result.selected_repair, 'operators_applied'):
                    for op_cls in pipeline_result.selected_repair.operators_applied:
                        op_name = op_cls.operator_type.value if hasattr(op_cls.operator_type, 'value') else str(op_cls.operator_type)
                        operators_applied.append({
                            'operator': op_name,
                            'confidence': op_cls.confidence,
                            'evidence': op_cls.evidence if hasattr(op_cls, 'evidence') else ''
                        })
                    if operators_applied:
                        operator_used = ', '.join([op['operator'] for op in operators_applied])

                # Fallback to old approach
                elif hasattr(pipeline_result.selected_repair, 'operator'):
                    op = pipeline_result.selected_repair.operator
                    operator_used = op.value if hasattr(op, 'value') else str(op)
                elif hasattr(pipeline_result.selected_repair, 'intervention_history'):
                    interventions = pipeline_result.selected_repair.intervention_history
                    if interventions and len(interventions) > 0:
                        op = interventions[0].operator
                        operator_used = op.value if hasattr(op, 'value') else str(op)

            # Get affinity and cost scores
            affinity_val = pipeline_result.repair_affinity
            if affinity_val is None and pipeline_result.selected_repair:
                affinity_val = getattr(pipeline_result.selected_repair, 'affinity_score', None)
            if affinity_val is None:
                affinity_val = 0.0

            cost_val = pipeline_result.repair_cost
            if cost_val is None and pipeline_result.selected_repair:
                cost_val = getattr(pipeline_result.selected_repair, 'cost_score', None)
            if cost_val is None:
                cost_val = 0.25  # Default

            # Extract diagnosis info from trace if available
            diagnosis_info = {}
            if hasattr(pipeline_result, 'trace') and pipeline_result.trace:
                trace = pipeline_result.trace
                if 'repair' in trace:
                    repair_trace = trace['repair']
                    diagnosis_info = {
                        'approach': repair_trace.get('approach', 'search'),
                        'causal_variables': repair_trace.get('causal_variables', []),
                        'max_hazard': repair_trace.get('max_hazard', 0),
                        'candidates_generated': repair_trace.get('candidates_generated', 0),
                        'candidates_validated': repair_trace.get('candidates_validated', 0),
                        'lambda': repair_trace.get('lambda', 0.5)
                    }
                # (Grounding stage is now recorded unconditionally above, before
                # the repair_performed block.)

            # Add full diagnosis data to diagnosis_info
            diag_fields = _extract_diagnosis_fields(pipeline_result)
            diagnosis_info.update(diag_fields)

            # Build intervention trace: which causal variables were changed and which
            # causal edges they target. Makes the counterfactual reasoning auditable.
            intervention_trace = _build_intervention_trace(pipeline_result)

            result['stages']['repair'] = {
                'original_task': task,
                'repaired_task': repaired_task_str,
                'repair_options': [],
                'operator_used': operator_used,
                'operators_applied': operators_applied,
                'cost': cost_val,
                'affinity': affinity_val,
                'analysis': pipeline_result.explanation or '',
                'what_changed': f"Replaced unsafe task with safe alternative using {operator_used} operator",
                'diagnosis': diagnosis_info,
                'intervention_trace': intervention_trace,
            }

            # Add repair options if available
            if hasattr(pipeline_result, 'repair_options') and pipeline_result.repair_options:
                for i, opt in enumerate(pipeline_result.repair_options[:2]):
                    # Extract task from repair option
                    opt_task = ''
                    opt_desc = ''
                    opt_rationale = ''
                    opt_operators = []

                    if hasattr(opt, 'brief_description'):
                        opt_task = opt.brief_description
                    if hasattr(opt, 'safety_rationale'):
                        opt_rationale = opt.safety_rationale

                    if hasattr(opt, 'repair_candidate') and opt.repair_candidate:
                        candidate = opt.repair_candidate

                        # New approach: ValidatedRepair with repaired_task
                        if hasattr(candidate, 'repaired_task') and candidate.repaired_task:
                            rt = candidate.repaired_task
                            if hasattr(rt, 'goal'):
                                opt_task = rt.goal
                            elif hasattr(rt, 'original_utterance'):
                                opt_task = rt.original_utterance

                            # Extract operator info from ValidatedRepair
                            if hasattr(candidate, 'operators_applied'):
                                for op_cls in candidate.operators_applied:
                                    op_name = op_cls.operator_type.value if hasattr(op_cls.operator_type, 'value') else str(op_cls.operator_type)
                                    opt_operators.append(op_name)

                        # Old approach: task attribute
                        elif hasattr(candidate, 'task') and candidate.task:
                            if hasattr(candidate.task, 'goal'):
                                opt_task = candidate.task.goal
                            elif hasattr(candidate.task, 'original_utterance'):
                                opt_task = candidate.task.original_utterance
                            else:
                                opt_task = str(candidate.task)

                    if not opt_task:
                        opt_task = str(opt)

                    # Get per-option scores from the repair candidate
                    opt_cost = 0.0
                    opt_affinity = 0.0
                    opt_operator_used = ', '.join(opt_operators) if opt_operators else 'AUTO'
                    if hasattr(opt, 'repair_candidate') and opt.repair_candidate:
                        cand = opt.repair_candidate
                        if hasattr(cand, 'cost_score'):
                            opt_cost = cand.cost_score
                        if hasattr(cand, 'affinity_score'):
                            opt_affinity = cand.affinity_score

                    result['stages']['repair']['repair_options'].append({
                        'label': f"Option {chr(65 + i)}",
                        'task': opt_task,
                        'description': opt_desc,
                        'rationale': opt_rationale,
                        'operators': opt_operators,
                        'cost': opt_cost,
                        'affinity': opt_affinity,
                        'operator_used': opt_operator_used
                    })

            # If no repair options found, create from repaired task
            if not result['stages']['repair']['repair_options'] and repaired_task_str:
                result['stages']['repair']['repair_options'].append({
                    'label': 'Option A',
                    'task': repaired_task_str,
                    'description': 'Primary safe alternative',
                    'rationale': pipeline_result.explanation or 'Ensures task safety'
                })

            # Case study data: rejected candidates, scoring breakdown,
            # action sequence, causal graph — for qualitative analysis
            if hasattr(pipeline_result, 'rejected_candidates') and pipeline_result.rejected_candidates:
                result['stages']['repair']['rejected_candidates'] = pipeline_result.rejected_candidates

            if hasattr(pipeline_result, 'action_sequence') and pipeline_result.action_sequence:
                result['stages']['repair']['action_sequence'] = pipeline_result.action_sequence

            if hasattr(pipeline_result, 'trace') and pipeline_result.trace:
                trace = pipeline_result.trace
                # Per-dimension affinity breakdown
                scoring = trace.get('repair', {}).get('scoring', {})
                if scoring:
                    result['stages']['repair']['scoring_breakdown'] = {
                        'affinity': scoring.get('affinity'),
                        'cost': scoring.get('cost'),
                        'final_score': scoring.get('final_score'),
                        'consistency_penalty': scoring.get('consistency_penalty'),
                        'lambda': scoring.get('lambda'),
                        'affinity_dimensions': scoring.get('affinity_dimensions', {}),
                        'affinity_weights': scoring.get('affinity_weights', {}),
                    }

                # Causal graph
                repair_trace = trace.get('repair', {})
                if repair_trace.get('causal_graph'):
                    result['stages']['repair']['causal_graph'] = repair_trace['causal_graph']

                # Cross-attempt feedback info
                if repair_trace.get('cross_attempt_feedback'):
                    result['stages']['repair']['cross_attempt_feedback'] = repair_trace['cross_attempt_feedback']

            result['repaired_task'] = repaired_task_str
            result['final_status'] = 'REPAIRED'
        else:
            result['final_status'] = 'SAFE'

        logger.info(f"TR-Graph processing completed: safe={result['is_safe']}, repaired={result['repair_performed']}")

        # Full pipeline trace for reviewer inspection
        if hasattr(pipeline_result, 'trace') and pipeline_result.trace:
            result['full_trace'] = {
                'perception': pipeline_result.trace.get('perception', {}),
                'parsing': pipeline_result.trace.get('parsing', {}),
                'skill_check': pipeline_result.trace.get('skill_check', {}),
                'grounding': pipeline_result.trace.get('grounding', {}),
                'safety': pipeline_result.trace.get('safety', {}),
                'routing': pipeline_result.trace.get('routing', {}),
                'repair': pipeline_result.trace.get('repair', {}),
                'repair_options': pipeline_result.trace.get('repair_options', {}),
                'explanation': pipeline_result.trace.get('explanation', {}),
                'rejected_candidates': pipeline_result.trace.get('rejected_candidates', []),
                'timing': pipeline_result.trace.get('timing', {}),
            }

    except Exception as e:
        logger.error(f"TR-Graph processing failed: {e}")
        traceback.print_exc()

        # Do NOT fall back to baseline silently - report the error to user
        result['stages']['ctr_error'] = {
            'error': str(e),
            'message': 'TR-Graph pipeline failed. Please check server logs for details.'
        }
        result['final_status'] = 'ERROR'
        result['error'] = f'TR-Graph processing failed: {str(e)}'
        result['is_safe'] = False
        result['repair_performed'] = False

    return result


def execute_in_ai2thor(code: str, floor_plan: int) -> Dict:
    """Execute code in AI2-THOR simulation."""
    if not ai2thor_controller:
        return {'success': False, 'error': 'AI2-THOR not available'}

    try:
        from ctr.simulation import AI2THORActionExecutor

        # Reset to floor plan
        ai2thor_controller.reset(scene=f"FloorPlan{floor_plan}")

        # Create executor
        session_id = str(uuid.uuid4())[:8]
        executor = AI2THORActionExecutor(ai2thor_controller, enable_video=True, session_id=session_id)

        # Re-initialize video camera after scene reset
        if executor.video_recorder:
            executor.video_recorder.notify_scene_reset()
            executor.video_recorder.setup_camera_after_scene_load(
                ai2thor_controller.last_event
            )

        # Parse and execute actions
        action_lines = [line.strip() for line in code.strip().split('\n') if line.strip() and not line.strip().startswith('#')]

        actions = []
        for line in action_lines:
            if '(' in line and ')' in line:
                action = line.split('#')[0].strip()
                if action:
                    actions.append(action)

        if not actions:
            return {'success': False, 'error': 'No valid actions found'}

        execution_result = executor.execute_action_sequence(actions)

        # Save screenshot
        screenshot_path = save_screenshot()

        return {
            'success': execution_result.get('success', False),
            'executed_actions': execution_result.get('executed_actions', []),
            'total_actions': len(actions),
            'screenshot': screenshot_path,
            'video': execution_result.get('video'),
            'error': execution_result.get('error')
        }

    except Exception as e:
        logger.error(f"AI2-THOR execution failed: {e}")
        return {'success': False, 'error': str(e)}



# HELPER FUNCTIONS

def get_provider_for_model(model: str) -> str:
    """Get provider name for a model."""
    if model.startswith('gpt'):
        return 'openai'
    elif model.startswith('claude'):
        return 'anthropic'
    elif model.startswith('gemini'):
        return 'google'
    else:
        return 'openai'  # default


def get_mock_scene_objects(floor_plan: int) -> List[str]:
    """Get mock scene objects for testing."""
    kitchen_objects = [
        'Apple', 'Bottle', 'Bowl', 'Bread', 'Cabinet', 'CoffeeMachine',
        'CounterTop', 'Cup', 'Fridge', 'Knife', 'Microwave', 'Mug',
        'Pan', 'Plate', 'Sink', 'SoapBottle', 'Spoon', 'Stove', 'Toaster'
    ]

    living_room_objects = [
        'ArmChair', 'Book', 'CoffeeTable', 'FloorLamp', 'Laptop',
        'Painting', 'Pillow', 'RemoteControl', 'Sofa', 'Television'
    ]

    bedroom_objects = [
        'Bed', 'Book', 'Desk', 'DeskLamp', 'Dresser', 'Mirror',
        'Painting', 'Pillow', 'AlarmClock'
    ]

    bathroom_objects = [
        'Bathtub', 'Cabinet', 'Faucet', 'Mirror', 'Sink',
        'SoapBar', 'Toilet', 'Towel', 'ToiletPaper'
    ]

    if floor_plan <= 30:
        return kitchen_objects
    elif floor_plan <= 230:
        return living_room_objects
    elif floor_plan <= 330:
        return bedroom_objects
    else:
        return bathroom_objects


def save_screenshot() -> Optional[str]:
    """Save current AI2-THOR frame as screenshot."""
    if not ai2thor_controller:
        return None

    try:
        from PIL import Image

        screenshot_dir = Path(__file__).parent.parent.parent / 'data' / 'screenshots'
        screenshot_dir.mkdir(parents=True, exist_ok=True)

        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S_%f')[:-3]
        filename = f'ctr_{timestamp}.png'
        filepath = screenshot_dir / filename

        frame = ai2thor_controller.last_event.frame
        img = Image.fromarray(frame)
        img.save(filepath, 'PNG')

        return filename

    except Exception as e:
        logger.error(f"Screenshot failed: {e}")
        return None


def build_streaming_final_result(
    pipeline_result,
    session_id: str,
    timestamp: str,
    task: str,
    scene: str,
    scene_objects: List[str],
    mode: str,
    model: str,
    floor_plan: int
) -> Dict:
    """
    Build the final result dict from a PipelineResult.

    This extracts all the relevant information for the frontend
    in the same format as the non-streaming endpoint.
    """
    result = {
        'session_id': session_id,
        'timestamp': timestamp,
        'task': task,
        'scene': scene,
        'scene_objects': scene_objects,
        'mode': mode,
        'model': model,
        'floor_plan': floor_plan,
        'stages': {},
        'processing_times': {
            'pipeline': pipeline_result.processing_time_ms
        },
        'total_time_ms': pipeline_result.processing_time_ms
    }

    result['is_safe'] = pipeline_result.is_original_safe
    result['repair_performed'] = pipeline_result.repair_performed
    result['explanation'] = pipeline_result.explanation

    # Surface task_id for trace/export linking
    if hasattr(pipeline_result, 'task_id') and pipeline_result.task_id:
        result['task_id'] = pipeline_result.task_id

    # Handle grounding-level outcomes (fast feedback — no safety eval ran)
    if getattr(pipeline_result, 'needs_clarification', False):
        result['needs_clarification'] = True
        result['clarification_questions'] = getattr(pipeline_result, 'clarification_questions', [])
        result['clarification_references'] = getattr(pipeline_result, 'clarification_references', [])
        result['stages']['grounding'] = {
            'outcome': 'clarify',
            'questions': result['clarification_questions'],
            'explanation': pipeline_result.explanation
        }
        return result

    if getattr(pipeline_result, 'is_infeasible', False) and not pipeline_result.repair_performed:
        result['is_infeasible'] = True
        result['missing_references'] = getattr(pipeline_result, 'missing_references', [])
        result['stages']['grounding'] = {
            'outcome': 'infeasible',
            'missing': result['missing_references'],
            'explanation': pipeline_result.explanation
        }
        return result

    # Safety evaluation stage
    if pipeline_result.safety_result:
        sr = pipeline_result.safety_result
        # Build safety-specific explanation from layer explanations (not repair explanation)
        layer_exps = []
        for ln in ['societal', 'organizational', 'individual']:
            lyr = getattr(sr, ln, None)
            if lyr and hasattr(lyr, 'explanation') and lyr.explanation:
                layer_exps.append(lyr.explanation)
        safety_explanation_2 = ' '.join(layer_exps) if layer_exps else pipeline_result.explanation

        safety_details = {
            'passed': pipeline_result.is_original_safe,
            'explanation': safety_explanation_2,
            'layers': {
                'societal': {
                    'decision': sr.societal.decision.value if hasattr(sr.societal, 'decision') else 'unknown',
                    'triggered_conditions': sr.societal.triggered_conditions if hasattr(sr.societal, 'triggered_conditions') else [],
                    'explanation': sr.societal.explanation if hasattr(sr.societal, 'explanation') else ''
                },
                'organizational': {
                    'decision': sr.organizational.decision.value if hasattr(sr.organizational, 'decision') else 'unknown',
                    'triggered_conditions': sr.organizational.triggered_conditions if hasattr(sr.organizational, 'triggered_conditions') else [],
                    'explanation': sr.organizational.explanation if hasattr(sr.organizational, 'explanation') else ''
                },
                'individual': {
                    'decision': sr.individual.decision.value if hasattr(sr.individual, 'decision') else 'unknown',
                    'triggered_conditions': sr.individual.triggered_conditions if hasattr(sr.individual, 'triggered_conditions') else [],
                    'explanation': sr.individual.explanation if hasattr(sr.individual, 'explanation') else ''
                }
            },
            'causal_variables': sr.all_causal_variables if hasattr(sr, 'all_causal_variables') else [],
            'hazards': []
        }

        # Extract hazards — only human-readable explanations, strip condition keys
        import re
        condition_pattern = re.compile(r'\bcondition_\w+\b', re.IGNORECASE)
        for layer_name in ['societal', 'organizational', 'individual']:
            layer = getattr(sr, layer_name, None)
            if layer and hasattr(layer, 'decision') and layer.decision.value == 'FORBIDDEN':
                if hasattr(layer, 'explanation') and layer.explanation:
                    # Strip any condition_xxx keys from the explanation text
                    clean_text = condition_pattern.sub('', layer.explanation).strip()
                    clean_text = re.sub(r'\s{2,}', ' ', clean_text)  # collapse multiple spaces
                    if clean_text:
                        safety_details['hazards'].append(clean_text)

        # Add reasoning trace from safety evaluation
        if hasattr(sr, 'reasoning_trace') and sr.reasoning_trace:
            safety_details['reasoning_trace'] = sr.reasoning_trace

        # Add diagnosis fields to safety stage
        diag_fields = _extract_diagnosis_fields(pipeline_result)
        safety_details.update(diag_fields)

        result['stages']['safety'] = safety_details

    # Grounding stage — always surface when available, regardless of repair outcome.
    # This lets researchers see reference resolution even for cases where the safety
    # evaluator rejected the task and no repair was accepted.
    if hasattr(pipeline_result, 'trace') and pipeline_result.trace and 'grounding' in pipeline_result.trace:
        g_trace = pipeline_result.trace['grounding']
        result['stages']['grounding'] = {
            'fully_grounded': g_trace.get('fully_grounded'),
            'confidence': g_trace.get('confidence'),
            'per_ref': g_trace.get('per_ref', []),
            'infeasible': g_trace.get('infeasible', []),
        }
        # Embedding validation audit (C2 hybrid grounding)
        if 'embedding_validation' in g_trace:
            result['stages']['grounding']['embedding_validation'] = g_trace['embedding_validation']

    # Repair stage (if repair was performed)
    if pipeline_result.repair_performed:
        # Extract repaired task string
        repaired_task_str = ''

        if pipeline_result.selected_repair:
            sr = pipeline_result.selected_repair
            if hasattr(sr, 'task_text') and sr.task_text:
                repaired_task_str = sr.task_text
            elif hasattr(sr, 'repaired_task') and sr.repaired_task:
                rt = sr.repaired_task
                if hasattr(rt, 'goal') and rt.goal:
                    repaired_task_str = rt.goal
                elif hasattr(rt, 'original_utterance') and rt.original_utterance:
                    repaired_task_str = rt.original_utterance
            elif hasattr(sr, 'task_variables') and sr.task_variables:
                tv = sr.task_variables
                if hasattr(tv, 'goal') and tv.goal:
                    repaired_task_str = tv.goal

        if not repaired_task_str and pipeline_result.final_task:
            if hasattr(pipeline_result.final_task, 'goal'):
                repaired_task_str = pipeline_result.final_task.goal or ''
            elif hasattr(pipeline_result.final_task, 'original_utterance'):
                repaired_task_str = pipeline_result.final_task.original_utterance or ''

        # Extract operator info
        operator_used = 'AUTO'
        operators_applied = []

        if pipeline_result.selected_repair:
            if hasattr(pipeline_result.selected_repair, 'operators_applied'):
                for op_cls in pipeline_result.selected_repair.operators_applied:
                    op_name = op_cls.operator_type.value if hasattr(op_cls.operator_type, 'value') else str(op_cls.operator_type)
                    operators_applied.append({
                        'operator': op_name,
                        'confidence': op_cls.confidence,
                        'evidence': op_cls.evidence if hasattr(op_cls, 'evidence') else ''
                    })
                if operators_applied:
                    operator_used = ', '.join([op['operator'] for op in operators_applied])
            elif hasattr(pipeline_result.selected_repair, 'operator'):
                op = pipeline_result.selected_repair.operator
                operator_used = op.value if hasattr(op, 'value') else str(op)

        # Get scores
        affinity_val = pipeline_result.repair_affinity if pipeline_result.repair_affinity is not None else 0.0
        cost_val = pipeline_result.repair_cost if pipeline_result.repair_cost is not None else 0.0

        # Build diagnosis info for repair stage
        diag_fields = _extract_diagnosis_fields(pipeline_result)

        # (Grounding stage is now recorded unconditionally above, before this block.)

        # Build intervention trace: which causal variables were changed and which
        # causal edges they target. This makes the counterfactual reasoning auditable.
        intervention_trace = _build_intervention_trace(pipeline_result)

        result['stages']['repair'] = {
            'original_task': task,
            'repaired_task': repaired_task_str,
            'repair_options': [],
            'operator_used': operator_used,
            'operators_applied': operators_applied,
            'cost': cost_val,
            'affinity': affinity_val,
            'analysis': pipeline_result.explanation or '',
            'what_changed': f"Replaced unsafe task with safe alternative using {operator_used} operator",
            'diagnosis': diag_fields,
            'intervention_trace': intervention_trace,
        }

        # Add repair options
        if hasattr(pipeline_result, 'repair_options') and pipeline_result.repair_options:
            for i, opt in enumerate(pipeline_result.repair_options[:2]):
                opt_task = ''
                opt_desc = ''
                opt_rationale = ''
                opt_operators = []

                if hasattr(opt, 'brief_description'):
                    opt_task = opt.brief_description
                if hasattr(opt, 'safety_rationale'):
                    opt_rationale = opt.safety_rationale

                if hasattr(opt, 'repair_candidate') and opt.repair_candidate:
                    candidate = opt.repair_candidate
                    if hasattr(candidate, 'repaired_task') and candidate.repaired_task:
                        rt = candidate.repaired_task
                        if hasattr(rt, 'goal'):
                            opt_task = rt.goal
                        elif hasattr(rt, 'original_utterance'):
                            opt_task = rt.original_utterance

                        if hasattr(candidate, 'operators_applied'):
                            for op_cls in candidate.operators_applied:
                                op_name = op_cls.operator_type.value if hasattr(op_cls.operator_type, 'value') else str(op_cls.operator_type)
                                opt_operators.append(op_name)

                if not opt_task:
                    opt_task = str(opt)

                # Get per-option scores from the repair candidate
                opt_cost = 0.0
                opt_affinity = 0.0
                opt_operator_used = ', '.join(opt_operators) if opt_operators else 'AUTO'
                if hasattr(opt, 'repair_candidate') and opt.repair_candidate:
                    candidate = opt.repair_candidate
                    if hasattr(candidate, 'cost_score'):
                        opt_cost = candidate.cost_score
                    if hasattr(candidate, 'affinity_score'):
                        opt_affinity = candidate.affinity_score

                result['stages']['repair']['repair_options'].append({
                    'label': f"Option {chr(65 + i)}",
                    'task': opt_task,
                    'description': opt_desc,
                    'rationale': opt_rationale,
                    'operators': opt_operators,
                    'cost': opt_cost,
                    'affinity': opt_affinity,
                    'operator_used': opt_operator_used
                })

        # Ensure at least one repair option
        if not result['stages']['repair']['repair_options'] and repaired_task_str:
            result['stages']['repair']['repair_options'].append({
                'label': 'Option A',
                'task': repaired_task_str,
                'description': 'Primary safe alternative',
                'rationale': pipeline_result.explanation or 'Ensures task safety'
            })

        # Case study data: rejected candidates, scoring breakdown,
        # action sequence, causal graph — for qualitative analysis
        if hasattr(pipeline_result, 'rejected_candidates') and pipeline_result.rejected_candidates:
            result['stages']['repair']['rejected_candidates'] = pipeline_result.rejected_candidates

        if hasattr(pipeline_result, 'action_sequence') and pipeline_result.action_sequence:
            result['stages']['repair']['action_sequence'] = pipeline_result.action_sequence

        if hasattr(pipeline_result, 'trace') and pipeline_result.trace:
            trace = pipeline_result.trace
            scoring = trace.get('repair', {}).get('scoring', {})
            if scoring:
                result['stages']['repair']['scoring_breakdown'] = {
                    'affinity': scoring.get('affinity'),
                    'cost': scoring.get('cost'),
                    'final_score': scoring.get('final_score'),
                    'consistency_penalty': scoring.get('consistency_penalty'),
                    'lambda': scoring.get('lambda'),
                    'affinity_dimensions': scoring.get('affinity_dimensions', {}),
                    'affinity_weights': scoring.get('affinity_weights', {}),
                }

            repair_trace = trace.get('repair', {})
            if repair_trace.get('causal_graph'):
                result['stages']['repair']['causal_graph'] = repair_trace['causal_graph']

            if repair_trace.get('cross_attempt_feedback'):
                result['stages']['repair']['cross_attempt_feedback'] = repair_trace['cross_attempt_feedback']

        result['repaired_task'] = repaired_task_str
        result['final_status'] = 'REPAIRED'
    else:
        if pipeline_result.is_original_safe:
            result['final_status'] = 'SAFE'
        else:
            # Grounding or other failure - set error for frontend display
            result['final_status'] = 'ERROR'
            result['error'] = pipeline_result.explanation or 'Processing failed'

    # FULL PIPELINE TRACE — for reviewer inspection and case studies
    # Saves the complete pipeline trace so reviewers can see every
    # intermediate reasoning step: parsing → grounding → safety →
    # diagnosis → generation → validation → repair selection
    if hasattr(pipeline_result, 'trace') and pipeline_result.trace:
        full_trace = pipeline_result.trace

        result['full_trace'] = {
            # Stage 1: Perception
            'perception': full_trace.get('perception', {}),

            # Stage 2: Parsing — task decomposition and frame classification
            'parsing': full_trace.get('parsing', {}),

            # Stage 2.5: Deterministic skill check
            'skill_check': full_trace.get('skill_check', {}),

            # Stage 3: Grounding — entity resolution + skill verification
            'grounding': full_trace.get('grounding', {}),

            # Stage 4: Safety evaluation (captured separately in stages)
            'safety': full_trace.get('safety', {}),

            # Stage 5: Routing decision
            'routing': full_trace.get('routing', {}),

            # Stage 6: Repair — diagnosis, generation, validation
            'repair': full_trace.get('repair', {}),

            # Stage 7: Repair options
            'repair_options': full_trace.get('repair_options', {}),

            # Stage 8: Explanation
            'explanation': full_trace.get('explanation', {}),

            # Rejected candidates across all stages
            'rejected_candidates': full_trace.get('rejected_candidates', []),

            # Timing breakdown
            'timing': full_trace.get('timing', {}),
        }

        # Add causal graph as structured data if available
        if hasattr(pipeline_result, 'selected_repair') and pipeline_result.selected_repair:
            sr = pipeline_result.selected_repair
            # All candidates that passed validation (not just selected)
            if hasattr(pipeline_result, 'repair_candidates') and pipeline_result.repair_candidates:
                result['full_trace']['all_validated_candidates'] = []
                for i, cand in enumerate(pipeline_result.repair_candidates[:5]):
                    cand_info = {}
                    if hasattr(cand, 'goal'):
                        cand_info['task_text'] = cand.goal
                    elif hasattr(cand, 'original_utterance'):
                        cand_info['task_text'] = cand.original_utterance
                    else:
                        cand_info['task_text'] = str(cand)
                    result['full_trace']['all_validated_candidates'].append(cand_info)

    return result


def save_session_log(result: Dict):
    """Save session result to log file."""
    try:
        log_dir = Path(__file__).parent.parent.parent / 'data' / 'logs' / 'sessions'
        log_dir.mkdir(parents=True, exist_ok=True)

        filename = f"{result['session_id']}.json"
        filepath = log_dir / filename

        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(result, f, indent=2, default=str, ensure_ascii=False)

    except Exception as e:
        logger.error(f"Failed to save session log: {e}")


# =============================================================================
def launch_browser(port: int = 5000):
    """Launch browser after delay."""
    time.sleep(2)
    try:
        webbrowser.open(f'http://localhost:{port}')
        print(f"Browser opened: http://localhost:{port}")
    except Exception as e:
        print(f"Could not open browser: {e}")
        print(f"Please open: http://localhost:{port}")



# APP INSTANCE
app = create_app()



# MAIN
def run_server(
    host: str = '0.0.0.0',
    port: int = 5000,
    debug: bool = False,
    open_browser: bool = True,
):
    """Run the web server.

    Args:
        host, port, debug, open_browser: standard Flask options.
    """

    print_banner()
    print()

    # Initialize components
    init_components()

    if not system_ready:
        print(f"Warning: System not fully initialized: {initialization_error}")
        print("Some features may not be available.")

    # Launch browser
    if open_browser and not os.environ.get('RAILWAY_ENVIRONMENT'):
        Thread(target=launch_browser, args=(port,), daemon=True).start()

    print(f"Starting server on http://{host}:{port}")
    print("Press Ctrl+C to stop")
    print()

    # Suppress Flask logs in production
    if not debug:
        log = logging.getLogger('werkzeug')
        log.setLevel(logging.WARNING)

    app.run(host=host, port=port, debug=debug, use_reloader=False)


if __name__ == '__main__':
    run_server()
