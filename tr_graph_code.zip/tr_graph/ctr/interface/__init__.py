"""
TR-Graph Web Interface Module.

Provides a Flask-based web interface for:
- Task input and scene configuration
- Mode selection (TR-Graph vs Baseline)
- Model selection (GPT-4o, Claude, Gemini, etc.)
- Repair visualization and multi-option display
- AI2-THOR execution and video playback
"""

from ctr.interface.app import app, create_app

__all__ = ["app", "create_app"]
