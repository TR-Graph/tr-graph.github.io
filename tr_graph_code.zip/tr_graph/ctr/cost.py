"""
TR-Graph Task Repair: Cost Computation
=============================================

This module computes the intervention cost for repairs.

Cost(T → T') = Σ wτ(i) · dτ(i)(zi, zi') · 𝟙[zi ≠ zi']

Where:
- wτ is the type weight (goal > action > object > parameter)
- dτ is the normalized distance function per variable type
- 𝟙 is the indicator function (1 if changed, 0 otherwise)
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Tuple
from enum import Enum
import math


# COST CONFIGURATION

@dataclass
class CostWeights:
    """
    Weights for different variable types, derived from the causal graph.

    Higher weight = more costly to change = more important to preserve.
    Weights are computed from graph-derived variable importance (Eq. 5-6),
    not hardcoded. Use CostWeights.from_graph() to construct.
    """
    goal: float = 0.0
    action: float = 0.0
    object: float = 0.0
    parameter: float = 0.0
    constraint: float = 0.0
    preference: float = 0.0
    plan: float = 0.0
    manner: float = 0.0
    recipient: float = 0.0

    def get_weight(self, variable_type: str) -> float:
        """
        Get weight for a variable type.

        Returns w_default=0.1 for variable types not in the causal graph (Equation 5).
        Non-causal variables get a small but nonzero cost that discourages
        unnecessary changes while making causal variables much more expensive.
        """
        weight = getattr(self, variable_type.lower(), None)
        if weight is not None and weight > 0.0:
            return weight
        return 0.1  # w_default from Equation 5

    @classmethod
    def uniform(cls) -> 'CostWeights':
        """Create CostWeights with equal weights across all variable types.

        Used for the enable_graph=False ablation: isolates the graph's
        contribution to cost weighting without eliminating cost entirely.
        All 9 variable types get weight 1/9. cost_available=True.
        """
        w = 1.0 / 9.0
        weights = cls(
            goal=w, action=w, object=w, parameter=w, constraint=w,
            preference=w, plan=w, manner=w, recipient=w
        )
        weights.cost_available = True
        return weights

    @classmethod
    def from_graph(cls, causal_graph, goal_node: str = "goal") -> 'CostWeights':
        """
        Create CostWeights from graph-derived variable importance (Eq. 5-6).

        Variables closer to violation sinks in the causal graph get higher weight.
        This is the only supported way to construct CostWeights.

        The method first looks for typed violation_sink nodes in the graph.
        If found, importance is computed relative to those sinks (closest sink wins).
        If no sinks are found, falls back to the legacy goal_node approach.

        If neither sinks nor a connected goal node exist,
        cost_available is set to False. Callers should rank by affinity alone.

        Args:
            causal_graph: CausalGraph from diagnosis extraction.
            goal_node: Legacy fallback goal node name.

        Returns:
            CostWeights with task-specific, graph-derived values.
            If graph has no sinks and no connected goal, returns weights
            with all zeros and cost_available=False.
        """
        if causal_graph is None or not causal_graph.nodes:
            # No graph — cost unavailable
            weights = cls()
            weights.cost_available = False
            return weights

        # Find violation sink nodes for importance computation
        sink_nodes = causal_graph.get_nodes_by_type("violation_sink") if hasattr(causal_graph, 'get_nodes_by_type') else []

        if sink_nodes:
            # Compute importance relative to nearest sink (9A)
            importance = cls._compute_importance_to_sinks(causal_graph, sink_nodes)
        elif goal_node in causal_graph.nodes:
            # Legacy fallback: use goal node if it exists and is connected
            importance = causal_graph.compute_importance(goal_node)
        else:
            # No sinks, no connected goal — cost unavailable 
            import logging
            logging.warning(
                "[CTR] Causal graph has no violation sink nodes and no connected goal. "
                "Graph-based cost computation is unavailable for this task."
            )
            weights = cls()
            weights.cost_available = False
            return weights

        # Map node names to variable types using PREFIX MATCHING.
        #
        # Previously used exact matching against a static list, which
        # failed for dynamic node names like "action.place" or
        # "resource.cup_red" — producing all-zero weights and a
        # silent fallback to uniform 0.1.
        #
        # Prefix matching splits "action.place" → prefix "action"
        # and looks up the variable type.
        prefix_to_variable = {
            'goal': 'goal',
            'action': 'action',
            'object': 'object',
            'resource': 'object',
            'container': 'object',
            'tool': 'object',
            'parameter': 'parameter',
            'constraint': 'constraint',
            'plan': 'plan',
            'manner': 'manner',
            'method': 'manner',
            'location': 'parameter',
            'recipient': 'recipient',
            'person': 'recipient',
            'beneficiary': 'recipient',
            'target': 'recipient',
        }

        FLOOR = 0.05
        variable_scores = {}

        for node, imp_score in importance.items():
            if node in sink_nodes:
                continue

            prefix = node.split('.')[0].lower()
            variable_type = prefix_to_variable.get(prefix)
            if variable_type:
                variable_scores[variable_type] = max(
                    variable_scores.get(variable_type, 0.0),
                    imp_score
                )

        all_types = ['goal', 'action', 'object', 'parameter',
                     'constraint', 'preference', 'plan', 'manner', 'recipient']

        for vt in all_types:
            if vt not in variable_scores:
                variable_scores[vt] = FLOOR

        total = sum(variable_scores.values())
        if total > 0:
            variable_scores = {k: v / total for k, v in variable_scores.items()}

        weights = cls()
        weights.cost_available = True
        for vt, score in variable_scores.items():
            if hasattr(weights, vt):
                setattr(weights, vt, score)

        return weights

    @staticmethod
    def _compute_importance_to_sinks(causal_graph, sink_nodes) -> dict:
        """
        Compute importance of each node based on shortest path to nearest
        violation sink (Eq. 5-6 adapted for sink-based graphs).

        Variables directly connected to sinks have highest importance.
        Variables far from all sinks have low importance.
        """
        default_weight = 0.1
        raw_weights = {}

        for node in causal_graph.nodes:
            if node in sink_nodes:
                # Sinks themselves get zero importance (they're outcomes, not interventions)
                raw_weights[node] = 0.0
                continue

            # Find shortest path to ANY sink
            min_dist = float('inf')
            for sink in sink_nodes:
                d = causal_graph.shortest_path(node, sink)
                min_dist = min(min_dist, d)

            if min_dist == float('inf'):
                raw_weights[node] = default_weight
            else:
                raw_weights[node] = 1.0 / (1.0 + min_dist)

        total = sum(raw_weights.values())
        if total == 0:
            return {n: 1.0 / max(len(causal_graph.nodes), 1) for n in causal_graph.nodes}
        return {n: w / total for n, w in raw_weights.items()}


@dataclass
class DistanceScales:
    """
    Scales for normalizing numeric distances.
    
    d_normalized = min(1, |a - b| / scale)
    """
    temperature: float = 60.0    # Celsius range (0-60 covers most cases)
    quantity: float = 1000.0     # ml range
    distance: float = 5.0        # meters
    time: float = 60.0           # seconds
    weight: float = 10.0         # kg
    age: float = 100.0           # years
    
    def get_scale(self, parameter_name: str) -> float:
        """Get scale for a parameter."""
        # Map common parameter names to scales
        name_lower = parameter_name.lower()
        if 'temp' in name_lower:
            return self.temperature
        elif 'quant' in name_lower or 'volume' in name_lower or 'amount' in name_lower:
            return self.quantity
        elif 'dist' in name_lower or 'range' in name_lower:
            return self.distance
        elif 'time' in name_lower or 'duration' in name_lower:
            return self.time
        elif 'weight' in name_lower or 'mass' in name_lower:
            return self.weight
        elif 'age' in name_lower:
            return self.age
        else:
            return 1.0  # Default scale


@dataclass
class CostConfig:
    """Complete cost configuration."""
    weights: CostWeights = field(default_factory=CostWeights)
    scales: DistanceScales = field(default_factory=DistanceScales)
    
    # Categorical distance uses semantic similarity
    # If embeddings not available, use simple match (0 if same, 1 if different)
    use_semantic_distance: bool = False


# DISTANCE FUNCTIONS

def numeric_distance(a: float, b: float, scale: float) -> float:
    """
    Compute normalized distance for numeric values.
    
    d_num(a, b) = min(1, |a - b| / scale)
    """
    if a is None or b is None:
        return 1.0 if (a is None) != (b is None) else 0.0
    
    return min(1.0, abs(a - b) / scale)


def categorical_distance(a: Any, b: Any, use_semantic: bool = False) -> float:
    """
    Compute distance for categorical values.
    
    Simple: 0 if same, 1 if different
    Semantic: 1 - cosine_similarity(embedding(a), embedding(b))
    """
    if a == b:
        return 0.0
    
    if use_semantic:
        # Would use embeddings here
        # For now, use simple heuristics based on string similarity
        a_str = str(a).lower()
        b_str = str(b).lower()
        
        # Check for partial overlap (e.g., "cup" vs "sippy_cup")
        if a_str in b_str or b_str in a_str:
            return 0.3
        
        # Check for shared words
        a_words = set(a_str.replace('_', ' ').split())
        b_words = set(b_str.replace('_', ' ').split())
        if a_words & b_words:
            overlap = len(a_words & b_words) / len(a_words | b_words)
            return 1.0 - overlap
    
    return 1.0


def set_distance(a: set, b: set) -> float:
    """
    Compute Jaccard distance for sets.
    
    d_set(A, B) = 1 - |A ∩ B| / |A ∪ B|
    """
    if not a and not b:
        return 0.0
    
    a_set = set(a) if not isinstance(a, set) else a
    b_set = set(b) if not isinstance(b, set) else b
    
    intersection = len(a_set & b_set)
    union = len(a_set | b_set)
    
    if union == 0:
        return 0.0
    
    return 1.0 - (intersection / union)


def sequence_distance(a: List, b: List) -> float:
    """
    Compute normalized edit distance for sequences.
    
    d_seq(π, π') = EditDistance(π, π') / max(|π|, |π'|)
    """
    if not a and not b:
        return 0.0
    if not a or not b:
        return 1.0
    
    # Levenshtein distance
    m, n = len(a), len(b)
    dp = [[0] * (n + 1) for _ in range(m + 1)]
    
    for i in range(m + 1):
        dp[i][0] = i
    for j in range(n + 1):
        dp[0][j] = j
    
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            if a[i-1] == b[j-1]:
                dp[i][j] = dp[i-1][j-1]
            else:
                dp[i][j] = 1 + min(dp[i-1][j], dp[i][j-1], dp[i-1][j-1])
    
    edit_distance = dp[m][n]
    max_len = max(m, n)
    
    return edit_distance / max_len


def dict_distance(a: Dict, b: Dict) -> float:
    """
    Compute distance for dictionary/object values.
    
    Averages distances over all keys.
    """
    if not a and not b:
        return 0.0
    if not a or not b:
        return 1.0
    
    all_keys = set(a.keys()) | set(b.keys())
    if not all_keys:
        return 0.0
    
    total_distance = 0.0
    for key in all_keys:
        val_a = a.get(key)
        val_b = b.get(key)
        
        if val_a is None or val_b is None:
            total_distance += 1.0 if (val_a is None) != (val_b is None) else 0.0
        elif isinstance(val_a, (int, float)) and isinstance(val_b, (int, float)):
            # Numeric comparison with default scale
            total_distance += numeric_distance(val_a, val_b, 100.0)
        else:
            total_distance += categorical_distance(val_a, val_b)
    
    return total_distance / len(all_keys)


# VARIABLE-LEVEL COST

def compute_variable_distance(
    original_value: Any,
    new_value: Any,
    variable_type: str,
    config: CostConfig
) -> float:
    """
    Compute distance for a single variable based on its type.
    
    Returns value in [0, 1].
    """
    # Same value = no change
    if original_value == new_value:
        return 0.0
    
    # Handle None
    if original_value is None or new_value is None:
        return 1.0
    
    # Type-specific distance
    var_type_lower = variable_type.lower()
    
    if var_type_lower == 'goal':
        # Goal is a string - use categorical
        return categorical_distance(original_value, new_value, config.use_semantic_distance)
    
    elif var_type_lower == 'action':
        # Action is a string - use categorical
        return categorical_distance(original_value, new_value, config.use_semantic_distance)
    
    elif var_type_lower == 'object':
        # Object could be a reference or dict
        if isinstance(original_value, dict) and isinstance(new_value, dict):
            return dict_distance(original_value, new_value)
        else:
            return categorical_distance(original_value, new_value, config.use_semantic_distance)
    
    elif var_type_lower == 'parameter':
        # Parameter could be numeric or categorical
        if isinstance(original_value, (int, float)) and isinstance(new_value, (int, float)):
            # Try to infer scale from common parameter names
            return numeric_distance(original_value, new_value, 100.0)
        else:
            return categorical_distance(original_value, new_value)
    
    elif var_type_lower == 'constraint':
        # Constraint is typically a structured object
        if isinstance(original_value, list) and isinstance(new_value, list):
            return set_distance(set(str(c) for c in original_value), 
                               set(str(c) for c in new_value))
        else:
            return categorical_distance(original_value, new_value)
    
    elif var_type_lower == 'preference':
        # Similar to constraint
        if isinstance(original_value, list) and isinstance(new_value, list):
            return set_distance(set(str(p) for p in original_value),
                               set(str(p) for p in new_value))
        else:
            return categorical_distance(original_value, new_value)
    
    elif var_type_lower == 'plan':
        # Plan is a sequence of subgoals
        if isinstance(original_value, list) and isinstance(new_value, list):
            return sequence_distance(original_value, new_value)
        else:
            return categorical_distance(original_value, new_value)
    
    elif var_type_lower == 'manner':
        return categorical_distance(original_value, new_value, config.use_semantic_distance)
    
    elif var_type_lower == 'recipient':
        if isinstance(original_value, dict) and isinstance(new_value, dict):
            return dict_distance(original_value, new_value)
        else:
            return categorical_distance(original_value, new_value)
    
    else:
        # Default: categorical distance
        return categorical_distance(original_value, new_value)


def compute_variable_cost(
    original_value: Any,
    new_value: Any,
    variable_type: str,
    config: CostConfig
) -> float:
    """
    Compute cost for a single variable change.
    
    c(zi) = wτ(i) · dτ(i)(zi, zi') · 𝟙[zi ≠ zi']
    """
    # Indicator: is there a change?
    if original_value == new_value:
        return 0.0
    
    # Get weight
    weight = config.weights.get_weight(variable_type)
    
    # Get distance
    distance = compute_variable_distance(original_value, new_value, variable_type, config)
    
    # Cost = weight * distance * indicator(changed)
    return weight * distance


# TASK-LEVEL COST

@dataclass
class CostBreakdown:
    """Detailed breakdown of cost computation."""
    total_cost: float
    variable_costs: Dict[str, float]  # variable_name -> cost
    variables_changed: List[str]
    num_changes: int


def compute_repair_cost(
    original_task: Any,  # TaskVariables
    repaired_task: Any,  # TaskVariables
    config: Optional[CostConfig] = None
) -> CostBreakdown:
    """
    Compute total cost of repair.
    
    Cost(T → T') = Σ c(zi) = Σ wτ(i) · dτ(i)(zi, zi') · 𝟙[zi ≠ zi']
    """
    if config is None:
        config = CostConfig()
    
    variable_costs = {}
    variables_changed = []
    
    # Define which variables to compare
    variables_to_check = [
        ('goal', 'goal'),
        ('action', 'action'),
        ('manner', 'manner'),
    ]
    
    # Check simple variables
    for var_name, var_type in variables_to_check:
        orig_val = getattr(original_task, var_name, None)
        new_val = getattr(repaired_task, var_name, None)
        
        cost = compute_variable_cost(orig_val, new_val, var_type, config)
        variable_costs[var_name] = cost
        if cost > 0:
            variables_changed.append(var_name)
    
    # Check objects (list)
    orig_objects = getattr(original_task, 'objects', []) or []
    new_objects = getattr(repaired_task, 'objects', []) or []
    
    # Compare by converting to comparable form
    orig_obj_strs = [_object_to_comparable(o) for o in orig_objects]
    new_obj_strs = [_object_to_comparable(o) for o in new_objects]
    
    obj_cost = set_distance(set(orig_obj_strs), set(new_obj_strs))
    obj_cost *= config.weights.get_weight('object')
    variable_costs['object'] = obj_cost
    if obj_cost > 0:
        variables_changed.append('object')

    # Check parameters
    orig_params = getattr(original_task, 'parameters', []) or []
    new_params = getattr(repaired_task, 'parameters', []) or []

    param_cost = _compute_parameters_cost(orig_params, new_params, config)
    variable_costs['parameter'] = param_cost
    if param_cost > 0:
        variables_changed.append('parameter')

    # Check constraints
    orig_constraints = getattr(original_task, 'constraints', []) or []
    new_constraints = getattr(repaired_task, 'constraints', []) or []

    constr_cost = _compute_list_cost(orig_constraints, new_constraints, 'constraint', config)
    variable_costs['constraint'] = constr_cost
    if constr_cost > 0:
        variables_changed.append('constraint')

    # Check preferences
    orig_prefs = getattr(original_task, 'preferences', []) or []
    new_prefs = getattr(repaired_task, 'preferences', []) or []

    pref_cost = _compute_list_cost(orig_prefs, new_prefs, 'preference', config)
    variable_costs['preference'] = pref_cost
    if pref_cost > 0:
        variables_changed.append('preference')
    
    # Check plan
    orig_plan = getattr(original_task, 'plan', []) or []
    new_plan = getattr(repaired_task, 'plan', []) or []
    
    if orig_plan or new_plan:
        plan_cost = sequence_distance(
            [_subgoal_to_comparable(s) for s in orig_plan],
            [_subgoal_to_comparable(s) for s in new_plan]
        )
        plan_cost *= config.weights.get_weight('plan')
        variable_costs['plan'] = plan_cost
        if plan_cost > 0:
            variables_changed.append('plan')
    
    # Check recipient
    orig_recipient = getattr(original_task, 'recipient', None)
    new_recipient = getattr(repaired_task, 'recipient', None)
    
    if orig_recipient is not None or new_recipient is not None:
        recip_cost = compute_variable_cost(
            _object_to_comparable(orig_recipient) if orig_recipient else None,
            _object_to_comparable(new_recipient) if new_recipient else None,
            'recipient',
            config
        )
        variable_costs['recipient'] = recip_cost
        if recip_cost > 0:
            variables_changed.append('recipient')
    
    # Total cost
    total_cost = sum(variable_costs.values())
    
    return CostBreakdown(
        total_cost=total_cost,
        variable_costs=variable_costs,
        variables_changed=variables_changed,
        num_changes=len(variables_changed)
    )


def _object_to_comparable(obj: Any) -> str:
    """Convert object reference to comparable string."""
    if obj is None:
        return ""
    if isinstance(obj, str):
        return obj
    if hasattr(obj, 'reference_text'):
        return obj.reference_text
    if hasattr(obj, 'grounded_id'):
        return obj.grounded_id or ""
    if isinstance(obj, dict):
        return obj.get('id', obj.get('label', str(obj)))
    return str(obj)


def _subgoal_to_comparable(subgoal: Any) -> str:
    """Convert subgoal to comparable string."""
    if subgoal is None:
        return ""
    if isinstance(subgoal, str):
        return subgoal
    if hasattr(subgoal, 'action'):
        return f"{subgoal.action}:{','.join(subgoal.objects) if hasattr(subgoal, 'objects') else ''}"
    return str(subgoal)


def _compute_parameters_cost(
    orig_params: List,
    new_params: List,
    config: CostConfig
) -> float:
    """Compute cost for parameter changes."""
    if not orig_params and not new_params:
        return 0.0
    
    # Build dicts for comparison
    orig_dict = {}
    for p in orig_params:
        if hasattr(p, 'name'):
            orig_dict[p.name] = p.value if hasattr(p, 'value') else p
        elif isinstance(p, dict):
            orig_dict[p.get('name', str(p))] = p.get('value', p)
    
    new_dict = {}
    for p in new_params:
        if hasattr(p, 'name'):
            new_dict[p.name] = p.value if hasattr(p, 'value') else p
        elif isinstance(p, dict):
            new_dict[p.get('name', str(p))] = p.get('value', p)
    
    # Compare
    all_keys = set(orig_dict.keys()) | set(new_dict.keys())
    if not all_keys:
        return 0.0
    
    total_cost = 0.0
    for key in all_keys:
        orig_val = orig_dict.get(key)
        new_val = new_dict.get(key)
        
        if orig_val != new_val:
            if isinstance(orig_val, (int, float)) and isinstance(new_val, (int, float)):
                scale = config.scales.get_scale(key)
                dist = numeric_distance(orig_val, new_val, scale)
            else:
                dist = categorical_distance(orig_val, new_val)
            
            total_cost += config.weights.get_weight('parameter') * dist
    
    return total_cost / len(all_keys)  # Average over parameters


def _compute_list_cost(
    orig_list: List,
    new_list: List,
    item_type: str,
    config: CostConfig
) -> float:
    """Compute cost for list changes (constraints, preferences)."""
    orig_strs = set()
    for item in orig_list:
        if hasattr(item, 'description'):
            orig_strs.add(item.description)
        elif isinstance(item, dict):
            orig_strs.add(item.get('description', str(item)))
        else:
            orig_strs.add(str(item))
    
    new_strs = set()
    for item in new_list:
        if hasattr(item, 'description'):
            new_strs.add(item.description)
        elif isinstance(item, dict):
            new_strs.add(item.get('description', str(item)))
        else:
            new_strs.add(str(item))
    
    dist = set_distance(orig_strs, new_strs)
    return config.weights.get_weight(item_type) * dist




def get_normalized_cost_with_breakdown(
    original_task: Any,
    repaired_task: Any,
    config: Optional[CostConfig] = None
) -> Tuple[float, Dict[str, Any]]:
    """
    Get normalized cost in [0, 1] range plus per-variable breakdown for traces.

    Returns:
        (normalized_cost, breakdown_dict) where breakdown_dict contains:
        - delta_variables: list of changed variable names
        - cost_per_variable: dict of variable -> c(v) cost contribution
        - total_raw_cost: un-normalized total
    """
    if config is None:
        config = CostConfig()

    breakdown = compute_repair_cost(original_task, repaired_task, config)

    max_possible = sum([
        1.0, 0.8, 0.6, 0.4, 0.3, 0.2, 0.5, 0.4, 0.7,
    ])

    normalized = min(1.0, breakdown.total_cost / max_possible)

    breakdown_dict = {
        'delta_variables': breakdown.variables_changed,
        'cost_per_variable': {k: round(v, 6) for k, v in breakdown.variable_costs.items() if v > 0},
        'total_raw_cost': round(breakdown.total_cost, 6),
    }

    return normalized, breakdown_dict
