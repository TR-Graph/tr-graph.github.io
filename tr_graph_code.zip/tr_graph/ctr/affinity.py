"""
TR-Graph Task Repair: Objective Affinity Scoring
====================================================

This module computes how well a repair preserves user objective.

The key insight: Objective preservation is not just about surface similarity.
It requires understanding:
1. What the user literally asked for
2. What the user actually wanted (underlying need)
3. What changed in the repair
4. Whether those changes affect the core intent
5. Whether the user would accept this as fulfilling their request
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Tuple
from enum import Enum
import json
import logging



# RUBRIC-TO-SCORE MAPPING (from fidelity_evaluation_rubric.md)
# The fidelity LLM assigns a discrete rubric level (1-5). This deterministic
# mapping converts it to the numerical affinity_score used downstream.
# The LLM never produces the numerical score directly.

RUBRIC_TO_SCORE = {
    5: 1.0,    # Full perlocutionary preservation
    4: 0.7,    # Illocutionary preservation with minor adjustment
    3: 0.4,    # Partial illocutionary preservation
    2: 0.1,    # Locutionary connection only
    1: -0.5,   # No preservation
}


# DETERMINISTIC AFFINITY SCORING
# Same inputs always produce same output. Zero variance.

# --- Dimension 1: Action Preservation ---

CLOSE_VERB_PAIRS = {
    frozenset({'put', 'place'}),
    frozenset({'hand', 'give'}),
    frozenset({'bring', 'deliver'}),
    frozenset({'get', 'fetch'}),
    frozenset({'make', 'prepare'}),
    frozenset({'turn_on', 'toggle_on', 'switch_on'}),
    frozenset({'turn_off', 'toggle_off', 'switch_off'}),
    frozenset({'move', 'relocate'}),
    frozenset({'pour', 'serve'}),
}


def score_action_preservation(original_action, repair_action):
    """Score how well the repair preserves the original action verb."""
    if not original_action or not repair_action:
        return 0.5  # can't assess, neutral

    orig = original_action.lower().strip()
    rep = repair_action.lower().strip()

    if orig == rep:
        return 1.0

    for pair in CLOSE_VERB_PAIRS:
        if orig in pair and rep in pair:
            return 0.8

    return 0.3  # different verb


# --- Dimension 2: Object Preservation ---

def score_object_preservation(original_objects, repair_objects,
                              causal_variables=None):
    """Score how well the repair preserves the original objects.

    Uses substitution-aware scoring: if an object was removed because
    it was on the causal path (the hazardous element), and a replacement
    was added, that counts as a functional substitution (0.7) rather
    than a pure Jaccard loss.

    Falls back to plain Jaccard when causal_variables is not provided.
    """
    orig_labels = {o.reference_text.lower().strip()
                   for o in original_objects if o.reference_text}
    rep_labels = {o.reference_text.lower().strip()
                  for o in repair_objects if o.reference_text}

    if not orig_labels and not rep_labels:
        return 1.0
    if not orig_labels or not rep_labels:
        return 0.0

    kept = orig_labels & rep_labels
    removed = orig_labels - rep_labels
    added = rep_labels - orig_labels

    # If we have causal variables, check if removed objects were causal
    # (i.e., the repair INTENTIONALLY substituted the hazardous object)
    if causal_variables and removed and added:
        causal_terms = set()
        for var in causal_variables:
            parts = var.lower().replace('.', ' ').replace('_', ' ').split()
            causal_terms.update(p for p in parts if len(p) > 2)

        causal_removals = 0
        for obj in removed:
            obj_words = set(obj.replace('_', ' ').split())
            if obj_words & causal_terms:
                causal_removals += 1

        if causal_removals > 0:
            # Deliberate substitution: objects removed were on causal path
            # and replacements were added. Score as functional substitution.
            n_total = len(orig_labels | rep_labels)
            kept_score = len(kept) / n_total if n_total > 0 else 0
            substitution_score = min(causal_removals, len(added)) * 0.7 / n_total
            return min(1.0, kept_score + substitution_score)

    # Default: plain Jaccard
    union = orig_labels | rep_labels
    return len(kept) / len(union) if union else 1.0


def score_object_preservation_jaccard(original_objects, repair_objects):
    """Original Jaccard-only scorer (kept for reversal if needed)."""
    orig_labels = {o.reference_text.lower().strip()
                   for o in original_objects if o.reference_text}
    rep_labels = {o.reference_text.lower().strip()
                  for o in repair_objects if o.reference_text}

    if not orig_labels and not rep_labels:
        return 1.0
    if not orig_labels or not rep_labels:
        return 0.0

    intersection = orig_labels & rep_labels
    union = orig_labels | rep_labels
    return len(intersection) / len(union)


# --- Dimension 3: Location Preservation ---

def score_location_preservation(original_locations, repair_locations):
    """Jaccard similarity on location reference labels."""
    orig_labels = {loc.reference_text.lower().strip()
                   for loc in original_locations if loc.reference_text}
    rep_labels = {loc.reference_text.lower().strip()
                  for loc in repair_locations if loc.reference_text}

    if not orig_labels and not rep_labels:
        return 1.0
    if not orig_labels or not rep_labels:
        return 0.3  # location added or removed

    intersection = orig_labels & rep_labels
    union = orig_labels | rep_labels
    return len(intersection) / len(union)


# --- Dimension 4: Recipient Preservation ---

def score_recipient_preservation(original_recipient, repair_recipient):
    """Score whether the same person receives the task result."""
    orig = (original_recipient.reference_text.lower().strip()
            if original_recipient and original_recipient.reference_text else None)
    rep = (repair_recipient.reference_text.lower().strip()
           if repair_recipient and repair_recipient.reference_text else None)

    if orig is None and rep is None:
        return 1.0
    if orig is None or rep is None:
        return 0.3  # recipient added or removed
    if orig == rep:
        return 1.0
    return 0.0  # different recipient


# --- Dimension 5: Causal Minimality ---

def score_causal_minimality(changes_made, causal_graph, causal_variables):
    """What proportion of changes target the causal path?

    With graph: on-path means the changed variable can reach a
    violation sink in the graph (catches intermediate hazard nodes).

    Without graph: on-path means the change text matches terms from
    the flat causal_variables list.
    """
    if not changes_made:
        return 0.5
    if not causal_variables:
        return 0.5

    # --- Graph path: reachability to sinks ---
    reachable_nodes = None
    if (causal_graph
            and hasattr(causal_graph, 'get_nodes_by_type')
            and causal_graph.edges):
        try:
            sinks = causal_graph.get_nodes_by_type("violation_sink")
            if sinks:
                reachable_nodes = set()
                for node in causal_graph.nodes:
                    if node in sinks:
                        continue
                    for sink in sinks:
                        if causal_graph.shortest_path(node, sink) < float('inf'):
                            reachable_nodes.add(node)
                            break
        except Exception:
            reachable_nodes = None

    on_path = 0
    off_path = 0

    if reachable_nodes is not None:
        # Graph-based: match change text against all reachable nodes
        for change in changes_made:
            c = change.lower()
            matched = False
            for node in reachable_nodes:
                terms = set(
                    p for p in node.lower().replace('.', ' ').replace('_', ' ').split()
                    if len(p) > 2
                )
                if any(t in c for t in terms):
                    matched = True
                    break
            if matched:
                on_path += 1
            else:
                off_path += 1
    else:
        # Flat fallback: match against causal_variables terms
        causal_terms = set()
        for var in causal_variables:
            parts = var.lower().replace('.', ' ').replace('_', ' ').split()
            causal_terms.update(p for p in parts if len(p) > 2)
        for change in changes_made:
            c = change.lower()
            if any(t in c for t in causal_terms):
                on_path += 1
            else:
                off_path += 1

    total = on_path + off_path
    if total == 0:
        return 0.5
    return on_path / total


# --- Dimension 6: Goal Semantic Similarity ---

_embedding_model = None
_FORCE_WORD_OVERLAP = False  # Ablation flag: when True, skip sentence transformer


def set_embedding_model(model):
    """Set the global embedding model (called once at pipeline init).

    Global injection pattern — do NOT pass the model as a parameter
    to every affinity call. Set it once, read it from module state.
    """
    global _embedding_model
    _embedding_model = model
    if model is not None:
        logging.info("[CTR] Embedding model set for goal similarity scoring")


def _get_embedding_model():
    """Load sentence embedding model. Returns None if unavailable.

    Tries to load all-MiniLM-L6-v2 (22MB, ~1.5s load, ~5ms encode).
    Falls back to None (word overlap) if sentence-transformers is not
    installed or loading fails for any reason.
    """
    if _FORCE_WORD_OVERLAP:
        return None

    global _embedding_model
    if _embedding_model is not None:
        return _embedding_model
    try:
        import os
        import io
        import contextlib
        import warnings as _warnings

        # Suppress harmless HuggingFace/safetensors warnings during load
        os.environ['TRANSFORMERS_VERBOSITY'] = 'error'
        _warnings.filterwarnings('ignore')
        _prev_levels = {}
        for _name in ['transformers', 'transformers.modeling_utils', 'safetensors', 'huggingface_hub']:
            _logger = logging.getLogger(_name)
            _prev_levels[_name] = _logger.level
            _logger.setLevel(logging.ERROR)

        from sentence_transformers import SentenceTransformer
        with contextlib.redirect_stderr(io.StringIO()):
            _embedding_model = SentenceTransformer('all-MiniLM-L6-v2')

        # Restore logger levels
        for _name, _level in _prev_levels.items():
            logging.getLogger(_name).setLevel(_level)
        _warnings.resetwarnings()

        logging.info("[CTR] Embedding model loaded: all-MiniLM-L6-v2")
        return _embedding_model
    except Exception as e:
        logging.warning(f"[CTR] Embedding model unavailable, using word overlap fallback: {e}")
        return None


def score_goal_similarity(original_goal, repair_goal):
    """Semantic similarity between original and repaired goals."""
    if not original_goal or not repair_goal:
        return 0.5

    if original_goal.lower().strip() == repair_goal.lower().strip():
        return 1.0

    model = _get_embedding_model()
    if model is None:
        # Fallback: word overlap Jaccard
        orig_words = set(original_goal.lower().split())
        rep_words = set(repair_goal.lower().split())
        if not orig_words or not rep_words:
            return 0.5
        return len(orig_words & rep_words) / len(orig_words | rep_words)

    embeddings = model.encode(
        [original_goal, repair_goal],
        normalize_embeddings=True
    )
    similarity = float(embeddings[0] @ embeddings[1])
    return max(0.0, (similarity + 1.0) / 2.0)


# --- Graph-Derived Dimension Weights ---

def compute_affinity_dimension_weights(causal_graph, causal_variables,
                                       return_derivation=False):
    """Derive dimension weights from causal graph structure.

    With graph: uses variable importance (distance to violation sinks)
    to upweight dimensions whose variables are closer to violations.

    Without graph: falls back to prefix counting over causal_variables.

    Args:
        causal_graph: The causal graph (or None).
        causal_variables: List of causal variable names.
        return_derivation: If True, return (weights, derivation_dict) tuple
            where derivation_dict contains c_z, p_z, w_z and method used.

    Returns:
        Dict of dimension weights (if return_derivation=False), or
        Tuple of (weights_dict, derivation_dict) if return_derivation=True.
    """
    derivation = {'method': 'flat_default', 'c_z': {}, 'p_z': {}, 'w_z': {}}

    if not causal_variables:
        weights = {
            'action': 0.15, 'object': 0.20, 'location': 0.10,
            'recipient': 0.15, 'minimality': 0.20, 'goal': 0.20,
        }
        derivation['method'] = 'no_causal_variables'
        derivation['w_z'] = dict(weights)
        if return_derivation:
            return weights, derivation
        return weights

    base_weights = {
        'action': 0.10, 'object': 0.15, 'location': 0.08,
        'recipient': 0.10, 'minimality': 0.20, 'goal': 0.17,
    }
    distributable = 0.20

    # --- Graph path: use structural importance ---
    if (causal_graph
            and hasattr(causal_graph, 'get_nodes_by_type')
            and causal_graph.edges):
        try:
            from ctr.cost import CostWeights
            sink_nodes = causal_graph.get_nodes_by_type("violation_sink")
            if sink_nodes:
                importance = CostWeights._compute_importance_to_sinks(
                    causal_graph, sink_nodes
                )
            else:
                importance = {}

            if importance:
                prefix_map = {
                    'action': ('action.',),
                    'object': ('object.', 'resource.', 'container.', 'tool.'),
                    'location': ('location.',),
                    'recipient': ('recipient.', 'person.', 'beneficiary.'),
                }
                dim_imp = {d: 0.0 for d in prefix_map}
                for var in causal_variables:
                    v = var.lower()
                    imp = importance.get(var, 0.0)
                    for dim, prefixes in prefix_map.items():
                        if v.startswith(prefixes):
                            dim_imp[dim] = max(dim_imp[dim], imp)
                            break

                total_imp = sum(dim_imp.values()) or 1.0
                for dim in dim_imp:
                    base_weights[dim] += distributable * (dim_imp[dim] / total_imp)

                total = sum(base_weights.values())
                final_weights = {k: v / total for k, v in base_weights.items()}

                derivation['method'] = 'graph_conditioned'
                derivation['c_z'] = dict(dim_imp)
                derivation['p_z'] = {k: v / total_imp for k, v in dim_imp.items()}
                derivation['w_z'] = dict(final_weights)

                if return_derivation:
                    return final_weights, derivation
                return final_weights
        except Exception:
            pass  # fall through to prefix counting

    # --- Flat fallback: prefix counting ---
    counts = {'action': 0, 'object': 0, 'location': 0, 'recipient': 0, 'other': 0}
    for var in causal_variables:
        v = var.lower()
        if v.startswith('action.'): counts['action'] += 1
        elif v.startswith(('object.', 'resource.')): counts['object'] += 1
        elif v.startswith('location.'): counts['location'] += 1
        elif v.startswith('recipient.'): counts['recipient'] += 1
        else: counts['other'] += 1

    total = sum(counts.values()) or 1
    for dim in ['action', 'object', 'location', 'recipient']:
        base_weights[dim] += distributable * (counts[dim] / total)

    total_weight = sum(base_weights.values())
    final_weights = {k: v / total_weight for k, v in base_weights.items()}

    derivation['method'] = 'prefix_counting'
    derivation['c_z'] = dict(counts)
    derivation['p_z'] = {k: v / total for k, v in counts.items()}
    derivation['w_z'] = dict(final_weights)

    if return_derivation:
        return final_weights, derivation
    return final_weights


# --- Combined Deterministic Scorer ---

def compute_deterministic_affinity(
    original_task, repaired_task, diagnosis=None, changes_made=None
):
    """Deterministic affinity score from structured task comparison.

    Returns (affinity_score, dimension_scores, dimension_weights).
    Score range: [-0.5, 1.0] matching RUBRIC_TO_SCORE range.
    Same inputs ALWAYS produce same output. Zero variance.

    Also stores weight derivation details on the module-level cache
    accessible via get_last_weight_derivation().
    """
    global _last_weight_derivation
    causal_vars = diagnosis.causal_variables if diagnosis else []

    scores = {
        'action': score_action_preservation(
            original_task.action, repaired_task.action
        ),
        'object': score_object_preservation(
            original_task.objects, repaired_task.objects,
            causal_variables=causal_vars
        ),
        'location': score_location_preservation(
            getattr(original_task, 'locations', []),
            getattr(repaired_task, 'locations', [])
        ),
        'recipient': score_recipient_preservation(
            original_task.recipient, repaired_task.recipient
        ),
        'minimality': score_causal_minimality(
            changes_made or [],
            diagnosis.causal_graph if diagnosis else None,
            diagnosis.causal_variables if diagnosis else []
        ),
        'goal': score_goal_similarity(
            original_task.goal, repaired_task.goal
        ),
    }

    weights, weight_derivation = compute_affinity_dimension_weights(
        diagnosis.causal_graph if diagnosis else None,
        diagnosis.causal_variables if diagnosis else [],
        return_derivation=True
    )

    _last_weight_derivation = weight_derivation

    raw_score = sum(weights[dim] * scores[dim] for dim in scores)

    # Rescale from [0,1] to [-0.5, 1.0] to match RUBRIC_TO_SCORE range.
    # Monotonic — preserves ranking. All reported results use this scaling.
    affinity = raw_score * 1.5 - 0.5

    return affinity, scores, weights


# Module-level cache for the last weight derivation (accessed by pipeline trace)
_last_weight_derivation: Dict[str, Any] = {}


def get_last_weight_derivation() -> Dict[str, Any]:
    """Return the weight derivation details from the last compute_deterministic_affinity call."""
    return _last_weight_derivation

