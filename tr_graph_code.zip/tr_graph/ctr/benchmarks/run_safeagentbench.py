"""
CLI entry point for running TR-Graph on SafeAgentBench.

Usage:
    # Test with 100 tasks
    python -m ctr.benchmarks.run_safeagentbench --num-tasks 100 --model gpt-4o

    # Full run on all splits
    python -m ctr.benchmarks.run_safeagentbench --model gpt-4o

    # Specific split only
    python -m ctr.benchmarks.run_safeagentbench --split unsafe_detailed --num-tasks 50

    # Use cheaper model for testing
    python -m ctr.benchmarks.run_safeagentbench --num-tasks 20 --model gpt-4o-mini

    # Use Gemini
    python -m ctr.benchmarks.run_safeagentbench --num-tasks 20 --model gemini-2.5-flash
"""

import argparse
import logging
import sys
import os

# Add project root to path
sys.path.insert(0, str(__import__('pathlib').Path(__file__).parent.parent.parent))


def main():
    parser = argparse.ArgumentParser(
        description='Run TR-Graph on SafeAgentBench tasks',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s --num-tasks 100 --model gpt-4o       # Test run (100 tasks)
  %(prog)s --model gpt-4o                        # Full run (all 750 tasks)
  %(prog)s --split unsafe_detailed --num-tasks 50 # 50 unsafe detailed tasks
  %(prog)s --num-tasks 20 --model gpt-4o-mini    # Quick test with cheap model
        """
    )

    parser.add_argument(
        '--num-tasks', '-n',
        type=int,
        default=0,
        help='Maximum number of tasks to run. 0 = all tasks (default: 0)',
    )
    parser.add_argument(
        '--model', '-m',
        type=str,
        default='gpt-4o',
        help='LLM model to use (default: gpt-4o)',
    )
    parser.add_argument(
        '--split', '-s',
        type=str,
        default=None,
        choices=['unsafe_detailed', 'safe_detailed', 'abstract', 'long_horizon'],
        help='Specific split to run. Default: all splits.',
    )
    parser.add_argument(
        '--output-dir', '-o',
        type=str,
        default=None,
        help='Output directory for results (default: results/safeagentbench/)',
    )
    parser.add_argument(
        '--workers', '-w',
        type=int,
        default=1,
        help='Number of parallel workers. 1 = sequential (default: 1)',
    )
    parser.add_argument(
        '--max-retries',
        type=int,
        default=3,
        help='Max retry attempts for low-quality repairs or errors (default: 3)',
    )
    parser.add_argument(
        '--affinity-threshold',
        type=float,
        default=0.4,
        help='Minimum repair affinity before triggering retry (default: 0.4)',
    )
    parser.add_argument(
        '--baseline',
        type=str,
        default=None,
        choices=['cot', 'selp-lite', 'safeplan'],
        help='Run a baseline instead of TR-Graph. '
             '"cot" = chain-of-thought accept/reject (no repair). '
             '"selp-lite" = NL->LTL verification + regeneration. '
             '"safeplan" = three-layer deontic detection + naive repair.',
    )
    parser.add_argument(
        '--ablation',
        type=str,
        nargs='*',
        default=None,
        metavar='VARIANT',
        help='Run ablation study. Variants: full, no-bandit, no-graph, '
             'no-consistency, no-operator-val, '
             'or "all". Can specify multiple: --ablation full no-graph',
    )
    parser.add_argument(
        '--seeds',
        type=int,
        nargs='+',
        default=None,
        help='Random seeds for ablation runs (default: 42 123 456)',
    )
    parser.add_argument(
        '--ablation-benchmark',
        type=str,
        default='ctr',
        choices=['ctr', 'safeagentbench'],
        help='Which benchmark to use for ablation. "ctr" = TR-Graph benchmark (621 tasks). '
             '"safeagentbench" = SafeAgentBench. Default: ctr.',
    )
    parser.add_argument(
        '--independent-model',
        type=str,
        default=None,
        help='LLM model for independent safety validation of repairs. '
             '"auto" = pick a different provider than --model. '
             'Default: None (skip validation).',
    )
    parser.add_argument(
        '--execute',
        type=str,
        default=None,
        metavar='JSON_PATH',
        help='Post-hoc: execute repaired tasks in AI2-THOR from a saved '
             'results JSON. Requires Linux with ai2thor installed.',
    )
    parser.add_argument(
        '--rerun-errors',
        type=str,
        default=None,
        metavar='JSON_PATH',
        help='Rerun only tasks that failed due to API/quota errors. '
             'Merges new results back into the original JSON.',
    )
    parser.add_argument(
        '--validate',
        type=str,
        default=None,
        metavar='JSON_PATH',
        help='Post-hoc: run independent validation on a saved results JSON '
             'and recompute metrics. Requires --independent-model.',
    )
    parser.add_argument(
        '--verbose', '-v',
        action='store_true',
        help='Enable verbose logging',
    )

    args = parser.parse_args()

    # Setup logging
    log_level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=log_level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    )
    # Suppress noisy loggers
    for name in ['httpx', 'httpcore', 'google_genai', 'sentence_transformers',
                 'transformers', 'huggingface_hub', 'urllib3']:
        logging.getLogger(name).setLevel(logging.WARNING)

    # Load environment variables
    try:
        from dotenv import load_dotenv
        load_dotenv()
    except ImportError:
        pass

    # Verify API key is set
    model = args.model
    if 'gpt' in model or 'openai' in model:
        if not os.environ.get('OPENAI_API_KEY'):
            print("Error: OPENAI_API_KEY not set. Set it in .env or environment.", file=sys.stderr)
            return 1
    elif 'gemini' in model:
        if not os.environ.get('GOOGLE_API_KEY'):
            print("Error: GOOGLE_API_KEY not set. Set it in .env or environment.", file=sys.stderr)
            return 1
    elif 'claude' in model:
        if not os.environ.get('ANTHROPIC_API_KEY'):
            print("Error: ANTHROPIC_API_KEY not set. Set it in .env or environment.", file=sys.stderr)
            return 1

    from pathlib import Path

    # Rerun API-error tasks
    if args.rerun_errors:
        from ctr.benchmarks.safeagentbench_adapter import rerun_errors
        try:
            rerun_errors(
                args.rerun_errors,
                model=model,
                workers=args.workers,
                max_retries=args.max_retries,
                affinity_threshold=args.affinity_threshold,
                independent_model=args.independent_model,
            )
            return 0
        except Exception as e:
            print(f"\nError: {e}", file=sys.stderr)
            import traceback
            traceback.print_exc()
            return 1

    # Post-hoc AI2-THOR execution mode
    if args.execute:
        from ctr.benchmarks.execution_harness import execute_from_json
        from ctr.benchmarks.metrics import compute_metrics, print_metrics
        try:
            execute_from_json(args.execute)
            import json
            with open(args.execute, 'r') as f:
                data = json.load(f)
            metrics = compute_metrics(data['results'], model=model)
            print_metrics(metrics)
            return 0
        except EnvironmentError as e:
            print(f"\nError: {e}", file=sys.stderr)
            return 1
        except Exception as e:
            print(f"\nError: {e}", file=sys.stderr)
            import traceback
            traceback.print_exc()
            return 1

    # Post-hoc validation mode
    if args.validate:
        if not args.independent_model:
            print("Error: --validate requires --independent-model", file=sys.stderr)
            return 1
        from ctr.benchmarks.independent_safety import validate_from_json
        from ctr.benchmarks.metrics import compute_metrics, print_metrics
        try:
            validate_from_json(
                args.validate,
                model=args.independent_model,
                workers=args.workers or 3,
            )
            # Recompute and display metrics from the updated JSON
            import json
            with open(args.validate, 'r') as f:
                data = json.load(f)
            metrics = compute_metrics(data['results'], model=model)
            print_metrics(metrics)
            return 0
        except Exception as e:
            print(f"\nError: {e}", file=sys.stderr)
            import traceback
            traceback.print_exc()
            return 1

    splits = [args.split] if args.split else None
    output_dir = Path(args.output_dir) if args.output_dir else None

    # Ablation mode
    if args.ablation is not None:
        from ctr.benchmarks.ablation_runner import run_ablation
        variants = args.ablation if args.ablation else ['all']
        try:
            run_ablation(
                model=model,
                variants=variants,
                num_tasks=args.num_tasks or 100,
                splits=splits,
                seeds=args.seeds,
                output_dir=Path(args.output_dir) if args.output_dir else None,
                max_retries=args.max_retries,
                affinity_threshold=args.affinity_threshold,
                benchmark=args.ablation_benchmark,
            )
            return 0
        except KeyboardInterrupt:
            print("\nInterrupted by user.")
            return 1
        except Exception as e:
            print(f"\nError: {e}", file=sys.stderr)
            import traceback
            traceback.print_exc()
            return 1

    # Baseline mode
    if args.baseline:
        from ctr.benchmarks.baseline_runners import run_baseline
        try:
            results = run_baseline(
                baseline=args.baseline,
                model=model,
                splits=splits,
                num_tasks=args.num_tasks,
                output_dir=output_dir,
                workers=args.workers,
                independent_model=args.independent_model,
            )
            return 0
        except KeyboardInterrupt:
            print("\nInterrupted by user.")
            return 1
        except Exception as e:
            print(f"\nError: {e}", file=sys.stderr)
            import traceback
            traceback.print_exc()
            return 1

    # Run TR-Graph benchmark
    from ctr.benchmarks.safeagentbench_adapter import run_benchmark

    try:
        results = run_benchmark(
            model=model,
            splits=splits,
            num_tasks=args.num_tasks,
            output_dir=output_dir,
            workers=args.workers,
            max_retries=args.max_retries,
            affinity_threshold=args.affinity_threshold,
            independent_model=args.independent_model,
        )
        return 0
    except KeyboardInterrupt:
        print("\nInterrupted by user.")
        return 1
    except Exception as e:
        print(f"\nError: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        return 1


def metrics_from_csv():
    """Standalone: recompute metrics from a saved results CSV."""
    parser = argparse.ArgumentParser(description='Compute metrics from a SafeAgentBench results CSV')
    parser.add_argument('csv_path', help='Path to the results CSV file')
    parser.add_argument('--model', '-m', default='', help='Model name for display')
    args = parser.parse_args()

    from pathlib import Path
    from ctr.benchmarks.metrics import load_results_csv, compute_metrics, print_metrics, save_metrics

    csv_path = Path(args.csv_path)
    if not csv_path.exists():
        print(f"Error: {csv_path} not found", file=sys.stderr)
        return 1

    results = load_results_csv(csv_path)
    metrics = compute_metrics(results, model=args.model)
    print_metrics(metrics)

    # Save alongside the CSV
    metrics_path = csv_path.with_suffix('.metrics.json')
    save_metrics(metrics, metrics_path)
    print(f"Metrics saved to: {metrics_path}")
    return 0


if __name__ == '__main__':
    # Check if called with --metrics flag for standalone metrics computation
    if len(sys.argv) > 1 and sys.argv[1] == '--metrics':
        sys.argv.pop(1)  # Remove the --metrics flag
        sys.exit(metrics_from_csv())
    else:
        sys.exit(main())
