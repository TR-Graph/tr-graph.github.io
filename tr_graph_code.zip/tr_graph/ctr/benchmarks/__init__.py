"""
TR-Graph Benchmark Adapters.

Provides adapters for running TR-Graph on external safety benchmarks:
- SafeAgentBench (750 tasks, AI2-THOR, 10 hazard types)

Plus metrics computation, baseline runners, and independent validation.
"""
