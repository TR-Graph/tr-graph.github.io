"""
Ablation Runner for TR-Graph Benchmark Experiments.

Runs TR-Graph with one component disabled at a time to measure each
component's contribution. 

5 ablation variants:
  1. Full           — all components enabled (control)
  2. No Bandit      — learned operator prioritization off
  3. No Graph       — causal graph derivation off
  4. No Consistency — consistency gating off
  5. No Operator Val— operator validity check off

Each variant: 3 seeds, report mean +/- std, bootstrap CIs.

Usage:
    # Run all variants
    python -m ctr.benchmarks.run_safeagentbench --ablation all

    # Run specific variant
    python -m ctr.benchmarks.run_safeagentbench --ablation no-graph

    # Run full system baseline for comparison
    python -m ctr.benchmarks.run_safeagentbench --ablation full
"""

import json
import logging
import math
import random
import time
from collections import defaultdict
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from ctr.benchmarks.safeagentbench_adapter import (
    TaskResult, _build_scene_graph, _run_pipeline_once,
    run_single_task, DEFAULT_MAX_RETRIES, DEFAULT_AFFINITY_THRESHOLD,
)
from ctr.benchmarks.safeagentbench_loader import SafeAgentBenchTask, load_dataset
from ctr.benchmarks.scene_cache import preload_scenes

logger = logging.getLogger(__name__)

_RESULTS_DIR = Path(__file__).parent.parent.parent / 'results' / 'safeagentbench' / 'ablation'


# Ablation variant definitions

from ctr.ablation import get_ablation, AblationConfig, ABLATIONS

ABLATION_VARIANTS = {
    'full': {
        'label': 'Full System',
        'description': 'TR-Graph with all components enabled (control)',
        'ablation_name': 'full',
    },
    'no-graph': {
        'label': 'No Graph',
        'description': 'Task-conditioned graph and all graph-dependent mechanisms disabled',
        'ablation_name': 'no_graph',
    },
    'no-bandit': {
        'label': 'No Bandit',
        'description': 'Learned operator prioritization disabled; uniform allocation',
        'ablation_name': 'no_bandit',
    },
    'no-consistency': {
        'label': 'No Consistency',
        'description': 'Graph consistency validation gate disabled',
        'ablation_name': 'no_consistency',
    },
    'no-operator-val': {
        'label': 'No Operator Validation',
        'description': 'Operator precondition validation gate disabled',
        'ablation_name': 'no_operator_val',
    },
}

ALL_VARIANT_NAMES = list(ABLATION_VARIANTS.keys())


# Stratified sampling

def stratified_sample(
    tasks: List[SafeAgentBenchTask],
    n: int = 200,
    seed: int = 42,
) -> List[SafeAgentBenchTask]:
    """Sample n tasks balanced by split and hazardous/safe ground truth.

    Ensures proportional representation across:
    - Split (unsafe_detailed, safe_detailed, abstract, long_horizon)
    - Ground truth label (hazardous vs safe)

    If a stratum has fewer tasks than its allocation, all are included.
    """
    rng = random.Random(seed)

    # Group tasks into strata
    strata: Dict[Tuple[str, bool], List[SafeAgentBenchTask]] = defaultdict(list)
    for task in tasks:
        key = (task.split, task.is_hazardous)
        strata[key].append(task)

    # Calculate proportional allocation
    total = len(tasks)
    sampled = []

    for key, stratum_tasks in strata.items():
        proportion = len(stratum_tasks) / total
        stratum_n = max(1, round(proportion * n))
        stratum_n = min(stratum_n, len(stratum_tasks))

        rng.shuffle(stratum_tasks)
        sampled.extend(stratum_tasks[:stratum_n])

    # If we have too many (due to rounding), trim
    if len(sampled) > n:
        rng.shuffle(sampled)
        sampled = sampled[:n]

    # Sort by task_id for deterministic ordering
    sampled.sort(key=lambda t: t.task_id)

    logger.info(
        f"[ablation] Stratified sample: {len(sampled)} tasks from {len(tasks)} "
        f"({len(strata)} strata)"
    )
    for key, stratum_tasks in sorted(strata.items()):
        count = sum(1 for t in sampled if (t.split, t.is_hazardous) == key)
        logger.info(f"  {key[0]}/{'hazardous' if key[1] else 'safe'}: {count}")

    return sampled


# Single ablation run

def _run_ablation_variant(
    variant_name: str,
    tasks: List[SafeAgentBenchTask],
    model: str,
    scene_objects_map: Dict[str, List[str]],
    scene_graphs: Dict[str, Any],
    seed: int = 42,
    max_retries: int = DEFAULT_MAX_RETRIES,
    affinity_threshold: float = DEFAULT_AFFINITY_THRESHOLD,
) -> List[TaskResult]:
    """Run TR-Graph on tasks with one component ablated.

    Creates a fresh pipeline per task with the ablation config applied.
    """
    results = []
    total = len(tasks)

    for i, task in enumerate(tasks):
        print(f"  [{i+1}/{total}] {task.task_id}...", end='\r')

        scene_objects = scene_objects_map.get(task.scene_name, [])
        scene_graph = scene_graphs.get(task.scene_name)
        if scene_graph is None:
            scene_graph = _build_scene_graph(task.scene_name, scene_objects)

        result = _run_single_ablated(
            task, model, scene_graph, scene_objects,
            variant_name, seed, max_retries, affinity_threshold,
        )
        results.append(result)

    print()
    return results


def _run_single_ablated(
    task: SafeAgentBenchTask,
    model: str,
    scene_graph: Any,
    scene_objects: List[str],
    variant_name: str,
    seed: int,
    max_retries: int,
    affinity_threshold: float,
) -> TaskResult:
    """Run a single task with ablated config, using retry logic."""
    from ctr.llm_client import create_client
    from ctr.pipeline import CTRPipeline, CTRConfig
    from ctr.interface.app import _interface_config, get_provider_for_model
    from ctr.benchmarks.safeagentbench_adapter import RETRY_TEMPERATURES

    # Build config from AblationConfig (authoritative experimental object)
    ablation_key = ABLATION_VARIANTS[variant_name]['ablation_name']
    ablation = get_ablation(ablation_key)
    config = CTRConfig.from_ablation(ablation)
    config.generate_explanation = False
    if seed is not None:
        config.random_seed = seed

    # Copy interface defaults that from_ablation doesn't set
    interface_defaults = _interface_config(strict_mode=True)
    for attr in ['lambda_min', 'lambda_max', 'defect_multipliers']:
        val = getattr(interface_defaults, attr, None)
        if val is not None and getattr(config, attr, None) is None:
            setattr(config, attr, val)

    attempts = []

    for attempt_num in range(max_retries):
        temp = RETRY_TEMPERATURES[min(attempt_num, len(RETRY_TEMPERATURES) - 1)]

        result = TaskResult(
            task_id=task.task_id,
            split=task.split,
            instruction=task.instruction,
            scene_name=task.scene_name,
            is_hazardous=task.is_hazardous,
            risk_category=task.risk_category,
        )

        start_time = time.time()

        try:
            provider = get_provider_for_model(model)
            client = create_client(provider=provider, model=model)
            client.config.temperature = temp

            # Route benchmark artifacts to variant-specific subdirectory
            run_config = config
            if config.export_reviewer_artifacts:
                import copy
                run_config = copy.copy(config)
                run_config.artifact_dir = str(
                    Path(config.artifact_dir) / "benchmark_runs" / variant_name
                )

            pipeline = CTRPipeline(client, run_config)
            pipeline._robot_mode = 'safeagentbench'

            # Deterministic task_id for benchmark cross-variant comparison
            if run_config.export_reviewer_artifacts:
                import hashlib
                pipeline._current_task_id = hashlib.md5(
                    f"{task.task_id}:{seed}".encode()
                ).hexdigest()[:12]

            pipeline_result = None
            for phase, phase_result in pipeline.process_streaming(
                task.instruction,
                scene_graph=scene_graph,
                context="",
                strict_mode=True,
                available_objects=scene_objects,
            ):
                if phase == 'complete':
                    pipeline_result = phase_result

            if pipeline_result is None:
                result.final_status = 'ERROR'
                result.error_message = 'Pipeline returned no complete result'
                result.processing_time_ms = (time.time() - start_time) * 1000
                attempts.append(result)
                continue

            # Extract results (same as safeagentbench_adapter._run_pipeline_once)
            result.tr_graph_safe = pipeline_result.is_original_safe
            result.tr_graph_flagged_unsafe = not pipeline_result.is_original_safe
            result.repair_performed = pipeline_result.repair_performed

            if getattr(pipeline_result, 'needs_clarification', False):
                result.final_status = 'CLARIFY'
            elif getattr(pipeline_result, 'is_infeasible', False):
                result.final_status = 'INFEASIBLE'
            elif pipeline_result.repair_performed:
                result.final_status = 'REPAIRED'
            elif pipeline_result.is_original_safe:
                result.final_status = 'SAFE'
            else:
                result.final_status = 'ERROR'
                result.error_message = pipeline_result.explanation or 'Unknown error'

            if pipeline_result.repair_performed and pipeline_result.selected_repair:
                sr = pipeline_result.selected_repair
                if hasattr(sr, 'task_text') and sr.task_text:
                    result.repaired_task = sr.task_text
                elif hasattr(sr, 'repaired_task') and sr.repaired_task:
                    rt = sr.repaired_task
                    if hasattr(rt, 'goal') and rt.goal:
                        result.repaired_task = rt.goal

                if hasattr(sr, 'operators_applied') and sr.operators_applied:
                    ops = [
                        op.operator_type.value if hasattr(op.operator_type, 'value')
                        else str(op.operator_type)
                        for op in sr.operators_applied
                    ]
                    result.operator_used = ', '.join(ops)

            if pipeline_result.repair_cost is not None:
                result.repair_cost = pipeline_result.repair_cost
            if pipeline_result.repair_affinity is not None:
                result.repair_affinity = pipeline_result.repair_affinity

            if hasattr(pipeline_result, 'repair_options') and pipeline_result.repair_options:
                for j, opt in enumerate(pipeline_result.repair_options[:2]):
                    opt_text = ''
                    if hasattr(opt, 'brief_description'):
                        opt_text = opt.brief_description
                    elif hasattr(opt, 'repair_candidate') and opt.repair_candidate:
                        rc = opt.repair_candidate
                        if hasattr(rc, 'repaired_task') and rc.repaired_task:
                            opt_text = getattr(rc.repaired_task, 'goal', '') or ''
                    if j == 0:
                        result.repair_option_a = opt_text
                    elif j == 1:
                        result.repair_option_b = opt_text

            if hasattr(pipeline_result, 'action_sequence') and pipeline_result.action_sequence:
                result.action_sequence = pipeline_result.action_sequence

            if hasattr(pipeline_result, 'trace') and pipeline_result.trace:
                g = pipeline_result.trace.get('grounding', {})
                result.fully_grounded = g.get('fully_grounded', False)
                result.grounding_confidence = g.get('confidence', 0.0)

            if hasattr(pipeline_result, 'rejected_candidates'):
                result.rejected_candidates = pipeline_result.rejected_candidates

            # Gate-level logging for ablation analysis
            rejections = getattr(pipeline, '_rejected_candidates', [])
            gate_counts = {
                'plan_lint': 0,
                'safety': 0,
                'consistency': 0,
                'operator_validation': 0,
                'affinity': 0,
                'other': 0,
            }
            for rej in rejections:
                stage = rej.get('stage', 'other')
                if stage == 'plan_linting':
                    gate_counts['plan_lint'] += 1
                elif stage == 'safety_validation':
                    gate_counts['safety'] += 1
                elif stage == 'consistency_check':
                    gate_counts['consistency'] += 1
                elif stage == 'operator_validation':
                    gate_counts['operator_validation'] += 1
                elif stage == 'affinity_computation':
                    gate_counts['affinity'] += 1
                else:
                    gate_counts['other'] += 1

            repair_trace = getattr(pipeline_result, 'trace', {}).get('repair', {})
            result.gate_log = {
                'variant': variant_name,
                'task_id': task.task_id,
                'detected_defect': not pipeline_result.is_original_safe,
                'num_generated': repair_trace.get('candidates_generated', 0),
                'num_final_valid': repair_trace.get('candidates_validated', 0),
                'rejection_reasons': gate_counts,
                'selected_affinity': result.repair_affinity,
                'selected_safe': result.independent_safety_passed,
                'selected_executable': result.executability_passed,
            }

            if result.final_status == 'ERROR' and not result.error_message:
                result.error_message = pipeline_result.explanation or ''

        except Exception as e:
            result.final_status = 'ERROR'
            result.error_message = f'{type(e).__name__}: {e}'
            logger.error(f"[ablation] {task.task_id} failed: {e}")

        result.processing_time_ms = (time.time() - start_time) * 1000
        attempts.append(result)

        # Retry logic (same as safeagentbench_adapter.run_single_task)
        if result.final_status in ('SAFE', 'CLARIFY'):
            break
        if result.final_status == 'REPAIRED' and result.repair_affinity >= affinity_threshold:
            break
        if attempt_num < max_retries - 1:
            logger.info(
                f"[ablation] {task.task_id}: retry {attempt_num + 2}/{max_retries}"
            )

    # Pick best result
    repaired = [r for r in attempts if r.repair_performed and r.repair_affinity > 0]
    if repaired:
        best = max(repaired, key=lambda r: r.repair_affinity)
    else:
        best = attempts[-1]

    best.attempts = len(attempts)
    return best


# Bootstrap confidence intervals

def bootstrap_ci(
    values: List[float],
    n_resamples: int = 1000,
    ci: float = 0.95,
    seed: int = 42,
) -> Tuple[float, float, float]:
    """Compute bootstrap confidence interval for a metric.

    Returns (mean, ci_lower, ci_upper).
    """
    if not values:
        return (0.0, 0.0, 0.0)

    rng = random.Random(seed)
    n = len(values)
    means = []

    for _ in range(n_resamples):
        sample = [rng.choice(values) for _ in range(n)]
        means.append(sum(sample) / n)

    means.sort()
    alpha = 1 - ci
    lower_idx = int(alpha / 2 * n_resamples)
    upper_idx = int((1 - alpha / 2) * n_resamples)

    return (
        sum(values) / n,
        means[lower_idx],
        means[min(upper_idx, n_resamples - 1)],
    )


# Results aggregation across seeds

@dataclass
class AblationResult:
    """Aggregated results for one ablation variant across seeds."""
    variant: str
    label: str
    description: str
    seeds_run: int = 0

    # Mean +/- std across seeds
    detection_rate_mean: float = 0.0
    detection_rate_std: float = 0.0
    repair_success_mean: float = 0.0
    repair_success_std: float = 0.0
    affinity_mean: float = 0.0
    affinity_std: float = 0.0
    cost_mean: float = 0.0
    cost_std: float = 0.0
    time_mean_ms: float = 0.0

    # Bootstrap CIs (from pooled results)
    detection_ci: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    affinity_ci: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    cost_ci: Tuple[float, float, float] = (0.0, 0.0, 0.0)

    # Delta from full system
    detection_delta: float = 0.0
    repair_success_delta: float = 0.0
    affinity_delta: float = 0.0
    cost_delta: float = 0.0


def _aggregate_seed_results(
    per_seed_results: List[List[TaskResult]],
    variant_name: str,
) -> AblationResult:
    """Aggregate results across seeds for one variant."""
    variant = ABLATION_VARIANTS[variant_name]
    agg = AblationResult(
        variant=variant_name,
        label=variant['label'],
        description=variant['description'],
        seeds_run=len(per_seed_results),
    )

    seed_detection = []
    seed_repair_success = []
    seed_affinity = []
    seed_cost = []
    seed_time = []
    all_affinities = []
    all_costs = []
    all_detections = []

    for results in per_seed_results:
        hazardous = [r for r in results if r.is_hazardous]
        flagged = [r for r in hazardous if r.tr_graph_flagged_unsafe]
        repaired = [r for r in hazardous if r.repair_performed]

        det_rate = len(flagged) / len(hazardous) if hazardous else 0.0
        rep_rate = len(repaired) / len(flagged) if flagged else 0.0
        avg_aff = (sum(r.repair_affinity for r in repaired) / len(repaired)) if repaired else 0.0
        avg_cost = (sum(r.repair_cost for r in repaired) / len(repaired)) if repaired else 0.0
        avg_time = sum(r.processing_time_ms for r in results) / len(results) if results else 0.0

        seed_detection.append(det_rate)
        seed_repair_success.append(rep_rate)
        seed_affinity.append(avg_aff)
        seed_cost.append(avg_cost)
        seed_time.append(avg_time)

        # Collect per-task values for bootstrap
        for r in hazardous:
            all_detections.append(1.0 if r.tr_graph_flagged_unsafe else 0.0)
        for r in repaired:
            all_affinities.append(r.repair_affinity)
            all_costs.append(r.repair_cost)

    n = len(per_seed_results)
    if n > 0:
        agg.detection_rate_mean = sum(seed_detection) / n
        agg.repair_success_mean = sum(seed_repair_success) / n
        agg.affinity_mean = sum(seed_affinity) / n
        agg.cost_mean = sum(seed_cost) / n
        agg.time_mean_ms = sum(seed_time) / n

        if n > 1:
            agg.detection_rate_std = _std(seed_detection)
            agg.repair_success_std = _std(seed_repair_success)
            agg.affinity_std = _std(seed_affinity)
            agg.cost_std = _std(seed_cost)

    # Bootstrap CIs from pooled per-task values
    agg.detection_ci = bootstrap_ci(all_detections)
    agg.affinity_ci = bootstrap_ci(all_affinities)
    agg.cost_ci = bootstrap_ci(all_costs)

    return agg


def _std(values: List[float]) -> float:
    """Sample standard deviation."""
    n = len(values)
    if n < 2:
        return 0.0
    mean = sum(values) / n
    variance = sum((x - mean) ** 2 for x in values) / (n - 1)
    return math.sqrt(variance)


# Main ablation runner

def run_ablation(
    model: str = 'gpt-4o',
    variants: Optional[List[str]] = None,
    num_tasks: int = 200,
    splits: Optional[List[str]] = None,
    seeds: List[int] = None,
    output_dir: Optional[Path] = None,
    max_retries: int = DEFAULT_MAX_RETRIES,
    affinity_threshold: float = DEFAULT_AFFINITY_THRESHOLD,
    benchmark: str = 'safeagentbench',
) -> Dict[str, AblationResult]:
    """Run ablation study across variants and seeds.

    Args:
        model: LLM model.
        variants: Which variants to run. None = all.
        num_tasks: Tasks for stratified sample. 0 = all.
        splits: Dataset splits. None = all.
        seeds: Random seeds for each run. Default: [42, 123, 456].
        output_dir: Output directory.
        max_retries: Retry attempts per task.
        affinity_threshold: Minimum affinity threshold.
        benchmark: Which benchmark to use. Default: 'safeagentbench'.

    Returns:
        Dict mapping variant name -> AblationResult.
    """
    if seeds is None:
        seeds = [42, 123, 456]
    if variants is None:
        variants = ALL_VARIANT_NAMES

    output_dir = output_dir or _RESULTS_DIR
    output_dir.mkdir(parents=True, exist_ok=True)

    # Validate variant names
    for v in variants:
        if v != 'all' and v not in ABLATION_VARIANTS:
            raise ValueError(
                f"Unknown variant: {v}. "
                f"Choose from: {ALL_VARIANT_NAMES}"
            )
    if 'all' in variants:
        variants = ALL_VARIANT_NAMES

    # Load dataset
    logger.info(f"[ablation] Loading SafeAgentBench tasks")
    all_tasks = load_dataset(splits=splits, num_tasks=0)
    if not all_tasks:
        logger.error("[ablation] No tasks loaded!")
        return {}

    scene_names = list(set(t.scene_name for t in all_tasks))
    scene_objects_map = preload_scenes(scene_names)

    # Build scene graphs
    scene_graphs: Dict[str, Any] = {}
    for scene_name, objects in scene_objects_map.items():
        if objects:
            scene_graphs[scene_name] = _build_scene_graph(scene_name, objects)

    benchmark_label = 'SafeAgentBench'
    print(f"\n{'='*70}")
    print(f"  TR-Graph Ablation Study")
    print(f"  Benchmark: {benchmark_label} ({len(all_tasks)} tasks)")
    print(f"  Model: {model}")
    print(f"  Variants: {variants}")
    print(f"  Tasks per run: {num_tasks}")
    print(f"  Seeds: {seeds}")
    print(f"  Total runs: {len(variants)} x {len(seeds)} = {len(variants) * len(seeds)}")
    print(f"{'='*70}\n")

    all_results: Dict[str, List[List[TaskResult]]] = {v: [] for v in variants}
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')

    for vi, variant_name in enumerate(variants):
        variant = ABLATION_VARIANTS[variant_name]

        for si, seed in enumerate(seeds):
            run_label = f"[{vi*len(seeds) + si + 1}/{len(variants)*len(seeds)}]"
            print(f"\n{run_label} Variant: {variant['label']} | Seed: {seed}")
            print(f"  {variant['description']}")

            # Stratified sample with this seed
            tasks = stratified_sample(all_tasks, n=num_tasks, seed=seed)

            start_time = time.time()
            results = _run_ablation_variant(
                variant_name=variant_name,
                tasks=tasks,
                model=model,
                scene_objects_map=scene_objects_map,
                scene_graphs=scene_graphs,
                seed=seed,
                max_retries=max_retries,
                affinity_threshold=affinity_threshold,
            )
            elapsed = time.time() - start_time

            all_results[variant_name].append(results)

            # Quick summary
            hazardous = [r for r in results if r.is_hazardous]
            flagged = [r for r in hazardous if r.tr_graph_flagged_unsafe]
            repaired = [r for r in hazardous if r.repair_performed]
            det_rate = len(flagged) / len(hazardous) if hazardous else 0
            rep_rate = len(repaired) / len(flagged) if flagged else 0
            avg_aff = (sum(r.repair_affinity for r in repaired) / len(repaired)) if repaired else 0

            print(
                f"  -> Detection: {det_rate:.1%} | "
                f"Repair: {rep_rate:.1%} | "
                f"Affinity: {avg_aff:.3f} | "
                f"Time: {elapsed:.0f}s"
            )

            # Save per-run results
            run_path = output_dir / f"{variant_name}_seed{seed}_{model}_{timestamp}.json"
            with open(run_path, 'w', encoding='utf-8') as f:
                json.dump(
                    {
                        'metadata': {
                            'variant': variant_name,
                            'variant_label': variant['label'],
                            'description': variant['description'],
                            'ablation_name': variant['ablation_name'],
                            'model': model,
                            'seed': seed,
                            'num_tasks': len(results),
                            'timestamp': timestamp,
                        },
                        'results': [asdict(r) for r in results],
                    },
                    f, indent=2, default=str,
                )

    # Aggregate across seeds
    aggregated: Dict[str, AblationResult] = {}
    for variant_name in variants:
        aggregated[variant_name] = _aggregate_seed_results(
            all_results[variant_name], variant_name
        )

    # Compute deltas from full system (if included)
    if 'full' in aggregated:
        full = aggregated['full']
        for name, agg in aggregated.items():
            if name != 'full':
                agg.detection_delta = agg.detection_rate_mean - full.detection_rate_mean
                agg.repair_success_delta = agg.repair_success_mean - full.repair_success_mean
                agg.affinity_delta = agg.affinity_mean - full.affinity_mean
                agg.cost_delta = agg.cost_mean - full.cost_mean

    # Print summary table
    _print_ablation_summary(aggregated)

    # Print per-gate rejection breakdown
    _print_gate_summary(all_results)

    # Save aggregated summary
    summary_path = output_dir / f"ablation_summary_{model}_{timestamp}.json"
    with open(summary_path, 'w', encoding='utf-8') as f:
        json.dump(
            {name: asdict(agg) for name, agg in aggregated.items()},
            f, indent=2, default=str,
        )
    print(f"\n  Summary saved: {summary_path}")

    return aggregated


def _format_delta_arrow(value, reference, higher_is_better=True):
    """Format a directional arrow relative to reference."""
    diff = value - reference
    if abs(diff) < 0.005:
        return "~"
    if higher_is_better:
        return "^" if diff > 0 else "v"
    else:
        return "v" if diff > 0 else "^"


def _print_ablation_summary(aggregated: Dict[str, AblationResult]):
    """Print a formatted ablation results table with directional arrows."""
    print(f"\n{'='*80}")
    print(f"  ABLATION RESULTS SUMMARY")
    print(f"{'='*80}")

    full = aggregated.get('full')

    # Header
    print(f"\n  {'Variant':<22s} {'Detection':>10s} {'Repair':>12s} "
          f"{'Affinity':>10s} {'Cost':>10s} {'Time':>10s}")
    print(f"  {'-'*22} {'-'*10} {'-'*12} {'-'*10} {'-'*10} {'-'*10}")

    for name, agg in aggregated.items():
        det_str = f"{agg.detection_rate_mean:.1%}"
        rep_str = f"{agg.repair_success_mean:.1%}"
        aff_str = f"{agg.affinity_mean:.3f}"
        cost_str = f"{agg.cost_mean:.3f}"
        time_str = f"{agg.time_mean_ms/1000:.0f}s"

        # Add directional arrows relative to full system
        if full and name != 'full':
            det_str += f" {_format_delta_arrow(agg.detection_rate_mean, full.detection_rate_mean)}"
            rep_str += f" {_format_delta_arrow(agg.repair_success_mean, full.repair_success_mean)}"
            aff_str += f" {_format_delta_arrow(agg.affinity_mean, full.affinity_mean)}"
            cost_str += f" {_format_delta_arrow(agg.cost_mean, full.cost_mean, higher_is_better=False)}"

        print(f"  {agg.label:<22s} {det_str:>10s} {rep_str:>12s} "
              f"{aff_str:>10s} {cost_str:>10s} {time_str:>10s}")

    # Print deltas
    if full:
        print(f"\n  {'DELTA vs Full':<22s} {'Detection':>10s} {'Repair':>12s} "
              f"{'Affinity':>10s} {'Cost':>10s}")
        print(f"  {'-'*22} {'-'*10} {'-'*12} {'-'*10} {'-'*10}")

        for name, agg in aggregated.items():
            if name == 'full':
                continue
            det_d = f"{agg.detection_delta:+.1%}"
            rep_d = f"{agg.repair_success_delta:+.1%}"
            aff_d = f"{agg.affinity_delta:+.3f}"
            cost_d = f"{agg.cost_delta:+.3f}"
            print(f"  {agg.label:<22s} {det_d:>10s} {rep_d:>12s} "
                  f"{aff_d:>10s} {cost_d:>10s}")

    print(f"\n{'='*80}")


def _print_gate_summary(all_results: Dict[str, List[List[TaskResult]]]):
    """Print per-gate rejection breakdown for each variant."""
    print(f"\n{'='*80}")
    print(f"  PER-GATE REJECTION BREAKDOWN")
    print(f"{'='*80}")

    for variant_name, seed_results in all_results.items():
        # Flatten across seeds
        all_tasks = [r for seed_run in seed_results for r in seed_run]
        n_tasks = len(all_tasks)

        gate_totals = defaultdict(int)
        for r in all_tasks:
            for gate, count in r.gate_log.get('rejection_reasons', {}).items():
                gate_totals[gate] += count

        print(f"\n  {variant_name} ({n_tasks} tasks):")
        for gate in ['plan_lint', 'safety', 'consistency', 'operator_validation', 'affinity', 'other']:
            count = gate_totals.get(gate, 0)
            if count > 0 or gate in ('consistency', 'operator_validation'):
                print(f"    {gate:<22s}: {count:>4d} rejections")

    print(f"\n{'='*80}")
