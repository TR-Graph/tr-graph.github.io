"""
EARBench Adapter — Run TR-Graph on EARBench Physical Risk Awareness Tasks.

Evaluates whether TR-Graph detects physical risks in task instructions
and produces safe repairs. Uses the same pipeline config as SafeAgentBench
(generalization claim).

Metrics:
  - Task Risk Rate (TRR): fraction of tasks where TR-Graph detected the risk
  - Task Effectiveness Rate (TER): fraction of repairs that remain executable
  - Part B repair metrics: repair success, safety rate, executability, affinity, cost

Usage:
    python -m ctr.benchmarks.run_earbench --num-tasks 100 --model gpt-4o
    python -m ctr.benchmarks.run_earbench --model gpt-4o --independent-model gemini-2.5-flash
"""

import csv
import json
import logging
import time
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from ctr.benchmarks.earbench_loader import EARBenchTask, load_dataset
from ctr.benchmarks.safeagentbench_adapter import (
    TaskResult, DEFAULT_MAX_RETRIES, DEFAULT_AFFINITY_THRESHOLD,
    RETRY_TEMPERATURES,
)

logger = logging.getLogger(__name__)

_RESULTS_DIR = Path(__file__).parent.parent.parent / 'results' / 'earbench'


# Scene graph builder

def _build_scene_graph(task: EARBenchTask) -> Any:
    """Build a TR-Graph scene graph from EARBench task context."""
    from ctr.data_structures import (
        SceneGraph, SceneNode, NodeType, ObjectProperties, RegionProperties
    )

    scene_graph = SceneGraph()

    # Add region from scene/environment
    scene_type = task.scene.lower() if task.scene else task.environment.lower()
    if scene_type:
        scene_graph.nodes['region_0'] = SceneNode(
            id='region_0',
            type=NodeType.REGION,
            label=scene_type.replace('_', ' ').title(),
            properties=RegionProperties(region_type=scene_type, accessible=True),
        )

    # Parse objects from the Objects field (comma-separated descriptions)
    objects_text = task.objects or ''
    if objects_text:
        # EARBench objects are descriptive: "desk, chair, computer monitor, ..."
        obj_list = [o.strip() for o in objects_text.split(',') if o.strip()]
        for i, obj_name in enumerate(obj_list):
            # Normalize to PascalCase
            from ctr.interface.app import _normalize_object_name
            normalized = _normalize_object_name(obj_name)
            scene_graph.nodes[f'obj_{i}'] = SceneNode(
                id=f'obj_{i}',
                label=normalized,
                type=NodeType.OBJECT,
                properties=ObjectProperties(),
            )

    return scene_graph


def _get_scene_objects(task: EARBenchTask) -> List[str]:
    """Extract object list from EARBench task."""
    from ctr.interface.app import _normalize_object_name
    objects_text = task.objects or ''
    if not objects_text:
        return []
    return [
        _normalize_object_name(o.strip())
        for o in objects_text.split(',')
        if o.strip()
    ]


# Single task runner

def _run_pipeline_once(
    task: EARBenchTask,
    model: str,
    scene_graph: Any,
    scene_objects: List[str],
    temperature: float = 0.0,
    previously_rejected: Optional[List[Dict[str, Any]]] = None,
) -> TaskResult:
    """Run TR-Graph on a single EARBench task."""
    from ctr.llm_client import create_client
    from ctr.pipeline import CTRPipeline
    from ctr.interface.app import _interface_config, get_provider_for_model

    result = TaskResult(
        task_id=task.task_id,
        split=task.environment,
        instruction=task.instruction,
        scene_name=task.scene,
        is_hazardous=task.is_hazardous,
        risk_category=task.safety_tip[:50] if task.safety_tip else '',
    )

    start_time = time.time()

    try:
        provider = get_provider_for_model(model)
        client = create_client(provider=provider, model=model)
        client.config.temperature = temperature

        config = _interface_config(strict_mode=True)
        config.generate_explanation = False

        pipeline = CTRPipeline(client, config)

        if previously_rejected:
            pipeline._previously_rejected = previously_rejected

        # Run pipeline with scene context from text_observation
        pipeline_result = None
        for phase, phase_result in pipeline.process_streaming(
            task.instruction,
            scene_graph=scene_graph,
            context=task.text_observation or task.scene or "",
            strict_mode=True,
            available_objects=scene_objects,
        ):
            if phase == 'complete':
                pipeline_result = phase_result

        if pipeline_result is None:
            result.final_status = 'ERROR'
            result.error_message = 'Pipeline returned no complete result'
            result.processing_time_ms = (time.time() - start_time) * 1000
            return result

        # Extract results (same as SafeAgentBench adapter)
        result.tr_graph_safe = pipeline_result.is_original_safe
        result.tr_graph_flagged_unsafe = not pipeline_result.is_original_safe
        result.repair_performed = pipeline_result.repair_performed

        if getattr(pipeline_result, 'needs_clarification', False):
            result.final_status = 'CLARIFY'
        elif getattr(pipeline_result, 'is_infeasible', False):
            result.final_status = 'INFEASIBLE'
        elif pipeline_result.repair_performed:
            result.final_status = 'REPAIRED'
        elif pipeline_result.is_original_safe:
            result.final_status = 'SAFE'
        else:
            result.final_status = 'ERROR'
            result.error_message = pipeline_result.explanation or 'Unknown error'

        if pipeline_result.repair_performed and pipeline_result.selected_repair:
            sr = pipeline_result.selected_repair
            if hasattr(sr, 'task_text') and sr.task_text:
                result.repaired_task = sr.task_text
            elif hasattr(sr, 'repaired_task') and sr.repaired_task:
                rt = sr.repaired_task
                if hasattr(rt, 'goal') and rt.goal:
                    result.repaired_task = rt.goal

            if hasattr(sr, 'operators_applied') and sr.operators_applied:
                ops = [
                    op.operator_type.value if hasattr(op.operator_type, 'value')
                    else str(op.operator_type)
                    for op in sr.operators_applied
                ]
                result.operator_used = ', '.join(ops)

        if pipeline_result.repair_cost is not None:
            result.repair_cost = pipeline_result.repair_cost
        if pipeline_result.repair_affinity is not None:
            result.repair_affinity = pipeline_result.repair_affinity

        if hasattr(pipeline_result, 'repair_options') and pipeline_result.repair_options:
            for i, opt in enumerate(pipeline_result.repair_options[:2]):
                opt_text = ''
                if hasattr(opt, 'brief_description'):
                    opt_text = opt.brief_description
                elif hasattr(opt, 'repair_candidate') and opt.repair_candidate:
                    rc = opt.repair_candidate
                    if hasattr(rc, 'repaired_task') and rc.repaired_task:
                        opt_text = getattr(rc.repaired_task, 'goal', '') or ''
                if i == 0:
                    result.repair_option_a = opt_text
                elif i == 1:
                    result.repair_option_b = opt_text

        if hasattr(pipeline_result, 'action_sequence') and pipeline_result.action_sequence:
            result.action_sequence = pipeline_result.action_sequence

        if hasattr(pipeline_result, 'trace') and pipeline_result.trace:
            g = pipeline_result.trace.get('grounding', {})
            result.fully_grounded = g.get('fully_grounded', False)
            result.grounding_confidence = g.get('confidence', 0.0)

        if hasattr(pipeline_result, 'rejected_candidates') and pipeline_result.rejected_candidates:
            result.rejected_candidates = pipeline_result.rejected_candidates

        if result.final_status == 'ERROR' and not result.error_message:
            result.error_message = pipeline_result.explanation or ''

    except Exception as e:
        result.final_status = 'ERROR'
        result.error_message = f'{type(e).__name__}: {str(e)}'
        logger.error(f"[earbench] Task {task.task_id} failed: {e}")
        traceback.print_exc()

    result.processing_time_ms = (time.time() - start_time) * 1000
    return result


def run_single_task(
    task: EARBenchTask,
    model: str,
    scene_graph: Any,
    scene_objects: List[str],
    max_retries: int = DEFAULT_MAX_RETRIES,
    affinity_threshold: float = DEFAULT_AFFINITY_THRESHOLD,
) -> TaskResult:
    """Run TR-Graph on an EARBench task with retry logic."""
    attempts = []
    cumulative_rejections: List[Dict[str, Any]] = []

    for attempt_num in range(max_retries):
        temp = RETRY_TEMPERATURES[min(attempt_num, len(RETRY_TEMPERATURES) - 1)]
        result = _run_pipeline_once(
            task, model, scene_graph, scene_objects,
            temperature=temp,
            previously_rejected=cumulative_rejections if cumulative_rejections else None,
        )
        attempts.append(result)

        for rej in result.rejected_candidates:
            cumulative_rejections.append(rej)

        if result.final_status in ('SAFE', 'CLARIFY'):
            break
        if result.final_status == 'REPAIRED' and result.repair_affinity >= affinity_threshold:
            break
        if attempt_num < max_retries - 1:
            logger.info(f"[earbench] {task.task_id}: retry {attempt_num + 2}/{max_retries}")

    repaired = [r for r in attempts if r.repair_performed and r.repair_affinity > 0]
    if repaired:
        best = max(repaired, key=lambda r: r.repair_affinity)
    else:
        best = attempts[-1]

    best.attempts = len(attempts)

    all_rejections = []
    for i, attempt in enumerate(attempts):
        for rej in attempt.rejected_candidates:
            rej_copy = dict(rej)
            rej_copy['attempt'] = i + 1
            all_rejections.append(rej_copy)
    best.rejected_candidates = all_rejections

    return best


# Batch runner

def _process_task_wrapper(args):
    """Wrapper for parallel execution."""
    task, model, scene_graph, scene_objects, max_retries, affinity_threshold = args
    return run_single_task(
        task, model, scene_graph, scene_objects,
        max_retries=max_retries,
        affinity_threshold=affinity_threshold,
    )


def run_benchmark(
    model: str = 'gpt-4o',
    num_tasks: int = 0,
    environments: Optional[List[str]] = None,
    output_dir: Optional[Path] = None,
    workers: int = 1,
    max_retries: int = DEFAULT_MAX_RETRIES,
    affinity_threshold: float = DEFAULT_AFFINITY_THRESHOLD,
    independent_model: Optional[str] = None,
) -> List[TaskResult]:
    """Run TR-Graph on EARBench tasks.

    Args:
        model: LLM model.
        num_tasks: Max tasks. 0 = all.
        environments: Filter by environment. None = all.
        output_dir: Output directory.
        workers: Parallel workers.
        max_retries: Retry attempts.
        affinity_threshold: Min affinity before retry.
        independent_model: LLM for independent validation.

    Returns:
        List of TaskResult objects.
    """
    output_dir = output_dir or _RESULTS_DIR
    output_dir.mkdir(parents=True, exist_ok=True)

    # Load tasks
    logger.info(f"[earbench] Loading EARBench tasks")
    tasks = load_dataset(num_tasks=num_tasks, environments=environments)
    if not tasks:
        logger.error("[earbench] No tasks loaded!")
        return []

    # Build scene graphs and object lists per task
    total = len(tasks)
    start_time = time.time()

    # Count by environment
    env_counts = {}
    for t in tasks:
        env_counts[t.environment] = env_counts.get(t.environment, 0) + 1

    print(f"\n{'='*60}")
    print(f"  EARBench Benchmark Run")
    print(f"  Model: {model}")
    print(f"  Tasks: {total}")
    print(f"  Environments: {env_counts}")
    print(f"  Workers: {workers}")
    print(f"{'='*60}\n")

    # Build task args
    task_args = []
    for task in tasks:
        scene_objects = _get_scene_objects(task)
        scene_graph = _build_scene_graph(task)
        task_args.append((task, model, scene_graph, scene_objects, max_retries, affinity_threshold))

    results: List[TaskResult] = []

    if workers <= 1:
        for i, args in enumerate(task_args):
            task = args[0]
            print(f"  [{i+1}/{total}] {task.task_id}: {task.instruction[:50]}...", end='\r')
            r = _process_task_wrapper(args)
            results.append(r)
    else:
        with ThreadPoolExecutor(max_workers=workers) as executor:
            future_map = {
                executor.submit(_process_task_wrapper, args): args[0]
                for args in task_args
            }
            completed = 0
            for future in as_completed(future_map):
                task = future_map[future]
                completed += 1
                try:
                    r = future.result(timeout=300)
                    results.append(r)
                except Exception as e:
                    logger.error(f"[earbench] {task.task_id} failed: {e}")
                    results.append(TaskResult(
                        task_id=task.task_id,
                        split=task.environment,
                        instruction=task.instruction,
                        scene_name=task.scene,
                        is_hazardous=task.is_hazardous,
                        final_status='ERROR',
                        error_message=f'{type(e).__name__}: {e}',
                    ))
                print(f"  [{completed}/{total}] completed", end='\r')

        # Sort back to original order
        task_order = {args[0].task_id: i for i, args in enumerate(task_args)}
        results.sort(key=lambda r: task_order.get(r.task_id, 0))

    print()

    total_time = time.time() - start_time
    logger.info(f"[earbench] Completed {total} tasks in {total_time:.1f}s")

    # Independent validation + executability
    if independent_model:
        from ctr.benchmarks.independent_safety import (
            validate_repairs, get_default_validator_model,
            check_executability_batch,
        )
        if independent_model == 'auto':
            independent_model = get_default_validator_model(model)
        val_workers = min(workers, 3)

        # Build scene objects map for validation
        scene_objects_map = {}
        for task in tasks:
            scene_objects_map[task.scene] = _get_scene_objects(task)

        logger.info(f"[earbench] Running independent validation with {independent_model}")
        validate_repairs(results, model=independent_model,
                         scene_objects_map=scene_objects_map, workers=val_workers)
        logger.info(f"[earbench] Running executability check with {independent_model}")
        check_executability_batch(results, model=independent_model,
                                  scene_objects_map=scene_objects_map, workers=val_workers)

    # Save results
    _save_results(results, model, output_dir)

    # Compute and display metrics
    from ctr.benchmarks.metrics import compute_metrics, print_metrics, save_metrics

    metrics = compute_metrics(results, model=f"EARBench ({model})")
    print_metrics(metrics)

    # EARBench-specific metrics
    _print_earbench_metrics(results, tasks)

    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    metrics_path = output_dir / f"metrics_{model}_{timestamp}.json"
    save_metrics(metrics, metrics_path)

    return results


def _print_earbench_metrics(results: List[TaskResult], tasks: List[EARBenchTask]):
    """Print EARBench-specific metrics (TRR, TER)."""
    total = len(results)
    flagged = sum(1 for r in results if r.tr_graph_flagged_unsafe)
    repaired = sum(1 for r in results if r.repair_performed)

    # Task Risk Rate: all EARBench tasks have safety tips, so flagged/total = detection rate
    trr = flagged / total if total > 0 else 0

    # Per-environment breakdown
    env_results = {}
    for r, t in zip(results, tasks):
        env = t.environment or 'unknown'
        if env not in env_results:
            env_results[env] = {'total': 0, 'flagged': 0, 'repaired': 0}
        env_results[env]['total'] += 1
        if r.tr_graph_flagged_unsafe:
            env_results[env]['flagged'] += 1
        if r.repair_performed:
            env_results[env]['repaired'] += 1

    print(f"\n  EARBENCH-SPECIFIC METRICS")
    print(f"  {'-'*50}")
    print(f"  Task Risk Detection Rate:  {trr:6.1%}  ({flagged}/{total} risks detected)")
    print(f"\n  Per-Environment Breakdown:")
    for env, counts in sorted(env_results.items()):
        det = counts['flagged'] / counts['total'] if counts['total'] > 0 else 0
        rep = counts['repaired'] / counts['flagged'] if counts['flagged'] > 0 else 0
        print(f"    {env:<20s}  detect={det:5.1%} ({counts['flagged']}/{counts['total']})"
              f"  repair={rep:5.1%} ({counts['repaired']}/{counts['flagged']})")


def _save_results(results: List[TaskResult], model: str, output_dir: Path):
    """Save results as CSV + JSON."""
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    base_name = f"earbench_{model}_{timestamp}"

    csv_path = output_dir / f"{base_name}.csv"
    fieldnames = [
        'task_id', 'split', 'instruction', 'scene_name', 'is_hazardous',
        'risk_category', 'tr_graph_flagged_unsafe', 'tr_graph_safe',
        'repair_performed', 'repaired_task', 'repair_cost', 'repair_affinity',
        'operator_used', 'repair_option_a', 'repair_option_b',
        'final_status', 'error_message', 'processing_time_ms',
        'independent_safety_passed', 'executability_passed',
        'fully_grounded', 'grounding_confidence', 'attempts',
    ]
    with open(csv_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction='ignore')
        writer.writeheader()
        for r in results:
            writer.writerow(asdict(r))

    json_path = output_dir / f"{base_name}.json"
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(
            {
                'metadata': {
                    'benchmark': 'earbench',
                    'model': model,
                    'timestamp': timestamp,
                    'total_tasks': len(results),
                    'environments': list(set(r.split for r in results)),
                },
                'results': [asdict(r) for r in results],
            },
            f, indent=2, default=str,
        )

    print(f"\n{'='*60}")
    print(f"  CSV: {csv_path}")
    print(f"  JSON: {json_path}")
    print(f"{'='*60}\n")
