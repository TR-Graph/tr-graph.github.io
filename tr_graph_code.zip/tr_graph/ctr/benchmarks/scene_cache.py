"""
Scene Object Cache — Dual-Mode Scene Loading.

Provides scene object lists for AI2-THOR floor plans used by SafeAgentBench
Two modes:

  * Live mode (Linux with AI2-THOR): queries the simulator directly, caches
    results in memory for the duration of the run. Always accurate.
  * Cache mode (Windows or no AI2-THOR): reads from pre-generated JSON files
    in data/scene_cache/. Accurate as long as the AI2-THOR version matches.

The adapter auto-detects which mode to use. On Linux, it prefers live queries.
On Windows, it falls back to disk cache.

Cache files can be generated with: python scripts/cache_safeagentbench_scenes.py
"""

import json
import logging
from pathlib import Path
from typing import Dict, List, Optional, Set

logger = logging.getLogger(__name__)

# In-memory cache: scene_name → sorted list of object type strings.
# Populated on first access per unique floor plan. Shared across all tasks
# in a single run so each floor plan is queried at most once.
_memory_cache: Dict[str, List[str]] = {}

# Disk cache directory
_CACHE_DIR = Path(__file__).parent.parent.parent / 'data' / 'scene_cache'

# Whether we've already checked for AI2-THOR availability
_ai2thor_available: Optional[bool] = None


def _check_ai2thor() -> bool:
    """Check if AI2-THOR is importable and usable."""
    global _ai2thor_available
    if _ai2thor_available is not None:
        return _ai2thor_available
    try:
        from ai2thor.controller import Controller
        _ai2thor_available = True
        logger.info("[scene_cache] AI2-THOR available — will use live queries")
    except ImportError:
        _ai2thor_available = False
        logger.info("[scene_cache] AI2-THOR not available — using disk cache")
    return _ai2thor_available


def _query_ai2thor(scene_name: str) -> List[str]:
    """Query AI2-THOR live for the objects in a scene.

    Returns a sorted, deduplicated list of object type strings.
    Raises RuntimeError if AI2-THOR can't be initialized.
    """
    from ai2thor.controller import Controller

    logger.info(f"[scene_cache] Querying AI2-THOR for {scene_name}...")
    controller = Controller(
        scene=scene_name,
        gridSize=0.25,
        renderDepthImage=False,
        renderInstanceSegmentation=False,
    )

    objects = sorted(set(
        obj['objectType']
        for obj in controller.last_event.metadata['objects']
    ))

    controller.stop()
    logger.info(f"[scene_cache] {scene_name}: {len(objects)} object types")
    return objects


def _read_disk_cache(scene_name: str) -> Optional[List[str]]:
    """Read a cached object list from disk."""
    cache_path = _CACHE_DIR / f'{scene_name}.json'
    if not cache_path.exists():
        return None
    try:
        with open(cache_path, 'r', encoding='utf-8') as f:
            objects = json.load(f)
        if isinstance(objects, list):
            return objects
    except Exception as e:
        logger.warning(f"[scene_cache] Failed to read cache for {scene_name}: {e}")
    return None


def _write_disk_cache(scene_name: str, objects: List[str]) -> None:
    """Write an object list to disk cache for future use."""
    try:
        _CACHE_DIR.mkdir(parents=True, exist_ok=True)
        cache_path = _CACHE_DIR / f'{scene_name}.json'
        with open(cache_path, 'w', encoding='utf-8') as f:
            json.dump(objects, f, indent=2)
        logger.debug(f"[scene_cache] Wrote cache for {scene_name}")
    except Exception as e:
        logger.warning(f"[scene_cache] Failed to write cache for {scene_name}: {e}")


# Rich metadata cache (for scene graph construction with spatial edges)

_RICH_CACHE_DIR = Path(__file__).parent.parent.parent / 'data' / 'scene_cache_rich'
_metadata_cache: Dict[str, dict] = {}


def _query_ai2thor_rich(scene_name: str) -> dict:
    """Query AI2-THOR for full per-object metadata.

    Returns a dict with:
        object_types: List[str] — sorted unique type names 
        objects: List[Dict] — full per-instance metadata for edge derivation
        agent: Dict — robot agent position and state
        scene_name: str
    """
    from ai2thor.controller import Controller

    logger.info(f"[scene_cache] Querying AI2-THOR (rich) for {scene_name}...")
    controller = Controller(
        scene=scene_name,
        gridSize=0.25,
        renderDepthImage=False,
        renderInstanceSegmentation=False,
    )

    event = controller.last_event
    raw_objects = event.metadata['objects']
    agent = event.metadata['agent']

    objects = []
    for obj in raw_objects:
        objects.append({
            'objectId': obj['objectId'],
            'objectType': obj['objectType'],
            'position': obj['position'],
            'parentReceptacles': obj.get('parentReceptacles') or [],
            'receptacleObjectIds': obj.get('receptacleObjectIds') or [],
            'isPickedUp': obj.get('isPickedUp', False),
            'pickupable': obj.get('pickupable', False),
            'openable': obj.get('openable', False),
            'isOpen': obj.get('isOpen', False),
            'visible': obj.get('visible', False),
            'distance': obj.get('distance', float('inf')),
            'isBroken': obj.get('isBroken', False),
            'isCooked': obj.get('isCooked', False),
            'isSliced': obj.get('isSliced', False),
            'temperature': obj.get('temperature', 'RoomTemp'),
            'isFilledWithLiquid': obj.get('isFilledWithLiquid', False),
            'fillLiquid': obj.get('fillLiquid', None),
            'mass': obj.get('mass', None),
        })

    agent_info = {
        'position': agent['position'],
        'reach_distance': 1.5,
    }

    object_types = sorted(set(obj['objectType'] for obj in raw_objects))

    controller.stop()
    logger.info(f"[scene_cache] {scene_name}: {len(objects)} instances, {len(object_types)} types")

    return {
        'object_types': object_types,
        'objects': objects,
        'agent': agent_info,
        'scene_name': scene_name,
    }


def _read_rich_cache(scene_name: str) -> Optional[dict]:
    """Read rich metadata from disk cache."""
    cache_path = _RICH_CACHE_DIR / f'{scene_name}.json'
    if not cache_path.exists():
        return None
    try:
        with open(cache_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if isinstance(data, dict) and 'objects' in data:
            return data
    except Exception as e:
        logger.warning(f"[scene_cache] Failed to read rich cache for {scene_name}: {e}")
    return None


def _write_rich_cache(scene_name: str, metadata: dict) -> None:
    """Write rich metadata to disk cache."""
    try:
        _RICH_CACHE_DIR.mkdir(parents=True, exist_ok=True)
        cache_path = _RICH_CACHE_DIR / f'{scene_name}.json'
        with open(cache_path, 'w', encoding='utf-8') as f:
            json.dump(metadata, f, indent=2)
        logger.debug(f"[scene_cache] Wrote rich cache for {scene_name}")
    except Exception as e:
        logger.warning(f"[scene_cache] Failed to write rich cache for {scene_name}: {e}")


def get_scene_metadata(scene_name: str) -> dict:
    """Get full scene metadata including positions and relationships.

    Resolution order:
      1. In-memory metadata cache
      2. Live AI2-THOR rich query (if available)
      3. Rich disk cache (data/scene_cache_rich/{scene_name}.json)
      4. Fallback: construct minimal metadata from object type list

    Returns:
        Dict with 'object_types', 'objects', 'agent', 'scene_name'.
        'objects' may be empty if only flat list is available.
    """
    if scene_name in _metadata_cache:
        return _metadata_cache[scene_name]

    # Try live AI2-THOR
    if _check_ai2thor():
        try:
            metadata = _query_ai2thor_rich(scene_name)
            _metadata_cache[scene_name] = metadata
            _write_rich_cache(scene_name, metadata)
            return metadata
        except Exception as e:
            logger.warning(f"[scene_cache] Rich AI2-THOR query failed for {scene_name}: {e}")

    # Try rich disk cache
    metadata = _read_rich_cache(scene_name)
    if metadata:
        _metadata_cache[scene_name] = metadata
        return metadata

    # Fallback: minimal metadata from flat object list
    objects = get_scene_objects(scene_name)
    return {
        'object_types': objects,
        'objects': [],  # No instance-level metadata available
        'agent': None,
        'scene_name': scene_name,
    }


# Fallback objects

def _get_fallback_objects(scene_name: str) -> Optional[List[str]]:
    """Last-resort fallback: infer room type from floor plan number and return
    generic objects. Less accurate than live or disk cache but sufficient for
    pipeline testing on Windows without AI2-THOR.
    """
    # Parse floor plan number from scene name like "FloorPlan401"
    import re
    match = re.search(r'(\d+)', scene_name)
    if not match:
        return None

    fp_num = int(match.group(1))

    # AI2-THOR iTHOR room type ranges
    if 1 <= fp_num <= 30:
        room_type = 'kitchen'
    elif 201 <= fp_num <= 230:
        room_type = 'living_room'
    elif 301 <= fp_num <= 330:
        room_type = 'bedroom'
    elif 401 <= fp_num <= 430:
        room_type = 'bathroom'
    else:
        return None

    # Generic object sets per room type (from AI2-THOR common objects).
    # These are approximate — the real set depends on the specific floor plan.
    # Good enough for testing grounding + safety eval + repair on Windows.
    GENERIC_OBJECTS = {
        'kitchen': [
            'Apple', 'Bottle', 'Bowl', 'Bread', 'ButterKnife', 'Cabinet',
            'CoffeeMachine', 'CounterTop', 'Cup', 'DiningTable', 'DishSponge',
            'Drawer', 'Egg', 'Faucet', 'Fork', 'Fridge', 'GarbageCan',
            'HousePlant', 'Kettle', 'Knife', 'Lettuce', 'LightSwitch',
            'Microwave', 'Mug', 'Pan', 'PepperShaker', 'Plate', 'Pot',
            'Potato', 'SaltShaker', 'Shelf', 'SinkBasin', 'SoapBottle',
            'Spatula', 'Spoon', 'StoveBurner', 'StoveKnob', 'Toaster',
            'Tomato', 'Window',
        ],
        'living_room': [
            'ArmChair', 'Book', 'Box', 'CoffeeTable', 'CreditCard',
            'Curtains', 'DeskLamp', 'DiningTable', 'Drawer', 'FloorLamp',
            'GarbageCan', 'HousePlant', 'KeyChain', 'Laptop', 'LightSwitch',
            'Newspaper', 'Ottoman', 'Painting', 'Pen', 'Pencil', 'Pillow',
            'Plate', 'RemoteControl', 'Shelf', 'SideTable', 'Sofa',
            'Statue', 'Television', 'TissueBox', 'Vase', 'Watch', 'Window',
        ],
        'bedroom': [
            'AlarmClock', 'BaseballBat', 'BasketBall', 'Bed', 'Book',
            'Bowl', 'Box', 'CD', 'CellPhone', 'Chair', 'Cloth',
            'CreditCard', 'Curtains', 'Desk', 'DeskLamp', 'Drawer',
            'Dresser', 'GarbageCan', 'HousePlant', 'KeyChain', 'Laptop',
            'LaundryHamper', 'LightSwitch', 'Mirror', 'Mug', 'Painting',
            'Pen', 'Pencil', 'Pillow', 'Poster', 'Shelf', 'TeddyBear',
            'TennisRacket', 'TissueBox', 'Window',
        ],
        'bathroom': [
            'Bathtub', 'BathtubBasin', 'Cabinet', 'Candle', 'Cloth',
            'CounterTop', 'Drawer', 'Faucet', 'GarbageCan', 'HandTowel',
            'HandTowelHolder', 'LightSwitch', 'Mirror', 'PaperTowelRoll',
            'Plunger', 'ShelvingUnit', 'ShowerCurtain', 'ShowerDoor',
            'ShowerGlass', 'ShowerHead', 'SinkBasin', 'SoapBar',
            'SoapBottle', 'SprayBottle', 'Toilet', 'ToiletPaper',
            'ToiletPaperHanger', 'Towel', 'TowelHolder', 'Window',
        ],
    }

    objects = GENERIC_OBJECTS.get(room_type)
    if objects:
        logger.debug(
            f"[scene_cache] Using generic {room_type} objects for {scene_name} "
            f"({len(objects)} types — approximate, not floor-plan-specific)"
        )
    return objects


def get_scene_objects(scene_name: str) -> List[str]:
    """Get the list of object types for an AI2-THOR scene.

    Resolution order:
      1. In-memory cache (from a prior call in this run)
      2. Live AI2-THOR query (if available — preferred on Linux)
      3. Disk cache (data/scene_cache/{scene_name}.json)
      4. Generic fallback by room type (approximate, for Windows testing)

    Returns:
        Sorted list of object type strings (e.g., ["Apple", "Bowl", "Knife", ...]).

    Raises:
        RuntimeError: if no source can provide objects for this scene.
    """
    # . In-memory cache
    if scene_name in _memory_cache:
        return _memory_cache[scene_name]

    # . Live AI2-THOR (preferred on Linux)
    if _check_ai2thor():
        try:
            objects = _query_ai2thor(scene_name)
            _memory_cache[scene_name] = objects
            # Also write to disk cache for future Windows use
            _write_disk_cache(scene_name, objects)
            return objects
        except Exception as e:
            logger.warning(f"[scene_cache] AI2-THOR query failed for {scene_name}: {e}")

    # . Disk cache
    objects = _read_disk_cache(scene_name)
    if objects is not None:
        _memory_cache[scene_name] = objects
        return objects

    # . Generic fallback
    objects = _get_fallback_objects(scene_name)
    if objects is not None:
        _memory_cache[scene_name] = objects
        return objects

    raise RuntimeError(
        f"No scene objects available for '{scene_name}'. "
        f"Options: (a) run on Linux with AI2-THOR installed, "
        f"(b) generate cache with scripts/cache_safeagentbench_scenes.py, "
        f"(c) place {scene_name}.json in data/scene_cache/"
    )


def get_unique_scenes(scene_names: List[str]) -> Set[str]:
    """Return the set of unique scene names from a task list."""
    return set(scene_names)


def preload_scenes(scene_names: List[str]) -> Dict[str, List[str]]:
    """Preload all unique scenes into the memory cache.

    Call this before processing tasks to front-load all AI2-THOR queries
    (or disk reads) so the per-task loop doesn't hit I/O.

    Returns:
        Dict mapping scene_name → object list for all requested scenes.
    """
    unique = get_unique_scenes(scene_names)
    logger.info(f"[scene_cache] Preloading {len(unique)} unique scenes...")

    results = {}
    for scene_name in sorted(unique):
        try:
            results[scene_name] = get_scene_objects(scene_name)
        except RuntimeError as e:
            logger.error(f"[scene_cache] Failed to load {scene_name}: {e}")
            results[scene_name] = []

    logger.info(
        f"[scene_cache] Preloaded {len(results)} scenes "
        f"({sum(len(v) for v in results.values())} total object types)"
    )
    return results


def infer_scene_type(scene_name: str) -> str:
    """Infer room type from AI2-THOR floor plan name."""
    import re
    match = re.search(r'(\d+)', scene_name)
    if match:
        fp_num = int(match.group(1))
        if 1 <= fp_num <= 30:
            return 'kitchen'
        elif 201 <= fp_num <= 230:
            return 'living_room'
        elif 301 <= fp_num <= 330:
            return 'bedroom'
        elif 401 <= fp_num <= 430:
            return 'bathroom'
    return 'home'
