"""
CLI entry point for running TR-Graph on EARBench.

Usage:
    # Test with 50 tasks
    python -m ctr.benchmarks.run_earbench --num-tasks 50 --model gpt-4o

    # Full run
    python -m ctr.benchmarks.run_earbench --model gpt-4o --workers 3

    # Specific environment
    python -m ctr.benchmarks.run_earbench --environment home --num-tasks 100

    # With validation
    python -m ctr.benchmarks.run_earbench --model gpt-4o --independent-model gemini-2.5-flash
"""

import argparse
import logging
import os
import sys

sys.path.insert(0, str(__import__('pathlib').Path(__file__).parent.parent.parent))


def main():
    parser = argparse.ArgumentParser(
        description='Run TR-Graph on EARBench physical risk awareness tasks',
    )

    parser.add_argument('--num-tasks', '-n', type=int, default=0,
                        help='Max tasks to run. 0 = all (default: 0)')
    parser.add_argument('--model', '-m', type=str, default='gpt-4o',
                        help='LLM model (default: gpt-4o)')
    parser.add_argument('--environment', '-e', type=str, nargs='*', default=None,
                        help='Filter by environment (e.g., home, bank, hospital)')
    parser.add_argument('--workers', '-w', type=int, default=1,
                        help='Parallel workers (default: 1)')
    parser.add_argument('--max-retries', type=int, default=3,
                        help='Max retry attempts (default: 3)')
    parser.add_argument('--affinity-threshold', type=float, default=0.4,
                        help='Min affinity before retry (default: 0.4)')
    parser.add_argument('--baseline', type=str, default=None,
                        choices=['cot', 'selp-lite', 'safeplan'],
                        help='Run a baseline instead of TR-Graph.')
    parser.add_argument('--independent-model', type=str, default=None,
                        help='LLM for independent validation. "auto" = auto-pick.')
    parser.add_argument('--output-dir', '-o', type=str, default=None,
                        help='Output directory (default: results/earbench/)')
    parser.add_argument('--verbose', '-v', action='store_true',
                        help='Enable verbose logging')

    args = parser.parse_args()

    log_level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=log_level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    )
    for name in ['httpx', 'httpcore', 'google_genai', 'sentence_transformers',
                 'transformers', 'huggingface_hub', 'urllib3']:
        logging.getLogger(name).setLevel(logging.WARNING)

    try:
        from dotenv import load_dotenv
        load_dotenv()
    except ImportError:
        pass

    model = args.model
    if 'gpt' in model and not os.environ.get('OPENAI_API_KEY'):
        print("Error: OPENAI_API_KEY not set.", file=sys.stderr)
        return 1
    elif 'gemini' in model and not os.environ.get('GOOGLE_API_KEY'):
        print("Error: GOOGLE_API_KEY not set.", file=sys.stderr)
        return 1

    from pathlib import Path

    output_dir = Path(args.output_dir) if args.output_dir else None

    # Baseline mode: reuse SafeAgentBench baseline runners with EARBench tasks
    if args.baseline:
        from ctr.benchmarks.baseline_runners import run_baseline
        from ctr.benchmarks.earbench_loader import load_dataset as load_ear

        # Load EARBench tasks and convert to SafeAgentBenchTask format
        # so the baseline runners can process them
        from ctr.benchmarks.safeagentbench_loader import SafeAgentBenchTask
        ear_tasks = load_ear(num_tasks=args.num_tasks, environments=args.environment)

        # Monkey-patch the loader so baselines load EARBench tasks
        converted = []
        for t in ear_tasks:
            converted.append(SafeAgentBenchTask(
                task_id=t.task_id,
                split=t.environment,
                index_in_split=0,
                instruction=t.instruction,
                scene_name=t.scene,
                is_hazardous=t.is_hazardous,
                risk_category=t.safety_tip[:50] if t.safety_tip else '',
            ))

        # Override the dataset loading in baseline runner
        import ctr.benchmarks.safeagentbench_loader as _loader
        _original_load = _loader.load_dataset
        _loader.load_dataset = lambda **kwargs: converted

        # Override scene cache to return objects from EARBench tasks
        from ctr.interface.app import _normalize_object_name
        ear_objects = {}
        for t in ear_tasks:
            if t.objects:
                obj_list = [_normalize_object_name(o.strip()) for o in t.objects.split(',') if o.strip()]
                ear_objects[t.scene] = obj_list

        import ctr.benchmarks.scene_cache as _cache
        _original_preload = _cache.preload_scenes
        _cache.preload_scenes = lambda scene_names: ear_objects

        try:
            results = run_baseline(
                baseline=args.baseline,
                model=model,
                splits=None,
                num_tasks=0,  # Already limited by load_ear
                output_dir=output_dir or Path(__file__).parent.parent.parent / 'results' / 'earbench',
                workers=args.workers,
                independent_model=args.independent_model,
            )
            return 0
        except KeyboardInterrupt:
            print("\nInterrupted by user.")
            return 1
        except Exception as e:
            print(f"\nError: {e}", file=sys.stderr)
            import traceback
            traceback.print_exc()
            return 1
        finally:
            # Restore original loaders
            _loader.load_dataset = _original_load
            _cache.preload_scenes = _original_preload

    # TR-Graph mode
    from ctr.benchmarks.earbench_adapter import run_benchmark

    try:
        results = run_benchmark(
            model=model,
            num_tasks=args.num_tasks,
            environments=args.environment,
            output_dir=output_dir,
            workers=args.workers,
            max_retries=args.max_retries,
            affinity_threshold=args.affinity_threshold,
            independent_model=args.independent_model,
        )
        return 0
    except KeyboardInterrupt:
        print("\nInterrupted by user.")
        return 1
    except Exception as e:
        print(f"\nError: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        return 1


if __name__ == '__main__':
    sys.exit(main())
