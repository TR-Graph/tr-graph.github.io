"""
AI2-THOR Execution Harness for TR-Graph Benchmark Experiments.

Executes repaired task plans in the AI2-THOR simulator and measures:
  - Step-level success/failure (per action)
  - Overall completion (all steps succeeded)
  - Crash detection (unrecoverable errors)

Supports two action formats:
  - SafeAgentBench: "find Egg", "pick Egg", "put Fridge"
  - TR-Graph pipeline: "GoToObject(robot1, 'Egg')", "PickupObject(robot1, 'Egg')"

Requires Linux with AI2-THOR installed. On Windows, the module loads
but execution functions raise EnvironmentError.

Usage:
    # Execute a single action sequence
    from ctr.benchmarks.execution_harness import execute_plan
    result = execute_plan(
        scene_name="FloorPlan3",
        action_sequence=["find Egg", "pick Egg", "find Fridge", "put Fridge"],
        action_format="safeagentbench",
    )

    # Batch execution on benchmark results
    from ctr.benchmarks.execution_harness import execute_repairs_batch
    execute_repairs_batch(results, scene_objects_map)
"""

import logging
import re
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


# Execution result

@dataclass
class StepResult:
    """Result of executing a single action step."""
    step_index: int
    action_raw: str           # Original action string
    action_name: str          # Normalized action name (e.g., "PickupObject")
    action_args: Dict         # Arguments (objectId, etc.)
    success: bool = False
    error_message: str = ""
    time_ms: float = 0.0


@dataclass
class ExecutionResult:
    """Result of executing a full action sequence."""
    scene_name: str
    total_steps: int = 0
    steps_succeeded: int = 0
    steps_failed: int = 0
    completed: bool = False       # All steps succeeded
    crashed: bool = False         # Unrecoverable error (controller died)
    error_message: str = ""
    step_results: List[StepResult] = field(default_factory=list)
    total_time_ms: float = 0.0

    @property
    def completion_rate(self) -> float:
        """Fraction of steps that succeeded."""
        return self.steps_succeeded / self.total_steps if self.total_steps > 0 else 0.0


# Action format translators

def _parse_safeagentbench_action(action_str: str) -> Tuple[str, Dict]:
    """Parse SafeAgentBench format: "find Egg", "pick Egg", "put Fridge".

    Returns (ai2thor_action_name, kwargs_dict).
    """
    parts = action_str.strip().split(None, 1)
    if not parts:
        return ('', {})

    verb = parts[0].lower()
    arg = parts[1].strip() if len(parts) > 1 else ''

    _ACTION_MAP = {
        'find': ('GetSpawnCoordinatesAboveReceptacle' if not arg else 'ObjectNavExpertAction', {}),
        'pick': ('PickupObject', {'objectId': arg}),
        'put': ('PutObject', {'objectId': arg}),
        'open': ('OpenObject', {'objectId': arg}),
        'close': ('CloseObject', {'objectId': arg}),
        'turn_on': ('ToggleObjectOn', {'objectId': arg}),
        'turn_off': ('ToggleObjectOff', {'objectId': arg}),
        'slice': ('SliceObject', {'objectId': arg}),
        'break': ('BreakObject', {'objectId': arg}),
        'throw': ('ThrowObject', {}),
        'drop': ('DropHandObject', {}),
        'cook': ('CookObject', {'objectId': arg}),
        'dirty': ('DirtyObject', {'objectId': arg}),
        'clean': ('CleanObject', {'objectId': arg}),
        'pour': ('EmptyLiquidFromObject', {}),
        'fillliquid': ('FillObjectWithLiquid', {'objectId': arg}),
        'emptyliquid': ('EmptyLiquidFromObject', {'objectId': arg}),
    }

    if verb in _ACTION_MAP:
        action_name, extra_args = _ACTION_MAP[verb]
        kwargs = {}
        if arg and 'objectId' in extra_args:
            kwargs['objectId'] = arg
        # find is special — needs teleport to object
        if verb == 'find':
            return ('_find', {'objectType': arg})
        return (action_name, kwargs)

    return (verb, {'objectId': arg} if arg else {})


def _parse_trgraph_action(action_str: str) -> Tuple[str, Dict]:
    """Parse TR-Graph pipeline format: "GoToObject(robot1, 'Egg')".

    Returns (ai2thor_action_name, kwargs_dict).
    """
    # Pattern: ActionName(robot1, 'Arg1', 'Arg2', ...)
    match = re.match(r"(\w+)\(([^)]*)\)", action_str.strip())
    if not match:
        return ('', {})

    action_name = match.group(1)
    args_str = match.group(2)

    # Parse arguments — skip 'robot1', extract quoted strings
    quoted = re.findall(r"'([^']*)'", args_str)

    _ACTION_MAP = {
        'GoToObject': '_find',
        'PickupObject': 'PickupObject',
        'PutObject': 'PutObject',
        'OpenObject': 'OpenObject',
        'CloseObject': 'CloseObject',
        'ToggleObjectOn': 'ToggleObjectOn',
        'ToggleObjectOff': 'ToggleObjectOff',
        'SliceObject': 'SliceObject',
        'BreakObject': 'BreakObject',
        'ThrowObject': 'ThrowObject',
        'PushObject': 'PushObject',
        'PullObject': 'PullObject',
        'DropHandObject': 'DropHandObject',
    }

    mapped = _ACTION_MAP.get(action_name, action_name)

    kwargs = {}
    if mapped == '_find' and quoted:
        kwargs['objectType'] = quoted[0]
    elif mapped == 'PutObject' and len(quoted) >= 2:
        kwargs['objectId'] = quoted[0]
        kwargs['receptacleObjectId'] = quoted[1]
    elif quoted:
        kwargs['objectId'] = quoted[0]

    return (mapped, kwargs)


def parse_action(action_str: str, action_format: str = 'auto') -> Tuple[str, Dict]:
    """Parse an action string into (action_name, kwargs).

    Args:
        action_str: The raw action string.
        action_format: "safeagentbench", "trgraph", or "auto" (detect).

    Returns:
        (ai2thor_action_name, kwargs_dict)
    """
    if action_format == 'auto':
        # Detect format: TR-Graph uses parentheses with 'robot1'
        if 'robot1' in action_str or re.match(r'\w+\(', action_str):
            action_format = 'trgraph'
        else:
            action_format = 'safeagentbench'

    if action_format == 'trgraph':
        return _parse_trgraph_action(action_str)
    else:
        return _parse_safeagentbench_action(action_str)


# AI2-THOR controller management

def _check_ai2thor_available():
    """Check if AI2-THOR is available on this system."""
    try:
        import ai2thor
        return True
    except ImportError:
        return False


def _create_controller(scene_name: str):
    """Create and initialize an AI2-THOR controller.

    Returns the controller instance or raises EnvironmentError.
    """
    if not _check_ai2thor_available():
        raise EnvironmentError(
            "AI2-THOR is not installed. Execution requires Linux with "
            "ai2thor installed: pip install ai2thor"
        )

    from ai2thor.controller import Controller

    controller = Controller(
        scene=scene_name,
        gridSize=0.25,
        renderDepthImage=False,
        renderInstanceSegmentation=False,
        width=300,
        height=300,
    )

    return controller


def _find_object_by_type(controller, object_type: str) -> Optional[str]:
    """Find the objectId for an object type in the current scene.

    AI2-THOR objects have IDs like "Egg|+00.97|+00.78|-01.44" but
    action sequences reference them by type ("Egg"). This resolves
    the type to the first matching objectId.
    """
    for obj in controller.last_event.metadata['objects']:
        # Match by type name
        if obj['objectType'] == object_type:
            return obj['objectId']
        # Also try case-insensitive match
        if obj['objectType'].lower() == object_type.lower():
            return obj['objectId']
    return None


def _find_nearest_object(controller, object_type: str) -> Optional[Dict]:
    """Find the nearest interactable instance of an object type."""
    agent_pos = controller.last_event.metadata['agent']['position']
    best = None
    best_dist = float('inf')

    for obj in controller.last_event.metadata['objects']:
        if obj['objectType'].lower() != object_type.lower():
            continue
        obj_pos = obj['position']
        dist = (
            (agent_pos['x'] - obj_pos['x']) ** 2 +
            (agent_pos['z'] - obj_pos['z']) ** 2
        ) ** 0.5
        if dist < best_dist:
            best_dist = dist
            best = obj

    return best


def _execute_find(controller, object_type: str) -> bool:
    """Navigate the agent to an object.

    Uses AI2-THOR's teleport to get near the object.
    SafeAgentBench's 'find' action does this internally.
    """
    target = _find_nearest_object(controller, object_type)
    if target is None:
        return False

    # Teleport near the object
    obj_pos = target['position']
    event = controller.step(
        action='Teleport',
        position=dict(x=obj_pos['x'], y=agent_pos_y(controller), z=obj_pos['z']),
    )

    if not event.metadata['lastActionSuccess']:
        # Try getting spawn coordinates
        event = controller.step(
            action='GetSpawnCoordinatesAboveReceptacle',
            objectId=target['objectId'],
            anywhere=True,
        )
        if event.metadata['lastActionSuccess'] and event.metadata['actionReturn']:
            coords = event.metadata['actionReturn']
            if coords:
                pos = coords[0] if isinstance(coords, list) else coords
                event = controller.step(action='Teleport', position=pos)

    return event.metadata['lastActionSuccess']


def agent_pos_y(controller) -> float:
    """Get the agent's current Y position."""
    return controller.last_event.metadata['agent']['position']['y']


# Single plan execution

def execute_plan(
    scene_name: str,
    action_sequence: List[str],
    action_format: str = 'auto',
    timeout_per_step_ms: float = 10000,
    dialect: str = None,
    grounding_map: Optional[Dict[str, str]] = None,
    scene_metadata: Optional[Dict[str, Any]] = None,
) -> ExecutionResult:
    """Execute an action sequence in AI2-THOR.

    When grounding_map or scene_metadata is provided, uses the
    TRGraphExecutionAdapter with CanonicalAction IR for structured
    parsing and object resolution. Otherwise falls back to legacy
    string-level parsing.

    Args:
        scene_name: AI2-THOR floor plan (e.g., "FloorPlan3").
        action_sequence: List of action strings.
        action_format: "safeagentbench", "trgraph", or "auto".
        timeout_per_step_ms: Max time per step before timeout.
        dialect: Action dialect for adapter path ("safeagentbench", "ai2thor", "franka").
        grounding_map: Optional grounding map from pipeline.
        scene_metadata: Optional scene metadata for object resolution.

    Returns:
        ExecutionResult with per-step and overall results.

    Raises:
        EnvironmentError: If AI2-THOR is not available.
    """
    # Adapter path: structured parsing with CanonicalAction IR
    if dialect and (grounding_map or scene_metadata):
        try:
            from ctr.simulation.execution_adapter import (
                TRGraphExecutionAdapter, get_cached_controller
            )
            controller = get_cached_controller(scene_name)
            adapter = TRGraphExecutionAdapter(
                controller=controller,
                dialect=dialect,
                grounding_map=grounding_map,
                scene_metadata=scene_metadata,
            )
            outcome = adapter.execute(action_sequence)
            # Convert ExecutionOutcome to ExecutionResult
            return ExecutionResult(
                scene_name=scene_name,
                total_steps=outcome.total_steps,
                steps_succeeded=outcome.steps_succeeded,
                steps_failed=outcome.steps_failed,
                completed=outcome.completed,
                total_time_ms=outcome.total_time_ms,
                step_results=[
                    StepResult(
                        step_index=s.step_index,
                        action_raw=s.original_action,
                        action_name=s.resolved_action,
                        action_args=s.resolved_args,
                        success=s.success,
                        error_message=s.error_message,
                        time_ms=s.time_ms,
                    )
                    for s in outcome.step_outcomes
                ],
            )
        except Exception as e:
            logger.warning(f"[execution] Adapter path failed, falling back to legacy: {e}")

    # Legacy path
    result = ExecutionResult(
        scene_name=scene_name,
        total_steps=len(action_sequence),
    )

    if not action_sequence:
        result.completed = True
        return result

    start_time = time.time()
    controller = None

    try:
        controller = _create_controller(scene_name)

        # Use the production executor — it has proper navigation,
        # distance-based receptacle finding, auto-open, and orientation.
        from ctr.simulation.ai2thor_actions import AI2THORActionExecutor
        executor = AI2THORActionExecutor(
            controller,
            enable_video=False,
            session_id='benchmark_exec',
        )

        # Convert action strings to the format the executor expects
        # and execute each one through the production pipeline
        for i, action_str in enumerate(action_sequence):
            step_start = time.time()

            # Parse the action string
            action_name, kwargs = parse_action(action_str, action_format)

            step = StepResult(
                step_index=i,
                action_raw=action_str,
                action_name=action_name,
                action_args=kwargs,
            )

            try:
                # Map parsed action to production executor method
                if action_name == '_find':
                    obj_type = kwargs.get('objectType', '')
                    step.success = executor.GoToObject('robot1', obj_type)
                    if not step.success:
                        step.error_message = f"Could not navigate to {obj_type}"

                elif action_name == 'PickupObject':
                    obj_type = kwargs.get('objectId', '')
                    step.success = executor.PickupObject('robot1', obj_type)
                    if not step.success:
                        step.error_message = f"Could not pick up {obj_type}"

                elif action_name == 'PutObject':
                    put_obj = kwargs.get('objectId', '')
                    receptacle = kwargs.get('receptacleObjectId', put_obj)
                    step.success = executor.PutObject('robot1', put_obj, receptacle)
                    if not step.success:
                        step.error_message = f"Could not put object in/on {receptacle}"

                elif action_name == 'OpenObject':
                    obj_type = kwargs.get('objectId', '')
                    step.success = executor.OpenObject('robot1', obj_type)
                    if not step.success:
                        step.error_message = f"Could not open {obj_type}"

                elif action_name == 'CloseObject':
                    obj_type = kwargs.get('objectId', '')
                    step.success = executor.CloseObject('robot1', obj_type)
                    if not step.success:
                        step.error_message = f"Could not close {obj_type}"

                elif action_name in ('ToggleObjectOn', 'SwitchOn'):
                    obj_type = kwargs.get('objectId', '')
                    step.success = executor.SwitchOn('robot1', obj_type)
                    if not step.success:
                        step.error_message = f"Could not toggle on {obj_type}"

                elif action_name in ('ToggleObjectOff', 'SwitchOff'):
                    obj_type = kwargs.get('objectId', '')
                    step.success = executor.SwitchOff('robot1', obj_type)
                    if not step.success:
                        step.error_message = f"Could not toggle off {obj_type}"

                elif action_name == 'SliceObject':
                    obj_type = kwargs.get('objectId', '')
                    step.success = executor.SliceObject('robot1', obj_type)
                    if not step.success:
                        step.error_message = f"Could not slice {obj_type}"

                elif action_name == 'BreakObject':
                    obj_type = kwargs.get('objectId', '')
                    step.success = executor.BreakObject('robot1', obj_type)
                    if not step.success:
                        step.error_message = f"Could not break {obj_type}"

                elif action_name == 'ThrowObject':
                    obj_type = kwargs.get('objectId', '')
                    step.success = executor.ThrowObject('robot1', obj_type)
                    if not step.success:
                        step.error_message = f"Could not throw {obj_type}"

                elif action_name == 'PushObject':
                    obj_type = kwargs.get('objectId', '')
                    step.success = executor.PushObject('robot1', obj_type)
                    if not step.success:
                        step.error_message = f"Could not push {obj_type}"

                elif action_name == 'PullObject':
                    obj_type = kwargs.get('objectId', '')
                    step.success = executor.PullObject('robot1', obj_type)
                    if not step.success:
                        step.error_message = f"Could not pull {obj_type}"

                elif action_name == 'DropHandObject':
                    step.success = executor.DropHandObject('robot1')
                    if not step.success:
                        step.error_message = "Could not drop object"

                else:
                    # Unknown action — try as generic controller step
                    obj_type = kwargs.get('objectId', '')
                    if obj_type:
                        import re as _re
                        obj_id = None
                        for obj in controller.last_event.metadata.get('objects', []):
                            if _re.match(obj_type, obj['objectId'], _re.IGNORECASE):
                                obj_id = obj['objectId']
                                break
                        if obj_id:
                            event = controller.step(
                                action=action_name,
                                objectId=obj_id,
                                forceAction=True,
                            )
                            step.success = event.metadata.get('lastActionSuccess', False)
                            if not step.success:
                                step.error_message = event.metadata.get('errorMessage', f'{action_name} failed')
                        else:
                            step.success = False
                            step.error_message = f"Unknown action '{action_name}' and object '{obj_type}' not found"
                    else:
                        step.success = False
                        step.error_message = f"Unknown action: {action_name}"

            except Exception as e:
                step.success = False
                step.error_message = f"{type(e).__name__}: {e}"
                logger.warning(f"[execution] Step {i} crashed: {e}")

            step.time_ms = (time.time() - step_start) * 1000

            if step.success:
                result.steps_succeeded += 1
            else:
                result.steps_failed += 1

            result.step_results.append(step)

    except Exception as e:
        result.crashed = True
        result.error_message = f"Controller crash: {type(e).__name__}: {e}"
        logger.error(f"[execution] Controller crash on {scene_name}: {e}")

    finally:
        if controller is not None:
            try:
                controller.stop()
            except Exception:
                pass

    result.total_time_ms = (time.time() - start_time) * 1000
    result.completed = (result.steps_succeeded == result.total_steps)

    return result


# Batch execution on benchmark results

def execute_repairs_batch(
    results: List[Any],
    scene_objects_map: Optional[Dict[str, List[str]]] = None,
    action_format: str = 'auto',
) -> List[Any]:
    """Execute repaired tasks in AI2-THOR and populate executability_passed.

    Only executes tasks where:
    - repair_performed=True
    - action_sequence is non-empty

    Tasks without action sequences are skipped (executability_passed stays None).

    Args:
        results: List of TaskResult dataclass instances.
        scene_objects_map: Not used for execution (kept for API consistency).
        action_format: Action format hint.

    Returns:
        The same results list, with executability_passed populated.
    """
    to_execute = [
        r for r in results
        if r.repair_performed and r.action_sequence
    ]

    if not to_execute:
        logger.info("[execution] No repairs with action sequences to execute.")
        return results

    if not _check_ai2thor_available():
        logger.warning(
            "[execution] AI2-THOR not available. Skipping execution. "
            "Run on Linux with ai2thor installed."
        )
        return results

    logger.info(f"[execution] Executing {len(to_execute)} repairs in AI2-THOR")
    start_time = time.time()

    executed = 0
    completed = 0
    crashed = 0

    for task_result in to_execute:
        logger.info(
            f"[execution] {task_result.task_id}: executing {len(task_result.action_sequence)} steps "
            f"in {task_result.scene_name}"
        )

        exec_result = execute_plan(
            scene_name=task_result.scene_name,
            action_sequence=task_result.action_sequence,
            action_format=action_format,
            dialect=action_format if action_format != 'auto' else None,
            grounding_map=getattr(task_result, 'grounding_map', None),
            scene_metadata=getattr(task_result, 'scene_metadata', None),
        )

        task_result.executability_passed = exec_result.completed
        executed += 1

        if exec_result.completed:
            completed += 1
        if exec_result.crashed:
            crashed += 1

        status = "COMPLETED" if exec_result.completed else "FAILED"
        if exec_result.crashed:
            status = "CRASHED"

        logger.info(
            f"[execution] {task_result.task_id}: {status} "
            f"({exec_result.steps_succeeded}/{exec_result.total_steps} steps, "
            f"{exec_result.total_time_ms:.0f}ms)"
        )

        # Save step-level execution details to the task result
        # so we can diagnose failures from the JSON
        execution_details = {
            'completed': exec_result.completed,
            'crashed': exec_result.crashed,
            'steps_succeeded': exec_result.steps_succeeded,
            'steps_failed': exec_result.steps_failed,
            'total_steps': exec_result.total_steps,
            'total_time_ms': exec_result.total_time_ms,
            'error_message': exec_result.error_message,
            'step_results': [],
        }
        for step in exec_result.step_results:
            step_data = {
                'step': step.step_index,
                'action': step.action_raw,
                'action_name': step.action_name,
                'success': step.success,
                'error': step.error_message,
                'time_ms': step.time_ms,
            }
            execution_details['step_results'].append(step_data)
            if not step.success:
                logger.info(
                    f"  Step {step.step_index}: FAILED {step.action_raw} "
                    f"-- {step.error_message}"
                )

        # Store on the task result — handles both dataclass and dict
        if hasattr(task_result, '__dict__'):
            task_result.execution_details = execution_details
        elif isinstance(task_result, dict):
            task_result['execution_details'] = execution_details

    elapsed = time.time() - start_time
    logger.info(
        f"[execution] Executed {executed} repairs in {elapsed:.1f}s -- "
        f"{completed} completed, {executed - completed - crashed} failed, "
        f"{crashed} crashed"
    )

    return results


# Standalone execution from saved results

def execute_from_json(
    json_path: str,
    action_format: str = 'auto',
) -> str:
    """Load results from JSON, execute repairs in AI2-THOR, save updated JSON.

    Args:
        json_path: Path to the results JSON file.
        action_format: Action format hint.

    Returns:
        Path to the updated JSON file.
    """
    import json as _json
    from dataclasses import asdict
    from ctr.benchmarks.safeagentbench_adapter import TaskResult

    with open(json_path, 'r', encoding='utf-8') as f:
        data = _json.load(f)

    # Reconstruct TaskResult objects
    results = []
    for r_dict in data.get('results', []):
        tr = TaskResult(
            task_id=r_dict['task_id'],
            split=r_dict['split'],
            instruction=r_dict['instruction'],
            scene_name=r_dict['scene_name'],
            is_hazardous=r_dict['is_hazardous'],
        )
        for field_name in [
            'risk_category', 'tr_graph_flagged_unsafe', 'tr_graph_safe',
            'repair_performed', 'repaired_task', 'repair_cost', 'repair_affinity',
            'operator_used', 'repair_option_a', 'repair_option_b',
            'final_status', 'error_message', 'processing_time_ms',
            'independent_safety_passed', 'executability_passed',
            'fully_grounded', 'grounding_confidence',
            'attempts', 'rejected_candidates', 'action_sequence',
        ]:
            if field_name in r_dict:
                setattr(tr, field_name, r_dict[field_name])
        results.append(tr)

    # Execute
    execute_repairs_batch(results, action_format=action_format)

    # Write back — merge asdict with dynamically added execution_details
    for i, r in enumerate(results):
        r_dict = asdict(r)
        # Include execution_details which is dynamically added (not a dataclass field)
        if hasattr(r, 'execution_details'):
            r_dict['execution_details'] = r.execution_details
        data['results'][i] = r_dict

    data['metadata']['execution_verified'] = True

    with open(json_path, 'w', encoding='utf-8') as f:
        _json.dump(data, f, indent=2, default=str)

    logger.info(f"[execution] Updated results saved to {json_path}")
    return json_path
