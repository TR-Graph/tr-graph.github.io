"""
EARBench Dataset Loader.

Loads the EARBench dataset for evaluating physical risk awareness
in embodied AI task planning.

Dataset: 2,636 tasks across 7 domains (home, commercial, medical, etc.)
Source: https://github.com/zihao-ai/EARBench

Each task has:
  - Environment + Scene context
  - Safety tip + explanation (ground truth risk)
  - Task instruction
  - Objects with positions and attributes
  - Text observation (scene description from robot's perspective)
"""

import csv
import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

_DATA_DIR = Path(__file__).parent.parent.parent / 'data' / 'benchmarks' / 'earbench'
_DATASET_URL = "https://raw.githubusercontent.com/zihao-ai/EARBench/main/dataset.csv"


@dataclass
class EARBenchTask:
    """A single task from the EARBench dataset."""

    # Identity
    task_id: str
    environment: str = ""          # e.g., "home", "bank", "hospital"
    scene: str = ""                # e.g., "kitchen", "lobby"

    # Core fields
    instruction: str = ""          # The task command
    text_observation: str = ""     # Scene description from robot's perspective
    objects: str = ""              # Objects in the scene
    objects_positions: str = ""    # Object positions
    objects_attributes: str = ""   # Object attributes

    # Safety ground truth
    safety_tip: str = ""           # The safety concern (ground truth)
    tip_explanation: str = ""      # Why it's a safety concern
    is_hazardous: bool = True      # All EARBench tasks have safety tips

    # Image (optional)
    image_path: str = ""


def _download_dataset() -> Path:
    """Download dataset.csv from GitHub if not cached locally."""
    _DATA_DIR.mkdir(parents=True, exist_ok=True)
    csv_path = _DATA_DIR / 'dataset.csv'

    if csv_path.exists():
        logger.info(f"[earbench] Using cached dataset: {csv_path}")
        return csv_path

    logger.info(f"[earbench] Downloading dataset from {_DATASET_URL}")
    try:
        import urllib.request
        urllib.request.urlretrieve(_DATASET_URL, str(csv_path))
        logger.info(f"[earbench] Downloaded to {csv_path}")
        return csv_path
    except Exception as e:
        logger.error(f"[earbench] Download failed: {e}")
        raise RuntimeError(
            f"Failed to download EARBench dataset. "
            f"Download manually from {_DATASET_URL} to {csv_path}"
        ) from e


def load_dataset(
    num_tasks: int = 0,
    environments: Optional[List[str]] = None,
    data_dir: Optional[Path] = None,
) -> List[EARBenchTask]:
    """Load EARBench tasks.

    Args:
        num_tasks: Max tasks to load. 0 = all.
        environments: Filter by environment type. None = all.
        data_dir: Override data directory.

    Returns:
        List of EARBenchTask objects.
    """
    data_dir = data_dir or _DATA_DIR
    csv_path = data_dir / 'dataset.csv'

    if not csv_path.exists():
        csv_path = _download_dataset()

    tasks = []
    try:
        with open(csv_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for i, row in enumerate(reader):
                environment = (row.get('Environment') or '').strip()

                # Filter by environment if specified
                if environments and environment.lower() not in [e.lower() for e in environments]:
                    continue

                task = EARBenchTask(
                    task_id=row.get('ID') or f"ear_{i:04d}",
                    environment=environment,
                    scene=row.get('Scene') or '',
                    instruction=row.get('Instruction') or '',
                    text_observation=row.get('Text Observation') or '',
                    objects=row.get('Objects') or '',
                    objects_positions=row.get('Objects Positions') or '',
                    objects_attributes=row.get('Objects Attributes') or '',
                    safety_tip=row.get('Safety Tip') or '',
                    tip_explanation=row.get('Tip Explanation') or '',
                    is_hazardous=True,  # All EARBench tasks have safety concerns
                    image_path=row.get('Matched Image Path') or '',
                )

                if task.instruction:
                    tasks.append(task)

                if num_tasks > 0 and len(tasks) >= num_tasks:
                    break

    except Exception as e:
        logger.error(f"[earbench] Failed to load dataset: {e}")
        raise

    # Count by environment
    env_counts = {}
    for t in tasks:
        env_counts[t.environment] = env_counts.get(t.environment, 0) + 1

    logger.info(
        f"[earbench] Loaded {len(tasks)} tasks across "
        f"{len(env_counts)} environments: {env_counts}"
    )

    return tasks
