"""
SafeAgentBench Dataset Loader.

Downloads and parses the SafeAgentBench dataset (750 tasks across 4 splits).
Handles format quirks: abstract instruction expansion, action normalization,
risk category cleanup.

Dataset source: https://huggingface.co/datasets/safeagentbench/SafeAgentBench
Paper: https://arxiv.org/abs/2412.13178
"""

import json
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

# HuggingFace raw file URLs for each split
_HF_BASE = "https://huggingface.co/datasets/safeagentbench/SafeAgentBench/resolve/main"
_SPLIT_FILES = {
    'unsafe_detailed': f'{_HF_BASE}/unsafe_detailed.jsonl',
    'safe_detailed': f'{_HF_BASE}/safe_detailed.jsonl',
    'abstract': f'{_HF_BASE}/abstract.jsonl',
    'long_horizon': f'{_HF_BASE}/long_horizon.jsonl',
}

# Local cache directory for downloaded dataset files
_DATA_DIR = Path(__file__).parent.parent.parent / 'data' / 'benchmarks' / 'safeagentbench'


# Task data structure

@dataclass
class SafeAgentBenchTask:
    """A single task from the SafeAgentBench dataset, normalized for TR-Graph."""

    # Identity
    task_id: str                        # e.g., "unsafe_detailed_042"
    split: str                          # "unsafe_detailed", "safe_detailed", "abstract", "long_horizon"
    index_in_split: int                 # 0-based index within the split

    # Core fields
    instruction: str                    # The natural language task command
    scene_name: str                     # AI2-THOR floor plan ID, e.g., "FloorPlan401"

    # Safety metadata
    is_hazardous: bool                  # True for unsafe/abstract/long_horizon tasks
    risk_category: str = ""             # Free-text hazard label (cleaned)

    # Ground truth (not always available)
    ground_truth_plan: List[str] = field(default_factory=list)  # Action steps
    final_state: Optional[List[Dict]] = None                    # Expected object states

    # Abstract task metadata
    abstraction_level: int = 0          # 0=not abstract, 1-4 for abstract tasks (1=most concrete)

    # Long-horizon metadata
    has_embedded_requirement: bool = False

    # Paired safe instruction (safe_detailed only)
    risk_instruction: str = ""          # The hazardous version of a safe task


def _normalize_risk_category(raw: str) -> str:
    """Clean up inconsistent risk_category strings.

    SafeAgentBench has ~50 variants like "Risk: Fire Hazard", "Fire Hazard",
    "Risk Category: Liquid and Spill Damage", etc. Normalize to a clean label.
    """
    if not raw:
        return "unknown"
    # Strip common prefixes
    cleaned = re.sub(r'^(Risk\s*(?:Category)?\s*:\s*)', '', raw, flags=re.IGNORECASE).strip()
    # Collapse whitespace
    cleaned = re.sub(r'\s+', ' ', cleaned)
    return cleaned if cleaned else "unknown"


def _normalize_action_step(step: str) -> str:
    """Normalize action step format.

    Handles: "turn on X" vs "turn_on X", case inconsistencies.
    """
    step = step.strip()
    # Normalize "turn on" / "turn off" (space vs underscore)
    step = re.sub(r'^turn[\s_]on\b', 'turn_on', step, flags=re.IGNORECASE)
    step = re.sub(r'^turn[\s_]off\b', 'turn_off', step, flags=re.IGNORECASE)
    # Normalize "toggle on" / "toggle off" → turn_on / turn_off
    step = re.sub(r'^toggle[\s_]on\b', 'turn_on', step, flags=re.IGNORECASE)
    step = re.sub(r'^toggle[\s_]off\b', 'turn_off', step, flags=re.IGNORECASE)
    return step


# Download helpers

def _download_file(url: str, dest: Path) -> bool:
    """Download a file from URL to dest. Returns True on success."""
    import urllib.request

    dest.parent.mkdir(parents=True, exist_ok=True)
    logger.info(f"[loader] Downloading {url} → {dest}")
    try:
        urllib.request.urlretrieve(url, str(dest))
        logger.info(f"[loader] Downloaded: {dest.name} ({dest.stat().st_size:,} bytes)")
        return True
    except Exception as e:
        logger.error(f"[loader] Download failed: {e}")
        return False


def _ensure_split_file(split: str) -> Path:
    """Ensure the JSONL file for a split exists locally. Download if needed."""
    local_path = _DATA_DIR / f'{split}.jsonl'
    if local_path.exists():
        return local_path

    url = _SPLIT_FILES.get(split)
    if not url:
        raise ValueError(f"Unknown split: '{split}'. Valid: {list(_SPLIT_FILES.keys())}")

    if not _download_file(url, local_path):
        raise RuntimeError(f"Failed to download {split} dataset from {url}")

    return local_path


# Dataset loading

def load_split(
    split: str,
    num_tasks: int = 0,
) -> List[SafeAgentBenchTask]:
    """Load a single split of the SafeAgentBench dataset.

    Args:
        split: One of "unsafe_detailed", "safe_detailed", "abstract", "long_horizon".
        num_tasks: Maximum number of tasks to load. 0 = load all.

    Returns:
        List of SafeAgentBenchTask objects, normalized and ready for TR-Graph.
    """
    file_path = _ensure_split_file(split)

    # Read raw JSONL
    raw_entries = []
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line:
                raw_entries.append(json.loads(line))

    logger.info(f"[loader] Loaded {len(raw_entries)} raw entries from {split}")

    # Parse into SafeAgentBenchTask objects
    tasks = []

    if split == 'abstract':
        # Abstract split: each entry has instruction=[str, str, str, str]
        # Expand into 4 tasks per entry (concrete → abstract)
        for i, entry in enumerate(raw_entries):
            instructions = entry.get('instruction', [])
            if not isinstance(instructions, list) or len(instructions) != 4:
                logger.warning(f"[loader] abstract entry {i}: unexpected instruction format, skipping")
                continue

            for level, instr_text in enumerate(instructions, start=1):
                tasks.append(SafeAgentBenchTask(
                    task_id=f"abstract_{i:03d}_L{level}",
                    split='abstract',
                    index_in_split=i,
                    instruction=instr_text,
                    scene_name=entry.get('scene_name', ''),
                    is_hazardous=True,
                    risk_category=_normalize_risk_category(entry.get('risk_category', '')),
                    ground_truth_plan=[
                        _normalize_action_step(s) for s in entry.get('step', [])
                    ],
                    final_state=entry.get('final_state'),
                    abstraction_level=level,
                ))

    elif split == 'long_horizon':
        # Long-horizon: only scene_name + instruction (no step, no final_state)
        for i, entry in enumerate(raw_entries):
            instr = entry.get('instruction', '')
            tasks.append(SafeAgentBenchTask(
                task_id=f"long_horizon_{i:03d}",
                split='long_horizon',
                index_in_split=i,
                instruction=instr,
                scene_name=entry.get('scene_name', ''),
                is_hazardous=True,
                has_embedded_requirement='requirement' in instr.lower(),
            ))

    elif split == 'safe_detailed':
        for i, entry in enumerate(raw_entries):
            tasks.append(SafeAgentBenchTask(
                task_id=f"safe_detailed_{i:03d}",
                split='safe_detailed',
                index_in_split=i,
                instruction=entry.get('instruction', ''),
                scene_name=entry.get('scene_name', ''),
                is_hazardous=False,
                ground_truth_plan=[
                    _normalize_action_step(s) for s in entry.get('step', [])
                ],
                final_state=entry.get('final_state'),
                risk_instruction=entry.get('risk_instruction', ''),
            ))

    elif split == 'unsafe_detailed':
        for i, entry in enumerate(raw_entries):
            tasks.append(SafeAgentBenchTask(
                task_id=f"unsafe_detailed_{i:03d}",
                split='unsafe_detailed',
                index_in_split=i,
                instruction=entry.get('instruction', ''),
                scene_name=entry.get('scene_name', ''),
                is_hazardous=True,
                risk_category=_normalize_risk_category(entry.get('risk_category', '')),
                ground_truth_plan=[
                    _normalize_action_step(s) for s in entry.get('step', [])
                ],
                final_state=entry.get('final_state'),
            ))

    else:
        raise ValueError(f"Unknown split: '{split}'")

    # Apply num_tasks limit
    if num_tasks > 0 and len(tasks) > num_tasks:
        tasks = tasks[:num_tasks]
        logger.info(f"[loader] Limited to {num_tasks} tasks")

    logger.info(
        f"[loader] {split}: {len(tasks)} tasks ready "
        f"({sum(1 for t in tasks if t.is_hazardous)} hazardous, "
        f"{sum(1 for t in tasks if not t.is_hazardous)} safe)"
    )
    return tasks


def load_dataset(
    splits: Optional[List[str]] = None,
    num_tasks: int = 0,
) -> List[SafeAgentBenchTask]:
    """Load multiple splits of SafeAgentBench and combine them.

    Args:
        splits: List of split names to load. None = load all 4 splits.
        num_tasks: Maximum TOTAL tasks across all splits. 0 = load all.
            Applied per-split proportionally if loading multiple splits.

    Returns:
        Combined list of SafeAgentBenchTask objects.
    """
    if splits is None:
        splits = ['unsafe_detailed', 'safe_detailed', 'abstract', 'long_horizon']

    all_tasks = []
    for split in splits:
        # If num_tasks is set and we're loading multiple splits,
        # distribute the limit roughly proportionally.
        if num_tasks > 0 and len(splits) > 1:
            per_split = max(1, num_tasks // len(splits))
        else:
            per_split = num_tasks

        tasks = load_split(split, num_tasks=per_split)
        all_tasks.extend(tasks)

    # Final trim if total exceeds requested
    if num_tasks > 0 and len(all_tasks) > num_tasks:
        all_tasks = all_tasks[:num_tasks]

    logger.info(
        f"[loader] Total: {len(all_tasks)} tasks from {len(splits)} split(s) "
        f"({sum(1 for t in all_tasks if t.is_hazardous)} hazardous, "
        f"{sum(1 for t in all_tasks if not t.is_hazardous)} safe)"
    )
    return all_tasks


def get_split_info() -> Dict[str, Dict]:
    """Return metadata about available splits (without loading them)."""
    return {
        'unsafe_detailed': {
            'description': 'Hazardous tasks with explicit instructions and ground-truth plans',
            'expected_count': 300,
            'has_ground_truth': True,
            'is_hazardous': True,
        },
        'safe_detailed': {
            'description': 'Safe tasks paired with risky alternatives',
            'expected_count': 300,
            'has_ground_truth': True,
            'is_hazardous': False,
        },
        'abstract': {
            'description': 'Hazardous tasks at 4 abstraction levels (expands to 400 tasks)',
            'expected_count': 400,  # 100 entries × 4 levels
            'has_ground_truth': True,
            'is_hazardous': True,
        },
        'long_horizon': {
            'description': 'Multi-step tasks with embedded safety requirements',
            'expected_count': 50,
            'has_ground_truth': False,
            'is_hazardous': True,
        },
    }
