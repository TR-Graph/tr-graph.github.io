"""
TR-Graph Task Repair: Core Data Structures
=================================================

This module defines the foundational data structures for the TR-Graph system.
All components of the pipeline operate on these schemas.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Dict, Set, Optional, Any, Tuple, Union
from datetime import datetime


# ENUMERATIONS

class NodeType(Enum):
    """Types of nodes in the scene graph."""
    OBJECT = "object"
    PERSON = "person"
    AGENT = "agent"
    REGION = "region"
    SURFACE = "surface"


class AgeGroup(Enum):
    """Age group categories for persons."""
    INFANT = "infant"      # 0-2 years
    CHILD = "child"        # 3-12 years
    TEEN = "teen"          # 13-17 years
    ADULT = "adult"        # 18-64 years
    ELDERLY = "elderly"    # 65+ years


class Capability(Enum):
    """Capability levels for persons."""
    LIMITED = "limited"
    NORMAL = "normal"


class Awareness(Enum):
    """Safety awareness levels."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class HazardLevel(Enum):
    """Hazard severity levels."""
    NONE = "none"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class Sharpness(Enum):
    """Sharpness categories for objects."""
    DULL = "dull"
    MODERATE = "moderate"
    SHARP = "sharp"


class ObjectState(Enum):
    """Common object states."""
    ON = "on"
    OFF = "off"
    OPEN = "open"
    CLOSED = "closed"
    FULL = "full"
    EMPTY = "empty"
    BROKEN = "broken"
    INTACT = "intact"


class RelationType(Enum):
    """Types of relationships between nodes.

    Location:      object in a region
    Support:       object resting on a surface — ON is the only support
                   edge, always child→surface direction (plate ON table).
                   We do not add a separate SUPPORTS type because it is
                   the inverse of ON and would double edges without adding
                   information. If the paper says "support relation," ON
                   is the implementation.
    Containment:   object inside a container, or container holds object
    Proximity:     spatial closeness between entities
    Accessibility: REACHABLE_BY direction is always object→robot/person.
                   Read as "this object is reachable by the robot."
                   The inverse reading ("robot can reach object") is
                   equivalent; the direction convention is fixed for
                   consistency across all construction paths.
    Interaction:   person currently engaging with object
    Spatial:       directional relationships
    """
    # Location
    LOCATED_IN = "located_in"

    # Support (ON = child→surface direction)
    ON = "on"

    # Containment
    INSIDE = "inside"           # object inside container (child→parent)
    CONTAINS = "contains"       # container holds object (parent→child)

    # Proximity
    NEAR = "near"
    ADJACENT_TO = "adjacent_to"

    # Accessibility
    REACHABLE_BY = "reachable_by"   # object reachable by robot/person

    # Interaction
    HOLDING = "holding"             # person gripping object
    INTERACTING_WITH = "interacting_with"

    # Spatial/directional
    FACING = "facing"
    BEHIND = "behind"
    ABOVE = "above"
    BELOW = "below"


class ConstraintTier(Enum):
    """Constraint priority tiers."""
    SOCIETAL = 1      # Universal safety rules - never relaxable
    ORGANIZATIONAL = 2 # Context-specific policies - rarely relaxable
    INDIVIDUAL = 3     # Person-specific preferences - relaxable


class ViolationSeverity(Enum):
    """Severity levels for constraint violations."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class OperatorType(Enum):
    """Types of repair operators."""
    SUBSTITUTE = "substitute"
    CONSTRAIN = "constrain"
    DECOMPOSE = "decompose"
    RELAX = "relax"
    REORDER = "reorder"
    RETARGET = "retarget"


class VariableType(Enum):
    """Types of task variables (for cost weighting)."""
    GOAL = "goal"
    ACTION = "action"
    OBJECT = "object"
    PARAMETER = "parameter"
    CONSTRAINT = "constraint"
    PREFERENCE = "preference"
    PLAN = "plan"


class TaskFrame(Enum):
    """Semantic frame types for task classification (Fillmore, 1976)."""
    TRANSFER = "transfer"           # Giving, handing, delivering to someone
    MANIPULATION = "manipulation"   # Cutting, pouring, operating on an object
    PLACEMENT = "placement"         # Putting, storing, setting down
    NAVIGATION = "navigation"       # Moving, going, approaching a location
    PREPARATION = "preparation"     # Cooking, assembling, mixing
    MONITORING = "monitoring"       # Watching, checking, guarding
    STATE_CHANGE = "state_change"   # Turning on/off, lighting, opening/closing
    GENERAL = "general"             # Unclassified or composite tasks


class DefectType(Enum):
    """Types of task defects detected during safety evaluation."""
    PHYSICAL_SAFETY = "physical_safety"       # Risk of bodily harm
    NORMATIVE = "normative"                   # Privacy, dignity, consent violation
    CONTEXTUAL = "contextual"                 # Wrong time, place, or sequence
    AUTONOMY = "autonomy"                     # Undermines person's agency
    FEASIBILITY = "feasibility"               # Required resource not available


class HazardType(Enum):
    """Hazard categories from ISO 12100 and extended for domestic robotics."""
    MECHANICAL = "mechanical"       # Cutting, crushing, impact, entanglement
    THERMAL = "thermal"             # Burns, scalds, fire
    CHEMICAL = "chemical"           # Poisoning, contamination, chemical burns
    BIOLOGICAL = "biological"       # Infection, allergen exposure
    ELECTRICAL = "electrical"       # Shock, electrical fire
    ERGONOMIC = "ergonomic"         # Strain, overexertion, falls
    NORMATIVE = "normative"         # Privacy, dignity, consent (non-physical)
    CONTEXTUAL = "contextual"       # Timing, sequencing, environmental state
    AUTONOMY = "autonomy"           # Agency, independence, decision-making


# WORLD REPRESENTATION (W)

@dataclass
class ObjectProperties:
    """Properties for Object-type nodes."""
    temperature: Optional[float] = None          # Celsius
    sharpness: Optional[Sharpness] = None
    mass: Optional[float] = None                 # kg
    state: Optional[ObjectState] = None
    affordances: Set[str] = field(default_factory=set)  # e.g., {"pour", "cut", "hold_liquid"}
    hazard_level: HazardLevel = HazardLevel.NONE
    child_safe: bool = True
    material: Optional[str] = None
    fragile: bool = False
    consumable: bool = False
    # Domain-specific
    contains: Optional[str] = None               # What the container holds
    capacity: Optional[float] = None             # ml or units


@dataclass
class PersonProperties:
    """Properties for Person-type nodes."""
    age: Optional[int] = None                    # Years
    age_group: Optional[AgeGroup] = None
    name: Optional[str] = None
    physical_capability: Capability = Capability.NORMAL
    cognitive_capability: Capability = Capability.NORMAL
    safety_awareness: Awareness = Awareness.MEDIUM
    # Safety-relevant attributes
    allergies: Set[str] = field(default_factory=set)
    mobility_limited: bool = False
    requires_supervision: bool = False


@dataclass
class AgentProperties:
    """Properties for Agent-type nodes (the robot)."""
    reach_distance: float = 1.0                  # meters
    gripper_capacity: float = 5.0                # kg
    current_holding: Optional[str] = None        # Object ID if holding something
    battery_level: float = 1.0                   # 0.0 to 1.0


@dataclass
class RegionProperties:
    """Properties for Region-type nodes."""
    region_type: str = ""                        # "kitchen", "bathroom", etc.
    accessible: bool = True
    hazardous: bool = False
    bounds: Optional[Dict[str, float]] = None    # Spatial bounds if known


@dataclass
class SceneNode:
    """A node in the scene graph."""
    id: str
    type: NodeType
    label: str                                   # Human-readable name
    properties: Union[ObjectProperties, PersonProperties, AgentProperties, RegionProperties]
    position: Optional[Tuple[float, float, float]] = None  # (x, y, z) if known
    confidence: float = 1.0                      # Perception confidence


@dataclass
class SceneEdge:
    """An edge (relationship) in the scene graph."""
    source_id: str
    target_id: str
    relation: RelationType
    confidence: float = 1.0
    metadata: Dict[str, Any] = field(default_factory=dict)  # e.g., {"distance": 0.5}


@dataclass
class SceneGraph:
    """
    Complete world representation W = (V, E, Φ).
    
    The scene graph captures all entities, their properties,
    and relationships relevant to task execution.
    """
    nodes: Dict[str, SceneNode] = field(default_factory=dict)  # id -> node
    edges: List[SceneEdge] = field(default_factory=list)
    timestamp: Optional[datetime] = None
    perception_confidence: float = 1.0

    # Situation Awareness (Endsley, 1995)
    situation_description: str = ""    # Level 2: what is happening in the scene
    projected_outcome: str = ""        # Level 3: what will happen if the task executes
    
    def get_node(self, node_id: str) -> Optional[SceneNode]:
        """Retrieve a node by ID."""
        return self.nodes.get(node_id)
    
    def get_nodes_by_type(self, node_type: NodeType) -> List[SceneNode]:
        """Get all nodes of a specific type."""
        return [n for n in self.nodes.values() if n.type == node_type]
    
    def get_edges_from(self, source_id: str) -> List[SceneEdge]:
        """Get all edges originating from a node."""
        return [e for e in self.edges if e.source_id == source_id]
    
    def get_edges_to(self, target_id: str) -> List[SceneEdge]:
        """Get all edges pointing to a node."""
        return [e for e in self.edges if e.target_id == target_id]
    
    def get_relation(self, source_id: str, target_id: str) -> Optional[SceneEdge]:
        """Get the edge between two specific nodes."""
        for e in self.edges:
            if e.source_id == source_id and e.target_id == target_id:
                return e
        return None

    def scene_signature(self) -> str:
        """Stable semantic signature for cache keys.

        Built from sorted tuples of (node.type, node.label, key properties)
        rather than node IDs like obj_0 which collide across different scenes.
        """
        import hashlib
        parts = []
        for node in sorted(self.nodes.values(), key=lambda n: (n.type.value, n.label)):
            key_props = ""
            if node.type == NodeType.OBJECT:
                props = node.properties
                key_props = f"|temp={getattr(props, 'temperature', None)}|sharp={getattr(props, 'sharpness', None)}"
            elif node.type == NodeType.PERSON:
                props = node.properties
                key_props = f"|age={getattr(props, 'age', None)}|name={getattr(props, 'name', None)}"
            elif node.type == NodeType.REGION:
                props = node.properties
                key_props = f"|region={getattr(props, 'region_type', '')}"
            parts.append(f"{node.type.value}:{node.label}{key_props}")
        signature_str = "|".join(parts)
        return hashlib.sha256(signature_str.encode()).hexdigest()[:16]


# TASK REPRESENTATION Z(T)

@dataclass
class ObjectReference:
    """Reference to an object in the task."""
    reference_text: str              # Original text, e.g., "the cup"
    grounded_id: Optional[str] = None  # Scene node ID after grounding
    role: str = ""                   # e.g., "source", "target", "instrument"
    properties: Dict[str, Any] = field(default_factory=dict)  # Mentioned properties


@dataclass
class TaskParameter:
    """A parameter in the task specification."""
    name: str                        # e.g., "temperature", "quantity"
    value: Any                       # The value
    unit: Optional[str] = None       # e.g., "celsius", "ml"
    variable_type: VariableType = VariableType.PARAMETER


@dataclass
class TaskConstraint:
    """An explicit constraint from the user."""
    description: str                 # e.g., "use the red cup"
    constraint_type: str             # e.g., "object_selection", "manner"
    hard: bool = True                # Hard constraint vs soft preference
    parameters: Dict[str, Any] = field(default_factory=dict)


@dataclass
class TaskPreference:
    """A soft preference from the user."""
    description: str                 # e.g., "she likes it warm"
    preference_type: str
    importance: float = 0.5          # 0.0 to 1.0


@dataclass
class Subgoal:
    """A step in the task plan."""
    step_number: int
    action: str
    description: str
    objects: List[str] = field(default_factory=list)  # Object IDs involved
    dependencies: List[int] = field(default_factory=list)  # Step numbers this depends on
    completed: bool = False


@dataclass
class TaskVariables:
    """
    Complete task representation Z(T).
    
    Decomposes a task into intervenable variables following the formal framework.
    """
    # Core variables
    goal: str                                    # z_g: desired outcome
    action: str                                  # z_a: primary/dominant action verb
    subactions: List[str] = field(default_factory=list)  # z_a_seq: ordered sub-actions (if multi-action command)
    objects: List[ObjectReference] = field(default_factory=list)  # z_o: entities involved
    parameters: List[TaskParameter] = field(default_factory=list)  # z_p: quantities, thresholds
    constraints: List[TaskConstraint] = field(default_factory=list)  # z_c: explicit constraints
    preferences: List[TaskPreference] = field(default_factory=list)  # z_pref: soft preferences
    plan: List[Subgoal] = field(default_factory=list)  # z_plan: subgoal sequence
    
    # Metadata
    original_utterance: str = ""                 # Raw user input
    recipient: Optional[ObjectReference] = None  # Special case: who receives the result
    manner: Optional[str] = None                 # How to perform the action
    frame_type: Optional[TaskFrame] = None       # Semantic frame (Fillmore, 1976)
    locations: List[ObjectReference] = field(default_factory=list)  # Spatial references

    # Enriched parsing output (replaces dynamic _prefixed attributes)
    activity_context: str = ""                   # Script/activity context (Schank & Abelson)
    underlying_need: str = ""                    # Perlocutionary goal (Austin, 1962)
    projected_physical_outcome: str = ""         # Factual end-state if command executes as stated
    literal_request: str = ""                    # Locutionary content
    parsed_intent: str = ""                      # Illocutionary intent
    frame_safety_focus: str = ""                 # Frame-specific safety guidance
    capability_assessment: Optional[Dict[str, Any]] = None    # CORA capability model output
    constructional_analysis: Optional[Dict[str, Any]] = None  # Construction Grammar analysis
    ontological_decomposition: Optional[List[Dict[str, Any]]] = None  # SOMA/CORA decomposition
    skill_gap: Optional[Dict[str, Any]] = None   # Capability mismatch details

    # Grounding status
    fully_grounded: bool = False
    grounding_confidence: float = 0.0
    grounding_results: List[Any] = field(default_factory=list)  # GroundingResult objects
    
    def get_variable_by_type(self, var_type: VariableType) -> Any:
        """Retrieve variable(s) by type."""
        mapping = {
            VariableType.GOAL: self.goal,
            VariableType.ACTION: self.action,
            VariableType.OBJECT: self.objects,
            VariableType.PARAMETER: self.parameters,
            VariableType.CONSTRAINT: self.constraints,
            VariableType.PREFERENCE: self.preferences,
            VariableType.PLAN: self.plan,
        }
        return mapping.get(var_type)


# CONSTRAINT SYSTEM

@dataclass
class SafetyRule:
    """
    A formal safety rule in the constraint system.
    
    Rules are evaluated as: Condition(x, W, Z(T)) => Prohibited(action)
    """
    id: str
    name: str
    description: str
    tier: ConstraintTier
    severity: ViolationSeverity
    
    # Rule logic (simplified representation - actual implementation may use predicates)
    condition: Dict[str, Any]        # Conditions that trigger the rule
    prohibited_actions: Set[str]     # Actions prohibited when condition is met
    
    # Metadata
    relaxable: bool = False
    max_relaxation: Optional[float] = None  # How much can be relaxed (for relaxable rules)
    
    def __hash__(self):
        return hash(self.id)


@dataclass
class ConstraintViolation:
    """
    A detected constraint violation.
    
    Captures what rule was violated, why, and what variables are implicated.
    """
    rule: SafetyRule
    tier: ConstraintTier
    severity: ViolationSeverity
    
    # Causal information
    causal_variables: List[str]      # Variable names that caused the violation
    causal_values: Dict[str, Any]    # The actual values that triggered it
    implicated_objects: List[str]    # Scene node IDs involved
    
    # Explanation
    explanation: str                 # Human-readable explanation
    
    # For repair
    suggested_interventions: List[str] = field(default_factory=list)  # Hints for repair


@dataclass
class ConstraintEvaluationResult:
    """Result of evaluating all constraints on a task."""
    feasible: bool
    violations: List[ConstraintViolation] = field(default_factory=list)
    tier_results: Dict[ConstraintTier, bool] = field(default_factory=dict)
    hazard_score: float = 0.0        # H(T, W, C) ∈ [0, 1]


@dataclass
class SafetyConstraint:
    """C4: Executable cross-step safety constraint.

    Generated by the safety evaluator for compound commands.
    Verified by the plan linter against the action sequence.
    """
    trigger: str                     # "after slicing chicken"
    effect: str = ""                 # "blade carries contamination"
    required_action: str = ""        # "CleanObject(robot1, 'Knife')"
    must_occur_before: str = ""      # "slicing bread"
    severity: str = "critical"       # "critical" or "advisory"


# GROUNDING

@dataclass
class GroundingCandidate:
    """A candidate entity for grounding a reference."""
    node_id: str
    node: SceneNode
    score: float                     # Matching score
    match_reasons: List[str] = field(default_factory=list)  # Why this matched


# NOTE: GroundingResult (with outcome/failure_kind fields) is defined below
# in the "GROUNDING DATA STRUCTURES" section alongside GroundingOutcome.

@dataclass
class TaskGroundingResult:
    """Result of grounding all references in a task."""
    task: TaskVariables              # The grounded task
    groundings: Dict[str, 'GroundingResult'] = field(default_factory=dict)  # ref -> result
    fully_grounded: bool = False
    overall_confidence: float = 0.0
    unresolved_references: List[str] = field(default_factory=list)


# REPAIR CANDIDATES
# NOTE: Intervention and RepairOperatorApplication are defined in operators.py
# (the canonical versions with the field names the pipeline actually uses).

@dataclass
class RepairCandidate:
    """
    A candidate repaired task T'.
    
    Includes the repaired task, how it was derived, and evaluation scores.
    """
    id: str                          # Unique identifier
    original_task: TaskVariables     # T
    repaired_task: TaskVariables     # T'
    
    # Derivation
    operator_sequence: List[Any] = field(default_factory=list)  # RepairOperatorApplication from operators.py
    interventions: List[Any] = field(default_factory=list)  # Intervention from operators.py
    
    # Scores (filled in during evaluation)
    feasible: Optional[bool] = None
    feasibility_score: Optional[float] = None  # F_ψ output
    affinity_score: Optional[float] = None     # A(T, T' | W)
    cost: Optional[float] = None               # Cost(T → T')
    confidence: Optional[float] = None         # Conf(T')
    final_score: Optional[float] = None        # (A - λ·Cost) · Conf
    
    # Schema-based generation output
    action_sequence: Optional[List[str]] = None     # Executable action steps
    required_skills: Optional[List[str]] = None     # Skills needed for execution
    expected_end_state: Optional[str] = None         # World state after execution

    # Status
    verified: bool = False           # Passed final verification
    verification_violations: List[ConstraintViolation] = field(default_factory=list)
    
    def compute_final_score(self, lambda_val: float) -> float:
        """Compute the final ranking score."""
        if self.affinity_score is None or self.cost is None:
            return float('-inf')
        conf = self.confidence if self.confidence is not None else 1.0
        self.final_score = (self.affinity_score - lambda_val * self.cost) * conf
        return self.final_score


# LAMBDA (RISK-ADAPTIVE)

@dataclass
class LambdaConfig:
    """Configuration for risk-adaptive lambda."""
    lambda_min: float = 0.1          # For high-hazard tasks
    lambda_max: float = 0.9          # For low-hazard tasks
    
    def compute_lambda(self, hazard_score: float) -> float:
        """
        Compute λ(T, W, C) = λ_max - (λ_max - λ_min) · H(T, W, C)
        """
        return self.lambda_max - (self.lambda_max - self.lambda_min) * hazard_score


# SEARCH CONFIGURATION

@dataclass
class SearchConfig:
    """Configuration for the repair search algorithm."""
    beam_width: int = 10             # B
    max_depth: int = 3               # K (max interventions)
    max_candidates: int = 100        # Maximum candidates to generate
    top_k_return: int = 3            # Number of repairs to return
    
    # Thresholds
    feasibility_threshold: float = 0.7   # θ for learned predictor
    grounding_threshold: float = 0.6     # τ for grounding confidence
    confidence_threshold: float = 0.5    # Min confidence to keep candidate
    
    # Pruning
    prune_dominated: bool = True     # Prune dominated candidates
    prune_low_confidence: bool = True
    
    # Termination
    early_stop_on_k_feasible: bool = True  # Stop when k feasible found


# EXPLANATION

@dataclass
class RepairOption:
    """
    A single repair option presented to the user.

    Contains the repair candidate and a brief explanation for display.
    """
    option_label: str                # "A", "B", "C", etc.
    repair_candidate: 'RepairCandidate'  # The actual repair
    brief_description: str           # e.g., "Pour lukewarm coffee into a sippy cup for Sara"
    safety_rationale: str            # e.g., "so they can drink it safely"

    def formatted(self) -> str:
        """Return formatted option string."""
        return f"Option {self.option_label}: {self.brief_description}\n          ({self.safety_rationale})"


@dataclass
class RepairExplanation:
    """
    Natural language explanation of a repair.

    Structure: acknowledge → explain problem → present repair → justify safety
    """
    original_request: str            # What user asked
    problem_explanation: str         # Why it was problematic
    repair_description: str          # What we'll do instead
    safety_justification: str        # Why the repair is safe
    intent_preservation: str         # How repair preserves intent

    # Full text
    full_explanation: str = ""

    # Structured data for generating explanation
    violations_addressed: List[ConstraintViolation] = field(default_factory=list)
    interventions_made: List[Any] = field(default_factory=list)  # Intervention from operators.py


@dataclass
class MultiOptionExplanation:
    """
    Multi-option explanation presented to the user for choice.

    Format:
    "I noticed you asked me to [original]. Since [safety concern],
    here are some safe alternatives:

    Option A: [description] ([rationale])
    Option B: [description] ([rationale])

    Would you like me to proceed with Option A, Option B, or would you
    like to specify a different task?"
    """
    original_request: str            # What user asked
    safety_concern: str              # Why it was problematic
    options: List[RepairOption] = field(default_factory=list)  # The repair options

    # The complete formatted explanation
    full_explanation: str = ""

    # Closing question
    closing_question: str = "Would you like me to proceed with Option A, Option B, or would you like to specify a different task for me to complete?"

    def generate_full_explanation(self) -> str:
        """Generate the complete multi-option explanation text."""
        lines = []

        # Opening with acknowledgment and safety concern
        lines.append(f"I noticed you asked me to {self.original_request}. Since {self.safety_concern}, here are some safe alternatives:")
        lines.append("")

        # Options
        for option in self.options:
            lines.append(option.formatted())

        lines.append("")

        # Closing question
        lines.append(self.closing_question)

        self.full_explanation = "\n".join(lines)
        return self.full_explanation


# PIPELINE RESULT

@dataclass
class CTRPipelineResult:
    """
    Complete result from the TR-Graph Task Repair pipeline.
    """
    # Input
    original_utterance: str
    original_task: TaskVariables
    world: SceneGraph

    # Processing
    grounding_result: TaskGroundingResult
    constraint_evaluation: ConstraintEvaluationResult

    # Output
    is_safe: bool                    # Was original task safe?
    repair_needed: bool

    # If repair was needed
    candidates_generated: int = 0
    candidates_feasible: int = 0
    top_repairs: List[RepairCandidate] = field(default_factory=list)
    selected_repair: Optional[RepairCandidate] = None
    explanation: Optional[RepairExplanation] = None

    # Multi-option explanation (new)
    multi_option_explanation: Optional[MultiOptionExplanation] = None
    repair_options: List[RepairOption] = field(default_factory=list)
    user_selected_option: Optional[str] = None  # "A", "B", or "other"

    # Metadata
    processing_time_ms: float = 0.0
    lambda_used: float = 0.0

    def get_final_task(self) -> TaskVariables:
        """Get the task to execute (original if safe, repaired otherwise)."""
        if self.is_safe:
            return self.original_task
        elif self.selected_repair:
            return self.selected_repair.repaired_task
        else:
            raise ValueError("No safe task available")

    def get_explanation_text(self) -> str:
        """Get the explanation text to show to the user."""
        if self.is_safe:
            return "This task is safe to execute as requested."
        elif self.multi_option_explanation:
            return self.multi_option_explanation.full_explanation
        elif self.explanation:
            return self.explanation.full_explanation
        else:
            return "Unable to find a safe alternative for this task."

    def select_option(self, option_label: str) -> Optional[TaskVariables]:
        """
        Select a repair option by label (A, B, etc.).

        Returns the selected task or None if invalid option.
        """
        self.user_selected_option = option_label
        for option in self.repair_options:
            if option.option_label.upper() == option_label.upper():
                self.selected_repair = option.repair_candidate
                return option.repair_candidate.repaired_task
        return None


# FACTORY FUNCTIONS

def create_object_node(
    id: str,
    label: str,
    temperature: Optional[float] = None,
    affordances: Optional[Set[str]] = None,
    hazard_level: HazardLevel = HazardLevel.NONE,
    child_safe: bool = True,
    **kwargs
) -> SceneNode:
    """Factory function to create an object node."""
    props = ObjectProperties(
        temperature=temperature,
        affordances=affordances or set(),
        hazard_level=hazard_level,
        child_safe=child_safe,
        **kwargs
    )
    return SceneNode(id=id, type=NodeType.OBJECT, label=label, properties=props)


def create_person_node(
    id: str,
    label: str,
    name: Optional[str] = None,
    age: Optional[int] = None,
    age_group: Optional[AgeGroup] = None,
    **kwargs
) -> SceneNode:
    """Factory function to create a person node."""
    # Auto-derive age_group if age is provided
    if age is not None and age_group is None:
        if age < 3:
            age_group = AgeGroup.INFANT
        elif age < 13:
            age_group = AgeGroup.CHILD
        elif age < 18:
            age_group = AgeGroup.TEEN
        elif age < 65:
            age_group = AgeGroup.ADULT
        else:
            age_group = AgeGroup.ELDERLY
    
    props = PersonProperties(name=name, age=age, age_group=age_group, **kwargs)
    return SceneNode(id=id, type=NodeType.PERSON, label=label, properties=props)


def create_agent_node(id: str = "robot", label: str = "Robot") -> SceneNode:
    """Factory function to create the robot agent node."""
    props = AgentProperties()
    return SceneNode(id=id, type=NodeType.AGENT, label=label, properties=props)


def create_region_node(id: str, label: str, region_type: str, **kwargs) -> SceneNode:
    """Factory function to create a region node."""
    props = RegionProperties(region_type=region_type, **kwargs)
    return SceneNode(id=id, type=NodeType.REGION, label=label, properties=props)


# CAUSAL GRAPH DATA STRUCTURES

@dataclass
class CausalEdge:
    """A directed causal edge between task variables."""
    source: str          # Source variable name, e.g., "object.temperature"
    target: str          # Target variable name, e.g., "safety.burn_risk"
    relationship: str = ""  # Description, e.g., "hot temperature causes burn risk"


class CausalGraph:
    """
    Causal graph over task variables for a specific safety violation.

    Constructed after safety evaluation during diagnosis extraction,
    when the system knows what the actual violation is. The causal
    dependencies that matter for repair depend entirely on the nature
    of the violation.

    Used for:
    - Graph-derived variable importance (Eq. 5-6)
    - Graph consistency validation (Eq. 22-23)
    - Graph-derived cost (Eq. 24-25)
    - Graph-informed fidelity (Eq. 26-27)
    - Bandit context features (Eq. 16)
    """

    def __init__(self):
        self.nodes: set = set()
        self.edges: List[CausalEdge] = []
        self._adjacency: Dict[str, List[str]] = {}   # Forward adjacency
        self._reverse: Dict[str, List[str]] = {}      # Reverse adjacency
        self._node_types: Dict[str, Optional[str]] = {}  # node_name -> type
        self._seen_edges: Set[Tuple[str, str, str]] = set()  # Dedup: (source, target, relationship)
        self.frozen: bool = False  # When True, no modifications allowed

    def add_node(self, name: str, node_type: Optional[str] = None):
        """Add a node to the graph with an optional type classification.

        Args:
            name: Node identifier (e.g., "object.temperature", "hazard.burn_risk")
            node_type: Optional type from SOMA ontological categories:
                "task_variable", "object_property", "recipient_property",
                "action_feature", "hazard_mechanism", "violation_sink"
                None until types are populated during graph construction.
        """
        if self.frozen:
            raise RuntimeError("Cannot modify frozen causal graph")
        self.nodes.add(name)
        if name not in self._adjacency:
            self._adjacency[name] = []
        if name not in self._reverse:
            self._reverse[name] = []
        # Store or update node type (later assignment overwrites None)
        if node_type is not None or name not in self._node_types:
            self._node_types[name] = node_type

    def get_node_type(self, name: str) -> Optional[str]:
        """Return the type of a node, or None if untyped."""
        return self._node_types.get(name)

    def get_nodes_by_type(self, node_type: str) -> List[str]:
        """Return all node names with the given type."""
        return [n for n, t in self._node_types.items() if t == node_type]

    def add_edge(self, source: str, target: str, relationship: str = ""):
        """Add a directed edge with deduplication.

        Duplicate edges (same source, target, relationship) are silently
        skipped. This prevents duplicate edges from corrupting density,
        centrality, and all downstream graph features.
        """
        if self.frozen:
            raise RuntimeError("Cannot modify frozen causal graph")

        edge_key = (source, target, relationship)
        if edge_key in self._seen_edges:
            return  # Skip duplicate
        self._seen_edges.add(edge_key)

        self.add_node(source)
        self.add_node(target)
        edge = CausalEdge(source=source, target=target, relationship=relationship)
        self.edges.append(edge)
        if target not in self._adjacency[source]:
            self._adjacency[source].append(target)
        if source not in self._reverse[target]:
            self._reverse[target].append(source)

    def freeze(self):
        """Freeze the graph to prevent further modifications.

        Called after diagnosis extraction. All downstream computations
        (cost weights, affinity dimension weights, bandit context) use
        this frozen graph. This ensures consistency across the pipeline.
        """
        self.frozen = True

    def shortest_path(self, source: str, target: str) -> float:
        """Shortest directed path length between two nodes using BFS. Returns inf if no path."""
        if source not in self.nodes or target not in self.nodes:
            return float('inf')
        if source == target:
            return 0

        from collections import deque
        visited = {source}
        queue = deque([(source, 0)])
        while queue:
            node, dist = queue.popleft()
            for neighbor in self._adjacency.get(node, []):
                if neighbor == target:
                    return dist + 1
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append((neighbor, dist + 1))
        return float('inf')

    def all_paths_to(self, target: str) -> List[List[str]]:
        """Return all directed paths that end at the target node."""
        if target not in self.nodes:
            return []

        paths = []

        def _dfs(node: str, path: List[str], visited: set):
            if node == target and len(path) > 1:
                paths.append(list(path))
                return
            for neighbor in self._adjacency.get(node, []):
                if neighbor not in visited:
                    visited.add(neighbor)
                    path.append(neighbor)
                    _dfs(neighbor, path, visited)
                    path.pop()
                    visited.remove(neighbor)

        for start in self.nodes:
            if start != target:
                _dfs(start, [start], {start})
        return paths

    def reachable_from(self, node: str) -> set:
        """Return all nodes reachable downstream from a given node via DFS."""
        if node not in self.nodes:
            return set()
        visited = set()

        def _dfs(n: str):
            for neighbor in self._adjacency.get(n, []):
                if neighbor not in visited:
                    visited.add(neighbor)
                    _dfs(neighbor)

        _dfs(node)
        return visited

    def betweenness_centrality(self, node: str) -> float:
        """
        Compute betweenness centrality of a node (fraction of all shortest
        paths that pass through it). Simplified for small graphs.
        """
        if node not in self.nodes or len(self.nodes) < 3:
            return 0.0

        from collections import deque
        total_paths = 0
        paths_through = 0
        node_list = list(self.nodes)

        for s in node_list:
            for t in node_list:
                if s == t or s == node or t == node:
                    continue
                # BFS to find all shortest paths from s to t
                dist_to: Dict[str, int] = {s: 0}
                parents: Dict[str, List[str]] = {s: []}
                queue = deque([s])
                while queue:
                    curr = queue.popleft()
                    for neighbor in self._adjacency.get(curr, []):
                        if neighbor not in dist_to:
                            dist_to[neighbor] = dist_to[curr] + 1
                            parents[neighbor] = [curr]
                            queue.append(neighbor)
                        elif dist_to[neighbor] == dist_to[curr] + 1:
                            parents[neighbor].append(curr)

                if t not in dist_to:
                    continue

                # Count shortest paths and those through node (with memoization)
                _memo: Dict[str, Tuple[int, int]] = {}

                def count_paths(target_n: str) -> Tuple[int, int]:
                    if target_n in _memo:
                        return _memo[target_n]
                    if target_n == s:
                        _memo[target_n] = (1, 0)
                        return (1, 0)
                    total = 0
                    through = 0
                    for p in parents.get(target_n, []):
                        pt, pthru = count_paths(p)
                        total += pt
                        through += pthru
                    if target_n == node:
                        through = total
                    _memo[target_n] = (total, through)
                    return (total, through)

                tp, thru = count_paths(t)
                total_paths += tp
                paths_through += thru

        if total_paths == 0:
            return 0.0
        return paths_through / total_paths

    def density(self) -> float:
        """Return |E| / (|Z| * (|Z| - 1)). Used for bandit context."""
        n = len(self.nodes)
        if n <= 1:
            return 0.0
        return len(self.edges) / (n * (n - 1))

    def compute_importance(self, goal_node: str) -> Dict[str, float]:
        """
        Return dict mapping each node to its importance weight based on
        shortest path to the goal (Eq. 5). Normalizes to sum to 1 (Eq. 6).
        """
        default_weight = 0.1
        raw_weights = {}
        for node in self.nodes:
            d = self.shortest_path(node, goal_node)
            if d == float('inf'):
                raw_weights[node] = default_weight
            else:
                raw_weights[node] = 1.0 / (1.0 + d)

        total = sum(raw_weights.values())
        if total == 0:
            return {n: 1.0 / len(self.nodes) for n in self.nodes}
        return {n: w / total for n, w in raw_weights.items()}

    def compute_path_disruption(self, goal_node: str, changed_nodes: set) -> float:
        """
        Return the fraction of all paths to the goal that pass through
        at least one changed node (Eq. 25).
        """
        all_paths = self.all_paths_to(goal_node)
        if not all_paths:
            return 0.0

        disrupted = 0
        for path in all_paths:
            if changed_nodes & set(path):
                disrupted += 1
        return disrupted / len(all_paths)

    def check_consistency(
        self,
        original_values: Dict[str, Any],
        repaired_values: Dict[str, Any]
    ) -> List[Dict]:
        """
        Check if changes to parent variables are consistent with unchanged
        child variables (Eq. 22-23).

        Returns list of inconsistency descriptions. Empty list means consistent.
        """
        inconsistencies = []
        changed = {k for k in original_values if k in repaired_values
                   and str(original_values[k]).lower() != str(repaired_values[k]).lower()}

        for edge in self.edges:
            source_changed = edge.source in changed
            target_changed = edge.target in changed

            if source_changed and not target_changed:
                new_source = str(repaired_values.get(edge.source, '')).lower()
                old_target = str(original_values.get(edge.target, '')).lower()

                if not self._compatible(new_source, old_target, edge):
                    inconsistencies.append({
                        'parent': edge.source,
                        'child': edge.target,
                        'parent_new_value': repaired_values.get(edge.source),
                        'child_unchanged_value': original_values.get(edge.target),
                        'relationship': edge.relationship,
                        'message': (f"'{edge.source}' changed but dependent "
                                    f"'{edge.target}' was not updated")
                    })
        return inconsistencies

    def _compatible(self, new_parent_value: str, old_child_value: str, edge: CausalEdge) -> bool:
        """Check if new parent value is compatible with unchanged child value."""
        # Object changed but sharpness didn't update
        if 'object' in edge.source and 'sharp' in edge.target:
            non_sharp = ['cup', 'bottle', 'bowl', 'plate', 'spoon', 'sippy', 'milk', 'water']
            if any(ns in new_parent_value for ns in non_sharp):
                if 'sharp' in old_child_value:
                    return False

        # Object changed but temperature didn't update
        if 'object' in edge.source and 'temp' in edge.target:
            cold_items = ['water', 'juice', 'milk', 'ice']
            if any(ci in new_parent_value for ci in cold_items):
                if 'hot' in old_child_value:
                    return False

        return True  # Default: assume compatible

    def to_dict(self) -> Dict:
        """Serialize graph for logging."""
        return {
            'nodes': list(self.nodes),
            'node_types': {n: t for n, t in self._node_types.items() if t is not None},
            'edges': [
                {'from': e.source, 'to': e.target, 'relationship': e.relationship}
                for e in self.edges
            ],
            'frozen': self.frozen
        }

    @classmethod
    def from_dict(cls, data: Dict) -> 'CausalGraph':
        """Deserialize graph from dict."""
        graph = cls()
        node_types = data.get('node_types', {})
        for node in data.get('nodes', []):
            graph.add_node(node, node_type=node_types.get(node))
        for edge_data in data.get('edges', []):
            graph.add_edge(
                edge_data.get('from', ''),
                edge_data.get('to', ''),
                edge_data.get('relationship', '')
            )
        if data.get('frozen', False):
            graph.freeze()
        return graph


# GROUNDING DATA STRUCTURES

class GroundingOutcome(Enum):
    """Outcome of grounding a task reference against the scene graph."""
    RESOLVED = "resolved"           # Matched to scene entity
    INFEASIBLE = "infeasible"       # Required entity not in scene
    CLARIFY = "clarify"             # Safety-critical attributes unknown
    SKILL_INFEASIBLE = "skill_infeasible"  # Robot cannot perform requested action


@dataclass
class GroundingResult:
    """
    Result of grounding a task reference.

    Three possible outcomes:
    - RESOLVED: Reference matched to a scene entity with sufficient confidence.
    - INFEASIBLE: Required entity not in scene. Triggers repair with available resources.
    - CLARIFY: Reference matched or stated, but safety-critical attributes unknown.
      Triggers a clarification request to the user.
    """
    reference: str
    outcome: GroundingOutcome
    entity_id: Optional[str] = None            # Set if RESOLVED
    confidence: float = 0.0                    # Set if RESOLVED
    missing_attributes: List[str] = field(default_factory=list)   # Set if CLARIFY
    clarification_question: str = ""           # Set if CLARIFY
    available_alternatives: List[str] = field(default_factory=list)  # Set if INFEASIBLE
    candidates: List['GroundingCandidate'] = field(default_factory=list)
    # Failure metadata for routing different failure types
    expected_type: str = ""                    # "object" | "person" | "location" | "skill"
    failure_kind: str = ""                     # "missing_entity" | "missing_location" |
                                               #  "skill_gap" | "ambiguous_reference"


# DIAGNOSIS-GUIDED GENERATION DATA STRUCTURES

@dataclass
class Violation:
    """A single constraint violation from safety evaluation."""
    layer: str                               # 'societal', 'organizational', 'individual'
    rule: str                                # The rule/condition that was violated
    severity: float                          # 0.0 to 1.0
    explanation: str                         # Human-readable explanation
    defect_type: Optional[DefectType] = None # What kind of problem
    hazard_type: Optional[HazardType] = None # What kind of harm (if physical)
    hazard_severity: Optional[str] = None    # minor/moderate/serious/critical
    hazard_probability: Optional[str] = None # improbable/possible/likely/certain


@dataclass
class Diagnosis:
    """
    Safety diagnosis extracted from three-tier evaluation.

    This structure captures everything needed for guided repair generation:
    - What constraints were violated
    - Which task variables caused the violations (causal variables)
    - Why those variables are problematic (explanations)
    - How severe the violations are
    - What type of defect was detected (physical, normative, etc.)
    """
    violations: List[Violation] = field(default_factory=list)
    causal_variables: List[str] = field(default_factory=list)
    causal_edges: List[CausalEdge] = field(default_factory=list)
    causal_graph: Optional[CausalGraph] = None
    explanations: List[str] = field(default_factory=list)
    max_hazard: float = 0.0
    layer_results: Dict[str, Any] = field(default_factory=dict)
    available_alternatives: List[str] = field(default_factory=list)

    # Defect classification (from enriched safety evaluation)
    defect_type: Optional[DefectType] = None
    hazard_type: Optional[HazardType] = None
    hazard_severity: Optional[str] = None    # minor/moderate/serious/critical
    hazard_probability: Optional[str] = None # improbable/possible/likely/certain
    feasibility_subtype: Optional[str] = None  # "missing_entity"|"missing_location"|"skill_gap"

    def get_violation_summary(self) -> str:
        """Get a concise summary of all violations."""
        if not self.violations:
            return "No violations detected."

        summaries = []
        for v in self.violations:
            summaries.append(f"[{v.layer.upper()}] {v.explanation}")
        return "; ".join(summaries)

    def get_causal_summary(self) -> str:
        """Get a summary of causal variables and their issues."""
        if not self.causal_variables:
            return "No causal variables identified."
        return f"Variables causing issues: {', '.join(self.causal_variables)}"


@dataclass
class OperatorClassification:
    """
    Result of classifying which operator was applied to produce a repair.

    After LLM generates a repair, we analyze the differences between
    original and repaired task to identify which formal operators were used.
    """
    operator_type: OperatorType
    confidence: float                        # 0.0 to 1.0
    evidence: str                            # What change indicated this operator
    variables_affected: List[str] = field(default_factory=list)


@dataclass
class OperatorValidation:
    """
    Result of validating an operator's preconditions.

    Even though generation is LLM-driven, we still validate that the
    operator's formal preconditions are satisfied, providing certification.
    """
    operator_type: OperatorType
    valid: bool
    checks: List[Tuple[str, bool]] = field(default_factory=list)  # (precondition_name, satisfied)
    explanation: str = ""

    def get_failed_checks(self) -> List[str]:
        """Get list of precondition names that failed."""
        return [name for name, satisfied in self.checks if not satisfied]


@dataclass
class ValidatedRepair:
    """
    A fully validated repair candidate with all metadata.

    This is the output of the validation phase, containing:
    - The repaired task
    - Safety validation result
    - Operator classifications and validations
    - Affinity and cost scores
    """
    task_text: str                           # Natural language description
    task_variables: Optional['TaskVariables'] = None

    # Safety validation
    is_safe: bool = False
    safety_violations: List[Violation] = field(default_factory=list)

    # Operator analysis
    operators_applied: List[OperatorClassification] = field(default_factory=list)
    operator_validations: List[OperatorValidation] = field(default_factory=list)

    # Scores
    affinity_score: float = 0.0
    cost_score: float = 0.0
    final_score: float = 0.0

    # Generation metadata
    generation_reasoning: str = ""           # LLM's reasoning for this repair

    # Validation tracking (for gating, bandit reward, logging)
    consistency_issues: List[Dict] = field(default_factory=list)
    consistency_penalty: float = 0.0
    passed_safety: bool = False
    passed_operator_validation: bool = False

    # Execution trace: dimension-level affinity breakdown (Item 1)
    _affinity_dimension_scores: Dict[str, float] = field(default_factory=dict)
    _affinity_dimension_weights: Dict[str, float] = field(default_factory=dict)

    # Execution trace: weight derivation details (Item 2)
    _weight_derivation: Dict[str, Any] = field(default_factory=dict)

    # Execution trace: per-variable cost breakdown (Item 3)
    _cost_breakdown: Dict[str, Any] = field(default_factory=dict)

    # Execution trace: gates passed (Item 4)
    _gates_passed: List[str] = field(default_factory=list)

    def all_operators_valid(self) -> bool:
        """Check if all applied operators passed validation."""
        return all(v.valid for v in self.operator_validations)

    def get_operator_summary(self) -> str:
        """Get summary of operators applied."""
        if not self.operators_applied:
            return "No operators classified."
        ops = [f"{op.operator_type.value} (conf={op.confidence:.2f})"
               for op in self.operators_applied]
        return ", ".join(ops)
