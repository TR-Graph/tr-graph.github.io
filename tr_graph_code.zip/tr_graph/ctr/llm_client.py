"""
TR-Graph Task Repair: Multi-Provider LLM/VLM Client
==========================================================

Unified interface for multiple LLM and VLM providers:
- OpenAI (GPT-4, GPT-4V)
- Anthropic (Claude)
- Google (Gemini)
- Hugging Face models

Usage:
    client = create_client("openai", model="gpt-4o")
    response = client.generate("System prompt", "User message")
    
    # With image
    response = client.generate_with_image("Describe this", image_data)
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Union
from enum import Enum
import base64
import json
import logging
import time
import os


# PROVIDER ENUM

class Provider(Enum):
    """Supported LLM/VLM providers."""
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    GOOGLE = "google"


# BASE CLIENT INTERFACE

@dataclass
class GenerationConfig:
    """Configuration for text generation."""
    temperature: float = 0.7
    max_tokens: int = 2000
    top_p: float = 0.95
    stop_sequences: List[str] = field(default_factory=list)


@dataclass
class LLMResponse:
    """Standardized response from any LLM."""
    text: str
    provider: Provider
    model: str
    usage: Dict[str, int] = field(default_factory=dict)  # tokens used
    latency_ms: float = 0.0
    raw_response: Any = None


class BaseLLMClient(ABC):
    """Abstract base class for LLM clients."""
    
    def __init__(
        self,
        model: str,
        api_key: Optional[str] = None,
        api_base: Optional[str] = None,
        config: Optional[GenerationConfig] = None
    ):
        self.model = model
        self.api_key = api_key
        self.api_base = api_base
        self.config = config or GenerationConfig()
    
    @abstractmethod
    def generate(
        self,
        system_prompt: str,
        user_prompt: str,
        config: Optional[GenerationConfig] = None
    ) -> LLMResponse:
        """Generate text response."""
        pass
    
    @abstractmethod
    def generate_with_image(
        self,
        prompt: str,
        image: Union[str, bytes],  # base64 string or raw bytes
        system_prompt: Optional[str] = None,
        config: Optional[GenerationConfig] = None
    ) -> LLMResponse:
        """Generate response with image input (for VLMs)."""
        pass
    
    @property
    @abstractmethod
    def provider(self) -> Provider:
        """Return the provider enum."""
        pass
    
    @property
    def supports_vision(self) -> bool:
        """Whether this client supports image input."""
        return False


# OPENAI CLIENT

class OpenAIClient(BaseLLMClient):
    """Client for OpenAI models (GPT-4, GPT-4V, GPT-4o)."""
    
    VISION_MODELS = {"gpt-4-vision-preview", "gpt-4o", "gpt-4o-mini", "gpt-4-turbo"}
    
    def __init__(
        self,
        model: str = "gpt-4o",
        api_key: Optional[str] = None,
        api_base: Optional[str] = None,
        config: Optional[GenerationConfig] = None
    ):
        super().__init__(model, api_key, api_base, config)
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY")
        self.api_base = api_base or "https://api.openai.com/v1"
        
        # Import here to avoid dependency if not using OpenAI
        try:
            import openai
            self._client = openai.OpenAI(
                api_key=self.api_key,
                base_url=self.api_base
            )
        except ImportError:
            self._client = None
    
    @property
    def provider(self) -> Provider:
        return Provider.OPENAI
    
    @property
    def supports_vision(self) -> bool:
        return self.model in self.VISION_MODELS or "vision" in self.model or "4o" in self.model

    def _uses_max_completion_tokens(self) -> bool:
        """Check if model requires max_completion_tokens instead of max_tokens.

        Newer OpenAI models (GPT-5.x, GPT-4o, o1, o3, o4, etc.) use max_completion_tokens.
        """
        model_lower = self.model.lower()
        # Models that require max_completion_tokens
        new_model_patterns = ['gpt-5', 'gpt-4o', 'o1', 'o3', 'o4']
        return any(pattern in model_lower for pattern in new_model_patterns)

    def generate(
        self,
        system_prompt: str,
        user_prompt: str,
        config: Optional[GenerationConfig] = None
    ) -> LLMResponse:
        cfg = config or self.config
        start_time = time.time()
        
        if self._client is None:
            return self._http_generate(system_prompt, user_prompt, cfg)

        # Build parameters - newer models use max_completion_tokens instead of max_tokens
        params = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            "temperature": cfg.temperature,
            "top_p": cfg.top_p
        }

        # Check if model requires max_completion_tokens (newer OpenAI models)
        if self._uses_max_completion_tokens():
            params["max_completion_tokens"] = cfg.max_tokens
        else:
            params["max_tokens"] = cfg.max_tokens

        response = self._client.chat.completions.create(**params)
        
        latency = (time.time() - start_time) * 1000
        
        return LLMResponse(
            text=response.choices[0].message.content,
            provider=self.provider,
            model=self.model,
            usage={
                "prompt_tokens": response.usage.prompt_tokens,
                "completion_tokens": response.usage.completion_tokens
            },
            latency_ms=latency,
            raw_response=response
        )
    
    def generate_with_image(
        self,
        prompt: str,
        image: Union[str, bytes],
        system_prompt: Optional[str] = None,
        config: Optional[GenerationConfig] = None
    ) -> LLMResponse:
        cfg = config or self.config
        start_time = time.time()
        
        # Encode image if bytes
        if isinstance(image, bytes):
            image_b64 = base64.b64encode(image).decode('utf-8')
        else:
            image_b64 = image
        
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        
        messages.append({
            "role": "user",
            "content": [
                {"type": "text", "text": prompt},
                {
                    "type": "image_url",
                    "image_url": {
                        "url": f"data:image/jpeg;base64,{image_b64}"
                    }
                }
            ]
        })
        
        if self._client is None:
            raise RuntimeError("OpenAI client not initialized. Install openai package.")

        # Build parameters - newer models use max_completion_tokens
        params = {
            "model": self.model,
            "messages": messages,
            "temperature": cfg.temperature
        }
        if self._uses_max_completion_tokens():
            params["max_completion_tokens"] = cfg.max_tokens
        else:
            params["max_tokens"] = cfg.max_tokens

        response = self._client.chat.completions.create(**params)

        latency = (time.time() - start_time) * 1000

        return LLMResponse(
            text=response.choices[0].message.content,
            provider=self.provider,
            model=self.model,
            usage={
                "prompt_tokens": response.usage.prompt_tokens,
                "completion_tokens": response.usage.completion_tokens
            },
            latency_ms=latency,
            raw_response=response
        )
    
    def _http_generate(self, system_prompt: str, user_prompt: str, cfg: GenerationConfig) -> LLMResponse:
        """Fallback HTTP-based generation without openai package."""
        import urllib.request
        
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        data = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            "temperature": cfg.temperature
        }
        # Newer models use max_completion_tokens
        if self._uses_max_completion_tokens():
            data["max_completion_tokens"] = cfg.max_tokens
        else:
            data["max_tokens"] = cfg.max_tokens
        
        req = urllib.request.Request(
            f"{self.api_base}/chat/completions",
            data=json.dumps(data).encode('utf-8'),
            headers=headers
        )
        
        start_time = time.time()
        with urllib.request.urlopen(req) as response:
            result = json.loads(response.read().decode('utf-8'))
        latency = (time.time() - start_time) * 1000
        
        return LLMResponse(
            text=result["choices"][0]["message"]["content"],
            provider=self.provider,
            model=self.model,
            usage=result.get("usage", {}),
            latency_ms=latency,
            raw_response=result
        )


# ANTHROPIC CLIENT

class AnthropicClient(BaseLLMClient):
    """Client for Anthropic Claude models."""
    
    VISION_MODELS = {"claude-3-opus-20240229", "claude-3-sonnet-20240229", 
                     "claude-3-haiku-20240307", "claude-3-5-sonnet-20241022",
                     "claude-sonnet-4-20250514"}
    
    def __init__(
        self,
        model: str = "claude-sonnet-4-20250514",
        api_key: Optional[str] = None,
        api_base: Optional[str] = None,
        config: Optional[GenerationConfig] = None
    ):
        super().__init__(model, api_key, api_base, config)
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        self.api_base = api_base or "https://api.anthropic.com"
        
        try:
            import anthropic
            self._client = anthropic.Anthropic(api_key=self.api_key)
        except ImportError:
            self._client = None
    
    @property
    def provider(self) -> Provider:
        return Provider.ANTHROPIC
    
    @property
    def supports_vision(self) -> bool:
        return "claude-3" in self.model or "claude-sonnet-4" in self.model
    
    def generate(
        self,
        system_prompt: str,
        user_prompt: str,
        config: Optional[GenerationConfig] = None
    ) -> LLMResponse:
        cfg = config or self.config
        start_time = time.time()
        
        if self._client is None:
            return self._http_generate(system_prompt, user_prompt, cfg)
        
        response = self._client.messages.create(
            model=self.model,
            max_tokens=cfg.max_tokens,
            system=system_prompt,
            messages=[
                {"role": "user", "content": user_prompt}
            ]
        )
        
        latency = (time.time() - start_time) * 1000
        
        return LLMResponse(
            text=response.content[0].text,
            provider=self.provider,
            model=self.model,
            usage={
                "input_tokens": response.usage.input_tokens,
                "output_tokens": response.usage.output_tokens
            },
            latency_ms=latency,
            raw_response=response
        )
    
    def generate_with_image(
        self,
        prompt: str,
        image: Union[str, bytes],
        system_prompt: Optional[str] = None,
        config: Optional[GenerationConfig] = None
    ) -> LLMResponse:
        cfg = config or self.config
        start_time = time.time()
        
        if isinstance(image, bytes):
            image_b64 = base64.b64encode(image).decode('utf-8')
        else:
            image_b64 = image
        
        if self._client is None:
            raise RuntimeError("Anthropic client not initialized. Install anthropic package.")
        
        response = self._client.messages.create(
            model=self.model,
            max_tokens=cfg.max_tokens,
            system=system_prompt or "",
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": "image/jpeg",
                                "data": image_b64
                            }
                        },
                        {
                            "type": "text",
                            "text": prompt
                        }
                    ]
                }
            ]
        )
        
        latency = (time.time() - start_time) * 1000
        
        return LLMResponse(
            text=response.content[0].text,
            provider=self.provider,
            model=self.model,
            usage={
                "input_tokens": response.usage.input_tokens,
                "output_tokens": response.usage.output_tokens
            },
            latency_ms=latency,
            raw_response=response
        )
    
    def _http_generate(self, system_prompt: str, user_prompt: str, cfg: GenerationConfig) -> LLMResponse:
        """Fallback HTTP-based generation."""
        import urllib.request
        
        headers = {
            "x-api-key": self.api_key,
            "Content-Type": "application/json",
            "anthropic-version": "2023-06-01"
        }
        
        data = {
            "model": self.model,
            "max_tokens": cfg.max_tokens,
            "system": system_prompt,
            "messages": [{"role": "user", "content": user_prompt}]
        }
        
        req = urllib.request.Request(
            f"{self.api_base}/v1/messages",
            data=json.dumps(data).encode('utf-8'),
            headers=headers
        )
        
        start_time = time.time()
        with urllib.request.urlopen(req) as response:
            result = json.loads(response.read().decode('utf-8'))
        latency = (time.time() - start_time) * 1000
        
        return LLMResponse(
            text=result["content"][0]["text"],
            provider=self.provider,
            model=self.model,
            usage=result.get("usage", {}),
            latency_ms=latency,
            raw_response=result
        )


# GOOGLE GEMINI CLIENT

class GeminiClient(BaseLLMClient):
    """Client for Google Gemini models.

    Uses the new google.genai SDK (replaces the deprecated google.generativeai).
    System instructions are passed as a dedicated parameter so newer Gemini
    models (2.5-flash, 2.5-pro, etc.) respect them properly.
    """

    def __init__(
        self,
        model: str = "gemini-2.5-flash",
        api_key: Optional[str] = None,
        api_base: Optional[str] = None,
        config: Optional[GenerationConfig] = None
    ):
        super().__init__(model, api_key, api_base, config)
        self.api_key = api_key or os.environ.get("GOOGLE_API_KEY")

        try:
            from google import genai
            self._client = genai.Client(api_key=self.api_key)
            self._genai = genai
        except ImportError:
            self._client = None
            self._genai = None

    @property
    def provider(self) -> Provider:
        return Provider.GOOGLE

    @property
    def supports_vision(self) -> bool:
        return "vision" in self.model or "1.5" in self.model or "2.0" in self.model or "2.5" in self.model

    def generate(
        self,
        system_prompt: str,
        user_prompt: str,
        config: Optional[GenerationConfig] = None
    ) -> LLMResponse:
        cfg = config or self.config
        start_time = time.time()

        if self._client is None:
            return self._http_generate(system_prompt, user_prompt, cfg)

        genai = self._genai

        # Gemini 2.5 models have "thinking" enabled by default — the model
        # spends tokens on internal reasoning that count toward the output
        # budget. With a 4096 limit, the model may exhaust most tokens on
        # thinking and truncate the visible JSON output. Use a generous limit
        # (Gemini Flash supports up to 65536 output tokens; you only pay for
        # what you use). This does NOT affect OpenAI — it's Gemini-specific.
        effective_max_tokens = max(cfg.max_tokens, 16384)

        response = self._client.models.generate_content(
            model=self.model,
            contents=user_prompt,
            config=genai.types.GenerateContentConfig(
                system_instruction=system_prompt,
                temperature=cfg.temperature,
                max_output_tokens=effective_max_tokens,
                top_p=cfg.top_p,
            ),
        )

        latency = (time.time() - start_time) * 1000

        # Extract the text from the response.  Gemini 2.5 models with
        # "thinking" enabled return both thought and text parts; .text
        # gives only the final text output.  If .text fails or is empty,
        # try extracting from parts directly.
        try:
            resp_text = response.text
        except (ValueError, AttributeError):
            resp_text = None

        if not resp_text and hasattr(response, 'candidates') and response.candidates:
            # Walk through parts and collect non-thought text
            parts = response.candidates[0].content.parts if response.candidates[0].content else []
            text_parts = []
            for part in parts:
                if hasattr(part, 'thought') and part.thought:
                    continue  # Skip thinking blocks
                if hasattr(part, 'text') and part.text:
                    text_parts.append(part.text)
            resp_text = '\n'.join(text_parts) if text_parts else ''

        if not resp_text:
            logging.warning(
                f"[Gemini] Empty response text for model={self.model}. "
                f"Candidates: {len(response.candidates) if hasattr(response, 'candidates') and response.candidates else 0}"
            )
            resp_text = ''

        logging.debug(
            f"[Gemini] Response: {len(resp_text)} chars, "
            f"first 200: {resp_text[:200]!r}"
        )

        # Extract usage if available
        usage = {}
        if hasattr(response, 'usage_metadata') and response.usage_metadata:
            um = response.usage_metadata
            usage = {
                'prompt_tokens': getattr(um, 'prompt_token_count', 0),
                'completion_tokens': getattr(um, 'candidates_token_count', 0),
                'total_tokens': getattr(um, 'total_token_count', 0),
            }

        return LLMResponse(
            text=resp_text,
            provider=self.provider,
            model=self.model,
            usage=usage,
            latency_ms=latency,
            raw_response=response
        )

    def generate_with_image(
        self,
        prompt: str,
        image: Union[str, bytes],
        system_prompt: Optional[str] = None,
        config: Optional[GenerationConfig] = None
    ) -> LLMResponse:
        cfg = config or self.config
        start_time = time.time()

        if self._client is None:
            raise RuntimeError("Gemini client not initialized. Install google-genai package.")

        import PIL.Image
        import io
        genai = self._genai

        # Convert to PIL Image
        if isinstance(image, bytes):
            img = PIL.Image.open(io.BytesIO(image))
        elif isinstance(image, str):
            # Assume base64
            img_bytes = base64.b64decode(image)
            img = PIL.Image.open(io.BytesIO(img_bytes))
        else:
            img = image

        response = self._client.models.generate_content(
            model=self.model,
            contents=[prompt, img],
            config=genai.types.GenerateContentConfig(
                system_instruction=system_prompt or "",
                temperature=cfg.temperature,
                max_output_tokens=cfg.max_tokens,
            ),
        )
        
        latency = (time.time() - start_time) * 1000
        
        return LLMResponse(
            text=response.text,
            provider=self.provider,
            model=self.model,
            usage={},
            latency_ms=latency,
            raw_response=response
        )
    
    def _http_generate(self, system_prompt: str, user_prompt: str, cfg: GenerationConfig) -> LLMResponse:
        """Fallback HTTP-based generation when the google.genai SDK is unavailable."""
        import urllib.request

        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent?key={self.api_key}"

        data = {
            "system_instruction": {
                "parts": [{"text": system_prompt}]
            },
            "contents": [
                {"parts": [{"text": user_prompt}]}
            ],
            "generationConfig": {
                "temperature": cfg.temperature,
                "maxOutputTokens": cfg.max_tokens,
                "topP": cfg.top_p
            }
        }
        
        req = urllib.request.Request(
            url,
            data=json.dumps(data).encode('utf-8'),
            headers={"Content-Type": "application/json"}
        )
        
        start_time = time.time()
        with urllib.request.urlopen(req) as response:
            result = json.loads(response.read().decode('utf-8'))
        latency = (time.time() - start_time) * 1000
        
        return LLMResponse(
            text=result["candidates"][0]["content"]["parts"][0]["text"],
            provider=self.provider,
            model=self.model,
            usage={},
            latency_ms=latency,
            raw_response=result
        )


class MultiLLMClient:
    """
    Manager for multiple LLM clients with fallback support.
    
    Usage:
        client = MultiLLMClient()
        client.add_client("openai", OpenAIClient("gpt-4o"))
        client.add_client("claude", AnthropicClient())
        
        # Use specific client
        response = client.generate("openai", "System", "User")
        
        # Use with fallback
        response = client.generate_with_fallback(["openai", "claude"], "System", "User")
    """
    
    def __init__(self):
        self.clients: Dict[str, BaseLLMClient] = {}
        self.default_client: Optional[str] = None
    
    def add_client(self, name: str, client: BaseLLMClient, set_default: bool = False):
        """Add a client with a name."""
        self.clients[name] = client
        if set_default or self.default_client is None:
            self.default_client = name
    
    def get_client(self, name: Optional[str] = None) -> BaseLLMClient:
        """Get a client by name (or default)."""
        name = name or self.default_client
        if name not in self.clients:
            raise ValueError(f"Client '{name}' not found. Available: {list(self.clients.keys())}")
        return self.clients[name]
    
    def generate(
        self,
        system_prompt: str,
        user_prompt: str,
        client_name: Optional[str] = None,
        config: Optional[GenerationConfig] = None
    ) -> LLMResponse:
        """Generate using specified client (or default)."""
        client = self.get_client(client_name)
        return client.generate(system_prompt, user_prompt, config)
    
    def generate_with_image(
        self,
        prompt: str,
        image: Union[str, bytes],
        system_prompt: Optional[str] = None,
        client_name: Optional[str] = None,
        config: Optional[GenerationConfig] = None
    ) -> LLMResponse:
        """Generate with image using specified client."""
        client = self.get_client(client_name)
        if not client.supports_vision:
            raise ValueError(f"Client '{client_name}' does not support vision")
        return client.generate_with_image(prompt, image, system_prompt, config)
    
    def generate_with_fallback(
        self,
        client_names: List[str],
        system_prompt: str,
        user_prompt: str,
        config: Optional[GenerationConfig] = None
    ) -> LLMResponse:
        """Try multiple clients in order until one succeeds."""
        last_error = None
        for name in client_names:
            try:
                return self.generate(system_prompt, user_prompt, name, config)
            except Exception as e:
                last_error = e
                continue
        
        raise RuntimeError(f"All clients failed. Last error: {last_error}")


# FACTORY FUNCTION

def create_client(
    provider: str,
    model: Optional[str] = None,
    api_key: Optional[str] = None,
    api_base: Optional[str] = None,
    config: Optional[GenerationConfig] = None
) -> BaseLLMClient:
    """
    Factory function to create LLM client.
    
    Args:
        model: Model name (uses default if not specified)
        api_key: API key (uses environment variable if not specified)
        api_base: API base URL (uses default if not specified)
        config: Generation configuration
        
    Returns:
        Configured LLM client
        
    Example:
        client = create_client("openai", model="gpt-4o")
        client = create_client("anthropic", model="claude-sonnet-4-20250514")
    """
    provider_lower = provider.lower()
    
    defaults = {
        "openai": ("gpt-4o", OpenAIClient),
        "anthropic": ("claude-sonnet-4-20250514", AnthropicClient),
        "google": ("gemini-1.5-pro", GeminiClient),
    }
    
    if provider_lower not in defaults:
        raise ValueError(f"Unknown provider: {provider}. Available: {list(defaults.keys())}")
    
    default_model, client_class = defaults[provider_lower]
    model = model or default_model
    
    if model is None:
        raise ValueError(f"Model must be specified for provider: {provider}")
    
    return client_class(
        model=model,
        api_key=api_key,
        api_base=api_base,
        config=config
    )


# CONVENIENCE: CREATE MULTI-CLIENT WITH COMMON PROVIDERS

def create_multi_client(
    providers: Optional[List[str]] = None,
    default: Optional[str] = None
) -> MultiLLMClient:
    """
    Create a MultiLLMClient with common providers.
    
    Args:
        providers: List of providers to initialize (default: all with API keys set)
        default: Default provider name
        
    Example:
        client = create_multi_client(["openai", "anthropic"], default="openai")
    """
    multi = MultiLLMClient()
    
    # Auto-detect available providers by checking for API keys
    if providers is None:
        providers = []
        if os.environ.get("OPENAI_API_KEY"):
            providers.append("openai")
        if os.environ.get("ANTHROPIC_API_KEY"):
            providers.append("anthropic")
        if os.environ.get("GOOGLE_API_KEY"):
            providers.append("google")
    
    for provider in providers:
        try:
            client = create_client(provider)
            is_default = (provider == default) or (default is None and len(multi.clients) == 0)
            multi.add_client(provider, client, set_default=is_default)
        except Exception as e:
            # Skip providers that fail to initialize
            pass
    
    if not multi.clients:
        raise RuntimeError("No LLM clients could be initialized. Check API keys.")
    
    return multi
