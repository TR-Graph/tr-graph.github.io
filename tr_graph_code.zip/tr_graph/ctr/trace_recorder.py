"""
Trace recorder for reviewer artifact export.

Captures raw LLM prompts and responses, parsed objects, graph
construction details, validation logs, and scoring breakdowns
into a structured per-task directory.

Files are sanitized on write — API keys, tokens, and local paths
are redacted before they touch disk.
"""

import json
import re
import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_SENSITIVE_PATTERNS = [
    (re.compile(r'sk-[a-zA-Z0-9]{20,}'), '[REDACTED_API_KEY]'),
    (re.compile(r'sk-ant-[a-zA-Z0-9\-]{20,}'), '[REDACTED_API_KEY]'),
    (re.compile(r'Bearer [a-zA-Z0-9\-._~+/]+=*'), '[REDACTED_TOKEN]'),
    (re.compile(r'api[_-]?key["\s:=]+["\']?[a-zA-Z0-9\-]{16,}'),
     'api_key: [REDACTED]'),
    (re.compile(r'/home/[a-zA-Z0-9_]+/'), '/home/[USER]/'),
    (re.compile(r'/Users/[a-zA-Z0-9_]+/'), '/Users/[USER]/'),
    (re.compile(r'C:\\\\Users\\\\[a-zA-Z0-9_]+\\\\'),
     'C:\\\\Users\\\\[USER]\\\\'),
    (re.compile(r'C:\\Users\\[a-zA-Z0-9_]+\\'),
     'C:\\Users\\[USER]\\'),
]


def _sanitize(text: str) -> str:
    """Sanitize text by redacting sensitive patterns."""
    for pattern, replacement in _SENSITIVE_PATTERNS:
        text = pattern.sub(replacement, text)
    return text


def _sanitize_with_counts(text: str) -> tuple:
    """Sanitize text and return (sanitized_text, redaction_counts)."""
    counts = {}
    for pattern, replacement in _SENSITIVE_PATTERNS:
        matches = len(pattern.findall(text))
        if matches > 0:
            counts[replacement] = counts.get(replacement, 0) + matches
            text = pattern.sub(replacement, text)
    return text, counts


class TraceRecorder:
    """Records pipeline stages to structured files for reviewer audit."""

    def __init__(self, root_dir: str, task_id: str):
        self.dir = Path(root_dir) / task_id
        self.dir.mkdir(parents=True, exist_ok=True)
        self._step = 0
        self._manifest = []
        self._redaction_counts = {}

    def save(self, label: str, obj: Any, fmt: str = "json"):
        """Save a pipeline artifact to disk.

        Args:
            label: Descriptive name (e.g., 'safety_parsed', 'repair_graph')
            obj: Data to save (dict/list for json, string for txt)
            fmt: File format ('json' or 'txt')
        """
        name = f"{self._step:02d}_{label}.{fmt}"
        path = self.dir / name
        self._step += 1
        try:
            if fmt == "json":
                from ctr.utils.trace_serialization import (
                    serialize_trace_object, prune_empty_fields
                )
                cleaned = serialize_trace_object(obj)
                if cleaned is None:
                    cleaned = obj
                cleaned = prune_empty_fields(cleaned)
                if cleaned is None:
                    cleaned = {}
                text = json.dumps(cleaned, indent=2, default=str,
                                  ensure_ascii=False)
            else:
                text = str(obj)
            text, counts = _sanitize_with_counts(text)
            for k, v in counts.items():
                self._redaction_counts[k] = (
                    self._redaction_counts.get(k, 0) + v
                )
            path.write_text(text, encoding="utf-8")
            self._manifest.append({
                'step': self._step - 1, 'label': label,
                'file': name, 'format': fmt,
            })
        except Exception as e:
            logger.warning(f"[TraceRecorder] Failed to write {name}: {e}")

    def save_manifest(self):
        """Write manifest and sanitization report."""
        self.save("manifest", self._manifest)
        if self._redaction_counts:
            self.save("sanitization_report", {
                "total_redactions": sum(self._redaction_counts.values()),
                "by_pattern": self._redaction_counts,
            })

    @property
    def active(self):
        return True


class NullRecorder:
    """No-op recorder when artifact export is disabled."""

    def save(self, label, obj, fmt="json"):
        pass

    def save_manifest(self):
        pass

    @property
    def active(self):
        return False
