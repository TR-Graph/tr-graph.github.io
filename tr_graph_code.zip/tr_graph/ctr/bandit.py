"""
Contextual Bandit for Operator Selection (LinUCB).

Learns which repair operators to prioritize for different types of tasks
based on causal graph features and diagnosis context. Improves operator
selection efficiency over time while maintaining safe exploration.

Reference: Equations 16-20 in the TR-Graph formulations.
"""

import json
import logging
import os
from typing import List, Optional, Dict, Tuple

import numpy as np

from ctr.data_structures import CausalGraph, CausalEdge


# Operator index mapping (matches OperatorType enum order)
OPERATOR_NAMES = ["SUBSTITUTE", "CONSTRAIN", "DECOMPOSE", "RELAX", "REORDER", "RETARGET"]

# Context: 9 base + 5 defect type one-hot + 8 frame type one-hot = 22
CONTEXT_DIM = 22


class OperatorBandit:
    """
    LinUCB contextual bandit for repair operator selection.

    Observes a 9-dimensional context vector derived from the causal graph
    and diagnosis, then selects operator priorities that guide candidate
    generation. Updates its model after observing repair outcomes.

    Context features (Eq. 16):
        [|Z_causal|, |E_causal|, h_max, sigma(D), rho(G_T), beta(G_T),
         eta_obj, eta_per, eta_act]
    """

    def __init__(
        self,
        n_operators: int = 6,
        context_dim: int = CONTEXT_DIM,
        alpha_ucb: float = 1.0,
        hierarchy_prior: Optional[List[float]] = None
    ):
        self.n_operators = n_operators
        self.context_dim = context_dim
        self.alpha_ucb = alpha_ucb

        # Hierarchy prior from config (not hardcoded)
        self._hierarchy_prior = hierarchy_prior or [0.05, 0.03, 0.02, 0.01, 0.01, 0.02]

        # Learning curve history
        self.history: List[Dict] = []

        # Initialize LinUCB state
        self._init_state()

    def _init_state(self):
        """Initialize or reinitialize LinUCB parameters with hierarchy prior."""
        self.A = [np.eye(self.context_dim) for _ in range(self.n_operators)]
        self.b = [np.zeros(self.context_dim) for _ in range(self.n_operators)]
        self.theta = [np.zeros(self.context_dim) for _ in range(self.n_operators)]

        # Apply hierarchy-informed prior (ISO 12100 hierarchy of controls)
        for i, prior in enumerate(self._hierarchy_prior):
            if i < self.n_operators:
                self.b[i] = np.ones(self.context_dim) * prior

    def reset(self):
        """
        11F: Reset to cold-start state for clean experiments.

        Reinitializes A, b, theta with the hierarchy prior. This ensures
        each experiment starts from the same initial state, preventing
        cross-experiment contamination.
        """
        self._init_state()
        logging.info("[CTR] Bandit reset to cold-start state")

    def compute_context(self, graph: Optional[CausalGraph], diagnosis) -> np.ndarray:
        """
        Build the 9-dimensional context vector from graph and diagnosis (Eq. 16).

        Features:
            0: |Z_causal|  - Number of causal variables
            1: |E_causal|  - Number of causal edges
            2: h_max       - Max hazard severity
            3: sigma(D)    - Layer-based severity score
            4: rho(G_T)    - Graph density
            5: beta(G_T)   - Mean betweenness centrality of causal nodes
            6: eta_obj     - Whether objects are causal (binary)
            7: eta_per     - Whether recipient is causal (binary)
            8: eta_act     - Whether action is causal (binary)
        """
        causal_vars = getattr(diagnosis, 'causal_variables', []) or []
        causal_edges = getattr(diagnosis, 'causal_edges', []) or []

        # Binary indicators for causal variable types (C4: prefix-based for canonical names)
        object_prefixes = ('object.', 'resource.', 'container.', 'tool.')
        person_prefixes = ('recipient.', 'person.', 'beneficiary.')
        action_prefixes = ('action.', 'manner.', 'method.')

        causal_lower = [v.lower() for v in causal_vars if v is not None]
        eta_obj = 1.0 if any(v.startswith(p) for v in causal_lower for p in object_prefixes) else 0.0
        eta_per = 1.0 if any(v.startswith(p) for v in causal_lower for p in person_prefixes) else 0.0
        eta_act = 1.0 if any(v.startswith(p) for v in causal_lower for p in action_prefixes) else 0.0

        # Graph properties
        density = graph.density() if graph else 0.0

        centrality_values = []
        if graph:
            for var in causal_vars:
                if var in graph.nodes:
                    centrality_values.append(graph.betweenness_centrality(var))
        mean_centrality = float(np.mean(centrality_values)) if centrality_values else 0.0

        # Severity score (Eq. 29)
        severity = self._compute_severity(diagnosis)

        base_features = [
            len(causal_vars),
            len(causal_edges),
            getattr(diagnosis, 'max_hazard', 0.0),
            severity,
            density,
            mean_centrality,
            eta_obj,
            eta_per,
            eta_act
        ]

        # Defect type one-hot encoding (5 features)
        from ctr.data_structures import DefectType
        defect = getattr(diagnosis, 'defect_type', None)
        defect_features = [
            1.0 if defect == DefectType.PHYSICAL_SAFETY else 0.0,
            1.0 if defect == DefectType.NORMATIVE else 0.0,
            1.0 if defect == DefectType.CONTEXTUAL else 0.0,
            1.0 if defect == DefectType.AUTONOMY else 0.0,
            1.0 if defect == DefectType.FEASIBILITY else 0.0,
        ]

        # Frame type one-hot encoding (8 features)
        from ctr.data_structures import TaskFrame
        frame = getattr(diagnosis, '_frame_type', None)
        frame_features = [
            1.0 if frame == TaskFrame.TRANSFER else 0.0,
            1.0 if frame == TaskFrame.MANIPULATION else 0.0,
            1.0 if frame == TaskFrame.PLACEMENT else 0.0,
            1.0 if frame == TaskFrame.NAVIGATION else 0.0,
            1.0 if frame == TaskFrame.PREPARATION else 0.0,
            1.0 if frame == TaskFrame.MONITORING else 0.0,
            1.0 if frame == TaskFrame.STATE_CHANGE else 0.0,
            1.0 if frame == TaskFrame.GENERAL else 0.0,
        ]

        context = np.array(base_features + defect_features + frame_features)

        # Dimension safety check — pad or clip to exactly CONTEXT_DIM.
        # Protects against novel defect/frame types not in the one-hot encoding.
        if len(context) < self.context_dim:
            context = np.pad(context, (0, self.context_dim - len(context)))
        elif len(context) > self.context_dim:
            logging.warning(
                f"[CTR] Context vector truncated from {len(context)} to "
                f"{self.context_dim} dimensions"
            )
            context = context[:self.context_dim]

        # Normalize context features to comparable scales.
        # Counts (features 0-1) can be 0-20+, while density/centrality are 0-1.
        # One-hot features (5-22) are already 0/1.
        return self._normalize_context(context)

    def _normalize_context(self, context: np.ndarray) -> np.ndarray:
        """
        11D: Normalize context features so LinUCB doesn't overweight
        high-magnitude dimensions.

        Features 0-1 (counts) → divide by reasonable maximums.
        Features 2-3 (severity) → already 0-1.
        Features 4-5 (density, centrality) → already 0-1.
        Features 6-8 (binary) → already 0/1.
        Features 9-21 (one-hot) → already 0/1.
        """
        normalized = context.copy()
        # Normalize counts to 0-1 range
        if len(normalized) > 0:
            normalized[0] = min(normalized[0] / 10.0, 1.0)  # |Z_causal| / 10
        if len(normalized) > 1:
            normalized[1] = min(normalized[1] / 15.0, 1.0)  # |E_causal| / 15
        # Clip all values to reasonable range
        np.clip(normalized, 0.0, 1.0, out=normalized)
        return normalized

    def _compute_severity(self, diagnosis) -> float:
        """Compute layer-based severity score sigma(D) (Eq. 29)."""
        layer_results = getattr(diagnosis, 'layer_results', {})
        if not layer_results:
            return 0.0

        score = 0.0
        for layer_name, weight in [('individual', 0.4), ('organizational', 0.3), ('societal', 0.3)]:
            layer_eval = layer_results.get(layer_name)
            if layer_eval and hasattr(layer_eval, 'decision'):
                from ctr.safety_evaluation import LayerDecision
                if layer_eval.decision == LayerDecision.FORBIDDEN:
                    score += weight
        return score

    def select(self, context: np.ndarray) -> np.ndarray:
        """
        Compute UCB scores and return operator priority distribution (Eq. 19-20).

        Returns:
            Array of probabilities summing to 1, one per operator.
        """
        ucb_scores = np.zeros(self.n_operators)
        for i in range(self.n_operators):
            A_inv = np.linalg.inv(self.A[i])
            self.theta[i] = A_inv @ self.b[i]

            exploitation = self.theta[i] @ context
            exploration = self.alpha_ucb * np.sqrt(context @ A_inv @ context)
            ucb_scores[i] = exploitation + exploration

        # Convert to probabilities (only positive scores)
        positive_scores = np.maximum(ucb_scores, 0.0)
        if positive_scores.sum() == 0:
            return np.ones(self.n_operators) / self.n_operators
        return positive_scores / positive_scores.sum()

    def allocate(self, priorities: np.ndarray, n_candidates: int = 5, top_k: int = 0) -> List[int]:
        """
        Convert probability distribution to integer slot allocation.

        11E: If top_k > 0, only the top k operators receive allocation.
        This concentrates exploration on the most promising operators.

        Args:
            priorities: Probability distribution over operators.
            n_candidates: Total number of candidates to generate.
            top_k: If > 0, only allocate to top k operators. 0 = all.

        Returns:
            List of integers summing to n_candidates.
        """
        effective_priorities = priorities.copy()

        # Zero out non-top-k operators
        if top_k > 0 and top_k < self.n_operators:
            top_indices = set(np.argsort(effective_priorities)[::-1][:top_k])
            for i in range(self.n_operators):
                if i not in top_indices:
                    effective_priorities[i] = 0.0
            # Re-normalize
            total = effective_priorities.sum()
            if total > 0:
                effective_priorities /= total
            else:
                effective_priorities = np.ones(self.n_operators) / self.n_operators

        raw = effective_priorities * n_candidates
        allocation = np.floor(raw).astype(int)

        # Distribute remaining slots to highest fractional parts
        remainder = n_candidates - allocation.sum()
        fractional = raw - allocation
        top_indices = np.argsort(fractional)[::-1][:int(remainder)]
        for idx in top_indices:
            allocation[idx] += 1

        return allocation.tolist()

    def update(self, context: np.ndarray, operator_indices: List[int], reward: float):
        """
        Update LinUCB parameters after observing reward.

        Args:
            context: The context vector used for selection.
            operator_indices: Indices of operators that were used.
            reward: The observed reward signal.
        """
        for i in operator_indices:
            if 0 <= i < self.n_operators:
                self.A[i] += np.outer(context, context)
                self.b[i] += reward * context
                self.theta[i] = np.linalg.inv(self.A[i]) @ self.b[i]

        # Record episode in learning history
        priorities = self.select(context)
        allocation = self.allocate(priorities)
        entropy = float(-np.sum(priorities * np.log(priorities + 1e-10)))
        cumulative = sum(h['reward'] for h in self.history) + reward

        self.history.append({
            'episode': len(self.history),
            'reward': reward,
            'cumulative_reward': cumulative,
            'winning_operators': operator_indices,
            'allocation_entropy': entropy,
        })

    def compute_reward(
        self,
        n_total: int,
        n_safe: int,
        n_valid: int,
        best_quality: float = 0.5,
        best_rubric_level: int = None,
        w_safe: float = 0.3,
        w_valid: float = 0.3,
        w_quality: float = 0.4
    ) -> float:
        """
        Compute reward signal from repair episode outcomes (Eq. 18).

        Args:
            n_total: Total candidates generated.
            n_safe: Candidates that passed safety re-evaluation.
            n_valid: Candidates that passed full validation.
            best_quality: Quality signal in [0, 1] from deterministic affinity.
            best_rubric_level: Rubric level (1-5).
            w_safe: Weight on safety pass rate.
            w_valid: Weight on full validation pass rate.
            w_quality: Weight on quality signal.

        Returns:
            Reward value in [0, 1].
        """
        safe_rate = n_safe / max(n_total, 1)
        valid_rate = n_valid / max(n_total, 1)

        # Use deterministic quality signal; fall back to rubric if legacy caller
        if best_rubric_level is not None and best_quality == 0.5:
            quality = (best_rubric_level - 1) / 4.0
        else:
            quality = best_quality

        return (
            w_safe * safe_rate +
            w_valid * valid_rate +
            w_quality * max(0.0, min(1.0, quality))
        )

    def save(self, path: str):
        """Serialize bandit state to disk."""
        os.makedirs(os.path.dirname(path) if os.path.dirname(path) else '.', exist_ok=True)
        state = {
            'A': [a.tolist() for a in self.A],
            'b': [b.tolist() for b in self.b],
            'n_operators': self.n_operators,
            'context_dim': self.context_dim,
            'alpha_ucb': self.alpha_ucb
        }
        with open(path, 'w') as f:
            json.dump(state, f)

    def load(self, path: str):
        """Deserialize bandit state from disk. Reinitializes if dimensions don't match."""
        with open(path, 'r') as f:
            state = json.load(f)

        saved_dim = state.get('context_dim', 0)
        if saved_dim != self.context_dim:
            logging.warning(
                f"[CTR] Bandit state dimension mismatch: saved={saved_dim}, "
                f"current={self.context_dim}. Starting fresh."
            )
            return  # Keep the freshly initialized state

        self.n_operators = state.get('n_operators', self.n_operators)
        self.alpha_ucb = state.get('alpha_ucb', self.alpha_ucb)
        self.A = [np.array(a) for a in state['A']]
        self.b = [np.array(b) for b in state['b']]
        self.theta = [np.linalg.inv(a) @ b for a, b in zip(self.A, self.b)]

    def get_learning_curves(self) -> Dict:
        """
        B2: Return learning curve data for paper plots.

        Returns:
            Dict with rewards, cumulative_rewards, allocation_entropy,
            and operator_win_rates — ready for matplotlib.
        """
        if not self.history:
            return {'rewards': [], 'cumulative_rewards': [], 'allocation_entropy': [], 'operator_win_rates': {}}

        # Compute operator win rates
        win_counts = {i: 0 for i in range(self.n_operators)}
        for h in self.history:
            for op_idx in h.get('winning_operators', []):
                if op_idx in win_counts:
                    win_counts[op_idx] += 1
        total_episodes = len(self.history)
        win_rates = {
            OPERATOR_NAMES[i]: win_counts[i] / max(total_episodes, 1)
            for i in range(self.n_operators)
        }

        return {
            'rewards': [h['reward'] for h in self.history],
            'cumulative_rewards': [h['cumulative_reward'] for h in self.history],
            'allocation_entropy': [h['allocation_entropy'] for h in self.history],
            'operator_win_rates': win_rates,
        }

    def get_priority_summary(self, priorities: np.ndarray, allocation: List[int]) -> str:
        """Format operator priorities as a human-readable summary."""
        indexed = sorted(enumerate(priorities), key=lambda x: x[1], reverse=True)
        lines = []
        for rank, (idx, prob) in enumerate(indexed):
            if allocation[idx] > 0:
                level = "high" if prob > 0.3 else "medium" if prob > 0.15 else "low"
                lines.append(
                    f"  {rank+1}. {OPERATOR_NAMES[idx]} "
                    f"(priority: {level} — {allocation[idx]} of {sum(allocation)} candidates)"
                )
        return "\n".join(lines)
