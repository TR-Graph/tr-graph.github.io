"""
TR-Graph Task Repair: Plan Linter
=======================================

Lightweight deterministic validator for robot action sequences.
Checks that every action is a supported skill, every object exists
in the scene, and physical constraints (one-object holding) are respected.

This module has ZERO dependencies on LLM, prompts, or pipeline.
It is pure deterministic validation, fully unit-testable in isolation.

Replaces the invariant module's descriptive-but-unenforced constraints
with actual enforcement at zero LLM cost.
"""

import re
import logging
from typing import List, Tuple, Optional, Set, Dict


# Canonical AI2-THOR action primitives (default)
VALID_ACTIONS: Set[str] = {
    'GoToObject',
    'PickupObject',
    'PutObject',
    'OpenObject',
    'CloseObject',
    'ToggleObjectOn',
    'ToggleObjectOff',
    'SliceObject',
    'BreakObject',
    'ThrowObject',
    'PushObject',
    'PullObject',
    'DropHandObject',
}

# Per-robot-mode valid action sets
_ROBOT_VALID_ACTIONS: Dict[str, Set[str]] = {
    'ai2thor': VALID_ACTIONS,
    'safeagentbench': {
        'find', 'pick', 'put', 'open', 'close', 'turn_on', 'turn_off',
        'slice', 'break', 'throw', 'drop', 'cook', 'dirty', 'clean',
        'pour', 'fillLiquid', 'emptyLiquid',
    },
    'franka': {'move_to', 'pick', 'place', 'push', 'open_gripper'},
    'spot': {'navigate', 'pick', 'place', 'inspect', 'open_door', 'sit', 'stand'},
}

# Actions that cause the robot to hold an object (per mode)
PICKUP_ACTIONS = {'PickupObject', 'pick'}

# Actions that release the held object (per mode)
RELEASE_ACTIONS = {'PutObject', 'DropHandObject', 'ThrowObject', 'place', 'open_gripper', 'drop', 'throw'}


def get_valid_actions(robot_mode: str = 'ai2thor') -> Set[str]:
    """Get the valid action set for a robot mode."""
    return _ROBOT_VALID_ACTIONS.get(robot_mode, VALID_ACTIONS)


def extract_action_name(action_line: str) -> Optional[str]:
    """Extract the action name from an action line.

    'GoToObject(robot1, \\'Apple\\')' -> 'GoToObject'
    """
    match = re.match(r'(\w+)\s*\(', action_line.strip())
    return match.group(1) if match else None


def extract_object_args(action_line: str) -> List[str]:
    """Extract quoted object names from an action line.

    "PutObject(robot1, 'Apple', 'CounterTop')" -> ['Apple', 'CounterTop']
    """
    return re.findall(r"'([^']+)'", action_line)


def lint_action_sequence(
    action_sequence: List[str],
    scene_entity_labels: Set[str],
    robot_skills: Set[str] = None
) -> Tuple[bool, List[str]]:
    """
    Validate an action sequence against hard constraints.

    Returns (is_valid, list_of_errors).
    Errors are human-readable strings suitable for logging and feedback.

    Checks:
        1. Skill validity — every action must be in VALID_ACTIONS
        2. Entity validity — every object arg must be in scene
        3. Holding constraint — robot can hold only one object at a time
        4. Required skills — if provided, must be subset of VALID_ACTIONS
        5. Non-empty — sequence must contain at least one action
    """
    errors = []
    skills = robot_skills or VALID_ACTIONS

    # Check 5: Non-empty sequence
    if not action_sequence:
        errors.append("Empty action sequence — repair does nothing")
        return False, errors

    # Walk through the sequence
    held_object: Optional[str] = None

    for i, action_line in enumerate(action_sequence):
        step = i + 1
        action_name = extract_action_name(action_line)
        object_args = extract_object_args(action_line)

        # Check 1: Skill validity
        if action_name is None:
            errors.append(f"Step {step}: Cannot parse action from '{action_line}'")
            continue

        if action_name not in skills:
            errors.append(
                f"Step {step}: Unsupported action '{action_name}'. "
                f"Must be one of: {', '.join(sorted(skills))}"
            )

        # Check 2: Entity validity
        # Skip 'robot1' — it's the robot identifier, not a scene entity
        for obj in object_args:
            if obj == 'robot1':
                continue
            if obj not in scene_entity_labels:
                errors.append(
                    f"Step {step}: Object '{obj}' not in scene. "
                    f"Available: {', '.join(sorted(list(scene_entity_labels)[:10]))}"
                )

        # Check 3: Holding constraint
        if action_name in PICKUP_ACTIONS:
            if held_object is not None:
                errors.append(
                    f"Step {step}: Cannot pick up '{object_args[0] if object_args else '?'}' "
                    f"while already holding '{held_object}'. "
                    f"Must PutObject or DropHandObject first."
                )
            else:
                held_object = object_args[0] if object_args else 'unknown'

        elif action_name in RELEASE_ACTIONS:
            held_object = None

    return (len(errors) == 0, errors)

