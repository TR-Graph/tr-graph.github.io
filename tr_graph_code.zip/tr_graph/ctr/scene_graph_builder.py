"""
Scene graph builder — domain-agnostic construction over the paper's
typed relation schema.

The builder defines HOW edges are constructed (the loop, the validation,
the enrichment). Domain adapters define WHAT counts as a surface, container,
hazardous object, etc.
"""

import math
import logging
from typing import List, Dict, Any, Optional
from ctr.data_structures import (
    SceneGraph, SceneNode, SceneEdge, NodeType, RelationType,
    ObjectProperties, AgentProperties, RegionProperties,
)
from ctr.scene_domain_adapter import SceneDomainAdapter

logger = logging.getLogger(__name__)


class SceneGraphBuilder:
    """Builds typed scene graphs using a domain adapter.

    Usage:
        builder = SceneGraphBuilder(adapter=AI2ThorSceneAdapter())
        scene = builder.build(metadata, floor_plan=1)
    """

    def __init__(self, adapter: SceneDomainAdapter):
        self.adapter = adapter

    def build_from_metadata(
        self,
        metadata: Dict[str, Any],
        floor_plan: int = 0,
    ) -> SceneGraph:
        """Build from rich source metadata (AI2-THOR, depth camera, etc.).

        Expects metadata with 'objects' list containing per-instance data
        (position, parentReceptacles, etc.) and optional 'agent' dict.
        """
        scene = SceneGraph()
        objects = metadata.get('objects', [])
        agent = metadata.get('agent')

        # Region node
        region_type = self.adapter.infer_region(floor_plan)
        if region_type:
            scene.nodes['region_0'] = SceneNode(
                id='region_0', type=NodeType.REGION,
                label=region_type.replace('_', ' ').title(),
                properties=RegionProperties(region_type=region_type, accessible=True),
            )

        # Robot agent node
        if agent:
            scene.nodes['robot'] = SceneNode(
                id='robot', type=NodeType.AGENT, label='Robot',
                properties=AgentProperties(
                    reach_distance=agent.get('reach_distance', 1.5)),
            )

        # Index objects by ID for receptacle lookups
        obj_by_id = {obj['objectId']: obj for obj in objects}
        node_id_map = {}  # objectId -> scene node id

        # Build object nodes via adapter
        for i, obj in enumerate(objects):
            node_id = f"obj_{i}"
            node_id_map[obj['objectId']] = node_id

            props = self.adapter.infer_object_properties(
                obj['objectType'], obj
            )

            scene.nodes[node_id] = SceneNode(
                id=node_id, type=NodeType.OBJECT,
                label=obj['objectType'], properties=props,
                position=(
                    obj['position']['x'],
                    obj['position']['y'],
                    obj['position']['z'],
                ) if obj.get('position') else None,
            )

        # --- Derive edges ---
        source = self.adapter.get_source_label()

        for obj in objects:
            src_id = node_id_map[obj['objectId']]

            # LOCATED_IN -> region
            if 'region_0' in scene.nodes:
                scene.edges.append(SceneEdge(
                    source_id=src_id, target_id='region_0',
                    relation=RelationType.LOCATED_IN,
                    confidence=1.0,
                    metadata={"source": source},
                ))

            # ON / INSIDE from parentReceptacles (via adapter classification)
            for parent_id in obj.get('parentReceptacles') or []:
                parent_obj = obj_by_id.get(parent_id)
                if not parent_obj:
                    continue
                parent_node_id = node_id_map.get(parent_id)
                if not parent_node_id:
                    continue

                receptacle_class = self.adapter.classify_receptacle(
                    parent_obj['objectType']
                )

                if receptacle_class == "surface":
                    scene.edges.append(SceneEdge(
                        source_id=src_id, target_id=parent_node_id,
                        relation=RelationType.ON,
                        confidence=1.0,
                        metadata={"source": source,
                                  "evidence": f"parentReceptacles includes {parent_obj['objectType']}"},
                    ))
                elif receptacle_class == "container":
                    scene.edges.append(SceneEdge(
                        source_id=src_id, target_id=parent_node_id,
                        relation=RelationType.INSIDE,
                        confidence=1.0,
                        metadata={"source": source,
                                  "evidence": f"parentReceptacles includes {parent_obj['objectType']}"},
                    ))
                    scene.edges.append(SceneEdge(
                        source_id=parent_node_id, target_id=src_id,
                        relation=RelationType.CONTAINS,
                        confidence=1.0,
                        metadata={"source": source, "evidence": "inverse of INSIDE"},
                    ))

            # HOLDING
            if obj.get('isPickedUp') and 'robot' in scene.nodes:
                scene.edges.append(SceneEdge(
                    source_id='robot', target_id=src_id,
                    relation=RelationType.HOLDING,
                    confidence=1.0,
                    metadata={"source": source, "evidence": "isPickedUp=True"},
                ))

            # REACHABLE_BY (via adapter)
            is_reach, conf, evidence = self.adapter.infer_reachability(
                obj, agent
            )
            if is_reach and 'robot' in scene.nodes:
                scene.edges.append(SceneEdge(
                    source_id=src_id, target_id='robot',
                    relation=RelationType.REACHABLE_BY,
                    confidence=conf,
                    metadata={"source": source, "evidence": evidence},
                ))

        # NEAR from positions
        threshold = self.adapter.get_near_threshold()
        obj_list = [(node_id_map[o['objectId']], o) for o in objects
                     if o.get('position')]
        for i, (id_a, obj_a) in enumerate(obj_list):
            for j, (id_b, obj_b) in enumerate(obj_list):
                if j <= i:
                    continue
                dist = _position_distance(obj_a['position'], obj_b['position'])
                if dist < threshold:
                    scene.edges.append(SceneEdge(
                        source_id=id_a, target_id=id_b,
                        relation=RelationType.NEAR,
                        confidence=max(0.5, 1.0 - dist / threshold),
                        metadata={"source": source,
                                  "evidence": f"position distance={dist:.2f}m"},
                    ))

        logger.info(
            f"[SceneGraphBuilder] {source} graph: "
            f"{len(scene.nodes)} nodes, {len(scene.edges)} edges "
            f"({_edge_type_summary(scene)})"
        )
        return scene

    def build_from_object_list(
        self,
        object_names: List[str],
        floor_plan: int = 0,
        task: str = "",
    ) -> SceneGraph:
        """Build from a flat object list (no spatial data available).

        NEAR edges are created only between task-relevant objects
        (not all pairs) to avoid O(n^2) low-value edges.
        """
        scene = SceneGraph()
        source = self.adapter.get_source_label()

        # Region
        region_type = self.adapter.infer_region(floor_plan)
        if region_type:
            scene.nodes['region_0'] = SceneNode(
                id='region_0', type=NodeType.REGION,
                label=region_type.replace('_', ' ').title(),
                properties=RegionProperties(region_type=region_type, accessible=True),
            )

        # Robot — use adapter-specific properties if available
        agent_props = (self.adapter.get_agent_properties()
                       if hasattr(self.adapter, 'get_agent_properties')
                       else AgentProperties())
        scene.nodes['robot'] = SceneNode(
            id='robot', type=NodeType.AGENT, label='Robot',
            properties=agent_props,
        )

        # Build nodes via adapter
        for i, obj_name in enumerate(object_names):
            node_id = f"obj_{i}"

            if self.adapter.is_person(obj_name):
                props = self.adapter.infer_person_properties(obj_name)
                scene.nodes[node_id] = SceneNode(
                    id=node_id, type=NodeType.PERSON,
                    label=obj_name, properties=props,
                )
            else:
                props = self.adapter.infer_object_properties(obj_name, {})
                scene.nodes[node_id] = SceneNode(
                    id=node_id, type=NodeType.OBJECT,
                    label=obj_name, properties=props,
                )

        # --- Edges ---
        entity_ids = [
            nid for nid, n in scene.nodes.items()
            if n.type in (NodeType.OBJECT, NodeType.PERSON)
        ]

        for nid in entity_ids:
            # LOCATED_IN
            if 'region_0' in scene.nodes:
                scene.edges.append(SceneEdge(
                    source_id=nid, target_id='region_0',
                    relation=RelationType.LOCATED_IN,
                    confidence=1.0,
                    metadata={"source": source},
                ))

            # REACHABLE_BY (via adapter)
            if scene.nodes[nid].type == NodeType.OBJECT:
                obj_info = {'label': scene.nodes[nid].label, 'objectType': scene.nodes[nid].label}
                is_reach, conf, evidence = self.adapter.infer_reachability(obj_info, None)
                if is_reach:
                    scene.edges.append(SceneEdge(
                        source_id=nid, target_id='robot',
                        relation=RelationType.REACHABLE_BY,
                        confidence=conf,
                        metadata={"source": source, "evidence": evidence},
                    ))

        # NEAR: not generated for flat object lists (no spatial evidence).
        # NEAR edges come from VLM perception (visual evidence) or
        # AI2-THOR metadata (position distances). Without either,
        # claiming objects are "near" each other is unsupported.

        logger.info(
            f"[SceneGraphBuilder] {source} object-list graph: "
            f"{len(scene.nodes)} nodes, {len(scene.edges)} edges "
            f"({_edge_type_summary(scene)})"
        )
        return scene


def enrich_scene_graph(scene: SceneGraph, robot_mode: str = None) -> SceneGraph:
    """Validate and enrich a scene graph.

    Wrapper that calls validate_and_enrich_scene_graph.
    """
    return validate_and_enrich_scene_graph(scene, robot_mode=robot_mode)


def validate_and_enrich_scene_graph(scene: SceneGraph, robot_mode: str = None) -> SceneGraph:
    """Schema-first validation and structural enrichment of a scene graph.

    Validation (structural integrity):
      1. Ensure all edge endpoints exist as nodes (node closure)
      2. Create missing surface nodes referenced by ON edges
      3. Drop edges with invalid relation types
      4. Normalize relation names

    Enrichment (structural completeness):
      5. Ensure region node exists
      6. Ensure robot node exists (with correct properties per robot_mode)
      7. Add LOCATED_IN for objects/persons without a location edge
      8. Add REACHABLE_BY for objects not inside closed containers

    Does NOT invent relations (no near, on, inside, contains).
    Only evidence-backed edges from VLM/metadata survive.
    """
    # --- VALIDATION ---

    # . Node closure: create missing surface nodes referenced by ON edges
    all_node_ids = set(scene.nodes.keys())
    for edge in list(scene.edges):
        if edge.relation == RelationType.ON and edge.target_id not in all_node_ids:
            # ON edge references a surface node that doesn't exist — create it
            surface_id = edge.target_id
            surface_label = surface_id.replace('_', ' ').title()
            scene.nodes[surface_id] = SceneNode(
                id=surface_id, type=NodeType.SURFACE,
                label=surface_label,
                properties=ObjectProperties(),
            )
            all_node_ids.add(surface_id)
            logger.info(f"[validate] Created missing surface node: {surface_id} ({surface_label})")

    # . Drop edges with endpoints that don't exist (after surface node creation)
    valid_edges = []
    for edge in scene.edges:
        if edge.source_id in all_node_ids and edge.target_id in all_node_ids:
            valid_edges.append(edge)
        else:
            logger.debug(f"[validate] Dropped edge with missing endpoint: "
                         f"{edge.source_id} -> {edge.target_id} ({edge.relation})")
    scene.edges = valid_edges

    # . Drop edges with invalid relation types
    valid_relations = set(RelationType)
    scene.edges = [e for e in scene.edges if e.relation in valid_relations]

    # --- ENRICHMENT ---

    # . Ensure region node exists
    region_nodes = [n for n in scene.nodes.values() if n.type == NodeType.REGION]
    if not region_nodes:
        scene.nodes['region_0'] = SceneNode(
            id='region_0', type=NodeType.REGION,
            label='Scene',
            properties=RegionProperties(region_type='scene', accessible=True),
        )
        region_nodes = [scene.nodes['region_0']]

    # . Ensure robot node exists with correct properties
    robot_nodes = [n for n in scene.nodes.values() if n.type == NodeType.AGENT]
    if not robot_nodes:
        if robot_mode == 'franka':
            agent_props = AgentProperties(reach_distance=0.855, gripper_capacity=3.0)
        elif robot_mode == 'spot':
            agent_props = AgentProperties(reach_distance=1.2, gripper_capacity=5.0)
        else:
            agent_props = AgentProperties()
        scene.nodes['robot'] = SceneNode(
            id='robot', type=NodeType.AGENT,
            label='Robot',
            properties=agent_props,
        )
        robot_nodes = [scene.nodes['robot']]

    # . Add LOCATED_IN for objects/persons/surfaces without a location edge
    region_id = region_nodes[0].id
    located = {e.source_id for e in scene.edges if e.relation == RelationType.LOCATED_IN}
    for nid, node in scene.nodes.items():
        if node.type in (NodeType.OBJECT, NodeType.PERSON, NodeType.SURFACE) and nid not in located:
            scene.edges.append(SceneEdge(
                source_id=nid, target_id=region_id,
                relation=RelationType.LOCATED_IN,
                confidence=0.9,
                metadata={"source": "enrichment"},
            ))

    # . Add REACHABLE_BY for manipulable objects (not surfaces, not inside containers)
    robot_id = robot_nodes[0].id
    reachable = {e.source_id for e in scene.edges if e.relation == RelationType.REACHABLE_BY}
    inside = {e.source_id for e in scene.edges if e.relation == RelationType.INSIDE}
    for nid, node in scene.nodes.items():
        if node.type == NodeType.OBJECT and nid not in reachable and nid not in inside:
            scene.edges.append(SceneEdge(
                source_id=nid, target_id=robot_id,
                relation=RelationType.REACHABLE_BY,
                confidence=0.7,
                metadata={"source": "enrichment"},
            ))

    return scene


def _position_distance(pos_a: Dict, pos_b: Dict) -> float:
    return math.sqrt(
        (pos_a['x'] - pos_b['x']) ** 2 +
        (pos_a['y'] - pos_b['y']) ** 2 +
        (pos_a['z'] - pos_b['z']) ** 2
    )


def _edge_type_summary(scene: SceneGraph) -> str:
    from collections import Counter
    counts = Counter(e.relation.value for e in scene.edges)
    return ", ".join(f"{v}x{k}" for k, v in counts.most_common())
