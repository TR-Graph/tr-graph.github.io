"""
TR-Graph Task Repair

A graph-structured framework for transforming defective task commands into safe,
executable alternatives that maintain fidelity to the original command.
Uses six repair operators: SUBSTITUTE, CONSTRAIN, DECOMPOSE, RELAX, REORDER, RETARGET.

Usage:
    from ctr import CTRPipeline, CTRConfig

    config = CTRConfig()
    pipeline = CTRPipeline(llm_client, config)
    result = pipeline.run("Pour hot coffee for the baby")
"""

__version__ = "0.1.0"
__author__ = "Anonymous"

# Core data structures
from ctr.data_structures import (
    TaskVariables,
    SceneGraph,
    SceneNode,
    RepairCandidate,
    RepairOption,
    MultiOptionExplanation,
    CTRPipelineResult,
    ObjectReference,
    TaskConstraint,
    Subgoal,
    CausalEdge,
    CausalGraph,
    GroundingOutcome,
    GroundingResult,
    TaskFrame,
    DefectType,
    HazardType,
)

# Contextual bandit
from ctr.bandit import OperatorBandit

# Pipeline
from ctr.pipeline import CTRPipeline, CTRConfig, PipelineResult

# Operators
from ctr.operators import (
    RepairOperators,
    OperatorType,
    OperatorResult,
)

# Safety evaluation
from ctr.safety_evaluation import SafePlanEvaluator, AlignmentResult

# Affinity and cost functions
from ctr.affinity import compute_deterministic_affinity
from ctr.cost import CostConfig, CostWeights

# LLM client
from ctr.llm_client import (
    MultiLLMClient,
    OpenAIClient,
    AnthropicClient,
    GeminiClient,
    Provider,
)

# Baseline and Judge
from ctr.baseline import BaselineLLMRepair, BaselineRepairResult

# Web Interface (optional - requires flask)
try:
    from ctr.interface import app as web_app, create_app
    from ctr.interface.app import run_server
    _has_web_interface = True
except ImportError:
    web_app = None
    create_app = None
    run_server = None
    _has_web_interface = False

# Simulation (AI2-THOR integration)
from ctr.simulation import (
    TaskExecutor,
    ExecutionResult,
    CodeGenerator,
    AI2THORActionExecutor,
)

__all__ = [
    # Version info
    "__version__",
    "__author__",
    # Data structures
    "TaskVariables",
    "SceneGraph",
    "SceneNode",
    "RepairCandidate",
    "RepairOption",
    "MultiOptionExplanation",
    "CTRPipelineResult",
    "ObjectReference",
    "TaskConstraint",
    "Subgoal",
    "CausalEdge",
    "CausalGraph",
    "GroundingOutcome",
    "GroundingResult",
    "TaskFrame",
    "DefectType",
    "HazardType",
    "OperatorBandit",
    # Configuration & Pipeline
    "CTRConfig",
    "CTRPipeline",
    "PipelineResult",
    # Operators
    "RepairOperators",
    "OperatorType",
    "OperatorResult",
    # Safety
    "SafePlanEvaluator",
    "AlignmentResult",
    # Scoring
    "CostConfig",
    "CostWeights",
    # LLM
    "MultiLLMClient",
    "OpenAIClient",
    "AnthropicClient",
    "GeminiClient",
    "Provider",
    # Simulation
    "TaskExecutor",
    "ExecutionResult",
    "CodeGenerator",
    "AI2THORActionExecutor",
    # Baseline and Judge
    "BaselineLLMRepair",
    "BaselineRepairResult",
    # Web Interface
    "web_app",
    "create_app",
    "run_server",
]
